#include "mex.h"
#include <cmath>
#include "distance.cpp" // Distance file

void mexFunction( int nlhs, mxArray *plhs[],  // Out
	int nrhs, const mxArray  *prhs[] ) // In
{
	if((nrhs!=3)||(nlhs!=1))
    {
        mexErrMsgTxt("\nUsage:\n[distance] = distanceNClusters(RGB1, RGB2, n);\n - RGB1 a row vector\n - RGB2 a row vector\n - n the number of clusters\n - returns the distance between the two RGBs using the metric learned with n clusters\n");
        return;
    }

	double *rgb1 = mxGetPr(prhs[0]);
	double *rgb2 = mxGetPr(prhs[1]);
	int nbClusters = (int) mxGetScalar(prhs[2]);
	plhs[0] =  mxCreateDoubleScalar(distanceClusters(rgb1,rgb2,nbClusters));
}