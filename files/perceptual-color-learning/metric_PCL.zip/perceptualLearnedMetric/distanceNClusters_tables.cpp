#include "mex.h"
#include <cmath>
#include "distance.cpp" // Distance file


#define _2D_to_linear(row, col, maxRow) ((col)*(maxRow)+(row))

void mexFunction( int nlhs, mxArray *plhs[],  // Out
	int nrhs, const mxArray  *prhs[] ) // In
{
	if((nrhs!=3)||(nlhs!=1))
    {
        mexErrMsgTxt("\nUsage:\n[distance] = distanceNClusters_tables(RGBs1, RGBs1, n);\n - RGBs1 a m*3 matrix of RGBs coordinates\n - RGBs2 a d*3 matrix of RGBs coordinates\n - n the number of clusters\n - returns a m*d matrix of distances");
        return;
    }

	double *vecteurs = mxGetPr(prhs[0]);
	int *tmpDimSizesVecteurs  = mxGetDimensions(prhs[0]);
	int numRowsVecteurs     = tmpDimSizesVecteurs[0];
    int numColsVecteurs     = tmpDimSizesVecteurs[1];
	
	double *centres = mxGetPr(prhs[1]);
	int *tmpDimSizesCentres  = mxGetDimensions(prhs[1]);
	int numRowsCentres     = tmpDimSizesCentres[0];
    int numColsCentres     = tmpDimSizesCentres[1];
	
	int nbClusters = (int) mxGetScalar(prhs[2]);

	plhs[0] =  mxCreateDoubleMatrix(numRowsVecteurs, numRowsCentres, mxREAL);
	double *toReturn = mxGetPr(plhs[0]);
	
	for(int i=0;i<numRowsVecteurs;i++){
		for(int j=0;j<numRowsCentres;j++){
			double rgb1[3] = {vecteurs[_2D_to_linear(i,0,numRowsVecteurs)],vecteurs[_2D_to_linear(i,1,numRowsVecteurs)],vecteurs[_2D_to_linear(i,2,numRowsVecteurs)]};
			double rgb2[3] = {centres[_2D_to_linear(j,0,numRowsCentres)],centres[_2D_to_linear(j,1,numRowsCentres)],centres[_2D_to_linear(j,2,numRowsCentres)]};
			toReturn[_2D_to_linear(i,j,numRowsVecteurs)] = distanceClusters(rgb1,rgb2,nbClusters);
		}
	}
}