double distance1clusters(double RGB1[3], double RGB2[3]);
double distance2clusters(double RGB1[3], double RGB2[3]);
double distance3clusters(double RGB1[3], double RGB2[3]);
double distance4clusters(double RGB1[3], double RGB2[3]);
double distance5clusters(double RGB1[3], double RGB2[3]);
double distance6clusters(double RGB1[3], double RGB2[3]);
double distance7clusters(double RGB1[3], double RGB2[3]);
double distance8clusters(double RGB1[3], double RGB2[3]);
double distance9clusters(double RGB1[3], double RGB2[3]);
double distance10clusters(double RGB1[3], double RGB2[3]);
double distance11clusters(double RGB1[3], double RGB2[3]);
double distance12clusters(double RGB1[3], double RGB2[3]);
double distance13clusters(double RGB1[3], double RGB2[3]);
double distance14clusters(double RGB1[3], double RGB2[3]);
double distance15clusters(double RGB1[3], double RGB2[3]);
double distance16clusters(double RGB1[3], double RGB2[3]);
double distance17clusters(double RGB1[3], double RGB2[3]);
double distance18clusters(double RGB1[3], double RGB2[3]);
double distance19clusters(double RGB1[3], double RGB2[3]);
double distance20clusters(double RGB1[3], double RGB2[3]);
double distance21clusters(double RGB1[3], double RGB2[3]);
double distance22clusters(double RGB1[3], double RGB2[3]);
double distance23clusters(double RGB1[3], double RGB2[3]);
double distance24clusters(double RGB1[3], double RGB2[3]);
double distance25clusters(double RGB1[3], double RGB2[3]);
double distance26clusters(double RGB1[3], double RGB2[3]);
double distance27clusters(double RGB1[3], double RGB2[3]);
double distance28clusters(double RGB1[3], double RGB2[3]);
double distance29clusters(double RGB1[3], double RGB2[3]);
double distance30clusters(double RGB1[3], double RGB2[3]);
double distance31clusters(double RGB1[3], double RGB2[3]);
double distance32clusters(double RGB1[3], double RGB2[3]);
double distance33clusters(double RGB1[3], double RGB2[3]);
double distance34clusters(double RGB1[3], double RGB2[3]);
double distance35clusters(double RGB1[3], double RGB2[3]);
double distance36clusters(double RGB1[3], double RGB2[3]);
double distance37clusters(double RGB1[3], double RGB2[3]);
double distance38clusters(double RGB1[3], double RGB2[3]);
double distance39clusters(double RGB1[3], double RGB2[3]);
double distance40clusters(double RGB1[3], double RGB2[3]);
double distance41clusters(double RGB1[3], double RGB2[3]);
double distance42clusters(double RGB1[3], double RGB2[3]);
double distance43clusters(double RGB1[3], double RGB2[3]);
double distance44clusters(double RGB1[3], double RGB2[3]);
double distance45clusters(double RGB1[3], double RGB2[3]);
double distance46clusters(double RGB1[3], double RGB2[3]);
double distance47clusters(double RGB1[3], double RGB2[3]);
double distance48clusters(double RGB1[3], double RGB2[3]);
double distance49clusters(double RGB1[3], double RGB2[3]);
double distance50clusters(double RGB1[3], double RGB2[3]);
double distance51clusters(double RGB1[3], double RGB2[3]);
double distance52clusters(double RGB1[3], double RGB2[3]);
double distance53clusters(double RGB1[3], double RGB2[3]);
double distance54clusters(double RGB1[3], double RGB2[3]);
double distance55clusters(double RGB1[3], double RGB2[3]);
double distance56clusters(double RGB1[3], double RGB2[3]);
double distance57clusters(double RGB1[3], double RGB2[3]);
double distance58clusters(double RGB1[3], double RGB2[3]);
double distance59clusters(double RGB1[3], double RGB2[3]);
double distance60clusters(double RGB1[3], double RGB2[3]);
double distance61clusters(double RGB1[3], double RGB2[3]);
double distance62clusters(double RGB1[3], double RGB2[3]);
double distance63clusters(double RGB1[3], double RGB2[3]);
double distance64clusters(double RGB1[3], double RGB2[3]);
double distance65clusters(double RGB1[3], double RGB2[3]);
double distance66clusters(double RGB1[3], double RGB2[3]);
double distance67clusters(double RGB1[3], double RGB2[3]);
double distance68clusters(double RGB1[3], double RGB2[3]);
double distance69clusters(double RGB1[3], double RGB2[3]);
double distance70clusters(double RGB1[3], double RGB2[3]);
double euclid(double RGB1[3], double RGB2[3]);

double distanceClusters(double RGB1[3], double RGB2[3], int clusters){
	switch (clusters){
		case 1:
			return distance1clusters(RGB1, RGB2);
		case 2:
			return distance2clusters(RGB1, RGB2);
		case 3:
			return distance3clusters(RGB1, RGB2);
		case 4:
			return distance4clusters(RGB1, RGB2);
		case 5:
			return distance5clusters(RGB1, RGB2);
		case 6:
			return distance6clusters(RGB1, RGB2);
		case 7:
			return distance7clusters(RGB1, RGB2);
		case 8:
			return distance8clusters(RGB1, RGB2);
		case 9:
			return distance9clusters(RGB1, RGB2);
		case 10:
			return distance10clusters(RGB1, RGB2);
		case 11:
			return distance11clusters(RGB1, RGB2);
		case 12:
			return distance12clusters(RGB1, RGB2);
		case 13:
			return distance13clusters(RGB1, RGB2);
		case 14:
			return distance14clusters(RGB1, RGB2);
		case 15:
			return distance15clusters(RGB1, RGB2);
		case 16:
			return distance16clusters(RGB1, RGB2);
		case 17:
			return distance17clusters(RGB1, RGB2);
		case 18:
			return distance18clusters(RGB1, RGB2);
		case 19:
			return distance19clusters(RGB1, RGB2);
		case 20:
			return distance20clusters(RGB1, RGB2);
		case 21:
			return distance21clusters(RGB1, RGB2);
		case 22:
			return distance22clusters(RGB1, RGB2);
		case 23:
			return distance23clusters(RGB1, RGB2);
		case 24:
			return distance24clusters(RGB1, RGB2);
		case 25:
			return distance25clusters(RGB1, RGB2);
		case 26:
			return distance26clusters(RGB1, RGB2);
		case 27:
			return distance27clusters(RGB1, RGB2);
		case 28:
			return distance28clusters(RGB1, RGB2);
		case 29:
			return distance29clusters(RGB1, RGB2);
		case 30:
			return distance30clusters(RGB1, RGB2);
		case 31:
			return distance31clusters(RGB1, RGB2);
		case 32:
			return distance32clusters(RGB1, RGB2);
		case 33:
			return distance33clusters(RGB1, RGB2);
		case 34:
			return distance34clusters(RGB1, RGB2);
		case 35:
			return distance35clusters(RGB1, RGB2);
		case 36:
			return distance36clusters(RGB1, RGB2);
		case 37:
			return distance37clusters(RGB1, RGB2);
		case 38:
			return distance38clusters(RGB1, RGB2);
		case 39:
			return distance39clusters(RGB1, RGB2);
		case 40:
			return distance40clusters(RGB1, RGB2);
		case 41:
			return distance41clusters(RGB1, RGB2);
		case 42:
			return distance42clusters(RGB1, RGB2);
		case 43:
			return distance43clusters(RGB1, RGB2);
		case 44:
			return distance44clusters(RGB1, RGB2);
		case 45:
			return distance45clusters(RGB1, RGB2);
		case 46:
			return distance46clusters(RGB1, RGB2);
		case 47:
			return distance47clusters(RGB1, RGB2);
		case 48:
			return distance48clusters(RGB1, RGB2);
		case 49:
			return distance49clusters(RGB1, RGB2);
		case 50:
			return distance50clusters(RGB1, RGB2);
		case 51:
			return distance51clusters(RGB1, RGB2);
		case 52:
			return distance52clusters(RGB1, RGB2);
		case 53:
			return distance53clusters(RGB1, RGB2);
		case 54:
			return distance54clusters(RGB1, RGB2);
		case 55:
			return distance55clusters(RGB1, RGB2);
		case 56:
			return distance56clusters(RGB1, RGB2);
		case 57:
			return distance57clusters(RGB1, RGB2);
		case 58:
			return distance58clusters(RGB1, RGB2);
		case 59:
			return distance59clusters(RGB1, RGB2);
		case 60:
			return distance60clusters(RGB1, RGB2);
		case 61:
			return distance61clusters(RGB1, RGB2);
		case 62:
			return distance62clusters(RGB1, RGB2);
		case 63:
			return distance63clusters(RGB1, RGB2);
		case 64:
			return distance64clusters(RGB1, RGB2);
		case 65:
			return distance65clusters(RGB1, RGB2);
		case 66:
			return distance66clusters(RGB1, RGB2);
		case 67:
			return distance67clusters(RGB1, RGB2);
		case 68:
			return distance68clusters(RGB1, RGB2);
		case 69:
			return distance69clusters(RGB1, RGB2);
		case 70:
			return distance70clusters(RGB1, RGB2);
		default:
			return sqrt(-1.0);
	}
}

double distance1clusters(double RGB1[3], double RGB2[3]){
	double matrix[1][3][3] =
	{
		{
			{0.030887382061325783, -0.02196361673200817, -0.00306808969416434},
			{-0.02196361673200816, 0.049375479186146196, -0.014877843672793399},
			{-0.0030680896941643375, -0.01487784367279341, 0.01753357500584031}
		}
	};

	double barycentre[1][3] =
	{
		{133.88285714285715, 141.44322751322753, 137.7730687830688}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<1;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<1;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		distance = distance1clusters(RGB1, RGB2);
	}
	return distance;
}

double euclid(double RGB1[3], double RGB2[3]){
	double d = 0;
	for(int i=0;i<3;i++){
		d += pow(RGB1[i]-RGB2[i],2);
	}
	return sqrt(d);
}
double distance2clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.020593550934632415, -0.015253336220031083, -0.003795785100939384},
		{-0.015253336220031083, 0.033061006383979574, -0.010203041952839395},
		{-0.003795785100939383, -0.010203041952839397, 0.014894373986062592}
	};

	double matrix[2][3][3] =
	{
		{
			{0.03315710013160056, -0.019388407539058572, -6.227046173102619E-4},
			{-0.01938840753905857, 0.043627085218543867, -0.010951345949892496},
			{-6.227046173102636E-4, -0.010951345949892496, 0.0153593073427972}
		},
		{
			{0.03015872253459097, -0.02309020469248027, -0.004302400498078108},
			{-0.023090204692480295, 0.05935519852959501, -0.020226766419300397},
			{-0.0043024004980781036, -0.020226766419300404, 0.0211328077506985}
		}
	};

	double barycentre[2][3] =
	{
		{134.62306900102988, 113.17107220505778, 82.87756036159743},
		{133.24623560673163, 165.75878358429287, 184.9861234130499}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<2;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<2;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance3clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026172036834883408, -0.018640819376657597, -0.004914306252228822},
		{-0.018640819376657597, 0.0380231638291807, -0.010675862404965306},
		{-0.004914306252228826, -0.010675862404965302, 0.013759720199097398}
	};

	double matrix[3][3][3] =
	{
		{
			{0.0298270825887833, -0.0237514384116195, -0.0035662562595798765},
			{-0.023751438411619478, 0.06198588181381226, -0.022790549596512392},
			{-0.0035662562595798774, -0.02279054959651239, 0.022657580849747103}
		},
		{
			{0.03138877192569329, -0.020455836583126306, -0.002070023269176942},
			{-0.020455836583126313, 0.0449228812908321, -0.011663107454952491},
			{-0.0020700232691769405, -0.011663107454952493, 0.016133855362371493}
		},
		{
			{0.03852920867183707, -0.011796004761325063, -0.0014573347038345451},
			{-0.011796004761325063, 0.05824225823577762, -0.006982991636448614},
			{-0.0014573347038345473, -0.006982991636448615, 0.015557671395362798}
		}
	};

	double barycentre[3][3] =
	{
		{122.16839157433337, 168.71581638865214, 193.80713502983076},
		{169.5, 139.50295937584073, 107.47027172450902},
		{82.06394097755917, 77.02090378112511, 65.5514909314479}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<3;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<3;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance4clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02935698531839354, -0.016289736774811506, -0.0055496726530093535},
		{-0.016289736774811506, 0.034020655951992475, -0.010542188993804102},
		{-0.0055496726530093535, -0.010542188993804106, 0.015152942662458401}
	};

	double matrix[4][3][3] =
	{
		{
			{0.030254752885371737, -0.01979801845067924, -5.858287590691357E-4},
			{-0.01979801845067924, 0.043139419059490945, -0.011542306799697206},
			{-5.858287590691383E-4, -0.01154230679969721, 0.015203755624660796}
		},
		{
			{0.022081452871192873, -0.021344362993359275, -1.155413525404038E-5},
			{-0.0213443629933593, 0.062071019835145916, -0.026895679026572597},
			{-1.1554135254035827E-5, -0.026895679026572597, 0.02471430634027078}
		},
		{
			{0.05092258541235671, -0.0342511456082172, -0.0061836819391078175},
			{-0.03425114560821721, 0.06064238033192906, -0.016108800947250694},
			{-0.006183681939107813, -0.016108800947250694, 0.019792711615690305}
		},
		{
			{0.04507553873377088, -0.012925278152268382, -0.001625511419372153},
			{-0.012925278152268396, 0.05690957296816929, -0.0035336476574162395},
			{-0.00162551141937215, -0.003533647657416236, 0.014899468021351609}
		}
	};

	double barycentre[4][3] =
	{
		{162.59594280013303, 134.69022281343533, 92.61922181576323},
		{102.89789438502673, 168.75501336898395, 191.92881016042782},
		{176.03659429129056, 159.20712368870457, 176.45986826055136},
		{76.7816625044595, 71.64823403496254, 62.464502318943985}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<4;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<4;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance5clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02451372240319421, -0.01699275215219621, -0.003959130787662634},
		{-0.016992752152196217, 0.03794188338883139, -0.011935916945149401},
		{-0.003959130787662634, -0.011935916945149392, 0.015393937041319208}
	};

	double matrix[5][3][3] =
	{
		{
			{0.04741258698104177, -0.029822834490055825, -0.005685867209343718},
			{-0.029822834490055825, 0.057073519809034585, -0.017852818708229815},
			{-0.0056858672093437175, -0.01785281870822981, 0.022119869492898493}
		},
		{
			{0.014272916869765104, -0.007260276758226564, -0.006371382212714707},
			{-0.007260276758226564, 0.039760406558039085, -0.019087486560812494},
			{-0.006371382212714707, -0.019087486560812494, 0.022337849740915114}
		},
		{
			{0.03690806341648527, -0.03323626354524266, -3.4792670554618563E-4},
			{-0.03323626354524268, 0.07632206964211037, -0.026963233797115106},
			{-3.4792670554618E-4, -0.026963233797115096, 0.025632697117376594}
		},
		{
			{0.03355385330589196, -0.023152375051411468, 0.0012933124480643565},
			{-0.023152375051411468, 0.04426839702684179, -0.00982223350283647},
			{0.001293312448064356, -0.00982223350283647, 0.012996169632361002}
		},
		{
			{0.05253968573295615, -0.015964887168731297, -0.006037469032145186},
			{-0.015964887168731297, 0.057290522732682224, 0.0018159031267306822},
			{-0.0060374690321451895, 0.0018159031267306787, 0.015644743991489303}
		}
	};

	double barycentre[5][3] =
	{
		{180.63793535454772, 150.66148834878476, 157.31696316712603},
		{95.17637540453075, 149.54180151024812, 148.1057173678533},
		{123.80575373993095, 179.21357882623707, 214.62853855005753},
		{166.60857848641365, 130.47316415899394, 79.78127105322254},
		{73.53391593841032, 65.67041198501873, 57.86766541822722}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<5;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<5;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance6clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029233354150074588, -0.019206395210148094, -0.004812426222754364},
		{-0.019206395210148105, 0.03399096187085773, -0.007880971981868429},
		{-0.004812426222754365, -0.00788097198186843, 0.012682296832377992}
	};

	double matrix[6][3][3] =
	{
		{
			{0.031275780431854534, -0.019157617006909117, 3.371232559124626E-4},
			{-0.019157617006909117, 0.039933112021692384, -0.007989637145013873},
			{3.3712325591245956E-4, -0.007989637145013873, 0.013413478001179}
		},
		{
			{0.05854638596942489, -0.018351424601996846, -0.009194385478987193},
			{-0.018351424601996857, 0.05908352165010204, 0.005975147362974215},
			{-0.009194385478987193, 0.00597514736297421, 0.017174003080326097}
		},
		{
			{0.03655978162264559, -0.024540506921685194, -2.9111894603371744E-4},
			{-0.024540506921685183, 0.057024448035372474, -0.018257245350734405},
			{-2.9111894603370964E-4, -0.0182572453507344, 0.0205892229425715}
		},
		{
			{0.052439276913780995, -0.03616945649946498, -0.006341610983010292},
			{-0.03616945649946495, 0.06256163299331498, -0.01700061523869549},
			{-0.006341610983010299, -0.017000615238695498, 0.022326593107720304}
		},
		{
			{0.029023882807796438, -0.02901665754232092, 0.002144871676166427},
			{-0.02901665754232094, 0.0744215485704586, -0.030114774488365803},
			{0.002144871676166424, -0.03011477448836581, 0.027040013632210307}
		},
		{
			{0.014051271725757588, -0.005821165525511362, -0.007460295925710065},
			{-0.005821165525511365, 0.038553685732941094, -0.01752712893669479},
			{-0.0074602959257100655, -0.017527128936694787, 0.02122196423982821}
		}
	};

	double barycentre[6][3] =
	{
		{156.49457215836526, 120.56002554278416, 65.00702426564496},
		{65.5748031496063, 60.98425196850393, 57.34153543307087},
		{179.45792666842522, 142.64072804009496, 122.43181218675811},
		{173.98189717595946, 165.62309920347573, 191.1220130340333},
		{110.87842926304465, 178.12587412587413, 213.21705217859065},
		{96.36017316017316, 147.55815295815296, 144.02077922077922}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<6;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<6;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance7clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03144278478827836, -0.02303713654078866, -0.0028266953231764515},
		{-0.023037136540788677, 0.03843019120119614, -0.010841335946802403},
		{-0.002826695323176447, -0.010841335946802396, 0.0142596254901861}
	};

	double matrix[7][3][3] =
	{
		{
			{0.031024018563635982, -0.030576924745355078, 0.0026513805462061914},
			{-0.030576924745355106, 0.07712088311522858, -0.030224318864902185},
			{0.0026513805462062006, -0.0302243188649022, 0.027670310917793997}
		},
		{
			{0.05837177795969663, -0.029202133683443113, -0.017718168453620415},
			{-0.029202133683443095, 0.07715366810487505, 0.009902545361408334},
			{-0.01771816845362041, 0.00990254536140834, 0.0234804583333449}
		},
		{
			{0.03471674834420749, -0.019278744739502692, -0.0010162646028320072},
			{-0.019278744739502692, 0.03856548409818921, -0.005009449947991001},
			{-0.0010162646028320055, -0.005009449947991004, 0.005401073354277568}
		},
		{
			{0.039308858900827075, -0.014163441224848678, -0.0013097338540683993},
			{-0.014163441224848678, 0.04781182484821122, -0.010174956149705101},
			{-0.0013097338540683993, -0.010174956149705107, 0.0167318269549789}
		},
		{
			{0.013871907382142301, -0.007853862903711168, -0.006044930362863882},
			{-0.007853862903711166, 0.041015254681814606, -0.018704557568788208},
			{-0.0060449303628638835, -0.0187045575687882, 0.021853287902230484}
		},
		{
			{0.028806595053193478, -0.02073010619633298, -0.0012260218167305984},
			{-0.020730106196332986, 0.06054767596960115, -0.022849015895399297},
			{-0.0012260218167305932, -0.0228490158953993, 0.025507894984418696}
		},
		{
			{0.05269751745496323, -0.031857159417406154, -0.008858990647432162},
			{-0.031857159417406154, 0.05131206845500914, -0.012067181774187906},
			{-0.008858990647432159, -0.012067181774187906, 0.02045350757091822}
		}
	};

	double barycentre[7][3] =
	{
		{116.12540476891375, 180.41036208419195, 217.69355313511923},
		{49.56629392971246, 45.805111821086264, 48.8370607028754},
		{187.5663198959688, 139.07672301690508, 54.1814044213264},
		{115.25048021513638, 101.65040338071456, 76.84940453323088},
		{92.85727002967359, 153.6940652818991, 155.9192878338279},
		{171.64635364635365, 139.1903096903097, 120.86588411588411},
		{177.33040935672514, 164.22222222222223, 186.58516081871346}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<7;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<7;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance8clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03469928050503799, -0.0260620619541759, -0.0016742115255025923},
		{-0.026062061954175895, 0.041613626119304616, -0.011570879951151705},
		{-0.0016742115255025944, -0.011570879951151709, 0.01388975270557401}
	};

	double matrix[8][3][3] =
	{
		{
			{0.044939611855999234, -0.012317863931280414, -0.003189475653065692},
			{-0.012317863931280416, 0.04856883782349143, -0.009647413194110938},
			{-0.003189475653065696, -0.009647413194110933, 0.017097820550084297}
		},
		{
			{0.01735818981363152, -0.006994609033229293, -0.010351574034659895},
			{-0.006994609033229291, 0.02303442335987438, -0.005536820685475218},
			{-0.0103515740346599, -0.005536820685475221, 0.014386223464828396}
		},
		{
			{0.012778890987901293, -0.011073409853950994, -0.0017630329505464934},
			{-0.011073409853951005, 0.049628929030807956, -0.024889774885612014},
			{-0.0017630329505464917, -0.024889774885612004, 0.027110392002097593}
		},
		{
			{0.030454317288878943, -0.029949885594712334, 0.003225057685367268},
			{-0.029949885594712348, 0.07651465987969674, -0.030226038187299506},
			{0.0032250576853672707, -0.030226038187299513, 0.027542795086547514}
		},
		{
			{0.03756726765959831, -0.024082938075901006, 0.0017045162551807172},
			{-0.024082938075901, 0.04214647889128314, -0.006481981455463872},
			{0.0017045162551807165, -0.006481981455463874, 0.005744240886778719}
		},
		{
			{0.04569132638022369, -0.032807073200703196, -1.581083502513684E-4},
			{-0.03280707320070322, 0.06909195173750661, -0.02845105531809899},
			{-1.5810835025136492E-4, -0.028451055318098988, 0.0296999989859394}
		},
		{
			{0.055345539528489085, -0.03859740295590047, -0.005392726467347871},
			{-0.038597402955900494, 0.06387818694885357, -0.019002833395071406},
			{-0.0053927264673478735, -0.019002833395071396, 0.02528387774620991}
		},
		{
			{0.06498819019515531, -0.0346411409021171, -0.02426850732075181},
			{-0.034641140902117104, 0.06845823139416675, 0.019653437033462708},
			{-0.02426850732075181, 0.019653437033462715, 0.02965012389717191}
		}
	};

	double barycentre[8][3] =
	{
		{109.78718159408382, 95.90304026294166, 75.42851273623664},
		{140.35353535353536, 166.79614325068871, 116.91414141414141},
		{85.50037037037038, 151.0511111111111, 164.05814814814815},
		{115.55958711291836, 181.07006568658116, 217.94713794182044},
		{184.210989010989, 136.27967032967032, 58.47802197802198},
		{178.57100785340313, 127.89201570680628, 131.63579842931938},
		{176.45586406962286, 167.71031910484874, 192.93825113966017},
		{45.74773139745916, 42.010889292196005, 46.8929219600726}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<8;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<8;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance9clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03399105703509071, -0.026868105325936763, -0.0011116663953418416},
		{-0.026868105325936767, 0.046784322381735674, -0.0142425689083104},
		{-0.0011116663953418334, -0.0142425689083104, 0.014926302362610496}
	};

	double matrix[9][3][3] =
	{
		{
			{0.048559213072725024, -0.012263633333921007, -0.003857724349402683},
			{-0.01226363333392101, 0.04930791693024929, -0.004137887876694146},
			{-0.003857724349402685, -0.0041378878766941485, 0.013721218312145707}
		},
		{
			{0.028917560015791724, -0.02996036313422371, 0.003456549708480691},
			{-0.029960363134223695, 0.07683728415910085, -0.03166120964234452},
			{0.00345654970848068, -0.03166120964234453, 0.028117310421478803}
		},
		{
			{0.0570461549132808, -0.04587258736191664, -0.001672714036255337},
			{-0.045872587361916614, 0.07934832838014479, -0.025064412675985012},
			{-0.001672714036255339, -0.02506441267598501, 0.02755881838394762}
		},
		{
			{0.06650240046436563, -0.01547595182397069, -0.04337385599161726},
			{-0.015475951823970721, 0.08603991160942359, -0.01152805398136205},
			{-0.04337385599161726, -0.011528053981362054, 0.07014798445758127}
		},
		{
			{0.0132451004725552, -0.009198858832936006, -0.00296636011766728},
			{-0.009198858832936009, 0.04574704917763943, -0.0221181006491635},
			{-0.002966360117667281, -0.02211810064916351, 0.0251370418371845}
		},
		{
			{0.017491411604714315, -0.004718863633608888, -0.010186879222994605},
			{-0.004718863633608886, 0.021528104907307905, -0.00606214789560231},
			{-0.010186879222994607, -0.006062147895602308, 0.013980194364504803}
		},
		{
			{0.03085784941338814, -0.025921088367019535, 0.002000129746548208},
			{-0.025921088367019545, 0.0551173738837344, -0.016168794347990196},
			{0.002000129746548207, -0.0161687943479902, 0.020595852891374}
		},
		{
			{0.05064427670584426, -0.03435542142782826, -0.0016052027415704084},
			{-0.03435542142782829, 0.06902084804637477, -0.028038582799000906},
			{-0.0016052027415704127, -0.028038582799000917, 0.030404465925912002}
		},
		{
			{0.03475645291766683, -0.013030930945198903, -0.0028979484438853634},
			{-0.013030930945198905, 0.030970353321942038, -0.001862911150980372},
			{-0.0028979484438853647, -0.001862911150980372, 0.0044455830809332205}
		}
	};

	double barycentre[9][3] =
	{
		{100.57430730478589, 89.63727959697734, 70.2382871536524},
		{111.82615681233933, 179.96625964010283, 216.72011568123392},
		{172.0768531150523, 170.9049567985448, 201.21782628467486},
		{42.39089968976215, 37.985522233712516, 44.699069286452946},
		{86.00885282183697, 148.87163408336409, 159.3659166359277},
		{147.24398433128147, 176.770565193061, 124.80302182428652},
		{152.97229916897507, 125.3205381875742, 89.05540166204986},
		{183.28053791557713, 132.96189764661935, 143.06387747478522},
		{203.05454545454546, 139.71764705882353, 44.132620320855615}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<9;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<9;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance10clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028573161876311617, -0.021067592519635924, -0.002439143743629111},
		{-0.021067592519635924, 0.04073312444488591, -0.012593870254559306},
		{-0.0024391437436291053, -0.012593870254559306, 0.014361591616065292}
	};

	double matrix[10][3][3] =
	{
		{
			{0.05711259054898087, -0.049101389306145035, -3.932580736509142E-4},
			{-0.049101389306145, 0.08921472633387639, -0.028772104779372788},
			{-3.932580736509218E-4, -0.028772104779372785, 0.028415884078028808}
		},
		{
			{0.027810437290349495, -0.0283419669935617, 0.004453097752519114},
			{-0.028341966993561705, 0.07573047641905041, -0.032424949727917186},
			{0.004453097752519114, -0.03242494972791719, 0.031214425522438624}
		},
		{
			{0.06858905448762981, -0.016886041286017513, -0.04435005589146809},
			{-0.016886041286017527, 0.08099170318477104, -0.004766032204735968},
			{-0.04435005589146812, -0.004766032204735975, 0.06494907132809241}
		},
		{
			{0.030608266768160794, -0.007802102306804916, -0.002998202528110668},
			{-0.007802102306804919, 0.0272691150786718, -0.0019838565816514982},
			{-0.002998202528110669, -0.0019838565816515013, 0.004619151436193958}
		},
		{
			{0.04570834456128488, -0.012686289142192489, -0.0028576263729571884},
			{-0.012686289142192489, 0.049332987655206564, -0.005255629857196038},
			{-0.0028576263729571893, -0.005255629857196038, 0.014940159866745701}
		},
		{
			{0.03641153819532908, -0.02852329213285575, 0.002320045262504807},
			{-0.028523292132855753, 0.057384434860222835, -0.017904760028048323},
			{0.002320045262504807, -0.01790476002804832, 0.021038054876443196}
		},
		{
			{0.012974106273270693, -0.012887267284324083, -0.001673540149333159},
			{-0.01288726728432409, 0.05446737550144892, -0.027067350688688176},
			{-0.0016735401493331555, -0.027067350688688183, 0.029774230024352862}
		},
		{
			{0.022851965151204502, -0.007800146561658393, -0.010594146970887498},
			{-0.007800146561658398, 0.032063153453317624, -0.0121335907437858},
			{-0.010594146970887498, -0.012133590743785805, 0.01922537307668499}
		},
		{
			{0.02397570852589458, -0.012402988569924578, -0.005564833961359768},
			{-0.012402988569924582, 0.04307577967782427, -0.0077980222169149755},
			{-0.005564833961359764, -0.007798022216914989, 0.012653521752935704}
		},
		{
			{0.047299456670288995, -0.02799787396456799, -0.005320746037339997},
			{-0.027997873964567984, 0.06309995043327933, -0.0263885205926691},
			{-0.005320746037339991, -0.026388520592669103, 0.030718955744662494}
		}
	};

	double barycentre[10][3] =
	{
		{169.24122807017545, 175.07066276803118, 203.0233918128655},
		{113.25820195994888, 183.35534725181083, 224.56795909671922},
		{42.544904137235115, 39.01917255297679, 45.59233097880929},
		{205.39013452914799, 133.89387144992526, 30.766816143497756},
		{105.09031198686371, 87.10509031198687, 65.80514504652436},
		{164.5198584349194, 126.31419583169485, 89.45576091230829},
		{89.76532929598788, 159.91029523088568, 176.00189250567752},
		{104.70679012345678, 140.08024691358025, 121.68981481481481},
		{175.708038585209, 177.7176848874598, 120.12475884244373},
		{177.4283261802575, 130.4489270386266, 153.82532188841202}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<10;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<10;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance11clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03140633113294396, -0.02161355035376852, -0.003398199245979271},
		{-0.02161355035376853, 0.037034002831236874, -0.010076507973479098},
		{-0.0033981992459792667, -0.010076507973479105, 0.013713415675466207}
	};

	double matrix[11][3][3] =
	{
		{
			{0.05212035499724154, -0.03631400736385512, 0.003342293713280099},
			{-0.03631400736385512, 0.07016868876018315, -0.02108257437238279},
			{0.003342293713280102, -0.021082574372382794, 0.018131405363129207}
		},
		{
			{0.02958488457702301, -0.0307271192525464, 0.0050071036861641105},
			{-0.030727119252546425, 0.07920824474471735, -0.03317273143274046},
			{0.005007103686164123, -0.03317273143274045, 0.031676718225991406}
		},
		{
			{0.07116532474107878, -0.015945108101470092, -0.04576183704387661},
			{-0.015945108101470082, 0.08083623355833847, -0.005892293264595068},
			{-0.045761837043876596, -0.0058922932645950644, 0.06610065413717639}
		},
		{
			{0.04858522816044024, -0.012149356143087557, -0.003858053238126018},
			{-0.012149356143087557, 0.05239954107004772, -0.0029605439100505154},
			{-0.0038580532381260217, -0.002960543910050514, 0.013846068714588199}
		},
		{
			{0.02971435366015888, -0.02447468195124889, 0.0021101035644068853},
			{-0.02447468195124888, 0.054686454689271684, -0.01737231045244189},
			{0.0021101035644068783, -0.017372310452441895, 0.021570367483881293}
		},
		{
			{0.04651772631745903, -0.02305031926301071, -0.009605130987136824},
			{-0.02305031926301069, 0.05014136976475576, -0.017411463914698683},
			{-0.00960513098713682, -0.017411463914698687, 0.024184390488453802}
		},
		{
			{0.05997760368382192, -0.048041949510832106, -0.0015698748415234449},
			{-0.04804194951083211, 0.08288373216244593, -0.030557291957897782},
			{-0.0015698748415234444, -0.03055729195789779, 0.03733935882503148}
		},
		{
			{0.028832062189070487, -0.005873104148210812, -0.002940121492726021},
			{-0.005873104148210812, 0.02640625000070923, -0.002194372001614755},
			{-0.002940121492726021, -0.0021943720016147535, 0.00519041663883591}
		},
		{
			{0.027043688776084, -0.00979992207148875, -0.00554353331736937},
			{-0.009799922071488748, 0.035411144835811426, -0.014545138018290098},
			{-0.005543533317369377, -0.014545138018290086, 0.0216413560233416}
		},
		{
			{0.015067477479758503, -0.001879445606793607, -0.011858835273263207},
			{-0.0018794456067936088, 0.0180346120255448, -0.006382270520874623},
			{-0.011858835273263207, -0.006382270520874622, 0.01595565617772801}
		},
		{
			{0.010393455651964582, -0.013118238127802363, 2.60836103118188E-4},
			{-0.01311823812780237, 0.05753354327016315, -0.03141863812787833},
			{2.608361031181967E-4, -0.03141863812787833, 0.03255089593519352}
		}
	};

	double barycentre[11][3] =
	{
		{196.82664437012264, 153.21348940914157, 118.2876254180602},
		{115.04102760736197, 181.99769938650306, 222.02914110429447},
		{42.66358024691358, 37.943415637860085, 45.129629629629626},
		{104.96825396825396, 85.1001221001221, 62.343101343101345},
		{156.91783073130648, 126.57271980279376, 87.62859490550534},
		{164.84577842850172, 129.73743289409467, 163.12005856515373},
		{176.18016431924883, 177.18016431924883, 204.56631455399062},
		{204.34039334341907, 134.75340393343419, 30.12102874432678},
		{93.82087447108604, 127.86177715091678, 119.0888575458392},
		{133.24935064935065, 177.2948051948052, 137.49025974025975},
		{81.94812680115274, 157.65994236311238, 177.73871277617675}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<11;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<11;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance12clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027282283629408106, -0.02053292575929951, -0.0016525291284974542},
		{-0.0205329257592995, 0.04262539332292879, -0.0141447630095892},
		{-0.0016525291284974466, -0.014144763009589204, 0.015580735132190807}
	};

	double matrix[12][3][3] =
	{
		{
			{0.0634790574134444, -0.05553698010665882, 4.134397682926498E-4},
			{-0.05553698010665885, 0.08468982318375058, -0.025134500015092414},
			{4.134397682926498E-4, -0.025134500015092424, 0.03237458205744481}
		},
		{
			{0.02679184160855979, -0.015382536307182174, -0.005144189693570094},
			{-0.015382536307182174, 0.04625017714926012, -0.007081599181586615},
			{-0.005144189693570093, -0.007081599181586613, 0.011805003498334198}
		},
		{
			{0.005130191201818429, -0.006713913622531709, 8.09119520663273E-4},
			{-0.006713913622531699, 0.05874049210340985, -0.0429349043436267},
			{8.091195206632665E-4, -0.042934904343626686, 0.04332943857428268}
		},
		{
			{0.05126980291079071, -0.012976080199994487, -0.0028568658145945807},
			{-0.01297608019999448, 0.04446933198180839, -0.0023564633912961444},
			{-0.002856865814594581, -0.002356463391296148, 0.014388706636926004}
		},
		{
			{0.045590991604854754, -0.023272969396220075, -0.011521964995827406},
			{-0.023272969396220068, 0.05053475148311101, -0.015128580294583097},
			{-0.011521964995827399, -0.01512858029458309, 0.023057539410217112}
		},
		{
			{0.03622903055696787, -0.02964923303647038, -4.7971848253209595E-5},
			{-0.029649233036470372, 0.05854140081045382, -0.020643384441788197},
			{-4.797184825320569E-5, -0.02064338444178819, 0.02336414312510412}
		},
		{
			{0.030348187115738435, -0.024942182477275913, 0.0026163528755871936},
			{-0.02494218247727591, 0.05067037522308327, -0.014319724705552503},
			{0.0026163528755871962, -0.014319724705552499, 0.01672101816780001}
		},
		{
			{0.06605791102673772, -0.015750633491993318, -0.043861890633784394},
			{-0.015750633491993328, 0.08789061426124392, -0.01850726643802274},
			{-0.043861890633784394, -0.018507266438022744, 0.08596144255262089}
		},
		{
			{0.02226045838743229, -0.007496768699202881, -0.010615871187606703},
			{-0.007496768699202876, 0.031395039541408494, -0.011149165035551505},
			{-0.010615871187606698, -0.0111491650355515, 0.018728767750393102}
		},
		{
			{0.03148613517370429, -0.006671214423572105, -0.0033831539370216294},
			{-0.006671214423572109, 0.02488067107938583, -0.0015076809797593305},
			{-0.003383153937021632, -0.001507680979759331, 0.0050741151397090695}
		},
		{
			{0.04860210246891881, -0.03311310158339919, 0.0011286954335075698},
			{-0.03311310158339922, 0.07174536970705529, -0.033447157687073605},
			{0.0011286954335075678, -0.0334471576870736, 0.03326637720648233}
		},
		{
			{0.02629792908931148, -0.028857081779573756, 0.00536688125519552},
			{-0.02885708177957376, 0.07906990312454422, -0.035052925179217674},
			{0.005366881255195519, -0.03505292517921767, 0.032946728914549486}
		}
	};

	double barycentre[12][3] =
	{
		{171.26451226810292, 180.59784560143626, 206.9210053859964},
		{177.411331861663, 179.49963208241354, 118.7991169977925},
		{40.558599695586, 147.6910197869102, 157.3881278538813},
		{100.89855072463769, 85.90078037904125, 67.53344481605352},
		{173.08617886178862, 135.12845528455284, 168.39241192411924},
		{106.09094583670169, 164.15925626515764, 183.6568310428456},
		{151.04754358161648, 127.73534072900158, 78.76281035393555},
		{42.83677910772579, 35.295973884657236, 43.105549510337326},
		{109.2536858159634, 144.52872394509404, 127.79003558718861},
		{207.2866344605475, 134.24798711755233, 29.36876006441224},
		{185.45002823263692, 124.67871259175607, 116.65443252399774},
		{112.11508553654744, 185.73094867807154, 229.22757905650596}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<12;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<12;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance13clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028077984191007297, -0.0198513680396286, -0.0028554878886958082},
		{-0.0198513680396286, 0.03793292367002467, -0.011223025467721392},
		{-0.002855487888695813, -0.011223025467721396, 0.014267610441666396}
	};

	double matrix[13][3][3] =
	{
		{
			{0.04629388225728307, -0.03605022722135277, -1.7596181686661177E-4},
			{-0.03605022722135278, 0.06372783323115332, -0.020354681789592134},
			{-1.7596181686661003E-4, -0.02035468178959212, 0.023418048186872906}
		},
		{
			{0.03508235310004853, -0.007432019495233993, -0.009579545486916606},
			{-0.007432019495234, 0.02804241641982068, -0.009683714597819193},
			{-0.009579545486916616, -0.009683714597819203, 0.018129513392613802}
		},
		{
			{0.05808326074531013, -0.047342721608401465, -0.0014720692940760273},
			{-0.04734272160840147, 0.08322089153025458, -0.02965386388276421},
			{-0.0014720692940760347, -0.02965386388276421, 0.03463034693570808}
		},
		{
			{0.058917200914468684, -0.019886871789144316, -0.03391954708378683},
			{-0.019886871789144313, 0.10878939485875305, -0.01924695830623717},
			{-0.03391954708378682, -0.01924695830623716, 0.06673747359641162}
		},
		{
			{0.07473587033786279, 6.008578236740255E-4, -0.008561285733317534},
			{6.008578236740256E-4, 0.033791969986607405, 0.001679978231404521},
			{-0.008561285733317535, 0.0016799782314045283, 0.018063359985567313}
		},
		{
			{0.02710562721390445, -0.028599301133744755, 0.005905344301288109},
			{-0.02859930113374475, 0.07753670757886152, -0.03520006539879979},
			{0.005905344301288102, -0.03520006539879979, 0.032679529892977316}
		},
		{
			{0.04850048311375954, -0.031900616451817736, 9.823475889792085E-5},
			{-0.03190061645181772, 0.061894197215605906, -0.012326038234327198},
			{9.823475889791998E-5, -0.012326038234327203, 0.011805955799722498}
		},
		{
			{0.037511391316469384, -0.014636524754333479, 0.001504367805250102},
			{-0.01463652475433348, 0.053756998436714096, -0.011682362858975597},
			{0.001504367805250101, -0.011682362858975597, 0.0153556941709781}
		},
		{
			{0.032719324500704625, -0.02438205062316153, 0.002371741771621966},
			{-0.0243820506231615, 0.05782649029923204, -0.01879335076254242},
			{0.002371741771621957, -0.018793350762542425, 0.021413360224780312}
		},
		{
			{0.04729181902791704, -0.027226005245258256, -0.006333121901621986},
			{-0.027226005245258287, 0.056208585842587075, -0.022871022154011825},
			{-0.006333121901621982, -0.022871022154011815, 0.029581592358630584}
		},
		{
			{0.030105479227171782, -0.006679024617121992, -0.003794878713353019},
			{-0.0066790246171219885, 0.0264062499986266, -0.001475693911544295},
			{-0.003794878713353017, -0.0014756939115442937, 0.00638578782032556}
		},
		{
			{0.005112722201253828, -0.006738798639472744, 8.078411093151642E-4},
			{-0.006738798639472748, 0.05805360202209267, -0.04263567031074239},
			{8.078411093151642E-4, -0.04263567031074238, 0.043883617080728986}
		},
		{
			{0.01499415275945341, -0.0013909761121203082, -0.0123980897189661},
			{-0.0013909761121203151, 0.0174533412068515, -0.006293259047474825},
			{-0.012398089718966096, -0.006293259047474825, 0.016414425603142088}
		}
	};

	double barycentre[13][3] =
	{
		{103.90127388535032, 157.89945404913558, 187.28980891719746},
		{104.81835323695789, 133.45065996228786, 121.88560653676933},
		{174.10998877665546, 175.0297418630752, 205.00785634118967},
		{41.69711538461539, 31.96514423076923, 40.72475961538461},
		{77.5281954887218, 82.54981203007519, 74.99812030075188},
		{114.05771144278607, 187.2323383084577, 228.05572139303482},
		{196.00613026819923, 166.58544061302683, 113.1249042145594},
		{129.34676007005254, 94.77583187390543, 55.22241681260946},
		{162.1012548680225, 128.7022933794894, 90.95672868887927},
		{175.5965485074627, 129.77192164179104, 155.60401119402985},
		{209.12671232876713, 133.6455479452055, 29.33732876712329},
		{42.58833063209076, 152.55915721231767, 164.3095623987034},
		{132.9840909090909, 180.11969696969697, 142.35681818181817}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<13;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<13;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance14clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03177928615049198, -0.024771669895164786, -8.50570451344507E-4},
		{-0.024771669895164817, 0.04322188601482041, -0.0126378981690171},
		{-8.505704513445029E-4, -0.0126378981690171, 0.0142570873504591}
	};

	double matrix[14][3][3] =
	{
		{
			{0.015343465951922004, -0.002028453659149429, -0.011631422147578206},
			{-0.0020284536591494203, 0.0204684950727414, -0.009522922986011076},
			{-0.011631422147578202, -0.009522922986011075, 0.017654352725641604}
		},
		{
			{0.05178071057719563, -0.025181282324745723, -0.008343291744163027},
			{-0.025181282324745702, 0.060658719775566, -0.02638996735506858},
			{-0.008343291744163034, -0.026389967355068576, 0.034537544177857295}
		},
		{
			{0.005372934353623838, -0.0073264112693431005, 0.0011415993962302184},
			{-0.007326411269343098, 0.05695055850296522, -0.04178237422761001},
			{0.0011415993962302145, -0.04178237422761, 0.043039884252039896}
		},
		{
			{0.049817382082083195, -0.02613715424143828, -0.007171628620191807},
			{-0.026137154241438285, 0.06739663399275957, -0.0179729845140591},
			{-0.007171628620191811, -0.01797298451405911, 0.018506680940544702}
		},
		{
			{0.027287557857386895, -0.004422452006703244, -0.004165648921127847},
			{-0.004422452006703249, 0.023784053007933802, -0.0016075102174709474},
			{-0.004165648921127836, -0.0016075102174709505, 0.00735152079421055}
		},
		{
			{0.04979905145728983, -0.032111517219328624, 4.095640131197159E-4},
			{-0.03211151721932862, 0.07033892387585017, -0.03249802962082722},
			{4.095640131197083E-4, -0.0324980296208272, 0.032269387956241194}
		},
		{
			{0.0404781500179018, -0.004842055538152483, -0.00965710269406853},
			{-0.0048420555381524935, 0.041551387302947926, -0.01336404221327359},
			{-0.00965710269406854, -0.013364042213273588, 0.019414833095013198}
		},
		{
			{0.06730282962287804, -0.01679490314390119, -0.044220704287598445},
			{-0.01679490314390119, 0.0876313858088638, -0.01780785508768769},
			{-0.044220704287598445, -0.017807855087687712, 0.08607196924284624}
		},
		{
			{0.02406476390994447, -0.027299134887519266, 0.006356342017813784},
			{-0.02729913488751927, 0.07857647674704245, -0.037602215736736486},
			{0.006356342017813788, -0.037602215736736486, 0.036938455940069996}
		},
		{
			{0.0636737888453951, -0.05948098371875762, 0.0028517354136444227},
			{-0.05948098371875762, 0.09857486001219189, -0.02866245843632883},
			{0.0028517354136444193, -0.028662458436328822, 0.02824578911186161}
		},
		{
			{0.0474381172721558, -0.011366141696991565, -0.0034240953169294777},
			{-0.011366141696991558, 0.052638977403715016, 1.338022589589162E-4},
			{-0.003424095316929475, 1.3380225895892004E-4, 0.014993239319108894}
		},
		{
			{0.03079121175804534, -0.02469818158939773, 0.0026202144241650113},
			{-0.024698181589397742, 0.05142457533611635, -0.014634226327815405},
			{0.0026202144241650135, -0.0146342263278154, 0.018082750001391496}
		},
		{
			{0.03212060613525781, -0.01757835304772074, -0.004025408579743482},
			{-0.01757835304772075, 0.044179003747144806, -0.006707935874228322},
			{-0.0040254085797434835, -0.006707935874228316, 0.011121253248479897}
		},
		{
			{0.03801784775302971, -0.032328595057144825, 0.0018856919075286036},
			{-0.03232859505714482, 0.06269535045410386, -0.02435874798112231},
			{0.0018856919075285964, -0.02435874798112231, 0.025700261020359813}
		}
	};

	double barycentre[14][3] =
	{
		{122.29098360655738, 169.81079234972677, 133.6448087431694},
		{192.63970588235293, 148.90514705882353, 169.1875},
		{47.04099560761347, 152.34992679355784, 166.32796486090777},
		{144.47669977081742, 124.61955691367456, 160.7494270435447},
		{206.4305799648506, 130.63796133567664, 25.797891036906854},
		{187.54450583179866, 125.280540208717, 115.23879680785758},
		{88.69416126042633, 119.63021316033364, 111.00556070435589},
		{42.5889502762431, 34.61546961325967, 43.20441988950276},
		{111.15187611673615, 187.63311494937463, 231.23645026801668},
		{165.37951807228916, 180.56265060240963, 209.23253012048193},
		{102.89878542510121, 82.44466936572199, 60.475033738191634},
		{149.96723102129982, 125.59639541234299, 79.80557072637903},
		{181.4153005464481, 177.82695810564664, 105.29326047358835},
		{103.84107806691449, 164.4907063197026, 188.6277881040892}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<14;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<14;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance15clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03056554713267548, -0.023055013290160395, -0.0018882268761933488},
		{-0.023055013290160395, 0.04153009187390996, -0.011737982957509807},
		{-0.001888226876193346, -0.011737982957509805, 0.013934031888597988}
	};

	double matrix[15][3][3] =
	{
		{
			{0.015092105271770406, -0.001366945985654542, -0.012773640925024712},
			{-0.0013669459856545446, 0.018051663641085694, -0.0065522543336083115},
			{-0.012773640925024712, -0.006552254333608311, 0.016610354917012824}
		},
		{
			{0.02540513306514533, -0.021970224267536816, -9.116230877338266E-4},
			{-0.021970224267536816, 0.047832094534799065, -0.011757639844251898},
			{-9.116230877338309E-4, -0.011757639844251898, 0.01567598599374681}
		},
		{
			{0.03834324691019983, -0.015324175953518118, 0.0010625633280317587},
			{-0.015324175953518114, 0.05706144519906003, -0.011735557169529204},
			{0.0010625633280317607, -0.011735557169529202, 0.015086349477586702}
		},
		{
			{0.03979487853051288, -0.029913176232422185, 1.9295456828297272E-4},
			{-0.029913176232422185, 0.06917932844853776, -0.028611008748737777},
			{1.9295456828296665E-4, -0.02861100874873778, 0.030412866934797785}
		},
		{
			{0.004643845117619684, -0.005669306383421009, 6.585409207099839E-4},
			{-0.005669306383421018, 0.05816044220354428, -0.0448341981769146},
			{6.58540920709987E-4, -0.04483419817691459, 0.04606805825103731}
		},
		{
			{0.03304303227568014, -0.006948831205111487, -0.005680627885709356},
			{-0.006948831205111485, 0.0239506217592216, -9.029614360057126E-4},
			{-0.005680627885709355, -9.029614360057133E-4, 0.007959270535767511}
		},
		{
			{0.064635803805275, -0.0573868814100682, 0.0015923553591988512},
			{-0.057386881410068216, 0.09074858020870383, -0.03173475429024327},
			{0.0015923553591988512, -0.03173475429024327, 0.0372163450214857}
		},
		{
			{0.044031760212326486, -0.027595372874386487, -0.0015621572942107684},
			{-0.027595372874386508, 0.0515417579667879, -0.008094782416491822},
			{-0.0015621572942107697, -0.00809478241649183, 0.00989867522224721}
		},
		{
			{0.027533719861314355, -0.020889020056710336, 9.692104556291133E-4},
			{-0.02088902005671034, 0.053919451408851564, -0.026530849744252516},
			{9.692104556291083E-4, -0.026530849744252516, 0.027585149107525016}
		},
		{
			{0.027016545363943337, -0.02902494905581947, 0.006296924261049639},
			{-0.02902494905581947, 0.08034383956121097, -0.036525983493242986},
			{0.006296924261049636, -0.036525983493243, 0.03476996196395861}
		},
		{
			{0.04947705378235385, -0.040694677056635126, -0.0019264034953704319},
			{-0.04069467705663508, 0.08887775562493165, -0.020807473357542187},
			{-0.0019264034953704297, -0.020807473357542183, 0.013593645595136997}
		},
		{
			{0.058917200914468684, -0.019886871789144316, -0.03391954708378683},
			{-0.019886871789144313, 0.10878939485875305, -0.01924695830623717},
			{-0.03391954708378682, -0.01924695830623716, 0.06673747359641162}
		},
		{
			{0.07526113747100485, 6.094933187295406E-5, -0.009300172490324865},
			{6.0949331872952976E-5, 0.0343343199142014, 0.0031236280179995214},
			{-0.009300172490324861, 0.003123628017999524, 0.016975953870188503}
		},
		{
			{0.05139315393972132, -0.03391777308111678, -0.0015584100003106956},
			{-0.03391777308111677, 0.06625415607255507, -0.028672527524574894},
			{-0.0015584100003106925, -0.028672527524574887, 0.0336450545766674}
		},
		{
			{0.0318039051748428, -0.007429715045935125, -0.009977211347203141},
			{-0.007429715045935119, 0.029137059971625006, -0.011002002101683495},
			{-0.009977211347203137, -0.011002002101683481, 0.021160677981766098}
		}
	};

	double barycentre[15][3] =
	{
		{132.752, 180.4672, 144.144},
		{151.16029411764706, 143.05882352941177, 79.65955882352941},
		{130.11769911504425, 93.45044247787611, 56.2},
		{174.11063372717507, 118.10580021482276, 113.38023630504834},
		{35.87651821862348, 151.07085020242914, 162.3502024291498},
		{211.39805825242718, 129.24271844660194, 26.06019417475728},
		{172.935817805383, 181.53416149068323, 209.47964113181504},
		{192.38643067846607, 173.79941002949852, 105.34808259587021},
		{94.54678692220969, 164.3618940248027, 184.31003382187149},
		{113.61203007518797, 185.87568922305763, 227.89323308270676},
		{139.3349593495935, 134.86666666666667, 181.9130081300813},
		{41.671480144404335, 31.90373044524669, 40.75451263537906},
		{77.84586466165413, 82.4859022556391, 74.61184210526316},
		{190.7508327781479, 142.3411059293804, 162.1292471685543},
		{101.72899159663865, 133.34593837535013, 122.19957983193277}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<15;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<15;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance16clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029326355097312795, -0.021840871195845487, -0.0014292719929897204},
		{-0.0218408711958455, 0.0444218715067781, -0.014602515973976604},
		{-0.0014292719929897147, -0.014602515973976611, 0.015819974779072498}
	};

	double matrix[16][3][3] =
	{
		{
			{0.05021514214853513, -0.02285830116125931, -0.0046963097593972335},
			{-0.022858301161259312, 0.0325135878563048, -0.006397749533437869},
			{-0.004696309759397233, -0.006397749533437868, 0.0130662999252357}
		},
		{
			{0.015314505692909302, -0.0010290818484250614, -0.012239477388464596},
			{-0.0010290818484250648, 0.0160599867365574, -0.007319280857069679},
			{-0.0122394773884646, -0.007319280857069677, 0.016971247809209094}
		},
		{
			{0.019015659817640217, -0.02284069354748041, 0.0056535298948778125},
			{-0.022840693547480403, 0.06815658296141791, -0.038816562841043754},
			{0.005653529894877806, -0.03881656284104376, 0.03865245147450584}
		},
		{
			{0.022760392224433386, -0.016630510571509705, -0.0018277049054625646},
			{-0.01663051057150971, 0.04726831193465171, -0.023183859744648094},
			{-0.0018277049054625618, -0.023183859744648087, 0.026967564649926286}
		},
		{
			{0.04906668879391257, -0.03692151197998394, -9.79840444195845E-4},
			{-0.03692151197998396, 0.07017763940796887, -0.02835547474593072},
			{-9.798404441958512E-4, -0.0283554747459307, 0.0328698040525818}
		},
		{
			{0.06613208713998124, -0.015836488319686703, -0.04409421721019352},
			{-0.015836488319686683, 0.08685745589090725, -0.018240120986954156},
			{-0.04409421721019349, -0.018240120986954142, 0.08730556340384259}
		},
		{
			{0.04583217293329136, -0.03226331088327697, -0.0018931794169976474},
			{-0.032263310883276976, 0.06421799085532069, -0.010962653097928895},
			{-0.0018931794169976509, -0.0109626530979289, 0.0120607177656974}
		},
		{
			{0.055025767830410105, -0.0558436107526894, 0.0029439474126773182},
			{-0.05584361075268941, 0.11190048721249005, -0.02473559942560941},
			{0.0029439474126773165, -0.024735599425609406, 0.027456258091444308}
		},
		{
			{0.02412026145879358, -0.0037925993330131047, -0.004093649940884867},
			{-0.0037925993330131047, 0.0299511523701739, 0.0017987139307431086},
			{-0.004093649940884871, 0.0017987139307431101, 0.003321622997971471}
		},
		{
			{0.004361878790009845, -0.004755956472324945, 4.0415569579549913E-4},
			{-0.004755956472324949, 0.056773387519532606, -0.04215005933899838},
			{4.041556957955087E-4, -0.04215005933899838, 0.044629978086516954}
		},
		{
			{0.053304705385816456, -0.04881049193983227, -0.0016219167681313417},
			{-0.048810491939832334, 0.09354743991798839, -0.017997673371871706},
			{-0.001621916768131343, -0.0179976733718717, 0.0143446752554393}
		},
		{
			{0.05245563774959548, -0.025007796777019503, -0.01623525903998068},
			{-0.025007796777019503, 0.05726588963024049, -0.0269183059222936},
			{-0.01623525903998068, -0.02691830592229361, 0.047472664074184184}
		},
		{
			{0.0497305311274376, -0.009794628358505829, -0.008343198285939038},
			{-0.009794628358505829, 0.029452726126195206, -0.009920965522519122},
			{-0.008343198285939026, -0.009920965522519124, 0.01745242572066749}
		},
		{
			{0.028014075456741706, -0.023354952322388906, 0.0013817672506609632},
			{-0.02335495232238891, 0.04772719435009543, -0.013000412026412906},
			{0.001381767250660961, -0.01300041202641291, 0.015139815781241205}
		},
		{
			{0.04611852181319488, -0.026168830762927683, -0.008317328772002554},
			{-0.026168830762927683, 0.055722460991714004, -0.022974901627937413},
			{-0.008317328772002568, -0.022974901627937413, 0.032317489126143684}
		},
		{
			{0.048486605063780115, -0.011145242540330998, -0.0038632177544499964},
			{-0.011145242540331009, 0.049563419791358955, -0.0013121218591345184},
			{-0.0038632177544499977, -0.001312121859134517, 0.014400981591457794}
		}
	};

	double barycentre[16][3] =
	{
		{209.025, 108.01666666666667, 23.944444444444443},
		{131.13515625, 174.2890625, 133.45625},
		{101.78325859491778, 187.1121076233184, 229.85201793721973},
		{95.09597701149426, 167.47988505747125, 179.4367816091954},
		{180.1096573208723, 120.32772585669782, 107.46417445482867},
		{42.46878422782037, 35.22672508214677, 43.271631982475355},
		{190.89576883384933, 174.6687306501548, 119.53560371517028},
		{146.84218629715164, 188.2217090069284, 219.75673595073133},
		{198.70737913486005, 173.01272264631044, 48.725190839694655},
		{32.86497064579256, 147.47553816046965, 154.44814090019568},
		{130.4935400516796, 142.25236864771747, 196.08010335917314},
		{188.78364116094986, 171.31574318381706, 193.9744942832014},
		{100.55481972038264, 127.06548933039, 123.9484915378955},
		{147.7983512999366, 131.35700697526948, 76.09511731135066},
		{175.8832298136646, 129.75093167701863, 156.0335403726708},
		{102.01152912621359, 84.01820388349515, 64.0121359223301}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<16;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<16;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance17clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.030347631849168992, -0.023079362758909587, -0.0015962165241353928},
		{-0.023079362758909587, 0.041886919173268373, -0.0120271335170134},
		{-0.0015962165241353936, -0.0120271335170134, 0.013735128686911003}
	};

	double matrix[17][3][3] =
	{
		{
			{0.04697331225609551, -0.01866253467354303, -0.014678600441906909},
			{-0.018662534673543014, 0.04142062700115891, -0.01346258347511289},
			{-0.014678600441906907, -0.013462583475112892, 0.025560544215509698}
		},
		{
			{0.03269137536250559, -0.023881012003156475, 0.002078315098569935},
			{-0.02388101200315648, 0.05949477364914657, -0.016915606007474382},
			{0.002078315098569937, -0.016915606007474382, 0.020165206707306396}
		},
		{
			{0.02682303788968459, -0.004583919044337442, -0.00529685844466562},
			{-0.004583919044337441, 0.023271069534865532, -0.001756211984305634},
			{-0.00529685844466561, -0.0017562119843056358, 0.0109432483662972}
		},
		{
			{0.06434235217953638, -0.014532375412909887, -0.00880998553307473},
			{-0.01453237541290989, 0.030581737640155517, -0.007368608032417386},
			{-0.008809985533074728, -0.007368608032417393, 0.01576905577506209}
		},
		{
			{0.059923651104014146, -0.022778837463340806, -0.03156617801156373},
			{-0.022778837463340817, 0.10583554073994995, -0.01894830858334622},
			{-0.03156617801156371, -0.018948308583346257, 0.0681520420592032}
		},
		{
			{0.02822669183998139, -0.01199253271610118, -0.003684129676428765},
			{-0.011992532716101192, 0.042727099600932295, -0.014840658954540101},
			{-0.003684129676428772, -0.014840658954540106, 0.018368299565031998}
		},
		{
			{0.06310710989703991, -0.04647396315562699, -0.004149356018148226},
			{-0.04647396315562702, 0.07632516375084875, -0.023938649946578013},
			{-0.004149356018148233, -0.023938649946578, 0.03331914057251969}
		},
		{
			{0.003697525418403862, -0.0021852498075255245, 0.0018129313242703712},
			{-0.0021852498075255154, 0.0633560206165287, -0.042867782436754084},
			{0.0018129313242703643, -0.04286778243675409, 0.050962458351503}
		},
		{
			{0.07902160777899427, -0.006936197721074683, -0.00959782288606908},
			{-0.006936197721074687, 0.0395411953531916, 0.005971179883169851},
			{-0.009597822886069078, 0.005971179883169855, 0.016399318616424012}
		},
		{
			{0.015789007692185886, -0.0025218034072748896, -0.011607634180813087},
			{-0.0025218034072748896, 0.01848851920327431, -0.007034420716306731},
			{-0.011607634180813087, -0.00703442071630673, 0.01604819047893029}
		},
		{
			{0.005278870934455784, -0.008302760808679295, 0.0025594376948365237},
			{-0.008302760808679279, 0.05696833857096331, -0.04232766452500511},
			{0.0025594376948365094, -0.04232766452500513, 0.04290419381354942}
		},
		{
			{0.05340013913763163, -0.035917064127506775, 0.0018121634148340641},
			{-0.035917064127506775, 0.07772597099014475, -0.037558251009839984},
			{0.0018121634148340632, -0.03755825100983999, 0.03589927522638741}
		},
		{
			{0.04073302430288765, -0.02342029246100019, -0.002440049996640476},
			{-0.02342029246100019, 0.042447233372073, -0.005833715193405043},
			{-0.0024400499966404756, -0.005833715193405044, 0.009662288679247337}
		},
		{
			{0.0385164391056748, -0.010449346149178597, 2.882380268043926E-4},
			{-0.010449346149178607, 0.055917896225454816, -0.012582387568473297},
			{2.882380268043963E-4, -0.012582387568473298, 0.015136555523485497}
		},
		{
			{0.05342672769610603, -0.050344866377927004, -2.3654019369636226E-5},
			{-0.05034486637792702, 0.104740234555685, -0.020513454455620694},
			{-2.3654019369638395E-5, -0.020513454455620694, 0.01608030710515129}
		},
		{
			{0.022646904463012475, -0.01624783238586008, -0.0016818079853850104},
			{-0.01624783238586008, 0.048918094494169, -0.02388640725279189},
			{-0.0016818079853850086, -0.023886407252791893, 0.026241346909542086}
		},
		{
			{0.026579009413635068, -0.027412435583184167, 0.006083786953217739},
			{-0.027412435583184153, 0.07793811807448736, -0.0392978669673184},
			{0.006083786953217742, -0.03929786696731839, 0.038751874427017996}
		}
	};

	double barycentre[17][3] =
	{
		{169.63726708074535, 130.93229813664595, 163.55217391304348},
		{158.85935828877004, 126.71336898395722, 85.59786096256684},
		{211.67080745341616, 128.62525879917183, 23.923395445134574},
		{109.90319634703197, 118.32237442922374, 107.47945205479452},
		{40.745049504950494, 31.440594059405942, 40.51361386138614},
		{95.17718446601941, 146.8584142394822, 151.63754045307442},
		{179.84604904632153, 181.5108991825613, 203.0865122615804},
		{32.708333333333336, 118.14583333333333, 103.55729166666667},
		{81.71933701657458, 76.30386740331491, 70.03867403314918},
		{135.95108259823576, 173.27506014434644, 127.83801122694467},
		{42.183953033268104, 157.54794520547946, 175.61839530332682},
		{195.50339673913044, 133.95991847826087, 124.85258152173913},
		{188.97578692493946, 178.8595641646489, 97.44915254237289},
		{129.30108695652174, 92.37608695652175, 50.17391304347826},
		{128.70428336079078, 148.7825370675453, 205.3649093904448},
		{106.15213239974538, 179.52832590706555, 187.92552514322088},
		{112.69021739130434, 189.91847826086956, 234.77309782608697}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<17;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<17;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance18clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.030668275269461084, -0.024030585879719873, -8.727654168164587E-4},
		{-0.024030585879719873, 0.045901599155018714, -0.013398855914883613},
		{-8.7276541681646E-4, -0.013398855914883613, 0.013823913509852907}
	};

	double matrix[18][3][3] =
	{
		{
			{0.033739325120013076, -0.00885143821282112, -0.007960373691259156},
			{-0.008851438212821132, 0.03216358723057539, -0.0125388877332338},
			{-0.007960373691259159, -0.012538887733233799, 0.02005091962380459}
		},
		{
			{0.06450467267031511, -0.060068305180123384, 0.0030460157349045803},
			{-0.060068305180123384, 0.10148265059116797, -0.033312621294491196},
			{0.003046015734904597, -0.0333126212944912, 0.035630772137099406}
		},
		{
			{0.021602885705996805, -0.013821011767603007, -0.0036126569706019136},
			{-0.01382101176760301, 0.042158526301283736, -0.020447400809072303},
			{-0.003612656970601904, -0.020447400809072293, 0.025503183868573}
		},
		{
			{0.027225511469006404, -0.004940387250860069, -0.004794005026322019},
			{-0.004940387250860066, 0.022301917630950914, -0.00206474978506586},
			{-0.004794005026322017, -0.002064749785065858, 0.011781781323500193}
		},
		{
			{0.028864184430613688, -0.02332055964713869, 0.00312479441595052},
			{-0.023320559647138688, 0.05041838936954295, -0.012135793626318099},
			{0.0031247944159505225, -0.012135793626318097, 0.016892463206328104}
		},
		{
			{0.0379342347168488, -0.011684364023024797, -0.009495168060859375},
			{-0.011684364023024795, 0.049022434629148695, -0.01700678158670829},
			{-0.009495168060859382, -0.0170067815867083, 0.024544183769009888}
		},
		{
			{0.03501217621844431, -0.01673313202530159, -0.0019936090136714003},
			{-0.016733132025301592, 0.037755491630316086, -0.006626358085281448},
			{-0.0019936090136714016, -0.006626358085281456, 0.0103379296551082}
		},
		{
			{0.07751562410678942, -0.0018700346348231233, -0.009812791324202349},
			{-0.0018700346348231281, 0.03293774169876992, 0.0023237902799641713},
			{-0.009812791324202349, 0.002323790279964168, 0.016669691600960712}
		},
		{
			{0.003994526323131927, -0.0028851935779443424, 0.0021018525786908604},
			{-0.002885193577944335, 0.06477692363242958, -0.0442535607313045},
			{0.0021018525786908543, -0.0442535607313045, 0.049959200451156704}
		},
		{
			{0.05701226387699836, -0.05574752395698461, -7.609770564039242E-4},
			{-0.05574752395698462, 0.101372159723906, -0.017176307152505906},
			{-7.609770564039255E-4, -0.01717630715250589, 0.014434279121242994}
		},
		{
			{0.047677312192294444, -0.022080759845333413, -0.011889800205186391},
			{-0.022080759845333416, 0.04695526978582789, -0.020249014625076195},
			{-0.011889800205186393, -0.020249014625076202, 0.03295632238388711}
		},
		{
			{0.02332046343364769, -0.02734221268254589, 0.0057971331568949045},
			{-0.027342212682545906, 0.07636068173078381, -0.037092237146464},
			{0.0057971331568949045, -0.03709223714646398, 0.03637245762408159}
		},
		{
			{0.09118851527949529, -0.05041051303879314, -0.01279748989157551},
			{-0.050410513038793146, 0.06196750716211743, -0.0055902483522215305},
			{-0.012797489891575503, -0.005590248352221534, 0.012960223376237905}
		},
		{
			{0.05914165341472115, -0.020497657391349497, -0.03352000573135365},
			{-0.0204976573913495, 0.10737008232986599, -0.01817888486027908},
			{-0.03352000573135365, -0.01817888486027907, 0.06610893476626903}
		},
		{
			{0.05852354488747348, -0.03700041977970028, 0.0015401352952257752},
			{-0.03700041977970025, 0.07836616397256758, -0.03609499800145072},
			{0.001540135295225764, -0.03609499800145072, 0.03351191656625923}
		},
		{
			{0.015384547734605996, -0.0025227848693961516, -0.011481850696625802},
			{-0.002522784869396156, 0.018634492797680403, -0.006850661405106908},
			{-0.011481850696625802, -0.006850661405106907, 0.016269735472137305}
		},
		{
			{0.0393567105122875, -0.012536520284596706, -6.386797203597673E-4},
			{-0.012536520284596694, 0.0601899886745567, -0.010032333701668505},
			{-6.386797203597684E-4, -0.010032333701668505, 0.014967106602377796}
		},
		{
			{0.00567393104240499, -0.0084875395767012, 0.001747782522089585},
			{-0.008487539576701186, 0.05742115934818337, -0.0420225832221525},
			{0.0017477825220895728, -0.042022583222152486, 0.042025034118942914}
		}
	};

	double barycentre[18][3] =
	{
		{96.22351959966639, 134.1184320266889, 125.2393661384487},
		{164.31559766763849, 180.0597667638484, 216.76166180758017},
		{103.87492590397154, 175.11144042679314, 180.61825726141078},
		{212.33853006681514, 126.98886414253897, 21.605790645879733},
		{150.79586009992863, 133.37830121341898, 78.30835117773019},
		{154.470737913486, 112.19083969465649, 123.51993214588634},
		{185.3841059602649, 173.21456953642385, 88.3205298013245},
		{84.51417399804497, 80.17986314760509, 74.14076246334311},
		{27.58433734939759, 118.98192771084338, 100.03012048192771},
		{124.11248892825509, 139.07883082373783, 191.77059344552703},
		{181.40653594771243, 139.93725490196078, 171.38039215686274},
		{108.39667896678966, 187.21648216482166, 230.63222632226322},
		{195.76648841354725, 196.08377896613192, 157.88948306595364},
		{41.73829531812725, 31.992797118847538, 40.76350540216087},
		{195.8003144654088, 131.48977987421384, 115.66116352201257},
		{133.78595890410958, 172.22003424657535, 128.57020547945206},
		{129.5047619047619, 91.67936507936508, 51.91216931216931},
		{46.917355371900825, 155.4909090909091, 173.3322314049587}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<18;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<18;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance19clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.03137512141304367, -0.024391249111402676, -0.0013883693548049439},
		{-0.024391249111402676, 0.045918893870355575, -0.013193644625699},
		{-0.0013883693548049475, -0.013193644625698997, 0.013691999766443006}
	};

	double matrix[19][3][3] =
	{
		{
			{0.037547607499298696, -0.026302695527306477, -5.80851896519418E-4},
			{-0.02630269552730649, 0.06771473948549188, -0.024416225990503592},
			{-5.808518965194072E-4, -0.02441622599050359, 0.030637652998112185}
		},
		{
			{0.03503963580081611, -0.016488160069957705, 5.893007984062435E-5},
			{-0.016488160069957698, 0.039772548633578424, -0.006601116604472582},
			{5.893007984062522E-5, -0.006601116604472582, 0.0100073979152314}
		},
		{
			{0.04769065822430192, -0.021682406266785192, -0.011388993878316095},
			{-0.021682406266785196, 0.05138827161576567, -0.021733020767110724},
			{-0.011388993878316104, -0.02173302076711073, 0.033503891604371214}
		},
		{
			{0.05440830829965895, -0.041067690253648946, -0.006218100429456799},
			{-0.041067690253648974, 0.08878505873312265, -0.013950399899277108},
			{-0.006218100429456802, -0.013950399899277098, 0.02145944450821481}
		},
		{
			{0.015313620177230213, -0.0028931727643263004, -0.01133131429161681},
			{-0.0028931727643262926, 0.01998813431593718, -0.0067429936304020804},
			{-0.011331314291616806, -0.006742993630402076, 0.01674851996232949}
		},
		{
			{0.10057175518078212, -0.055753823553599556, -0.015229828833310515},
			{-0.055753823553599514, 0.05435892692135901, 7.361354104394808E-5},
			{-0.015229828833310506, 7.361354104394981E-5, 0.011986751283808003}
		},
		{
			{0.017145710408699597, -0.007024370593944059, -0.007348998763563539},
			{-0.007024370593944056, 0.041634835930732, -0.017545882279037795},
			{-0.00734899876356354, -0.017545882279037806, 0.022382375116751896}
		},
		{
			{0.05262659856478773, -0.03592533526354751, 0.002739286057544714},
			{-0.03592533526354755, 0.07822009667267797, -0.03638864647289032},
			{0.002739286057544709, -0.03638864647289032, 0.035030893063915214}
		},
		{
			{0.04029426683932242, -0.015517238473242009, -4.2009601671551483E-4},
			{-0.015517238473242004, 0.061696953636010514, -0.011895709711509305},
			{-4.2009601671551397E-4, -0.011895709711509307, 0.015053176301658096}
		},
		{
			{0.062221110054563704, -0.05692301258364701, 0.0030688364910364963},
			{-0.056923012583646994, 0.11567844246628095, -0.03855159371867804},
			{0.003068836491036488, -0.03855159371867807, 0.04020259450426408}
		},
		{
			{0.02287323565630212, -0.013581748186140094, -0.0025652277138626337},
			{-0.013581748186140094, 0.040765235913441396, -0.0179128883984883},
			{-0.002565227713862631, -0.017912888398488303, 0.021689102900056097}
		},
		{
			{0.02698174968612402, -0.021967252331386005, 6.336231232311586E-4},
			{-0.021967252331386012, 0.04768763046308675, -0.01055326163746019},
			{6.336231232311608E-4, -0.010553261637460195, 0.014577197876124694}
		},
		{
			{0.02050573112170482, -0.02212249901263375, 0.004465158444442888},
			{-0.022122499012633735, 0.06663114557896077, -0.038283249630579545},
			{0.0044651584444428735, -0.03828324963057955, 0.03680301856261034}
		},
		{
			{0.05941468953814294, -0.021315597338242512, -0.03276832646480114},
			{-0.02131559733824253, 0.10752267145289202, -0.01907391367724185},
			{-0.03276832646480116, -0.019073913677241854, 0.06722719787544763}
		},
		{
			{0.049524825190846604, -0.009238045442751235, -0.010739679061050101},
			{-0.009238045442751244, 0.02806572766273842, -0.00797355875352588},
			{-0.010739679061050111, -0.007973558753525881, 0.0192982159655722}
		},
		{
			{0.08000705661477198, -0.006061332880036105, -0.009437746774305558},
			{-0.006061332880036103, 0.0354501875892434, 0.006813132408157429},
			{-0.009437746774305556, 0.006813132408157439, 0.017084709178191503}
		},
		{
			{0.05025669650077632, -0.019438556959128293, -0.013555182980528095},
			{-0.0194385569591283, 0.04696606613133069, -0.01164770411659781},
			{-0.013555182980528097, -0.01164770411659781, 0.023074421700184193}
		},
		{
			{0.029991691919324683, -0.006480573609362821, -0.005559975238751463},
			{-0.0064805736093628205, 0.022522501429808627, -0.0019759159222207017},
			{-0.005559975238751457, -0.0019759159222207017, 0.011697845493383}
		},
		{
			{0.004434169306835047, -0.007166292984651731, 0.001982201809637908},
			{-0.007166292984651735, 0.059325404623444954, -0.045739865752381065},
			{0.001982201809637911, -0.04573986575238106, 0.04769763527970067}
		}
	};

	double barycentre[19][3] =
	{
		{166.1503469545104, 113.2521202775636, 99.5011565150347},
		{188.7107969151671, 170.7712082262211, 87.71850899742931},
		{179.78401898734177, 148.98180379746836, 186.626582278481},
		{111.42160844841592, 151.86352558895206, 203.94069861900894},
		{134.1794425087108, 170.3371080139373, 124.28571428571429},
		{196.86274509803923, 198.60588235294117, 159.66470588235293},
		{120.66354264292409, 189.0149953139644, 182.45548266166824},
		{196.1240369799692, 135.29738058551618, 130.731124807396},
		{126.5559038662487, 90.40020898641588, 51.24764890282132},
		{159.67759078830824, 182.70150575730736, 224.38618246235606},
		{90.7971586424625, 154.1767955801105, 160.83346487766377},
		{147.706, 139.922, 73.846},
		{103.34615384615384, 190.8477564102564, 232.26682692307693},
		{41.27372262773723, 31.779805352798054, 40.61070559610705},
		{100.06471183013144, 121.74823053589485, 110.79373104145601},
		{74.93991416309012, 80.28111587982832, 73.11051502145922},
		{150.66540642722117, 122.48865784499054, 154.96124763705103},
		{213.27740492170022, 126.58836689038031, 22.038031319910516},
		{33.45851528384279, 153.6768558951965, 166.86681222707423}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<19;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<19;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance20clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028640366328580694, -0.021576577165941493, -0.0019710387132346576},
		{-0.021576577165941486, 0.04292876063928064, -0.01426017638906191},
		{-0.001971038713234656, -0.014260176389061909, 0.016209822693124112}
	};

	double matrix[20][3][3] =
	{
		{
			{0.07872855333648131, -0.0048312311086666565, -0.009316643843549402},
			{-0.004831231108666656, 0.03820577349381549, 0.005597925104559952},
			{-0.0093166438435494, 0.005597925104559953, 0.017109130401827287}
		},
		{
			{0.059924125868249245, -0.022772329022437768, -0.031559830544158035},
			{-0.022772329022437768, 0.10593818134640998, -0.018996613762959743},
			{-0.031559830544158014, -0.01899661376295979, 0.06809776190015505}
		},
		{
			{0.05507988889231949, -0.032711213044605614, -0.005054406943606753},
			{-0.032711213044605614, 0.05626699290166525, -0.005754654806789567},
			{-0.005054406943606753, -0.005754654806789567, 0.010791931704155993}
		},
		{
			{0.047530418450365125, -0.021375764097392683, -0.011005389234289913},
			{-0.0213757640973927, 0.05126179668348898, -0.02233252014929171},
			{-0.011005389234289908, -0.022332520149291712, 0.0341193570319744}
		},
		{
			{0.052264809544792415, -0.014822061569198009, -0.015862266470781705},
			{-0.014822061569198013, 0.04478978677246204, -0.011159696983484395},
			{-0.015862266470781712, -0.011159696983484388, 0.02472821351940141}
		},
		{
			{0.04367353063506469, -0.008384095123559653, -0.009809472407476129},
			{-0.008384095123559657, 0.03315194281452021, -0.007608814037199044},
			{-0.009809472407476125, -0.007608814037199046, 0.016512672423520808}
		},
		{
			{0.034700357758896315, -0.024940147811047274, 3.8032908835799756E-4},
			{-0.024940147811047288, 0.07242097776503932, -0.023413529535074612},
			{3.8032908835799756E-4, -0.023413529535074615, 0.028634064678777417}
		},
		{
			{0.055867954072824105, -0.034318151366457834, 0.0020157087116661576},
			{-0.034318151366457834, 0.07596893156117306, -0.03444702701802577},
			{0.0020157087116661645, -0.03444702701802579, 0.0327912173304816}
		},
		{
			{0.0222860406720176, -0.013406257988167882, -0.0021472467867950863},
			{-0.013406257988167875, 0.044955149679792084, -0.015915830259405708},
			{-0.002147246786795079, -0.015915830259405708, 0.019988026390014825}
		},
		{
			{0.05179152189380564, -0.046991575650160426, -7.228297948992778E-4},
			{-0.04699157565016043, 0.0946230559190756, -0.017739102997866588},
			{-7.2282979489928E-4, -0.017739102997866595, 0.014332326558653503}
		},
		{
			{0.004335909112054002, -0.004151465234315838, 0.0018522838732182075},
			{-0.004151465234315839, 0.05081749403696559, -0.03863198915365581},
			{0.0018522838732182019, -0.03863198915365581, 0.046095944334392035}
		},
		{
			{0.024324657980667536, 7.930449434540104E-4, -0.004304870630585233},
			{7.930449434540095E-4, 0.0229448940365691, 0.002214174335074682},
			{-0.0043048706305852304, 0.002214174335074682, 0.0033346956874077587}
		},
		{
			{0.028180241100017316, -0.02333109605488522, 7.264047307339026E-5},
			{-0.023331096054885207, 0.04810318591140369, -0.013443976958828907},
			{7.264047307338787E-5, -0.013443976958828902, 0.014848935511108302}
		},
		{
			{0.02753866076052692, -0.02799244657596263, 0.007367446590508535},
			{-0.027992446575962622, 0.0826170921805091, -0.042100851652866124},
			{0.007367446590508538, -0.04210085165286613, 0.04006299453256324}
		},
		{
			{0.06844239324348741, -0.057553906329534915, 0.002941736555974209},
			{-0.057553906329534915, 0.09912476287344754, -0.037750393859582794},
			{0.0029417365559742032, -0.03775039385958279, 0.04347614715791169}
		},
		{
			{0.03860384421738412, -0.014556879040264014, 2.62762627790535E-4},
			{-0.014556879040264007, 0.0539888155360876, -0.011569664771597503},
			{2.627626277905326E-4, -0.011569664771597503, 0.014448303997684}
		},
		{
			{0.015084144635774416, -0.002312624669317812, -0.011244621691531407},
			{-0.002312624669317813, 0.01867931720123321, -0.0065218795246626705},
			{-0.011244621691531415, -0.0065218795246626705, 0.01688247445598791}
		},
		{
			{0.01705380959806229, -0.004334790227997831, -0.00932206081613257},
			{-0.004334790227997833, 0.039056441171830686, -0.016198805142471392},
			{-0.009322060816132577, -0.016198805142471406, 0.021448750575195796}
		},
		{
			{0.02656909496930417, -0.02227639975088958, 0.002352285526359383},
			{-0.022276399750889585, 0.061821626828991554, -0.02842342594258592},
			{0.00235228552635939, -0.028423425942585928, 0.02764816414863801}
		},
		{
			{0.05141241234402855, -0.024224946778989974, -0.003974535116826148},
			{-0.02422494677899001, 0.03323233696848095, -0.006963843617269264},
			{-0.003974535116826153, -0.006963843617269266, 0.013861254804396194}
		}
	};

	double barycentre[20][3] =
	{
		{78.47228144989339, 78.09061833688699, 71.09701492537313},
		{40.90528905289053, 31.600246002460025, 40.49569495694957},
		{196.184249628529, 187.96879643387817, 135.0178306092125},
		{185.83980181668042, 143.04789430222957, 173.952931461602},
		{150.23613963039014, 120.95893223819301, 150.91683778234085},
		{100.8361809045226, 121.98391959798995, 107.10351758793969},
		{159.83960573476702, 110.47132616487455, 96.8915770609319},
		{195.11517509727628, 132.46225680933853, 117.51050583657587},
		{92.39141630901288, 150.45407725321888, 156.71330472103006},
		{135.7306338028169, 150.15845070422534, 204.02288732394365},
		{27.372596153846153, 148.86298076923077, 155.84375},
		{204.57243816254416, 179.98233215547702, 41.38515901060071},
		{156.89769820971867, 148.45183290707587, 78.12020460358056},
		{113.2670906200318, 190.9093799682035, 236.48092209856915},
		{175.96642929806714, 185.45778229908444, 215.03967446592065},
		{128.8343949044586, 93.1135881104034, 49.34819532908705},
		{132.8318181818182, 170.33545454545455, 124.99090909090908},
		{125.34782608695652, 191.14492753623188, 182.11076604554864},
		{88.53472222222223, 166.78645833333334, 199.95659722222223},
		{216.5264797507788, 108.17757009345794, 26.29595015576324}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<20;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<20;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance21clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028745318810793494, -0.022652438926939605, -9.171330861814963E-4},
		{-0.022652438926939585, 0.043448454630016294, -0.014034622834328096},
		{-9.171330861814971E-4, -0.014034622834328098, 0.015531303417804804}
	};

	double matrix[21][3][3] =
	{
		{
			{0.05135057574014024, -0.03434807603486155, 0.004016777171759903},
			{-0.03434807603486154, 0.07795694867047377, -0.03839320408978013},
			{0.004016777171759907, -0.03839320408978014, 0.035658774953924104}
		},
		{
			{0.05295157194040511, -0.010682236440114404, -0.009739797222643173},
			{-0.010682236440114396, 0.04142475648225471, -0.0111903865994382},
			{-0.00973979722264317, -0.011190386599438206, 0.019056828664712203}
		},
		{
			{0.07780985489955271, -0.003239986183485785, -0.012060360055117306},
			{-0.0032399861834857824, 0.042227911291892704, 0.006726898304980853},
			{-0.012060360055117307, 0.006726898304980863, 0.01728183349698711}
		},
		{
			{0.04824935778102421, -0.017739439488763782, -0.013941301581821483},
			{-0.01773943948876379, 0.04543885452461886, -0.019508195623482504},
			{-0.013941301581821483, -0.01950819562348252, 0.03361371759950949}
		},
		{
			{0.022177427358812504, 4.75678479742369E-4, -0.003588055001892716},
			{4.7567847974236855E-4, 0.027613104545918303, 0.0016997437624249835},
			{-0.0035880550018927136, 0.0016997437624249846, 0.0032727446195000014}
		},
		{
			{0.01602797249036159, -0.002095229794639551, -0.011759857232802087},
			{-0.002095229794639555, 0.020243175664273406, -0.008250428592236493},
			{-0.011759857232802085, -0.008250428592236491, 0.01732476604507688}
		},
		{
			{0.02651403214367792, -0.02882392166328755, 0.008450792616947471},
			{-0.028823921663287528, 0.08221876159172942, -0.04386165880025831},
			{0.00845079261694746, -0.04386165880025831, 0.04144201501135933}
		},
		{
			{0.016772387052601916, -0.0026410980445223152, -0.01066827855904181},
			{-0.0026410980445223187, 0.03563540877425311, -0.01391048740309249},
			{-0.010668278559041813, -0.013910487403092493, 0.02031751002685521}
		},
		{
			{0.059918005320636465, -0.022772041760817943, -0.03157729961771638},
			{-0.02277204176081798, 0.10571944456991, -0.018914249934029036},
			{-0.03157729961771635, -0.01891424993402905, 0.06831486818274018}
		},
		{
			{0.0293450042367521, -0.01556625127971838, -0.004937336355335587},
			{-0.015566251279718378, 0.048892074189758127, -0.010181751009582508},
			{-0.004937336355335587, -0.010181751009582508, 0.015290166370567302}
		},
		{
			{0.0041877104698775265, -0.00394461746878437, 0.002072838269626581},
			{-0.0039446174687843595, 0.05314830890015038, -0.040929863181533105},
			{0.0020728382696265715, -0.040929863181533105, 0.047000830590754314}
		},
		{
			{0.024477629340051602, -0.019798946975922896, 0.002380030306650742},
			{-0.019798946975922896, 0.05905411741245329, -0.0291423126556765},
			{0.002380030306650735, -0.0291423126556765, 0.027883898160399694}
		},
		{
			{0.046343740712915006, -0.012190493633403604, -0.0165919132009024},
			{-0.012190493633403608, 0.04106332739986991, -0.0112777265902962},
			{-0.016591913200902402, -0.011277726590296203, 0.02627611416159499}
		},
		{
			{0.1009542225464201, -0.051069298345629975, -0.016974669054243312},
			{-0.05106929834562997, 0.054610542773045355, -7.363810349088052E-4},
			{-0.016974669054243302, -7.36381034908801E-4, 0.012400214586430699}
		},
		{
			{0.07191048740544613, -0.06940207875548099, 0.010342227666731072},
			{-0.069402078755481, 0.11817110581815692, -0.04760938336486498},
			{0.010342227666731077, -0.04760938336486496, 0.05205489141424389}
		},
		{
			{0.03556153888597323, -0.025201282055345345, -0.001167432337962967},
			{-0.025201282055345338, 0.07031532337960661, -0.023948361601974714},
			{-0.0011674323379629661, -0.023948361601974708, 0.029761088108924198}
		},
		{
			{0.02775316178730886, -0.018052251177141456, 3.8292126114040535E-4},
			{-0.018052251177141463, 0.05209215628607118, -0.018281890563413675},
			{3.8292126114040275E-4, -0.018281890563413672, 0.019763765920020084}
		},
		{
			{0.05306026468153423, -0.04718720147476306, -6.177983155860561E-4},
			{-0.0471872014747631, 0.09153889704188575, -0.0160985784089422},
			{-6.177983155860513E-4, -0.016098578408942195, 0.014816231392924395}
		},
		{
			{0.05132074884664512, -0.02422276858546216, -0.0036640492141748215},
			{-0.024222768585462167, 0.033258771432104414, -0.007091804928977698},
			{-0.0036640492141748232, -0.007091804928977706, 0.014086979768946201}
		},
		{
			{0.026760728922838317, -0.02131648969154253, -2.9022773439606186E-4},
			{-0.02131648969154254, 0.04676560567567787, -0.009171438771657842},
			{-2.902277343960584E-4, -0.009171438771657844, 0.013975299084586595}
		},
		{
			{0.03898932703188858, -0.010924843733438808, -6.403288164819553E-4},
			{-0.0109248437334388, 0.061386701769393336, -0.012753250903072895},
			{-6.403288164819555E-4, -0.012753250903072891, 0.014571267144395599}
		}
	};

	double barycentre[21][3] =
	{
		{197.80724876441516, 133.60708401976936, 123.74546952224053},
		{99.45196506550218, 116.74781659388647, 106.91703056768559},
		{77.87848383500557, 77.40022296544036, 70.07134894091416},
		{184.02735042735043, 146.8153846153846, 181.25811965811965},
		{204.77639751552795, 178.00310559006212, 45.5},
		{123.07692307692308, 166.81006647673314, 126.62108262108262},
		{110.84303797468354, 191.31223628691984, 236.0987341772152},
		{125.73673257023934, 190.93132154006244, 180.75962539021853},
		{40.7008652657602, 31.552533992583438, 40.46477132262052},
		{170.16101694915255, 170.2312348668281, 106.16101694915254},
		{26.843520782396087, 149.11491442542788, 155.7726161369193},
		{87.79815668202765, 168.22764976958524, 199.50967741935483},
		{153.27342995169082, 121.8463768115942, 151.75072463768117},
		{201.03434343434344, 197.00808080808082, 155.61414141414141},
		{168.19829424307036, 184.73773987206823, 221.77825159914713},
		{163.69109075770191, 112.1940049958368, 98.97252289758535},
		{91.21435059037239, 148.46684831970936, 158.65849227974567},
		{131.32803738317756, 149.08691588785047, 203.7981308411215},
		{216.20307692307694, 108.31384615384616, 26.56},
		{149.35162601626016, 140.1747967479675, 72.91260162601625},
		{128.15486725663717, 91.09181415929204, 49.3783185840708}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<21;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<21;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance22clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.030740223556171585, -0.02406484703583587, -0.0011438264258528546},
		{-0.024064847035835855, 0.04413259411328356, -0.012676741808301691},
		{-0.0011438264258528533, -0.012676741808301696, 0.013807988469619193}
	};

	double matrix[22][3][3] =
	{
		{
			{0.04877196639562116, -0.018246656919283677, -0.014195285306575073},
			{-0.018246656919283677, 0.04621076252879209, -0.020544835028839914},
			{-0.014195285306575081, -0.020544835028839917, 0.03470432573534998}
		},
		{
			{0.07130143743873309, -0.06773939691312841, 0.009807502913191457},
			{-0.06773939691312837, 0.11275946719309196, -0.04627731804478179},
			{0.009807502913191456, -0.04627731804478182, 0.05329089610495871}
		},
		{
			{0.016845155548932796, -0.004601484492211179, -0.009227483006646959},
			{-0.004601484492211181, 0.03995080016842802, -0.016501384159097097},
			{-0.00922748300664696, -0.016501384159097097, 0.0215482686547362}
		},
		{
			{0.051246160257977166, -0.03388828892587388, 0.003651911443145469},
			{-0.03388828892587385, 0.077930906606583, -0.03801739806013731},
			{0.0036519114431454794, -0.038017398060137306, 0.0351882693892336}
		},
		{
			{0.05428081486117162, -0.010630558613868402, -0.010418737521100804},
			{-0.010630558613868406, 0.029425805473138916, -0.007424595904577216},
			{-0.010418737521100802, -0.007424595904577209, 0.0172592831944084}
		},
		{
			{0.02942169763464081, -0.006194892709373134, -0.005454583610277893},
			{-0.006194892709373135, 0.022481923258671488, -0.002005628207841851},
			{-0.00545458361027789, -0.002005628207841853, 0.011684368552479797}
		},
		{
			{0.026890842741072105, -0.02218872211142431, 0.0030255559573130995},
			{-0.022188722111424294, 0.06209728846534987, -0.029088837429455082},
			{0.0030255559573130887, -0.029088837429455075, 0.027371612722885498}
		},
		{
			{0.052222026486350576, -0.047795439213054666, -8.556910581798915E-4},
			{-0.04779543921305472, 0.09630729182758387, -0.017018045994450996},
			{-8.556910581798919E-4, -0.01701804599445099, 0.013915252645566699}
		},
		{
			{0.046706097072608914, -0.012789659174476223, -0.01596026796554481},
			{-0.012789659174476211, 0.04574620482294452, -0.011834007506069496},
			{-0.015960267965544804, -0.011834007506069506, 0.023824238262039193}
		},
		{
			{0.00394613893407743, -0.005525257570424566, 0.0016975970845755752},
			{-0.005525257570424568, 0.05575783290224174, -0.04478622688193549},
			{0.0016975970845755787, -0.04478622688193549, 0.04642002210616222}
		},
		{
			{0.09727047581818075, -0.049364541437710914, -0.015280785836803003},
			{-0.04936454143771093, 0.054262000886933816, -0.0013010504797130273},
			{-0.015280785836803019, -0.0013010504797130295, 0.011765088547381902}
		},
		{
			{0.015285127903287793, -0.002746401902383771, -0.0113003174174033},
			{-0.0027464019023837735, 0.01913625515364131, -0.006301103080376605},
			{-0.011300317417403302, -0.0063011030803766, 0.016867089800372315}
		},
		{
			{0.02240960069663381, -0.013465812211882193, -0.00196213728950864},
			{-0.013465812211882195, 0.043578534794133886, -0.016581459616221296},
			{-0.0019621372895086355, -0.016581459616221293, 0.0200923641174275}
		},
		{
			{0.08622608957652875, -0.003817341790871537, -0.05430225144951944},
			{-0.0038173417908715403, 0.07526257304702802, 0.018756214072141793},
			{-0.05430225144951945, 0.01875621407214182, 0.05771787051479856}
		},
		{
			{0.003314511068989762, -0.0022344505649039624, 0.0025956036715732663},
			{-0.002234450564903975, 0.06584708200521804, -0.04294298973605173},
			{0.0025956036715732763, -0.04294298973605172, 0.05019165918865243}
		},
		{
			{0.03656819453418413, -0.027557052843326428, -7.895624382131443E-4},
			{-0.02755705284332644, 0.07165941532464996, -0.02370993705311617},
			{-7.895624382131547E-4, -0.02370993705311618, 0.0300168650475828}
		},
		{
			{0.04491406249184278, -0.007496320997811844, -0.012635619741594406},
			{-0.007496320997811849, 0.15969714263150206, -0.024049595201667835},
			{-0.012635619741594406, -0.02404959520166783, 0.055648302426642746}
		},
		{
			{0.026151157155306203, -0.02858153105306634, 0.008141407325951385},
			{-0.02858153105306633, 0.08240303362033527, -0.043310831571602024},
			{0.00814140732595139, -0.043310831571602024, 0.04121942779552302}
		},
		{
			{0.07563764579078681, -0.004664948559706871, -0.007004916650692492},
			{-0.004664948559706869, 0.04581634599726009, 0.006411764065466595},
			{-0.007004916650692489, 0.006411764065466601, 0.015494220766235599}
		},
		{
			{0.0390137288913345, -0.014128295210564289, -2.422293476776374E-4},
			{-0.014128295210564301, 0.062161685888326004, -0.0115077367977396},
			{-2.4222934767763695E-4, -0.011507736797739601, 0.013955436918622898}
		},
		{
			{0.027121678014194482, -0.02235669140821479, 0.001058848955738541},
			{-0.022356691408214793, 0.04824065944311968, -0.011105734816771507},
			{0.0010588489557385445, -0.01110573481677151, 0.014956228244356504}
		},
		{
			{0.03490966346028321, -0.016583613470927492, -3.071712582481821E-5},
			{-0.01658361347092749, 0.039493862014504576, -0.006475464581207117},
			{-3.0717125824817997E-5, -0.006475464581207119, 0.0100450031513748}
		}
	};

	double barycentre[22][3] =
	{
		{184.1695652173913, 146.34434782608696, 180.61478260869566},
		{168.0504731861199, 183.98948475289168, 221.78654048370137},
		{124.7497371188223, 190.96424815983175, 181.9137749737119},
		{196.37201646090534, 134.6493827160494, 126.6},
		{101.27213114754099, 120.51693989071038, 109.2655737704918},
		{213.60544217687075, 127.04761904761905, 21.839002267573697},
		{89.40469738030714, 166.78952122854562, 199.6260162601626},
		{132.60420650095602, 148.3470363288719, 202.85372848948376},
		{152.0406746031746, 121.09920634920636, 151.16468253968253},
		{30.16809116809117, 156.47008547008548, 169.980056980057},
		{198.14481409001957, 197.28375733855185, 157.28375733855185},
		{134.39103139013454, 170.52825112107624, 124.34349775784753},
		{92.36057287278854, 150.8576242628475, 155.23420387531593},
		{56.97649572649573, 40.98504273504273, 54.48290598290598},
		{28.819875776397517, 118.67701863354037, 98.52173913043478},
		{165.408393866021, 112.89911218724778, 98.21630347054077},
		{29.352534562211982, 25.65668202764977, 30.34562211981567},
		{110.69211409395973, 191.01845637583892, 236.16023489932886},
		{83.92583732057416, 79.52870813397129, 71.02990430622009},
		{129.46472564389697, 91.65845464725643, 49.90481522956327},
		{147.5753564154786, 141.14256619144604, 75.08044806517312},
		{188.49799196787149, 171.01338688085676, 86.97858099062918}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<22;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<22;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance23clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029629315960578207, -0.023415297109023812, -0.001260958469135437},
		{-0.023415297109023816, 0.04439661734246735, -0.01348682914112921},
		{-0.0012609584691354301, -0.013486829141129206, 0.0147659922745627}
	};

	double matrix[23][3][3] =
	{
		{
			{0.015906719981275422, -0.003075623720166218, -0.011620383430024006},
			{-0.003075623720166212, 0.017748145841232195, -0.0068608514737635495},
			{-0.011620383430024006, -0.006860851473763552, 0.017135702332301005}
		},
		{
			{0.015531127572071701, -0.006329112738770548, -0.0045183839710189015},
			{-0.006329112738770548, 0.0346623935033328, -0.014258031903458212},
			{-0.00451838397101891, -0.01425803190345821, 0.020751166723238908}
		},
		{
			{0.059367678332559876, -0.023156275695694378, -0.03042275257387839},
			{-0.023156275695694374, 0.10687622745825898, -0.018906213113438007},
			{-0.030422752573878373, -0.018906213113438035, 0.06739471946255748}
		},
		{
			{0.003517599650197436, -0.004959572227678533, 0.0015771596424320033},
			{-0.004959572227678545, 0.05252515710844735, -0.04437664157325499},
			{0.0015771596424320059, -0.04437664157325501, 0.047862697980264865}
		},
		{
			{0.039878712501830206, -0.012533491440492504, -6.771532150023527E-4},
			{-0.012533491440492489, 0.059766945885043894, -0.010891504864662607},
			{-6.771532150023529E-4, -0.010891504864662607, 0.013590714418101904}
		},
		{
			{0.05320360745818177, -0.04644088048800279, -0.0012895210408062148},
			{-0.04644088048800279, 0.09678646368121759, -0.017164343639787093},
			{-0.0012895210408062174, -0.017164343639787093, 0.015861476170303902}
		},
		{
			{0.03450893119175392, -0.022234836408990606, -0.002138956053587167},
			{-0.022234836408990596, 0.06531907217030493, -0.022533295112406187},
			{-0.002138956053587184, -0.02253329511240619, 0.02877799069438161}
		},
		{
			{0.0394064162175641, -0.025552424180780714, -0.0026015100480873314},
			{-0.025552424180780693, 0.055586956282167144, -0.009624651892660317},
			{-0.002601510048087329, -0.009624651892660317, 0.013610860572752802}
		},
		{
			{0.05921305371546581, -0.030430966485434023, -0.005330002855600739},
			{-0.030430966485434023, 0.037510678055947204, -0.004494179232530336},
			{-0.00533000285560074, -0.004494179232530336, 0.012383903296275301}
		},
		{
			{0.02744628359934056, -0.02263474237837745, 0.0011825675077365497},
			{-0.02263474237837745, 0.04836733677395234, -0.011483198261575487},
			{0.001182567507736548, -0.011483198261575484, 0.01429751105736429}
		},
		{
			{0.003314511068989762, -0.0022344505649039624, 0.0025956036715732663},
			{-0.002234450564903975, 0.06584708200521804, -0.04294298973605173},
			{0.0025956036715732763, -0.04294298973605172, 0.05019165918865243}
		},
		{
			{0.09942284946869956, -0.04794478391493771, -0.012063314911388512},
			{-0.04794478391493772, 0.05064907629548196, -0.0016150476230572643},
			{-0.012063314911388508, -0.0016150476230572617, 0.014701750092207201}
		},
		{
			{0.03141415098165487, -0.0246004895685902, 0.0033594694053419452},
			{-0.024600489568590178, 0.06254492539409162, -0.0295189375773813},
			{0.003359469405341947, -0.029518937577381308, 0.026702297019237195}
		},
		{
			{0.06102583835728884, -0.0168626028382513, -0.008247918002849436},
			{-0.0168626028382513, 0.03127501981883891, -0.00618129488682178},
			{-0.008247918002849436, -0.006181294886821776, 0.0152984356546095}
		},
		{
			{0.0697360776316687, -0.06037406982654164, 0.005084793009803423},
			{-0.06037406982654164, 0.10356968820949691, -0.033195804378183064},
			{0.0050847930098034295, -0.03319580437818308, 0.05053129376356429}
		},
		{
			{0.022687624449403466, -0.024644842718425593, 0.006392729419684823},
			{-0.02464484271842558, 0.07070990258470321, -0.03878805017729143},
			{0.006392729419684817, -0.03878805017729143, 0.04005915124547814}
		},
		{
			{0.04462302461999983, -0.03272815759595294, -0.00203107904005274},
			{-0.03272815759595295, 0.06709505662860217, -0.028364871984760832},
			{-0.0020310790400527496, -0.028364871984760825, 0.03371127286919852}
		},
		{
			{0.016680159668172302, -0.00483336137380395, -0.00886356584424642},
			{-0.004833361373803948, 0.03924677762743479, -0.016390569193174512},
			{-0.008863565844246421, -0.0163905691931745, 0.021614376852002296}
		},
		{
			{0.07708704640359769, -0.007393853751433527, -0.013358048821567284},
			{-0.00739385375143352, 0.04851838273076642, 0.009144728500934193},
			{-0.013358048821567292, 0.009144728500934202, 0.016992704758751996}
		},
		{
			{0.054443196441243284, -0.019897856543592524, -0.012775951346635818},
			{-0.019897856543592524, 0.052056382479905766, -0.008835692444806085},
			{-0.012775951346635832, -0.00883569244480609, 0.0162611064150985}
		},
		{
			{0.0491504817199342, -0.021791561268343092, -0.013946571136985702},
			{-0.021791561268343095, 0.0532944633901235, -0.027474716626150704},
			{-0.013946571136985705, -0.027474716626150694, 0.04403837390336392}
		},
		{
			{0.06291268136750318, -0.03746442118947123, -1.713348337222015E-4},
			{-0.03746442118947123, 0.0718459606594826, -0.032273861262156193},
			{-1.713348337222054E-4, -0.032273861262156193, 0.0341435820612317}
		},
		{
			{0.0227511564449076, 9.551748543078151E-4, -0.003745252552902072},
			{9.551748543078064E-4, 0.023936877250668405, 0.0026883805390138403},
			{-0.0037452525529020736, 0.002688380539013842, 0.00294678871921581}
		}
	};

	double barycentre[23][3] =
	{
		{129.01075268817203, 169.32649071358748, 126.20430107526882},
		{89.94881889763779, 151.3041338582677, 149.39173228346456},
		{40.488139825218475, 31.294631710362047, 40.42696629213483},
		{28.379939209726444, 156.62613981762917, 170.50759878419453},
		{129.61883408071748, 91.9932735426009, 49.07062780269058},
		{131.22893954410307, 151.99900891972248, 207.52923686818633},
		{161.42558746736293, 111.31505657093125, 102.92689295039165},
		{178.76923076923077, 173.6883963494133, 104.65319426336376},
		{217.63859649122807, 105.30877192982456, 24.743859649122808},
		{150.3956356736243, 141.37571157495256, 74.5910815939279},
		{29.36196319018405, 118.54601226993866, 99.17791411042944},
		{198.79273504273505, 198.50641025641025, 160.94017094017093},
		{89.09904430929626, 163.18940052128585, 194.3275412684622},
		{101.82387022016222, 115.94206257242179, 104.56546929316339},
		{165.1375, 188.54125, 226.025},
		{107.12016806722689, 191.17563025210083, 234.90588235294118},
		{187.1541774332472, 132.79242032730406, 150.03789836347977},
		{124.31875, 190.809375, 181.81770833333334},
		{81.21444954128441, 75.14908256880734, 68.84747706422019},
		{139.02105263157895, 122.47602339181286, 156.98245614035088},
		{180.22090729783037, 152.72090729783037, 190.9990138067061},
		{200.35809987819732, 131.6760048721072, 105.36175395858709},
		{205.06225680933852, 175.71984435797665, 32.09338521400778}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<23;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<23;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance24clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029356143703668455, -0.022477660567490038, -0.0014771193678818728},
		{-0.022477660567490062, 0.04349138461550953, -0.013910560084781504},
		{-0.001477119367881873, -0.013910560084781502, 0.0157717814731643}
	};

	double matrix[24][3][3] =
	{
		{
			{0.059460243626059756, -0.019575649706121995, -0.015678417578081714},
			{-0.01957564970612198, 0.05187827811305058, -0.008894135389781274},
			{-0.015678417578081694, -0.00889413538978128, 0.01744845322618161}
		},
		{
			{0.0351377665531367, -0.024875771301961894, 0.0021546524533428727},
			{-0.024875771301961905, 0.05976972956002098, -0.028291513608643085},
			{0.0021546524533428797, -0.028291513608643085, 0.026197223132060292}
		},
		{
			{0.02385791905298882, 0.001021669641380573, -0.00336179721203538},
			{0.0010216696413805782, 0.02409388747498209, 0.0029191355099791915},
			{-0.0033617972120353764, 0.002919135509979191, 0.0031327831847110213}
		},
		{
			{0.0038054742720384617, -0.004380931421951709, 4.2896826289747945E-4},
			{-0.004380931421951721, 0.05534784024127421, -0.04409052419241444},
			{4.2896826289748596E-4, -0.04409052419241443, 0.045997605135357944}
		},
		{
			{0.05205536702615133, -0.04651486348217712, -0.0022299736260130015},
			{-0.04651486348217712, 0.10316615071676492, -0.017108342584376393},
			{-0.002229973626013, -0.0171083425843764, 0.0152817490637333}
		},
		{
			{0.08010484681218975, -0.006185258847592452, -0.009245818023131618},
			{-0.006185258847592453, 0.04354133933644603, 0.007642771445471763},
			{-0.009245818023131616, 0.0076427714454717615, 0.016314651446282108}
		},
		{
			{0.04166919270521441, -0.009876741365952912, -0.0012088032508115506},
			{-0.009876741365952917, 0.060285370111549566, -0.011732966034914803},
			{-0.0012088032508115506, -0.01173296603491481, 0.013255884402417801}
		},
		{
			{0.014777133488459323, -0.016714546603664317, 0.004136566023278039},
			{-0.01671454660366432, 0.057154527514110216, -0.036116500727460976},
			{0.004136566023278035, -0.036116500727460976, 0.03724322328190157}
		},
		{
			{0.059367678332559876, -0.023156275695694378, -0.03042275257387839},
			{-0.023156275695694374, 0.10687622745825898, -0.018906213113438007},
			{-0.030422752573878373, -0.018906213113438035, 0.06739471946255748}
		},
		{
			{0.05851065745502761, -0.032813471287067804, -0.0010383028179271848},
			{-0.032813471287067804, 0.06727418889133346, -0.028700972955236187},
			{-0.001038302817927184, -0.028700972955236194, 0.0319117542445446}
		},
		{
			{0.027751709658603785, -0.02318754753995827, 0.001158701624156894},
			{-0.023187547539958265, 0.048311259249022964, -0.012100565079167288},
			{0.0011587016241568935, -0.012100565079167291, 0.014330418013503597}
		},
		{
			{0.016194528578510205, -0.0038420745218489915, -0.010973924957308496},
			{-0.003842074521848984, 0.03723611539719149, -0.014915797838742518},
			{-0.010973924957308494, -0.014915797838742514, 0.0207028002242719}
		},
		{
			{0.017404844260576684, -0.00612757592172091, -0.00847081007155074},
			{-0.006127575921720909, 0.029524532723803093, -0.007213472355755113},
			{-0.00847081007155074, -0.007213472355755112, 0.016846496243178605}
		},
		{
			{0.053309445673100114, -0.03785699737123716, -0.009211577451325469},
			{-0.03785699737123718, 0.0861101553319925, -0.025706549210151093},
			{-0.009211577451325486, -0.025706549210151086, 0.05635573359934118}
		},
		{
			{0.03611093740079857, -0.020275069560132274, -6.540591428946547E-4},
			{-0.020275069560132277, 0.07435562886075095, -0.0113159617467046},
			{-6.540591428946555E-4, -0.011315961746704607, 0.022310853747185305}
		},
		{
			{0.09535947392120603, -0.04810696168350767, -0.015586555758891393},
			{-0.04810696168350767, 0.0584595735398167, 3.476618713247957E-4},
			{-0.015586555758891394, 3.476618713247868E-4, 0.0105077296685121}
		},
		{
			{0.03510285186394321, -0.025132579749210914, -5.060220253284217E-4},
			{-0.02513257974921092, 0.06719945224154335, -0.023705819882350418},
			{-5.06022025328413E-4, -0.02370581988235041, 0.03109411558411729}
		},
		{
			{0.07090744370186929, -0.06566131157848284, 0.006521502957635855},
			{-0.06566131157848287, 0.1314711672846439, -0.059645820337502424},
			{0.0065215029576358545, -0.05964582033750245, 0.058622645416350976}
		},
		{
			{0.047394451004908716, -0.01993481506747089, -0.013998977066398112},
			{-0.01993481506747091, 0.05043237395483169, -0.02394755929389538},
			{-0.013998977066398112, -0.02394755929389539, 0.03899579377597681}
		},
		{
			{0.0033145109310368064, -0.002234450159884739, 0.0025956034708253008},
			{-0.0022344501598847407, 0.06584708145718768, -0.04294298914809459},
			{0.0025956034708253034, -0.04294298914809459, 0.05019165945789691}
		},
		{
			{0.05105850334869438, -0.023635752533166174, -0.004794656948199487},
			{-0.023635752533166177, 0.03274931170827048, -0.006354769474131},
			{-0.004794656948199487, -0.0063547694741310015, 0.013107811149498196}
		},
		{
			{0.05673761547660391, -0.01723143099837111, -0.008860329260977283},
			{-0.01723143099837111, 0.03760517162062883, -0.008042780072089833},
			{-0.008860329260977287, -0.00804278007208983, 0.015988462153899}
		},
		{
			{0.0442788259082044, -0.03424825739383512, -4.89771927234638E-4},
			{-0.03424825739383514, 0.07243111238044726, -0.03047630224186792},
			{-4.897719272346315E-4, -0.030476302241867887, 0.03458401206828617}
		},
		{
			{0.015225521197355294, -0.0022267438955171194, -0.009595007524245585},
			{-0.002226743895517116, 0.024014153934394003, -0.011155181884970099},
			{-0.009595007524245584, -0.011155181884970099, 0.018945718611540086}
		}
	};

	double barycentre[24][3] =
	{
		{135.3562945368171, 121.51543942992875, 155.1080760095012},
		{90.19840637450199, 159.47011952191235, 184.71713147410358},
		{203.7438596491228, 181.74035087719298, 42.03157894736842},
		{33.50761421319797, 154.98477157360406, 168.55329949238578},
		{130.4070981210856, 149.79958246346555, 204.60125260960334},
		{81.16162790697675, 75.16162790697675, 70.26860465116279},
		{124.1929203539823, 91.76637168141593, 37.74867256637168},
		{96.30549898167006, 190.4511201629328, 228.5295315682281},
		{40.58032378580324, 31.33623910336239, 40.42465753424658},
		{201.19041916167666, 139.7556886227545, 103.98203592814372},
		{153.6495145631068, 143.16990291262135, 74.11747572815534},
		{125.39895287958115, 190.95811518324606, 178.67748691099476},
		{151.35791543756145, 172.32546705998033, 117.2173058013766},
		{133.86146095717885, 183.78715365239296, 235.66624685138538},
		{139.02121212121213, 96.72575757575757, 75.23333333333333},
		{202.35021097046413, 195.51898734177215, 150.69620253164558},
		{166.8740740740741, 114.45462962962964, 108.07685185185186},
		{176.5737704918033, 189.08643815201194, 217.61847988077497},
		{179.15662650602408, 150.27911646586347, 188.6074297188755},
		{29.32515337423313, 118.46625766871166, 98.68098159509202},
		{216.29315960912052, 107.8013029315961, 24.042345276872965},
		{100.6469864698647, 118.38622386223862, 104.67650676506766},
		{187.51418439716312, 132.65248226950354, 149.38652482269504},
		{100.99612778315586, 157.90029041626332, 135.108422071636}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<24;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<24;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance25clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02904826659286132, -0.02315101531044551, -9.533232392709111E-4},
		{-0.023151015310445514, 0.04421649409358435, -0.014017897455440713},
		{-9.533232392709182E-4, -0.014017897455440718, 0.015377993747804118}
	};

	double matrix[25][3][3] =
	{
		{
			{0.07124406196940554, -0.0641876768133169, 0.00728370716154627},
			{-0.06418767681331689, 0.10907855312775498, -0.03817677911890841},
			{0.007283707161546291, -0.038176779118908426, 0.052639150095203}
		},
		{
			{0.10263966354342997, -0.051428091456586666, -0.015364347054325194},
			{-0.05142809145658663, 0.05618067983509448, -7.743210942706556E-4},
			{-0.015364347054325182, -7.743210942706478E-4, 0.0124216550529543}
		},
		{
			{0.0862850626230021, -0.007755360046735434, -0.01361817304794082},
			{-0.007755360046735438, 0.044294769260091134, 0.008779893145642011},
			{-0.013618173047940817, 0.00877989314564202, 0.0181037264768016}
		},
		{
			{0.054277232826904026, -0.018278591446652233, -0.014643959557770418},
			{-0.018278591446652254, 0.04865371484369225, -0.006972101291609845},
			{-0.014643959557770427, -0.0069721012916098436, 0.016475461349453713}
		},
		{
			{0.05230120708946124, -0.04587455626438475, -0.0015982875147365597},
			{-0.04587455626438475, 0.09677394549074676, -0.017410568957530112},
			{-0.0015982875147365601, -0.017410568957530105, 0.016417902479467616}
		},
		{
			{0.06219323449114707, -0.036025882735635055, -6.69450214305803E-4},
			{-0.0360258827356351, 0.07200836845893349, -0.03056433277497169},
			{-6.694502143058064E-4, -0.03056433277497169, 0.03251042265554687}
		},
		{
			{0.003445064119698935, -0.0026948318915718484, 0.0028703923045422654},
			{-0.0026948318915718406, 0.06658701057261873, -0.044023614011908324},
			{0.0028703923045422576, -0.044023614011908324, 0.050945008414741304}
		},
		{
			{0.03556992553765182, -0.02490648272169584, -0.0018841956436817311},
			{-0.0249064827216958, 0.06667002138700732, -0.022314182552593813},
			{-0.0018841956436817311, -0.022314182552593806, 0.029754420537471012}
		},
		{
			{0.019672083363982792, -0.0088327941632483, -0.009315242035376897},
			{-0.008832794163248297, 0.028204586486723287, -0.009662526717347535},
			{-0.009315242035376902, -0.009662526717347528, 0.018025160106187706}
		},
		{
			{0.03516083347722701, -0.016993162654660807, -2.5733031750370915E-4},
			{-0.016993162654660818, 0.07031576549829205, -0.012821026981417304},
			{-2.5733031750370394E-4, -0.012821026981417308, 0.0223108537392597}
		},
		{
			{0.028526361680592367, -0.024392797896963667, 0.0021121603887570145},
			{-0.02439279789696366, 0.06343481253985389, -0.02772009265391589},
			{0.0021121603887570162, -0.027720092653915885, 0.027626554211790184}
		},
		{
			{0.049244445394289404, -0.0224109612616707, -0.01369156031251041},
			{-0.022410961261670706, 0.05306313910489291, -0.027190605074203095},
			{-0.013691560312510407, -0.027190605074203095, 0.043911206500151706}
		},
		{
			{0.059647603425460896, -0.023435651917837495, -0.03040710958955961},
			{-0.023435651917837513, 0.1056994425909351, -0.018425948563291127},
			{-0.030407109589559618, -0.018425948563291127, 0.0675149216919653}
		},
		{
			{0.04127691081619661, -0.011042616267146423, -0.0013237825292344223},
			{-0.011042616267146414, 0.06411588374633863, -0.014134752393687295},
			{-0.0013237825292344236, -0.014134752393687305, 0.014971371135100298}
		},
		{
			{0.017499568216991303, -0.00808219406273629, -0.004261549941961161},
			{-0.008082194062736293, 0.03745001947952201, -0.015368275680871485},
			{-0.004261549941961162, -0.015368275680871485, 0.02270354875141669}
		},
		{
			{0.060287110504061964, -0.02937041672063438, -0.00247507739403541},
			{-0.029370416720634382, 0.035315068216924574, -0.0071964794327436625},
			{-0.0024750773940354063, -0.0071964794327436625, 0.012916565617612098}
		},
		{
			{0.021446710013330816, 0.0026085794740840287, -0.0037690902233310547},
			{0.0026085794740840287, 0.022377112353054687, 0.0027370619354185493},
			{-0.0037690902233310486, 0.002737061935418549, 0.002986765793002168}
		},
		{
			{0.044668531628134577, -0.032660520305953365, -0.0017794713458845163},
			{-0.032660520305953386, 0.06694612166606835, -0.028212449509924308},
			{-0.0017794713458845128, -0.0282124495099243, 0.03429411021695233}
		},
		{
			{0.0037120367779942404, -0.004770791452103164, 0.001595165534491722},
			{-0.004770791452103163, 0.0522900574298266, -0.044259059500040006},
			{0.0015951655344917182, -0.044259059500040006, 0.0478091902122171}
		},
		{
			{0.024033890360701235, -0.027747536430907535, 0.008846389515057063},
			{-0.027747536430907545, 0.07996297547326804, -0.04484720146314649},
			{0.008846389515057073, -0.044847201463146504, 0.04321752739995718}
		},
		{
			{0.09009980155118272, -0.013618921159177773, -0.013836282819241996},
			{-0.013618921159177766, 0.051898982472881466, -0.006734990872238869},
			{-0.013836282819241992, -0.006734990872238861, 0.015802649486243214}
		},
		{
			{0.014534431593399698, 9.243109352119689E-4, -0.012330403545911302},
			{9.243109352119689E-4, 0.017149833113583996, -0.006457364391787422},
			{-0.012330403545911304, -0.006457364391787422, 0.01731123681496181}
		},
		{
			{0.015927605603471204, -0.0051925875853989735, -0.007100668180795189},
			{-0.005192587585398973, 0.043632003468929016, -0.020711482868151304},
			{-0.007100668180795189, -0.020711482868151304, 0.0251547881100907}
		},
		{
			{0.030891958773654873, -0.017513557021879782, -0.004617381448331397},
			{-0.01751355702187976, 0.04566247083082718, -0.007478490412364624},
			{-0.004617381448331398, -0.007478490412364623, 0.013666673174127501}
		},
		{
			{0.03311358406771699, -0.02743322445102466, 0.003201998592132763},
			{-0.02743322445102466, 0.05190551327520539, -0.013082680239578096},
			{0.003201998592132765, -0.0130826802395781, 0.012339954613239397}
		}
	};

	double barycentre[25][3] =
	{
		{165.748730964467, 188.49111675126903, 225.9720812182741},
		{199.72899159663865, 198.5189075630252, 159.2247899159664},
		{80.53545232273838, 74.55745721271394, 69.67726161369193},
		{139.72563176895306, 122.82069795427196, 157.08182912154032},
		{131.38706467661692, 151.56019900497512, 207.08855721393036},
		{204.39528795811518, 136.93324607329842, 106.78141361256544},
		{27.55483870967742, 119.44516129032257, 98.06451612903226},
		{166.5435185185185, 114.65648148148148, 109.12685185185185},
		{118.5680693069307, 150.62871287128712, 104.60396039603961},
		{138.46074074074073, 97.99259259259259, 74.70222222222222},
		{88.96018518518518, 164.56944444444446, 196.88703703703703},
		{180.32153690596562, 153.04550050556117, 191.267947421638},
		{40.433041301627036, 31.269086357947433, 40.35419274092616},
		{121.93010752688173, 90.1415770609319, 38.261648745519715},
		{89.32822966507177, 151.12535885167463, 153.68229665071772},
		{217.63066202090593, 105.19163763066202, 25.10801393728223},
		{206.38683127572017, 177.08641975308643, 31.05349794238683},
		{187.53153153153153, 133.42612612612612, 151.44594594594594},
		{27.90432098765432, 156.8858024691358, 170.58333333333334},
		{107.77180616740088, 191.14801762114539, 236.10925110132158},
		{97.31831831831832, 109.31231231231232, 108.65165165165165},
		{131.75564409030545, 178.18725099601593, 140.15803452855246},
		{123.03837471783295, 191.8216704288939, 187.08126410835214},
		{171.36666666666667, 171.93076923076924, 103.48333333333333},
		{158.7775147928994, 139.1905325443787, 69.04378698224852}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<25;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<25;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance26clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02951933808907227, -0.02306219235341739, -0.0012398531099621776},
		{-0.023062192353417384, 0.043495099814987184, -0.0133618003847979},
		{-0.0012398531099621789, -0.013361800384797897, 0.014951895359058703}
	};

	double matrix[26][3][3] =
	{
		{
			{0.032671296183931456, -0.027076854486891483, 0.002031479240057842},
			{-0.027076854486891472, 0.05174642641188728, -0.012260461914106499},
			{0.00203147924005784, -0.012260461914106499, 0.013104022325352701}
		},
		{
			{0.03355166739837612, -0.021117725465871127, -0.0037457282253540785},
			{-0.02111772546587114, 0.06803017520500372, -0.0228550835316854},
			{-0.003745728225354089, -0.022855083531685406, 0.028633234115669988}
		},
		{
			{0.07305355760126717, -0.01458928076913358, -0.010404386580471001},
			{-0.01458928076913358, 0.055958783929001825, -0.0039501577365905075},
			{-0.010404386580471004, -0.003950157736590526, 0.013255757515925197}
		},
		{
			{0.038738419085258706, -0.00898711480802527, -0.0010931480553938763},
			{-0.008987114808025285, 0.06192800115436441, -0.013699646110251297},
			{-0.0010931480553938709, -0.013699646110251299, 0.0149389949800561}
		},
		{
			{0.024095861850383298, -0.027589871764903684, 0.009166265442710153},
			{-0.027589871764903684, 0.08220979939065465, -0.04676377732247509},
			{0.009166265442710151, -0.04676377732247509, 0.04393985600846361}
		},
		{
			{0.021784739506252176, 0.004486474114975219, -0.004671219500180358},
			{0.004486474114975211, 0.018485440318594375, 0.0027151804057407624},
			{-0.004671219500180353, 0.002715180405740767, 0.003353628153255719}
		},
		{
			{0.0482360024743036, -0.019877048723753198, -0.014321632675010004},
			{-0.019877048723753205, 0.05081772029232929, -0.026272252457497595},
			{-0.014321632675010007, -0.0262722524574976, 0.042944043428495615}
		},
		{
			{0.015105650147209774, 6.703699967661467E-4, -0.012126382280735776},
			{6.703699967661484E-4, 0.018330207416000412, -0.00622112653660766},
			{-0.012126382280735775, -0.006221126536607659, 0.01669930818863148}
		},
		{
			{0.04640332923303077, -0.008369882704319192, -0.0137123366137955},
			{-0.008369882704319192, 0.15705192771374815, -0.02264466160766638},
			{-0.013712336613795503, -0.022644661607666334, 0.056459097588676115}
		},
		{
			{0.07577421439210764, -0.06095699788000262, -0.0031228104657319723},
			{-0.06095699788000263, 0.10549709938028207, -0.025262556503702824},
			{-0.003122810465731979, -0.025262556503702824, 0.027651813501284615}
		},
		{
			{0.07099163732971425, -0.004037758850412781, -0.012195284857163504},
			{-0.004037758850412788, 0.0489303709347202, 0.00926657734905335},
			{-0.0121952848571635, 0.00926657734905335, 0.017341537801989895}
		},
		{
			{0.05133414878224935, -0.045607571200263285, -6.249218132528085E-4},
			{-0.04560757120026331, 0.1051550046805212, -0.025406679430475632},
			{-6.249218132528115E-4, -0.02540667943047561, 0.0206343798559905}
		},
		{
			{0.0035270943506545433, -0.004486739414101557, 0.0013115242263442048},
			{-0.00448673941410156, 0.05480078482344651, -0.04530116135908339},
			{0.0013115242263442091, -0.04530116135908338, 0.04806052526120017}
		},
		{
			{0.02620361142864597, -0.018299962056163646, 0.00240833902610837},
			{-0.018299962056163657, 0.05300296059595611, -0.029390583434659518},
			{0.002408339026108373, -0.029390583434659497, 0.027249482597892}
		},
		{
			{0.0552747198851809, -0.026706725144437796, -0.006106256941919813},
			{-0.026706725144437816, 0.033655852112550406, -0.004047101011911473},
			{-0.006106256941919814, -0.004047101011911473, 0.013014523054074308}
		},
		{
			{0.0123708153577517, -1.4576704960442537E-4, -0.00774587853604352},
			{-1.4576704960442884E-4, 0.02897759301428659, -0.013772123613268392},
			{-0.007745878536043518, -0.013772123613268397, 0.021774593150950705}
		},
		{
			{0.07247306657839565, -0.0646687662256417, 0.00891306045756704},
			{-0.06466876622564172, 0.1072956905670822, -0.03752848010711526},
			{0.00891306045756704, -0.03752848010711525, 0.050616151525302425}
		},
		{
			{0.002934353928287564, -0.0011868268636876377, 0.002150148913832593},
			{-0.001186826863687642, 0.06446426082080303, -0.04185963997157495},
			{0.0021501489138325927, -0.04185963997157493, 0.05150719873569913}
		},
		{
			{0.01605887354625629, -0.004642427169426901, -0.007162841183196481},
			{-0.004642427169426901, 0.04369648323527209, -0.020303234903995597},
			{-0.007162841183196481, -0.020303234903995607, 0.024653224124868}
		},
		{
			{0.048303735212822364, -0.037349251471813144, 0.0014627105407964843},
			{-0.037349251471813116, 0.0753304986699254, -0.03134758562054399},
			{0.0014627105407964774, -0.031347585620544, 0.03399850588696719}
		},
		{
			{0.10811311707824699, -0.054629062320249326, -0.015165654628770911},
			{-0.05462906232024931, 0.05686572092222422, -2.1417644730265537E-4},
			{-0.015165654628770904, -2.1417644730265537E-4, 0.0157228235573183}
		},
		{
			{0.09206403086709503, -0.0075132392274125485, -0.059338976103866},
			{-0.007513239227412562, 0.08083880172482978, 0.024158003158785708},
			{-0.05933897610386597, 0.024158003158785718, 0.054801405181854765}
		},
		{
			{0.03905316011815131, -0.0238051451495749, -0.0032039418080144016},
			{-0.023805145149574894, 0.04833279769678168, -0.00721565894439441},
			{-0.0032039418080144007, -0.0072156589443944045, 0.0130076577448092}
		},
		{
			{0.046521500336717085, -0.013986954608823605, -0.016031196330616906},
			{-0.013986954608823599, 0.05022672530822984, -0.010111303054397289},
			{-0.016031196330616913, -0.010111303054397284, 0.02174720897919491}
		},
		{
			{0.06196396849228751, -0.03633507601676354, 2.2357006998651114E-4},
			{-0.036335076016763515, 0.07076153135350965, -0.031836875403528725},
			{2.2357006998651027E-4, -0.03183687540352873, 0.03367218786017931}
		},
		{
			{0.02035259246403058, -0.01125955242738659, -0.00861311176031145},
			{-0.011259552427386594, 0.029276307104190415, -0.006978839746781191},
			{-0.008613111760311456, -0.006978839746781186, 0.0159644184759286}
		}
	};

	double barycentre[26][3] =
	{
		{157.04191616766468, 136.50419161676646, 67.1556886227545},
		{161.07978241160473, 111.63735267452402, 102.93381686310063},
		{100.3887399463807, 110.82305630026809, 107.43699731903486},
		{128.28987194412107, 90.87892898719441, 49.473806752037255},
		{108.45529197080292, 191.4589416058394, 236.71076642335765},
		{206.7905138339921, 171.89328063241106, 25.32806324110672},
		{180.77208835341366, 152.60441767068272, 190.6265060240964},
		{135.37342657342657, 179.2853146853147, 139.97342657342656},
		{29.548314606741574, 26.078651685393258, 30.674157303370787},
		{102.48079877112136, 133.45929339477726, 176.48694316436251},
		{82.72564102564102, 78.81025641025641, 69.29871794871795},
		{133.48863636363637, 153.6095041322314, 209.17252066115702},
		{29.899425287356323, 156.1293103448276, 169.47701149425288},
		{87.87058823529412, 169.31764705882352, 197.58235294117648},
		{219.67857142857142, 101.42460317460318, 26.821428571428573},
		{91.86879823594266, 157.07056229327452, 144.58213891951488},
		{166.42460317460316, 188.8716931216931, 226.2526455026455},
		{27.787096774193547, 119.10967741935484, 98.12903225806451},
		{123.94295692665891, 192.05355064027938, 186.9778812572759},
		{192.14822134387353, 135.66106719367588, 147.6304347826087},
		{200.63677130044843, 198.64349775784754, 161.5134529147982},
		{57.42163355408388, 40.52980132450331, 55.12141280353201},
		{178.853470437018, 173.8586118251928, 102.12724935732648},
		{151.61631753031975, 122.46747519294377, 153.63947078280043},
		{199.9382391590013, 130.86333771353483, 103.70565045992116},
		{126.14017521902377, 152.44555694618273, 101.85231539424281}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<26;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<26;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance27clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029519738429217245, -0.02331214338333963, -6.979633117591179E-4},
		{-0.02331214338333963, 0.04316875530692552, -0.013384190768604304},
		{-6.979633117591151E-4, -0.0133841907686043, 0.0149035678630199}
	};

	double matrix[27][3][3] =
	{
		{
			{0.02256988189935607, -0.007929175810541512, -0.011433069884814476},
			{-0.007929175810541518, 0.034110569673980205, -0.010728083206089103},
			{-0.011433069884814474, -0.010728083206089107, 0.017542561081737174}
		},
		{
			{0.021446710013330816, 0.0026085794740840287, -0.0037690902233310547},
			{0.0026085794740840287, 0.022377112353054687, 0.0027370619354185493},
			{-0.0037690902233310486, 0.002737061935418549, 0.002986765793002168}
		},
		{
			{0.0038255723347220493, -0.004686198428013199, 0.0019581580674816555},
			{-0.004686198428013202, 0.05208445514967905, -0.043626188828889405},
			{0.001958158067481658, -0.043626188828889405, 0.04667395267824489}
		},
		{
			{0.015151285630305392, -0.008069036273562041, -0.004152069770443988},
			{-0.008069036273562043, 0.0392259586748364, -0.017414135916822684},
			{-0.004152069770443986, -0.017414135916822688, 0.0234939991376473}
		},
		{
			{0.06219323449763229, -0.035998290528460784, -1.6418102634302477E-4},
			{-0.035998290528460784, 0.07130348611986637, -0.030979095611464585},
			{-1.6418102634302174E-4, -0.030979095611464585, 0.032347729354207384}
		},
		{
			{0.031822311799639576, -0.02314503747693969, 0.008857932846352577},
			{-0.023145037476939676, 0.06524690138227177, -0.016616050203859586},
			{0.008857932846352575, -0.016616050203859596, 0.014109936489144593}
		},
		{
			{0.06929297657277604, -0.05929897283016592, 0.006605744506455593},
			{-0.05929897283016592, 0.10111990409907702, -0.03508659106353672},
			{0.0066057445064556, -0.03508659106353672, 0.0542262172335177}
		},
		{
			{0.03433911689278259, -0.023980218195055233, -1.3490004756615617E-4},
			{-0.02398021819505523, 0.06710017673686934, -0.024242448480167492},
			{-1.3490004756615487E-4, -0.024242448480167492, 0.029251680724090793}
		},
		{
			{0.046893724022829535, -0.016396425627054713, -0.012441645461682912},
			{-0.016396425627054727, 0.034798859149001694, -0.0035008970500480276},
			{-0.012441645461682908, -0.003500897050048038, 0.017049646715356505}
		},
		{
			{0.029791572889088607, -0.025369878674144322, 0.0013197004037703943},
			{-0.025369878674144305, 0.0649896536983963, -0.02636855526766711},
			{0.0013197004037703952, -0.02636855526766711, 0.02753708198974211}
		},
		{
			{0.09900525228495714, -0.04770267064023761, -0.01514217738990059},
			{-0.047702670640237595, 0.05529125586082469, -6.926399392314028E-4},
			{-0.015142177389900596, -6.92639939231408E-4, 0.012419134317603699}
		},
		{
			{0.016639919866818, -0.005138052910598471, -0.008230187154285258},
			{-0.005138052910598469, 0.042945513777215304, -0.0183928836466911},
			{-0.008230187154285256, -0.018392883646691095, 0.022881959909254304}
		},
		{
			{0.049057707807894015, -0.0244071322630913, -0.012919651751382513},
			{-0.024407132263091297, 0.053931906430013325, -0.0282101302038019},
			{-0.012919651751382507, -0.028210130203801902, 0.045338580810885494}
		},
		{
			{0.05733535571215873, -0.027553872168075318, -0.0044035841010542625},
			{-0.027553872168075314, 0.034836636248105124, -0.006699645319093451},
			{-0.004403584101054263, -0.006699645319093443, 0.012472012996738297}
		},
		{
			{0.04686752943936523, -0.03257271537338471, -0.0021179240500392555},
			{-0.03257271537338468, 0.06548411291236539, -0.027305430684924414},
			{-0.0021179240500392572, -0.02730543068492441, 0.033402339200766705}
		},
		{
			{0.030565882884423426, -0.017379095052990214, -0.0053398105479968445},
			{-0.017379095052990214, 0.04653759733781083, -0.00729368039461681},
			{-0.005339810547996846, -0.007293680394616806, 0.014105032294634303}
		},
		{
			{0.003410712228350101, -0.0024775425328955976, 0.0026816730995635656},
			{-0.002477542532895598, 0.06613901497807448, -0.04306208060941947},
			{0.002681673099563566, -0.043062080609419476, 0.04959503730358737}
		},
		{
			{0.02293256542535962, -0.025439078254056616, 0.007886750160962245},
			{-0.025439078254056616, 0.07534357847771915, -0.043981758268080526},
			{0.00788675016096225, -0.04398175826808053, 0.043474979832744926}
		},
		{
			{0.052894171724944566, -0.024997900245093258, -0.00912660884148277},
			{-0.024997900245093272, 0.06889740250968467, -0.015962300632691297},
			{-0.009126608841482772, -0.015962300632691294, 0.016982449325607996}
		},
		{
			{0.10288706694272305, -0.006810327384189409, -0.02813158299146401},
			{-0.0068103273841894196, 0.05117635154998151, -0.01353692018050759},
			{-0.02813158299146402, -0.0135369201805076, 0.02107932020947461}
		},
		{
			{0.08706164198339957, -0.003557460353544095, -0.053830967345225154},
			{-0.003557460353544071, 0.06807576731462908, 0.019610512909398883},
			{-0.05383096734522508, 0.019610512909398862, 0.058736659923735945}
		},
		{
			{0.04209394799479238, -0.007354486438377225, -0.008473270628733272},
			{-0.0073544864383772324, 0.167462694001262, -0.02412056611040217},
			{-0.00847327062873329, -0.02412056611040219, 0.04976698320492644}
		},
		{
			{0.0531029868915586, -0.04690725048782275, -4.278549786928673E-4},
			{-0.046907250487822745, 0.09511000577265297, -0.022253817128475288},
			{-4.27854978692869E-4, -0.022253817128475285, 0.023617339505863297}
		},
		{
			{0.014201540558888795, 2.652021876921491E-4, -0.01200080904560749},
			{2.652021876921448E-4, 0.018123854129020484, -0.006543224108861912},
			{-0.012000809045607486, -0.0065432241088619215, 0.017395248741954472}
		},
		{
			{0.03685722298240113, -0.014375925646344403, -0.0022580802767932003},
			{-0.014375925646344403, 0.0636308176853232, -0.013137175034142207},
			{-0.002258080276793196, -0.013137175034142199, 0.0240754003926978}
		},
		{
			{0.03609443626170567, -0.029757935860424644, 0.00205925961209194},
			{-0.02975793586042464, 0.05013459589469922, -0.011238177238778502},
			{0.0020592596120919387, -0.011238177238778508, 0.013780906417921302}
		},
		{
			{0.10118999996111101, -0.01622530738303438, -4.554312335310132E-4},
			{-0.01622530738303439, 0.0558078718026692, 0.005947713871633062},
			{-4.554312335310134E-4, 0.005947713871633063, 0.018465590549910104}
		}
	};

	double barycentre[27][3] =
	{
		{113.78021978021978, 146.3186813186813, 101.24908424908425},
		{206.4814814814815, 177.25925925925927, 31.320987654320987},
		{28.817910447761193, 156.51044776119403, 170.24776119402986},
		{89.749, 152.845, 154.861},
		{203.78426395939087, 136.1763959390863, 106.55964467005076},
		{135.32008830022076, 95.20971302428256, 35.81015452538632},
		{166.0565275908479, 189.74697173620459, 226.628532974428},
		{165.6269477543538, 115.00366636113657, 112.38863428047662},
		{90.40858208955224, 84.86007462686567, 52.03917910447761},
		{89.50969529085873, 164.18190212373037, 196.9796860572484},
		{199.6304801670146, 198.53444676409185, 159.0438413361169},
		{124.15942028985508, 191.61315496098103, 185.12040133779263},
		{180.40441176470588, 154.60504201680672, 192.71008403361344},
		{218.77857142857144, 105.08571428571429, 25.207142857142856},
		{187.99007220216606, 133.95938628158845, 152.32129963898916},
		{170.9469598965071, 172.35705045278138, 103.94954721862872},
		{27.493506493506494, 119.68181818181819, 98.3961038961039},
		{106.75459558823529, 192.74356617647058, 235.77573529411765},
		{141.20933014354068, 126.54904306220095, 165.02033492822966},
		{101.14772727272727, 110.91477272727273, 123.05492424242425},
		{55.99574468085106, 40.57446808510638, 53.770212765957446},
		{29.057279236276848, 25.24343675417661, 29.804295942720763},
		{130.81364562118125, 154.9307535641548, 211.78309572301427},
		{130.74462705436156, 175.58154235145386, 136.49178255372945},
		{137.71619613670134, 97.57503714710252, 78.6225854383358},
		{159.47800925925927, 139.61574074074073, 71.14351851851852},
		{83.78252427184466, 78.06601941747573, 86.42135922330097}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<27;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<27;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance28clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029552123514858804, -0.022557977559246895, -0.001168028553719713},
		{-0.022557977559246892, 0.04356536283796014, -0.014197449440329407},
		{-0.0011680285537197144, -0.014197449440329411, 0.015699516671293493}
	};

	double matrix[28][3][3] =
	{
		{
			{0.06406401169132821, -0.031049954421967098, -0.0025885132969849607},
			{-0.03104995442196709, 0.03485944871570129, -0.006981703707224829},
			{-0.002588513296984959, -0.006981703707224835, 0.012830212408762996}
		},
		{
			{0.014981210991765595, 8.496358186753017E-4, -0.012490891160718097},
			{8.49635818675306E-4, 0.016403868653333202, -0.005563411294920316},
			{-0.012490891160718104, -0.00556341129492032, 0.016113918085504407}
		},
		{
			{0.0318042956483469, -0.022131037839479395, -0.002161750616541908},
			{-0.022131037839479388, 0.05337260373584247, -0.019730531992224198},
			{-0.0021617506165419126, -0.019730531992224215, 0.028163319159067314}
		},
		{
			{0.03536961640420243, -0.01885814951943251, -3.32383239419109E-4},
			{-0.01885814951943251, 0.0698176332907241, -0.0121386240050553},
			{-3.3238323941910466E-4, -0.0121386240050553, 0.0224893311865274}
		},
		{
			{0.04423669119188352, -0.031978021054932616, -0.002153846671132714},
			{-0.03197802105493262, 0.06616497839533945, -0.027668630333144574},
			{-0.0021538466711327167, -0.027668630333144567, 0.03404233893147338}
		},
		{
			{0.029953725137459582, -0.016353512518105087, -0.004720473505509251},
			{-0.016353512518105094, 0.04622575926526131, -0.006917445594559826},
			{-0.004720473505509247, -0.006917445594559819, 0.014163927947802399}
		},
		{
			{0.036691226697545064, -0.02356885078118719, -0.0020177558014938396},
			{-0.023568850781187187, 0.0646759500848149, -0.021340750129369583},
			{-0.002017755801493844, -0.02134075012936959, 0.0288332137331457}
		},
		{
			{0.004024668035589069, -0.005507588425278164, 0.0015103655458992837},
			{-0.00550758842527818, 0.05314233728467363, -0.04369792942501407},
			{0.0015103655458992933, -0.04369792942501406, 0.047056626132767884}
		},
		{
			{0.06075158081508311, -0.007162947893738487, -0.010529800855303499},
			{-0.007162947893738494, 0.04660043576771619, 0.0071376595781275625},
			{-0.010529800855303502, 0.007137659578127561, 0.01609863784850379}
		},
		{
			{0.05738023209472418, -0.05656573383013946, 0.002730543303743057},
			{-0.05656573383013946, 0.10454962610649389, -0.027754587298237376},
			{0.002730543303743064, -0.027754587298237376, 0.04853581395283607}
		},
		{
			{0.0577571225140407, -0.012178663585947602, -0.03792609147739209},
			{-0.012178663585947599, 0.11538622016470101, -0.03660160156554541},
			{-0.037926091477392135, -0.03660160156554539, 0.103764191081307}
		},
		{
			{0.056758131629004026, -0.010612397387945728, -0.020586820496509832},
			{-0.010612397387945734, 0.052259762144055026, -0.012329271153740485},
			{-0.02058682049650983, -0.012329271153740468, 0.022059854942658517}
		},
		{
			{0.021883236108556227, -0.011562923764231604, -0.009335425439028518},
			{-0.011562923764231611, 0.03248151623054579, -0.00789117935738528},
			{-0.009335425439028516, -0.007891179357385272, 0.01540537219931061}
		},
		{
			{0.05223544345531851, -0.04524763967837027, -0.0012142807828790206},
			{-0.045247639678370234, 0.10943241405286307, -0.0184195412613109},
			{-0.0012142807828790223, -0.018419541261310915, 0.014049800182282}
		},
		{
			{0.09124507170114687, -0.022912416661713748, -0.06458919046351767},
			{-0.022912416661713723, 0.0597471603764632, 0.025451697785043026},
			{-0.06458919046351765, 0.025451697785043012, 0.05933518001474723}
		},
		{
			{0.020419003373918214, 0.0037611157133481295, -0.0038748413239952585},
			{0.003761115713348131, 0.021070961839452493, 0.0029582555016107077},
			{-0.003874841323995259, 0.0029582555016107047, 0.0030440919093238823}
		},
		{
			{0.022531619245793704, -0.01888223742054053, 0.0021631693162941943},
			{-0.018882237420540522, 0.05874862399485201, -0.02882683033434919},
			{0.002163169316294187, -0.0288268303343492, 0.029265666257178694}
		},
		{
			{0.0136941279115937, -0.001765866566853798, -0.008978675551145034},
			{-0.0017658665668537996, 0.033194176121991506, -0.013547037169653503},
			{-0.008978675551145038, -0.013547037169653503, 0.022468189595707004}
		},
		{
			{0.0872705450164939, -0.05502032455632061, -0.010864704177478698},
			{-0.05502032455632061, 0.06942215362553218, -0.013495848975868798},
			{-0.010864704177478694, -0.013495848975868793, 0.0288524195948508}
		},
		{
			{0.03607821568659091, -0.03009689221509081, 0.0029584670158878733},
			{-0.03009689221509079, 0.05037125706892548, -0.011740285822482498},
			{0.0029584670158878694, -0.011740285822482502, 0.013310609835328994}
		},
		{
			{0.021996349740003994, -0.0237421228203982, 0.008384254535437908},
			{-0.023742122820398205, 0.07150768415351144, -0.04579035225521608},
			{0.008384254535437915, -0.0457903522552161, 0.046823672865383574}
		},
		{
			{0.06280703217583453, -0.036863930354036276, -0.0016549696742515193},
			{-0.0368639303540363, 0.07170881322141122, -0.03300609580091048},
			{-0.0016549696742515175, -0.03300609580091048, 0.0362509088395489}
		},
		{
			{0.04839381542522594, -0.021586031202608102, -0.013835263606200581},
			{-0.02158603120260809, 0.051789786675278705, -0.02524797875919471},
			{-0.013835263606200575, -0.02524797875919472, 0.04103925144781237}
		},
		{
			{0.0413065920033653, -0.010926159042896462, 0.0024899532091245914},
			{-0.010926159042896462, 0.06588921756761051, -0.016025042428706605},
			{0.0024899532091245914, -0.016025042428706608, 0.013335326378868705}
		},
		{
			{0.015876672601695983, -0.0047721284137174835, -0.007399906153908006},
			{-0.0047721284137174835, 0.0416610155908155, -0.018953166497560504},
			{-0.007399906153908003, -0.018953166497560507, 0.02450996077966089}
		},
		{
			{0.08348520942875047, -0.020566388286112187, -0.005244404559180686},
			{-0.020566388286112215, 0.0937514710382353, -0.005723167151125327},
			{-0.005244404559180691, -0.005723167151125329, 0.010683209279097198}
		},
		{
			{0.08977038400270732, -0.04260574635731564, -0.007853355651038934},
			{-0.04260574635731566, 0.05819251025688164, -6.817204232327041E-4},
			{-0.007853355651038937, -6.817204232327037E-4, 0.008666951315101838}
		},
		{
			{0.0037230270604719394, -0.0031615493989069305, 0.002909967983782957},
			{-0.0031615493989069344, 0.06489334178963702, -0.04398957232501101},
			{0.0029099679837829603, -0.04398957232501102, 0.051068421879106214}
		}
	};

	double barycentre[28][3] =
	{
		{218.11888111888112, 105.43006993006993, 25.36013986013986},
		{131.97215189873418, 177.5873417721519, 138.9987341772152},
		{93.401614530777, 156.8476286579213, 172.50353178607466},
		{138.1671826625387, 96.58204334365325, 72.85139318885449},
		{186.87762557077625, 132.63470319634703, 150.57077625570776},
		{171.18241469816272, 170.9750656167979, 103.17847769028872},
		{164.5830078125, 114.015625, 107.931640625},
		{30.56179775280899, 156.34550561797752, 170.23595505617976},
		{85.39488636363636, 80.8778409090909, 64.27556818181819},
		{147.05679012345678, 181.53456790123457, 228.47407407407408},
		{32.7032967032967, 28.084249084249084, 32.93589743589744},
		{137.49439601494396, 121.46326276463263, 154.2129514321295},
		{124.30290456431536, 148.26417704011064, 97.33333333333333},
		{129.6712962962963, 147.33333333333334, 203.15162037037038},
		{62.49278846153846, 43.75, 63.22596153846154},
		{207.36051502145924, 178.38197424892704, 30.532188841201716},
		{87.89798488664988, 169.28715365239296, 207.35642317380353},
		{89.71656976744185, 148.6671511627907, 131.98401162790697},
		{188.4581497797357, 194.3876651982379, 212.89647577092512},
		{161.18997361477574, 139.4036939313984, 68.07387862796834},
		{105.59666666666666, 193.46, 236.8011111111111},
		{201.84954604409856, 132.6887159533074, 106.69130998702983},
		{178.67198404785643, 151.21136590229312, 189.54336989032902},
		{127.4304347826087, 92.59347826086956, 34.356521739130436},
		{124.55209580838323, 192.88862275449102, 186.83712574850298},
		{97.18121911037892, 103.52388797364085, 106.11037891268533},
		{205.8337182448037, 192.09468822170902, 145.4503464203233},
		{26.10810810810811, 118.91216216216216, 97.14189189189189}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<28;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<28;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance29clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029349705304406514, -0.02250304005916331, -0.0010682515667267923},
		{-0.02250304005916331, 0.045819980543964335, -0.015654578349617015},
		{-0.0010682515667267958, -0.015654578349617018, 0.016674949519050204}
	};

	double matrix[29][3][3] =
	{
		{
			{0.06551094407810477, -0.03121001845526583, -0.002707929585513983},
			{-0.03121001845526581, 0.07719894880641984, -0.017035327076034616},
			{-0.002707929585513971, -0.0170353270760346, 0.0350359098821388}
		},
		{
			{0.06291990359996022, -0.034284987660751, -0.0032238157514868165},
			{-0.034284987660750985, 0.056903673682071755, -0.02040320367067029},
			{-0.003223815751486814, -0.020403203670670285, 0.027573717419429093}
		},
		{
			{0.0622682610563811, -0.05639621255790271, -0.001519175088618934},
			{-0.05639621255790271, 0.10526909113266897, -0.014961297708763494},
			{-0.0015191750886189353, -0.014961297708763498, 0.0145167435818484}
		},
		{
			{0.05946752979352697, -0.02284776247055106, -0.03061198061479308},
			{-0.022847762470551085, 0.10753254138257097, -0.019254387170834213},
			{-0.03061198061479308, -0.01925438717083422, 0.0674097670282411}
		},
		{
			{0.01644890579729361, -0.0021500401758193614, -0.0111570851469162},
			{-0.0021500401758193606, 0.03930778072673309, -0.015945965191693893},
			{-0.011157085146916199, -0.015945965191693896, 0.020965326560851885}
		},
		{
			{0.05567910882146848, -0.028801035798533468, -0.0072540499695953374},
			{-0.028801035798533478, 0.03721359495569736, -0.002919552561456341},
			{-0.00725404996959534, -0.0029195525614563347, 0.013609815916868504}
		},
		{
			{0.01611834572536139, -0.007873656057351672, -0.004005128603359193},
			{-0.007873656057351668, 0.03709481780123339, -0.01688042547258021},
			{-0.004005128603359189, -0.016880425472580205, 0.023532480341034796}
		},
		{
			{0.04823296689861607, -0.016560364063158813, -0.013427848023979696},
			{-0.0165603640631588, 0.059470320232690506, -0.0060079359243033655},
			{-0.0134278480239797, -0.006007935924303367, 0.01178316069468261}
		},
		{
			{0.0034085098886893813, -0.0049858370933144325, 0.0013912686663789418},
			{-0.004985837093314438, 0.05302288782990956, -0.04477599985070446},
			{0.0013912686663789461, -0.044775999850704476, 0.0484565428924016}
		},
		{
			{0.042491277619901895, -0.011625955538806545, -0.0035134884715154963},
			{-0.011625955538806534, 0.054443233095532534, -0.007002356398828139},
			{-0.0035134884715154946, -0.00700235639882814, 0.015492933183217003}
		},
		{
			{0.024033497137676718, -0.018037537036866405, -0.0026810443018199285},
			{-0.018037537036866405, 0.04513205537134243, -0.009726916793630656},
			{-0.0026810443018199306, -0.009726916793630653, 0.017225665224407296}
		},
		{
			{0.04690665355069883, -0.017770284741029728, -0.008597457836965743},
			{-0.01777028474102972, 0.04754208830661751, -0.0106955945194654},
			{-0.008597457836965744, -0.01069559451946539, 0.0180506073682341}
		},
		{
			{0.03349505455400008, -0.018655818165821993, -0.00932535676034719},
			{-0.01865581816582199, 0.03715615445561413, -4.278821470951046E-5},
			{-0.00932535676034719, -4.278821470950775E-5, 0.009191185759543806}
		},
		{
			{0.0878579025994339, -0.004375443050445781, -0.012327543494718896},
			{-0.004375443050445783, 0.05167835327121089, 0.011305500703499395},
			{-0.012327543494718898, 0.011305500703499402, 0.017753287027675292}
		},
		{
			{0.05277432785826249, -0.023571537514728208, -0.010213281732510496},
			{-0.023571537514728194, 0.05657311875773122, -0.02678959180913559},
			{-0.010213281732510501, -0.02678959180913558, 0.039858288587876003}
		},
		{
			{0.016977166626290407, -0.01846450763357191, 0.005843585162758959},
			{-0.018464507633571905, 0.06306547230375104, -0.04192198005267331},
			{0.00584358516275896, -0.04192198005267331, 0.04314098646175119}
		},
		{
			{0.015785783202875703, -0.0013851747751009837, -0.011956161102335707},
			{-0.001385174775100995, 0.01952742706072161, -0.008204676904034598},
			{-0.011956161102335702, -0.008204676904034602, 0.017580799235458293}
		},
		{
			{0.023531482262397672, 0.0026604183427858946, -0.003233621506318174},
			{0.0026604183427858938, 0.020269299976143185, 0.0024875120296458187},
			{-0.003233621506318171, 0.0024875120296458204, 0.0031208346639256083}
		},
		{
			{0.028930628597977934, -0.014865349341731136, -0.0038725461846961413},
			{-0.014865349341731143, 0.04480198350613831, -0.007995229606415846},
			{-0.0038725461846961426, -0.007995229606415851, 0.014595973320126094}
		},
		{
			{0.047862926561839374, -0.04176445777681601, 0.00599033024751771},
			{-0.04176445777681598, 0.05827113288464064, -0.009226622392945525},
			{0.0059903302475177046, -0.009226622392945524, 0.002479241459838791}
		},
		{
			{0.026883449917681396, -0.020975645625512702, 0.0026003446367271407},
			{-0.02097564562551271, 0.0577684553313319, -0.028570251101741915},
			{0.002600344636727139, -0.02857025110174191, 0.027857999934218985}
		},
		{
			{0.11874115907008402, -0.06094016025826495, -0.02066916970234032},
			{-0.06094016025826491, 0.07434561390568634, -0.012380874372876292},
			{-0.02066916970234031, -0.012380874372876306, 0.029839577306243294}
		},
		{
			{0.0674635684500385, -0.02214246629964531, -0.014505343437838181},
			{-0.0221424662996453, 0.048225457831547386, -0.010545052760939793},
			{-0.014505343437838167, -0.010545052760939798, 0.02528100005067481}
		},
		{
			{0.08652138797559229, -0.04705648756821353, -6.66382896410516E-4},
			{-0.04705648756821352, 0.07735710189115443, -0.02596722251565551},
			{-6.663828964105216E-4, -0.025967222515655506, 0.02415321624461908}
		},
		{
			{0.003361626922912318, -0.0025590501989164673, 0.002815851234277763},
			{-0.0025590501989164608, 0.06643882612666828, -0.04402510754522119},
			{0.0028158512342777563, -0.04402510754522119, 0.05222151916109639}
		},
		{
			{0.035315879383031996, -0.024164683523663792, 0.0011068818153271882},
			{-0.024164683523663816, 0.06786793956416208, -0.022000083490031092},
			{0.0011068818153271917, -0.02200008349003109, 0.028369268361483686}
		},
		{
			{0.0562907822399142, -0.04605656828199138, -0.0064983575573031895},
			{-0.04605656828199136, 0.10854836892348586, -0.03130828060291461},
			{-0.006498357557303196, -0.031308280602914594, 0.06945630446897381}
		},
		{
			{0.05355668115269032, -0.03641765604174981, -0.0062607890890375995},
			{-0.0364176560417498, 0.06384885924723083, -0.030679381185234302},
			{-0.0062607890890375995, -0.030679381185234313, 0.0457921935509077}
		},
		{
			{0.03349717156623304, -0.0207480107016218, -0.0023503172909845904},
			{-0.020748010701621807, 0.06275514664517853, -0.02966741889068569},
			{-0.002350317290984584, -0.029667418890685693, 0.0341728697000031}
		}
	};

	double barycentre[29][3] =
	{
		{117.92038216560509, 162.4108280254777, 226.13694267515925},
		{196.21711568938193, 127.14738510301109, 90.82408874801902},
		{121.16913946587538, 142.12166172106825, 193.78635014836794},
		{40.21166032953105, 31.125475285171103, 39.953105196451205},
		{124.15205327413985, 190.35183129855716, 180.7447280799112},
		{220.05384615384617, 105.8076923076923, 21.23076923076923},
		{86.90628328008519, 151.43876464323748, 154.35889243876466},
		{161.58220211161387, 131.06485671191552, 170.62745098039215},
		{26.51779935275081, 157.25242718446603, 170.8640776699029},
		{121.05151915455747, 86.28401585204756, 53.77410832232497},
		{143.20981595092024, 142.08220858895706, 78.66993865030675},
		{96.72998643147896, 115.92672998643148, 104.8303934871099},
		{176.40848806366049, 197.71352785145888, 141.12466843501326},
		{78.64930114358323, 73.53240152477764, 70.2274459974587},
		{193.863173216885, 141.86899563318778, 167.6957787481805},
		{100.87945879458795, 196.99630996309963, 233.9741697416974},
		{122.85311871227364, 166.52213279678068, 126.25855130784709},
		{206.18595041322314, 179.82644628099175, 35.12809917355372},
		{170.5639614855571, 169.08803301237964, 98.37551581843191},
		{152.80747126436782, 117.80172413793103, 37.24425287356322},
		{87.70386740331492, 169.12486187845303, 194.49171270718233},
		{198.01652892561984, 200.19559228650138, 202.70247933884298},
		{128.30755395683454, 118.41007194244604, 147.39028776978418},
		{207.79739776951672, 155.64684014869889, 130.45910780669146},
		{27.63225806451613, 119.2516129032258, 98.58064516129032},
		{154.28520710059172, 107.60591715976331, 95.98461538461538},
		{148.43679775280899, 189.0, 230.50842696629215},
		{172.1961259079903, 160.68886198547216, 202.99031476997578},
		{177.5770065075922, 121.95661605206074, 128.89154013015184}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<29;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<29;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance30clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.0297125888748754, -0.021462034026981183, -0.0020771159864602226},
		{-0.021462034026981207, 0.0403195534516849, -0.0113524751247102},
		{-0.0020771159864602217, -0.011352475124710196, 0.0136145076613326}
	};

	double matrix[30][3][3] =
	{
		{
			{0.109288355068324, -0.054980846821448395, -0.016421755835895002},
			{-0.0549808468214484, 0.050213570107987854, -2.6955005906878146E-4},
			{-0.01642175583589501, -2.695500590687832E-4, 0.01662325921703171}
		},
		{
			{0.06219323447652274, -0.036627289643043404, 4.6022855325050056E-4},
			{-0.036627289643043404, 0.07109433021179837, -0.03198836165122042},
			{4.6022855325050186E-4, -0.03198836165122039, 0.032939353193266}
		},
		{
			{0.00244376682494099, -6.470805912300562E-4, 7.117096029304847E-4},
			{-6.470805912300655E-4, 0.0643361842482713, -0.04105445110741702},
			{7.117096029304963E-4, -0.04105445110741702, 0.04854470786491932}
		},
		{
			{0.018620350895668412, -0.013088517234035604, -0.0031030691228544753},
			{-0.013088517234035613, 0.06368737642067948, -0.02792412007113983},
			{-0.0031030691228544688, -0.02792412007113982, 0.027571105817441023}
		},
		{
			{0.043286163674222264, -0.007056436603668607, -0.011511836458015722},
			{-0.007056436603668614, 0.04634386295463932, 8.75236156583914E-5},
			{-0.011511836458015713, 8.752361565838446E-5, 0.017302453846139713}
		},
		{
			{0.05006777913186525, -0.04923305606363895, 0.0038958132084365975},
			{-0.04923305606363892, 0.11553700876814986, -0.02716729678379258},
			{0.003895813208436598, -0.02716729678379258, 0.014633949673842399}
		},
		{
			{0.0035967250554539976, -0.004850636426771864, 0.0011602097460969162},
			{-0.004850636426771847, 0.05247949847473668, -0.04476159851184659},
			{0.001160209746096914, -0.044761598511846606, 0.04876824270652641}
		},
		{
			{0.03149240989321944, -0.02628355000591477, 0.002382943034007238},
			{-0.02628355000591479, 0.050402327438035605, -0.013693126644642405},
			{0.0023829430340072425, -0.013693126644642398, 0.015261589403786103}
		},
		{
			{0.035130075935056876, -0.02150439623146919, -0.002524067649937678},
			{-0.0215043962314692, 0.06757427254690763, -0.02437901354230732},
			{-0.0025240676499376736, -0.024379013542307315, 0.03068453042125762}
		},
		{
			{0.04083726893728792, -0.015814042640688912, 0.0026102492524834216},
			{-0.01581404264068892, 0.03634024663866231, -0.005218674618743303},
			{0.002610249252483421, -0.005218674618743302, 0.007828575308621757}
		},
		{
			{0.08506669346676513, -0.0031154713915760163, -0.05160238386748027},
			{-0.003115471391576023, 0.06783857910798766, 0.019100491774277643},
			{-0.0516023838674803, 0.019100491774277653, 0.057257158466102964}
		},
		{
			{0.02064193642899441, -0.021568496529712107, 0.006193126145732227},
			{-0.021568496529712104, 0.06696992548284779, -0.04354631349005716},
			{0.006193126145732223, -0.04354631349005716, 0.0444599687778041}
		},
		{
			{0.05742797830984551, -0.028664198096245395, -0.00440666832124554},
			{-0.0286641980962454, 0.03634704030504159, -0.006016838380907665},
			{-0.004406668321245541, -0.006016838380907663, 0.012466930263715311}
		},
		{
			{0.050201389965376916, -0.01408702729056181, -0.01661726828784381},
			{-0.014087027290561804, 0.0427051283446383, -0.010813630991135508},
			{-0.016617268287843795, -0.010813630991135512, 0.025851774318340192}
		},
		{
			{0.0344199471693505, -0.018753253872591392, 0.0014485895542332794},
			{-0.018753253872591392, 0.07323018339922267, -0.007602479151045557},
			{0.0014485895542332783, -0.007602479151045555, 0.018209078191544104}
		},
		{
			{0.04706172998754831, -0.010621336060771404, -0.013585630823408123},
			{-0.0106213360607714, 0.16140566177969706, -0.018095719753685714},
			{-0.013585630823408114, -0.018095719753685693, 0.05054897457379052}
		},
		{
			{0.07588917734373825, -0.06263091388491311, -0.0060071753222346955},
			{-0.06263091388491314, 0.11064374441171006, -0.03382890180948893},
			{-0.0060071753222346895, -0.0338289018094889, 0.03175887060000309}
		},
		{
			{0.09658409766738897, -0.013575505759414795, -0.00219629892758753},
			{-0.013575505759414805, 0.06976947236867612, 0.009764995671338145},
			{-0.002196298927587529, 0.009764995671338142, 0.017670077896591408}
		},
		{
			{0.06893004672306777, -0.05734412614852499, 0.005581195964571125},
			{-0.057344126148524986, 0.09455585034930651, -0.03193983739559932},
			{0.005581195964571135, -0.03193983739559934, 0.05210400117643921}
		},
		{
			{0.040195166583683585, -0.040589593576648285, 0.009157426089974613},
			{-0.040589593576648306, 0.07003609663739607, -0.010746309365872805},
			{0.009157426089974614, -0.010746309365872803, 0.004640334505749403}
		},
		{
			{0.04840414545723113, -0.018735999759355103, -0.016142897251115913},
			{-0.018735999759355096, 0.0574017152984687, -0.034157005323524496},
			{-0.016142897251115902, -0.03415700532352452, 0.05153289404050611}
		},
		{
			{0.010068385273987198, -0.0018123837295239494, -0.007303939994241827},
			{-0.0018123837295239476, 0.028737831231277607, -0.01340399247214321},
			{-0.007303939994241828, -0.013403992472143196, 0.022780846439845192}
		},
		{
			{0.06618279393257784, -0.049251614918273325, -0.003092093433470322},
			{-0.049251614918273325, 0.08364050528075449, -0.022903665674695806},
			{-0.003092093433470327, -0.022903665674695803, 0.03606230454851531}
		},
		{
			{0.048565872338701, -0.03916943723181669, 0.0024854459077668927},
			{-0.039169437231816706, 0.07911307956593124, -0.03432706931748792},
			{0.0024854459077668883, -0.03432706931748791, 0.035851358875983404}
		},
		{
			{0.027243396262682483, -0.013380243288024318, -0.006044961401605936},
			{-0.013380243288024316, 0.050684951300023, -0.010385937140912804},
			{-0.006044961401605948, -0.0103859371409128, 0.016056011767963403}
		},
		{
			{0.013829944817330995, 0.0014330148902526353, -0.011834756621487096},
			{0.0014330148902526336, 0.017810128006268185, -0.006657470642080231},
			{-0.011834756621487096, -0.00665747064208023, 0.0166592005218581}
		},
		{
			{0.026395242028122417, -0.019060676195070625, 0.0012554271417443068},
			{-0.019060676195070618, 0.05643240586166286, -0.027429867304990523},
			{0.0012554271417442992, -0.027429867304990533, 0.026260126112707803}
		},
		{
			{0.0223820672533585, -0.011850221713831884, -0.009506781115680532},
			{-0.011850221713831894, 0.02904345585666838, -0.007997218651637274},
			{-0.009506781115680532, -0.007997218651637283, 0.017252877738162694}
		},
		{
			{0.0212638095431631, 0.003721436356655769, -0.006295048817825342},
			{0.003721436356655776, 0.013955287662819407, 0.00164731698735607},
			{-0.006295048817825351, 0.0016473169873560635, 0.006698766825437908}
		},
		{
			{0.08435007862261085, -0.009436546294244993, -0.013558558692208322},
			{-0.009436546294244973, 0.07951962884202536, -0.008682700312222395},
			{-0.013558558692208305, -0.008682700312222413, 0.015111934012008603}
		}
	};

	double barycentre[30][3] =
	{
		{198.95515695067266, 198.34977578475338, 162.16816143497758},
		{200.3382949932341, 131.46143437077131, 104.09878213802436},
		{27.215686274509803, 119.25490196078431, 97.79084967320262},
		{127.31439894319684, 194.10303830911494, 189.63804491413475},
		{92.87758945386064, 84.53860640301318, 49.410546139359695},
		{144.5816733067729, 148.30013280212484, 198.0},
		{28.72072072072072, 156.78378378378378, 171.12612612612614},
		{158.33495736906212, 141.17904993909866, 70.0925700365408},
		{163.63402571711177, 113.44609297725025, 104.88229475766568},
		{205.3370786516854, 186.45318352059925, 82.40074906367042},
		{55.65665236051502, 40.5, 53.71030042918455},
		{103.48871331828443, 196.5372460496614, 235.8882618510158},
		{220.86885245901638, 100.60655737704919, 28.204918032786885},
		{152.3728423475259, 121.85615650172612, 151.81357882623706},
		{135.4454409566517, 93.12855007473841, 68.44544095665172},
		{29.04306220095694, 25.198564593301434, 29.772727272727273},
		{102.9904912836767, 132.7908082408875, 177.32171156893818},
		{82.55179282868527, 75.69721115537848, 84.58366533864542},
		{167.27434842249656, 189.06310013717422, 226.90672153635117},
		{140.234126984127, 102.44047619047619, 24.543650793650794},
		{184.44586728754365, 153.22933643771827, 189.9359720605355},
		{87.56771545827634, 152.93023255813952, 141.2298221614227},
		{119.6278755074425, 163.77807848443842, 226.54803788903925},
		{192.70924195223262, 135.49428868120458, 147.9896157840083},
		{166.85041551246536, 169.74653739612188, 110.11357340720221},
		{128.68552631578947, 178.2828947368421, 143.5236842105263},
		{90.41787003610108, 169.6254512635379, 189.99909747292418},
		{121.20770288858321, 150.74828060522697, 102.74690508940853},
		{206.09677419354838, 167.3709677419355, 12.989247311827956},
		{100.8375796178344, 111.40286624203821, 109.36146496815287}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<30;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<30;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance31clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029573423616728507, -0.022469738524847002, -9.72019423696222E-4},
		{-0.022469738524847006, 0.04228643172704538, -0.012616842672894701},
		{-9.72019423696223E-4, -0.012616842672894694, 0.014258569997777209}
	};

	double matrix[31][3][3] =
	{
		{
			{0.0037230270604719394, -0.0031615493989069305, 0.002909967983782957},
			{-0.0031615493989069344, 0.06489334178963702, -0.04398957232501101},
			{0.0029099679837829603, -0.04398957232501102, 0.051068421879106214}
		},
		{
			{0.014322159869395123, -0.01818204937742902, 0.0050760003452418965},
			{-0.018182049377429017, 0.06213381574971954, -0.03930648874833389},
			{0.005076000345241902, -0.03930648874833388, 0.040376169851680695}
		},
		{
			{0.07535158858941855, -0.07148026549202076, 0.01331283784480835},
			{-0.07148026549202076, 0.13760342545425608, -0.06018289999412576},
			{0.013312837844808334, -0.060182899994125745, 0.05898591094038204}
		},
		{
			{0.05774686847928508, -0.025777148441376786, -0.00402774305195206},
			{-0.025777148441376786, 0.028520577025504215, -0.0058936349415109925},
			{-0.004027743051952059, -0.005893634941510998, 0.012568761819805891}
		},
		{
			{0.053142068157375745, -0.028364049268844508, -0.0021160783680932555},
			{-0.028364049268844515, 0.04527753958205519, -0.007571455806570683},
			{-0.002116078368093258, -0.007571455806570688, 0.008407803356571809}
		},
		{
			{0.051970246698981135, -0.04515756670439236, -0.004767516604419949},
			{-0.045157566704392346, 0.0958253737703697, -0.011308243139559608},
			{-0.0047675166044199545, -0.011308243139559611, 0.014349252845013302}
		},
		{
			{0.018253939266665187, -0.007652892221031433, -0.004603639716117335},
			{-0.007652892221031433, 0.04878378167719561, -0.024236316031351297},
			{-0.0046036397161173396, -0.024236316031351297, 0.027353269940995708}
		},
		{
			{0.09780728151615069, -0.0285878492802457, -0.011959902329916294},
			{-0.02858784928024571, 0.040699073733055084, -0.0066892644838153804},
			{-0.011959902329916295, -0.00668926448381538, 0.016485027828484496}
		},
		{
			{0.01845519347059641, -0.007549632274686052, -0.004281326920832747},
			{-0.007549632274686054, 0.03673998450267188, -0.015279155455988111},
			{-0.004281326920832744, -0.015279155455988118, 0.0211616032257623}
		},
		{
			{0.0502386686511869, -0.036454119109543985, -0.007895786309299546},
			{-0.03645411910954397, 0.08997064640720341, -0.0371993657501778},
			{-0.007895786309299543, -0.03719936575017781, 0.07270718155215514}
		},
		{
			{0.024280143814120022, 7.936997851481784E-4, -0.004407343574885081},
			{7.93699785148178E-4, 0.023005669598744005, 0.002294058845752488},
			{-0.004407343574885077, 0.0022940588457524887, 0.0032783605670097227}
		},
		{
			{0.0577571225140407, -0.012178663585947602, -0.03792609147739209},
			{-0.012178663585947599, 0.11538622016470101, -0.03660160156554541},
			{-0.037926091477392135, -0.03660160156554539, 0.103764191081307}
		},
		{
			{0.012754492267511503, 0.0012822089735457986, -0.011902411713785501},
			{0.0012822089735457943, 0.017006308617862387, -0.0071233291434382945},
			{-0.011902411713785503, -0.007123329143438293, 0.017788351345982688}
		},
		{
			{0.05256978770895316, -0.020266036811613992, -0.0129166379754844},
			{-0.02026603681161398, 0.060070158132674314, -0.009538504027395905},
			{-0.012916637975484388, -0.009538504027395896, 0.016469205617614807}
		},
		{
			{0.03117114208873161, -0.01473558465432119, -0.014137284084876299},
			{-0.0147355846543212, 0.0251381476469193, 1.5404946094543792E-4},
			{-0.014137284084876297, 1.5404946094542925E-4, 0.017082834685544203}
		},
		{
			{0.027450079692507193, -0.013337681774465971, -0.006498716333319535},
			{-0.013337681774465971, 0.0503530545732865, -0.01059417660396189},
			{-0.006498716333319532, -0.010594176603961883, 0.015740276127513896}
		},
		{
			{0.032445580466561985, -0.02347094192151907, 0.0019959866675831354},
			{-0.023470941921519068, 0.05703148802437922, -0.027990720068698287},
			{0.0019959866675831424, -0.027990720068698287, 0.0280593228953069}
		},
		{
			{0.03854402145172286, -0.02245802174190896, -0.003205484033801509},
			{-0.022458021741908987, 0.06316619024478354, -0.023186169810504403},
			{-0.0032054840338015048, -0.023186169810504406, 0.030341557067572012}
		},
		{
			{0.061851114846826934, -0.036303714173183246, -9.073275365779144E-4},
			{-0.03630371417318323, 0.0742936896445889, -0.030633682978496408},
			{-9.073275365779196E-4, -0.030633682978496397, 0.0327021675888161}
		},
		{
			{0.037196320296169344, -0.03143150506551663, 0.0026841677258424125},
			{-0.03143150506551663, 0.05810760517489514, -0.014851290804644915},
			{0.0026841677258424112, -0.014851290804644918, 0.0203412848366768}
		},
		{
			{0.12248518060002407, -0.06274221516884744, -0.021252714623758207},
			{-0.06274221516884743, 0.08738068819222956, -0.01882487539230569},
			{-0.021252714623758214, -0.018824875392305686, 0.025982903650876316}
		},
		{
			{0.08992912661424311, -0.025373334107365392, -0.06387488835171026},
			{-0.02537333410736541, 0.07358677335674053, 0.024259798823576706},
			{-0.06387488835171026, 0.0242597988235767, 0.05845002946868417}
		},
		{
			{0.022751012350377797, -0.012088380861775813, -0.009550784006584767},
			{-0.012088380861775806, 0.03101964246212822, -0.009626201866518554},
			{-0.009550784006584776, -0.009626201866518549, 0.01703388596441019}
		},
		{
			{0.03933562645918162, -0.012335883225757984, -2.23934047111406E-4},
			{-0.012335883225757974, 0.06723746672118933, -0.013162514164376297},
			{-2.2393404711140838E-4, -0.013162514164376294, 0.016987555907655494}
		},
		{
			{0.048995314998255504, -0.023071652471555206, -0.012965873329203516},
			{-0.02307165247155521, 0.0518789466822623, -0.02505428034103519},
			{-0.012965873329203521, -0.025054280341035188, 0.04080865058306131}
		},
		{
			{0.029049154390527493, -0.022708450836519792, -3.128243530163299E-4},
			{-0.02270845083651981, 0.04220325956171932, -0.010550228169197795},
			{-3.128243530163238E-4, -0.010550228169197796, 0.013838413447618091}
		},
		{
			{0.0204988198268821, -0.004807577122420414, -0.006893555485064675},
			{-0.004807577122420415, 0.02682965822484538, -0.003962907929933237},
			{-0.006893555485064673, -0.003962907929933239, 0.010948191413427196}
		},
		{
			{0.0035830593225851274, -0.004901712723282123, 0.001600746036734474},
			{-0.004901712723282126, 0.052554000605259305, -0.045145171981762613},
			{0.001600746036734481, -0.045145171981762613, 0.04874059082615972}
		},
		{
			{0.04625156222179774, -0.03325659631903399, -0.0013884249878532867},
			{-0.033256596319034, 0.06683143388385421, -0.02836309872471421},
			{-0.0013884249878532836, -0.028363098724714216, 0.03413622078525821}
		},
		{
			{0.053418850012953184, -0.009568734769771825, -0.009145604502133111},
			{-0.009568734769771823, 0.04938204595666666, 0.005467045921981803},
			{-0.009145604502133116, 0.0054670459219817915, 0.0176389498794774}
		},
		{
			{0.08464752986897427, -0.018650069347736824, 0.0015484618110609325},
			{-0.018650069347736827, 0.05612389217173291, -0.005167381496797543},
			{0.0015484618110609325, -0.005167381496797543, 0.013139566287090298}
		}
	};

	double barycentre[31][3] =
	{
		{26.10810810810811, 118.91216216216216, 97.14189189189189},
		{94.82265446224257, 190.3340961098398, 230.15217391304347},
		{173.62025316455697, 188.8496835443038, 220.91455696202533},
		{221.64397905759162, 100.36125654450262, 46.55497382198953},
		{208.2, 199.28947368421052, 106.62631578947368},
		{129.07920792079207, 150.1771177117712, 205.91639163916392},
		{121.32077764277035, 191.71810449574727, 191.10085054678007},
		{127.92967032967033, 104.85934065934066, 117.75604395604395},
		{86.64229765013054, 142.45953002610966, 140.98694516971278},
		{131.81594202898552, 183.29275362318842, 239.28550724637682},
		{210.5090909090909, 183.9939393939394, 27.64848484848485},
		{32.7032967032967, 28.084249084249084, 32.93589743589744},
		{122.11097099621689, 174.82597730138713, 141.74401008827238},
		{141.8539176626826, 125.11819389110225, 161.81673306772907},
		{167.87925696594428, 203.94736842105263, 164.37151702786377},
		{163.87194244604316, 170.38129496402877, 112.53237410071942},
		{89.95435684647303, 160.61327800829875, 185.15103734439833},
		{169.41379310344828, 116.23168103448276, 111.3459051724138},
		{202.11173184357543, 135.64106145251398, 108.66759776536313},
		{151.0745856353591, 113.95580110497238, 73.88259668508287},
		{213.49825783972125, 178.26132404181186, 162.23693379790942},
		{62.545012165450125, 43.49391727493917, 63.47931873479319},
		{118.8060686015831, 147.2994722955145, 99.35620052770449},
		{126.44331395348837, 88.22238372093024, 48.13517441860465},
		{178.79021739130434, 152.71195652173913, 191.77608695652174},
		{166.02315484804632, 150.92474674384948, 71.69319826338639},
		{198.4720812182741, 122.83248730964468, 6.9847715736040605},
		{28.223241590214066, 157.63914373088684, 170.90825688073394},
		{186.98529411764707, 132.39313725490197, 152.31470588235294},
		{83.69811320754717, 80.27924528301887, 57.43396226415094},
		{89.19449541284403, 95.36146788990825, 96.37798165137615}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<31;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<31;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance32clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028797235178875547, -0.021166265566816722, -0.0014400657111623223},
		{-0.02116626556681671, 0.042875201459638676, -0.014580924972179603},
		{-0.0014400657111623245, -0.014580924972179606, 0.01605822731738771}
	};

	double matrix[32][3][3] =
	{
		{
			{0.02871531793461138, -0.025321542917332778, 0.0018999651517368665},
			{-0.025321542917332775, 0.06522584946819492, -0.02709231438449818},
			{0.0018999651517368648, -0.027092314384498183, 0.027899635906841008}
		},
		{
			{0.003500774863946502, -0.004448432553245057, 0.0013526241538451655},
			{-0.004448432553245046, 0.05518965035926481, -0.04550305022518669},
			{0.001352624153845166, -0.04550305022518669, 0.04808928412720597}
		},
		{
			{0.04948225662505637, -0.027160160101345497, -0.007697921434656878},
			{-0.027160160101345504, 0.05803028322955552, -0.023263824211713014},
			{-0.007697921434656882, -0.023263824211712997, 0.034880186735046}
		},
		{
			{0.05351470693324838, -0.0268727496423296, -0.0073430294918669274},
			{-0.026872749642329594, 0.036646216280453, -0.0021979078507506147},
			{-0.007343029491866927, -0.0021979078507506113, 0.014331305270941798}
		},
		{
			{0.04098272483654451, -0.013978612826479164, -0.0021474966136321976},
			{-0.013978612826479166, 0.06657841642589714, -0.013714259751776488},
			{-0.002147496613632202, -0.013714259751776498, 0.018840307600872}
		},
		{
			{0.02623563157837589, -0.020865707116360988, 2.5267826253129975E-5},
			{-0.02086570711636099, 0.04773549536762401, -0.010789014340836308},
			{2.5267826253132578E-5, -0.010789014340836312, 0.0168579487847738}
		},
		{
			{0.048730393260255495, -0.0234414419259842, -0.016142728380655898},
			{-0.0234414419259842, 0.048056870744556605, -0.022704635572881493},
			{-0.016142728380655898, -0.022704635572881486, 0.042924975176350195}
		},
		{
			{0.06746485740036325, -0.041957195525871016, 0.0014484555615828952},
			{-0.041957195525870974, 0.08638056488327989, -0.02484495615719501},
			{0.001448455561582896, -0.024844956157195022, 0.04577764841810052}
		},
		{
			{0.04283490992391907, -0.010142780053612306, -0.009725607004414483},
			{-0.010142780053612306, 0.15657515959944499, -0.020401963439940166},
			{-0.009725607004414494, -0.020401963439940142, 0.05163955386803564}
		},
		{
			{0.018526048718342077, -0.010179303427217089, -0.0039945975553484295},
			{-0.010179303427217092, 0.05117838742861889, -0.023283662333800612},
			{-0.0039945975553484355, -0.023283662333800595, 0.026855711926580608}
		},
		{
			{0.040896298192115405, -0.037533288149026525, 0.0023222525273972677},
			{-0.0375332881490265, 0.06218387139413031, -0.0048057906766325},
			{0.0023222525273972677, -0.004805790676632501, 3.8975159121056393E-4}
		},
		{
			{0.024182406289797703, 0.0026605508790314503, -0.0032047124769388827},
			{0.0026605508790314486, 0.0198753249468816, 0.002706821224851843},
			{-0.0032047124769388775, 0.002706821224851848, 0.0031021708913321288}
		},
		{
			{0.023845591472293114, -0.004922759774747753, -0.012335148053202412},
			{-0.004922759774747754, 0.02650537713548151, -0.010057487788742088},
			{-0.012335148053202419, -0.010057487788742086, 0.020720046021730606}
		},
		{
			{0.06561712234235921, -0.07040409366252308, 0.012659829733593694},
			{-0.07040409366252312, 0.134093319087517, -0.04526814751215896},
			{0.01265982973359369, -0.04526814751215896, 0.059789482626305186}
		},
		{
			{0.126009251104998, -0.050673616446272135, -0.01875449561223938},
			{-0.050673616446272135, 0.11391033216761189, -0.02664345230365458},
			{-0.018754495612239387, -0.02664345230365458, 0.0236517578159511}
		},
		{
			{0.09062276738136407, -0.046925590280494214, -0.0066180227977442625},
			{-0.046925590280494214, 0.07554686824418284, -0.005178998953247746},
			{-0.006618022797744265, -0.005178998953247749, 0.008564260175389273}
		},
		{
			{0.04884380096205038, -0.009482767351285098, -0.01538664267467011},
			{-0.009482767351285098, 0.051608049041708, -0.011577708352669896},
			{-0.015386642674670102, -0.011577708352669904, 0.023228911219064508}
		},
		{
			{0.047095218243494615, -0.015900310675506808, -0.010583457605038496},
			{-0.015900310675506808, 0.03890182796163882, -5.451114262003658E-4},
			{-0.0105834576050385, -5.451114262003706E-4, 0.015859277344190896}
		},
		{
			{0.003162316635337792, -0.001741036810153031, 0.0023077169639990863},
			{-0.0017410368101530346, 0.06594065387789166, -0.04201742276188358},
			{0.0023077169639990876, -0.04201742276188355, 0.04899857478864208}
		},
		{
			{0.03379235297456357, -0.02077469510235524, -0.003955739697519826},
			{-0.02077469510235525, 0.07288419320972514, -0.026641433740008682},
			{-0.003955739697519829, -0.0266414337400087, 0.0324946684112713}
		},
		{
			{0.06267835560111543, -0.03206259074592241, -0.0036080746426265294},
			{-0.032062590745922395, 0.05391101806929425, -0.019031530722069104},
			{-0.003608074642626533, -0.01903153072206911, 0.027232011375926318}
		},
		{
			{0.08706164198339957, -0.003557460353544095, -0.053830967345225154},
			{-0.003557460353544071, 0.06807576731462908, 0.019610512909398883},
			{-0.05383096734522508, 0.019610512909398862, 0.058736659923735945}
		},
		{
			{0.017086754331051304, -7.572089102544106E-4, -0.014097087802539097},
			{-7.572089102544106E-4, 0.014939076515040797, -6.090714460689207E-4},
			{-0.014097087802539097, -6.090714460689174E-4, 0.014836764013256494}
		},
		{
			{0.10958595155393701, -0.06396897957608962, -0.0128003482796921},
			{-0.06396897957608962, 0.08522485988225138, -0.02146955935511619},
			{-0.012800348279692095, -0.021469559355116193, 0.03377384373762951}
		},
		{
			{0.06528619797128413, -0.04733972880870085, -9.213107688628053E-4},
			{-0.04733972880870084, 0.112738609033324, -0.02859230643079841},
			{-9.213107688628075E-4, -0.02859230643079841, 0.018128769092302}
		},
		{
			{0.029113223452384596, -0.013992502286015585, -0.005750257803896572},
			{-0.013992502286015574, 0.04476220117870641, -0.007839802286188455},
			{-0.005750257803896574, -0.007839802286188456, 0.014959095265162911}
		},
		{
			{0.052644022302587724, -0.0434694680620872, -0.006380154821249864},
			{-0.0434694680620872, 0.09722396932864942, -0.011624006147572898},
			{-0.006380154821249861, -0.011624006147572905, 0.011297391258386798}
		},
		{
			{0.015647141223229997, -0.002152245258330782, -0.011746546558968092},
			{-0.0021522452583307696, 0.020507753727412176, -0.005743614337828788},
			{-0.011746546558968089, -0.005743614337828784, 0.017915215121758383}
		},
		{
			{0.013913598414878093, -0.017107745770499488, 0.005824150311659728},
			{-0.017107745770499495, 0.06311550644345203, -0.04384664266652261},
			{0.00582415031165973, -0.04384664266652261, 0.046764593785441705}
		},
		{
			{0.045262654527074, -0.03337573780790678, 0.0027126367675520883},
			{-0.033375737807906765, 0.08386956212224513, -0.03919942922509479},
			{0.0027126367675520866, -0.039199429225094784, 0.03946535394228598}
		},
		{
			{0.0112191196243169, -0.0031268578193406824, -0.008331098521339817},
			{-0.0031268578193406824, 0.03387984039976159, -0.009616462785688503},
			{-0.00833109852133982, -0.009616462785688493, 0.02050251597568331}
		},
		{
			{0.09576420224777824, -0.0072198766768123215, 0.0014253776227313416},
			{-0.007219876676812317, 0.05002075270365299, 0.003208876335617736},
			{0.0014253776227313411, 0.003208876335617736, 0.019575345826208804}
		}
	};

	double barycentre[32][3] =
	{
		{87.22170361726954, 164.5320886814469, 200.6581096849475},
		{28.622356495468278, 157.5287009063444, 169.48942598187313},
		{188.87213510253318, 138.20024125452352, 164.39806996381182},
		{220.4564315352697, 104.31535269709543, 19.83817427385892},
		{127.32459970887919, 87.32459970887919, 57.379912663755455},
		{146.33764705882353, 140.8729411764706, 75.9235294117647},
		{176.92793931731984, 155.71554993678888, 196.08217446270544},
		{124.037147102526, 176.06983655274888, 237.2109955423477},
		{29.021377672209027, 25.40855106888361, 29.89311163895487},
		{119.828418230563, 191.1112600536193, 192.4302949061662},
		{152.10247349823322, 115.773851590106, 31.918727915194346},
		{207.1769911504425, 178.96902654867256, 30.92920353982301},
		{96.828173374613, 140.41331269349845, 108.843653250774},
		{156.52782193958666, 183.97615262321145, 223.71224165341812},
		{114.3961038961039, 102.68398268398268, 115.51515151515152},
		{211.2876712328767, 187.586301369863, 138.72876712328767},
		{149.88059701492537, 121.77114427860697, 152.8047263681592},
		{84.38604651162791, 83.4906976744186, 50.7953488372093},
		{27.392156862745097, 119.45751633986929, 98.16993464052288},
		{161.86508753861997, 111.95880535530381, 99.74150360453142},
		{202.37916666666666, 128.52916666666667, 86.9375},
		{55.93952483801296, 40.28509719222462, 53.79913606911447},
		{148.5673289183223, 193.90949227373068, 156.28476821192052},
		{194.55882352941177, 200.12058823529412, 207.7941176470588},
		{88.97297297297297, 130.86872586872587, 161.4980694980695},
		{172.82075471698113, 170.4177897574124, 99.33288409703503},
		{130.22934648581997, 144.8335388409371, 198.66337854500617},
		{129.59562841530055, 167.65437158469945, 122.91256830601093},
		{97.44992526158445, 198.21973094170403, 233.39760837070253},
		{191.07934782608694, 131.2804347826087, 127.04021739130435},
		{98.78505747126437, 167.38275862068966, 159.32413793103447},
		{83.51282051282051, 78.41025641025641, 87.08875739644971}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<32;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<32;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance33clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.030035185481559062, -0.021960861189226494, -0.0018750560437444024},
		{-0.021960861189226508, 0.040649244713320244, -0.011694534902094107},
		{-0.0018750560437444013, -0.011694534902094107, 0.013681301872947502}
	};

	double matrix[33][3][3] =
	{
		{
			{0.05047793235319747, -0.008546155858276283, -0.015938808238328894},
			{-0.008546155858276297, 0.05273819487289492, -0.01198937181516459},
			{-0.015938808238328897, -0.011989371815164598, 0.0218110439357044}
		},
		{
			{0.0280599897789886, -0.02441345713203689, 0.0044040971647994615},
			{-0.024413457132036895, 0.0743702562763539, -0.03377112919043481},
			{0.004404097164799457, -0.03377112919043481, 0.03241657533541181}
		},
		{
			{0.022274926044731, 0.003621957756572687, -0.006489703092192854},
			{0.003621957756572688, 0.013300524368700595, 0.0030664881537154644},
			{-0.006489703092192854, 0.003066488153715465, 0.007543409234448392}
		},
		{
			{0.025661195138717896, -0.011695974344534095, -0.008181369763376014},
			{-0.011695974344534094, 0.04035798390131619, -0.007042841679754325},
			{-0.008181369763376016, -0.007042841679754325, 0.015562320710177794}
		},
		{
			{0.037316436614820224, -0.02227189953866852, -0.003062116557811757},
			{-0.02227189953866853, 0.06605422244432614, -0.02528183282457888},
			{-0.0030621165578117674, -0.02528183282457888, 0.031712089935264795}
		},
		{
			{0.003680052225874223, -0.0031143160396303426, 0.002919032175712974},
			{-0.003114316039630342, 0.06514481975235109, -0.043432920359039},
			{0.002919032175712973, -0.043432920359039, 0.0499115321586805}
		},
		{
			{0.062020452592745946, -0.036889554878280745, -1.6828731340044365E-4},
			{-0.03688955487828072, 0.07309597731152778, -0.03111090368658191},
			{-1.6828731340043628E-4, -0.031110903686581915, 0.03405592195215533}
		},
		{
			{0.0153413131993303, 0.00193102033417178, -0.013999453562303905},
			{0.0019310203341717696, 0.014657237965151079, -0.007025231923036147},
			{-0.013999453562303896, -0.007025231923036147, 0.01989784929922468}
		},
		{
			{0.014675787667503482, -0.017387449073570756, 0.004840314505750903},
			{-0.017387449073570763, 0.060426814402747046, -0.040250713732011195},
			{0.004840314505750912, -0.040250713732011195, 0.04504784457306689}
		},
		{
			{0.05488481375211842, -0.02689739367850404, -0.004557021121257849},
			{-0.02689739367850404, 0.03522682011685513, -0.005752927957966392},
			{-0.004557021121257849, -0.00575292795796639, 0.0124875184204318}
		},
		{
			{0.031929582773951484, -0.009009838055347429, -4.026770808506601E-4},
			{-0.00900983805534743, 0.03573192858634602, -0.0048798624411851895},
			{-4.026770808506603E-4, -0.004879862441185188, 0.008045504978631008}
		},
		{
			{0.124558955205709, -0.051972801507617176, -0.004411767040199107},
			{-0.05197280150761716, 0.07305025549794934, -0.01619102465947719},
			{-0.004411767040199107, -0.0161910246594772, 0.017657901329513698}
		},
		{
			{0.05757583349617508, -0.055724647758714003, 0.004682588309869397},
			{-0.055724647758714003, 0.11403944588102108, -0.03200622163338344},
			{0.004682588309869403, -0.03200622163338344, 0.01911788643151242}
		},
		{
			{0.04800585300782234, -0.013189617349345706, -0.012230192984584613},
			{-0.013189617349345708, 0.04464209910237586, 3.026795162252734E-4},
			{-0.01223019298458462, 3.0267951622527014E-4, 0.016951008026373202}
		},
		{
			{0.042834909986209604, -0.010142779991312507, -0.009725607020151452},
			{-0.010142779991312504, 0.1565751596550041, -0.02040196346028047},
			{-0.00972560702015145, -0.020401963460280465, 0.05163955384501496}
		},
		{
			{0.04616402565780893, -0.014360037111190502, -0.017460911341708588},
			{-0.014360037111190495, 0.052771198268073895, -0.03183837893646421},
			{-0.01746091134170858, -0.03183837893646421, 0.0497876159526067}
		},
		{
			{0.023098820944301695, -0.013049784882758183, -9.949695685896407E-4},
			{-0.013049784882758186, 0.048664815821974676, -0.025867119036722397},
			{-9.949695685896407E-4, -0.02586711903672239, 0.028018969591245516}
		},
		{
			{0.03135638946864808, -0.018610159744611575, -0.0032933098222611193},
			{-0.01861015974461158, 0.048351674153575656, -0.008841419255722065},
			{-0.0032933098222611263, -0.008841419255722066, 0.0161492752735899}
		},
		{
			{0.11122643378342993, -0.05672722774087205, -0.0165967232014385},
			{-0.05672722774087206, 0.0643223921342126, -5.301638596779301E-4},
			{-0.01659672320143851, -5.301638596779375E-4, 0.013014345446515212}
		},
		{
			{0.003506987372940265, -0.004943707179861872, 0.0014626996802229743},
			{-0.004943707179861871, 0.052656220367722176, -0.044624097373953286},
			{0.0014626996802229748, -0.04462409737395328, 0.0482568448397615}
		},
		{
			{0.08706164198339957, -0.003557460353544095, -0.053830967345225154},
			{-0.003557460353544071, 0.06807576731462908, 0.019610512909398883},
			{-0.05383096734522508, 0.019610512909398862, 0.058736659923735945}
		},
		{
			{0.028133651695371988, -0.021997007505979403, -0.0025430330384978578},
			{-0.021997007505979414, 0.04098858266536614, -0.007695406593046697},
			{-0.0025430330384978578, -0.00769540659304669, 0.0169490617826359}
		},
		{
			{0.026768818662266106, -0.0019264075370765451, -0.005053688412598888},
			{-0.001926407537076547, 0.04096198674735209, -0.015658642153491907},
			{-0.005053688412598892, -0.015658642153491907, 0.0211245752941573}
		},
		{
			{0.016781172744415696, -0.0023517108804624546, -0.0124246321946871},
			{-0.002351710880462458, 0.025676877125686098, -0.00811732045373917},
			{-0.012424632194687101, -0.008117320453739172, 0.0176822999891196}
		},
		{
			{0.017033275073298913, -0.007622128476494464, -0.002653656304829043},
			{-0.0076221284764944625, 0.04998671316737248, -0.016304936127722408},
			{-0.002653656304829042, -0.01630493612772241, 0.020984154997200424}
		},
		{
			{0.04223459442994046, -0.03318786625565985, 0.0014719233130602084},
			{-0.03318786625565982, 0.07299241669657808, -0.03138740640728869},
			{0.0014719233130601975, -0.03138740640728869, 0.03522827815456729}
		},
		{
			{0.07026658134367197, -0.04672181791751162, -0.01021634521838901},
			{-0.04672181791751163, 0.08925967614782007, -0.012096543679858197},
			{-0.010216345218389003, -0.012096543679858195, 0.01955827345685039}
		},
		{
			{0.02645081165088091, -0.02269890001449061, 0.0074072581149035935},
			{-0.022698900014490604, 0.06925263183836787, -0.009752429968209237},
			{0.00740725811490359, -0.009752429968209228, 0.004915642230824758}
		},
		{
			{0.10522133708119397, -0.01740940339240207, 0.0014051561636594227},
			{-0.01740940339240208, 0.061099639413036644, 0.005102341704346595},
			{0.0014051561636594235, 0.005102341704346598, 0.015246715122188104}
		},
		{
			{0.04043185663873648, -0.013478134876442971, -0.003611477699721641},
			{-0.013478134876442975, 0.07402625738145516, -0.00952657900037597},
			{-0.0036114776997216392, -0.009526579000375974, 0.020741062030726405}
		},
		{
			{0.05564994985025096, -0.040773472655737455, -0.004828622986020575},
			{-0.04077347265573748, 0.08573106945031549, -0.029221225288524503},
			{-0.004828622986020572, -0.029221225288524492, 0.058513294316042005}
		},
		{
			{0.07697936025141747, -0.06022295226091899, 0.010969776871746176},
			{-0.06022295226091897, 0.11029790274902788, -0.04894072257709253},
			{0.01096977687174618, -0.048940722577092526, 0.05583428208168973}
		},
		{
			{0.0391144591675733, -0.03214496981441631, 0.005937575891994915},
			{-0.032144969814416315, 0.05549629828748419, -0.016128853197894203},
			{0.005937575891994916, -0.016128853197894203, 0.015566786978565901}
		}
	};

	double barycentre[33][3] =
	{
		{144.84410646387832, 123.65019011406844, 157.77439797211662},
		{128.29179810725552, 195.43690851735016, 200.57413249211356},
		{206.85632183908046, 165.25862068965517, 9.948275862068966},
		{114.08761904761904, 134.7847619047619, 87.24380952380952},
		{165.23897435897436, 113.42051282051283, 106.74051282051282},
		{25.868965517241378, 118.72413793103448, 96.09655172413792},
		{201.8773841961853, 134.15531335149865, 105.98228882833787},
		{129.03721682847896, 186.76699029126215, 160.60679611650485},
		{96.82700421940929, 195.0478199718706, 234.48382559774964},
		{221.29583333333332, 99.93333333333334, 28.808333333333334},
		{202.72759856630825, 183.63082437275986, 75.73476702508961},
		{119.28506787330316, 102.83484162895928, 115.80316742081448},
		{153.77279102384293, 153.42636746143057, 200.48807854137448},
		{85.43680709534368, 83.18625277161863, 50.66518847006652},
		{29.05924170616114, 25.42654028436019, 29.914691943127963},
		{187.12752525252526, 149.57449494949495, 184.02146464646464},
		{89.08472553699283, 171.96539379474942, 195.70883054892602},
		{168.54640980735553, 176.63922942206656, 120.84588441330999},
		{204.1827676240209, 197.96083550913838, 160.38903394255874},
		{27.79192546583851, 157.2639751552795, 170.8136645962733},
		{56.0412147505423, 40.19522776572668, 53.85249457700651},
		{157.78930307941653, 156.30145867098867, 87.6515397082658},
		{82.72846441947566, 132.79026217228466, 132.60861423220973},
		{120.04871794871795, 163.67564102564103, 123.54871794871795},
		{91.80929095354523, 156.59535452322737, 164.26772616136918},
		{188.5674273858921, 131.9533195020747, 146.56950207468878},
		{113.64868603042876, 145.92116182572613, 204.4412171507607},
		{138.3813953488372, 101.9906976744186, 21.074418604651164},
		{83.386, 78.046, 87.928},
		{129.3739837398374, 87.18861788617886, 62.0650406504065},
		{132.45839210155148, 179.4330042313117, 238.25811001410437},
		{179.33151183970855, 189.69216757741347, 221.31329690346084},
		{159.4261796042618, 127.01369863013699, 66.16590563165906}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<33;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<33;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance34clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.029715841361421257, -0.02131009103815639, -0.0016593509859081938},
		{-0.021310091038156394, 0.03997601355861283, -0.011225260887726702},
		{-0.0016593509859081956, -0.0112252608877267, 0.013219406220769296}
	};

	double matrix[34][3][3] =
	{
		{
			{0.05407811264951164, -0.03372373505414667, -0.008996862885735143},
			{-0.03372373505414668, 0.058726721193699316, -0.02559014724083561},
			{-0.00899686288573514, -0.02559014724083561, 0.04440641821629513}
		},
		{
			{0.08676794205914462, -0.03211441039121401, -0.015427110928092302},
			{-0.032114410391214036, 0.0252093404499805, 0.004011968644336203},
			{-0.015427110928092305, 0.004011968644336196, 0.017324672121978496}
		},
		{
			{0.09490546625574078, -0.04009957500281719, -0.0239176748514935},
			{-0.04009957500281717, 0.06717038729607447, -0.0042199504001547575},
			{-0.023917674851493487, -0.004219950400154748, 0.0169606039024106}
		},
		{
			{0.0558390912584773, -0.030474054207055703, -0.005456846814497611},
			{-0.03047405420705571, 0.041440435305642204, -0.0011997605601282496},
			{-0.005456846814497611, -0.0011997605601282522, 0.012714032940349503}
		},
		{
			{0.08481433495160329, -0.021074190181091926, -0.007270548532101795},
			{-0.021074190181091905, 0.11100911248282103, -0.006078809187541589},
			{-0.007270548532101791, -0.006078809187541582, 0.010564966515529203}
		},
		{
			{0.013975973395876917, 0.0013369297994685614, -0.011873625217787006},
			{0.001336929799468557, 0.018120674063020696, -0.007366236177657082},
			{-0.011873625217786997, -0.0073662361776570835, 0.016886444382796382}
		},
		{
			{0.0757853412485856, -0.05208144866338217, -0.0043912363330884194},
			{-0.05208144866338217, 0.10804981274154604, -0.0258180859166647},
			{-0.004391236333088416, -0.0258180859166647, 0.024577044314945486}
		},
		{
			{0.03619055383790344, -0.02574150130806064, -1.9510177693412428E-4},
			{-0.02574150130806065, 0.06831203202075001, -0.024654746334618862},
			{-1.951017769341295E-4, -0.024654746334618866, 0.031090362979498284}
		},
		{
			{0.08532670408695572, -0.06909752135765947, 0.0154591361725586},
			{-0.06909752135765944, 0.13007165427489792, -0.0380866022193686},
			{0.015459136172558582, -0.03808660221936858, 0.054324790839220906}
		},
		{
			{0.03176855595512733, -0.02637648242283202, 0.0021784390548308},
			{-0.02637648242283202, 0.05187498221405507, -0.015199182229907123},
			{0.0021784390548308047, -0.015199182229907116, 0.015926679948273497}
		},
		{
			{0.004031964543160219, -0.005685278977632286, 0.0013297365822708572},
			{-0.005685278977632293, 0.053612422349025274, -0.04423085078111669},
			{0.0013297365822708537, -0.04423085078111668, 0.0479028938143189}
		},
		{
			{0.022342249056365518, -0.01914213972992242, -0.0012986564809878754},
			{-0.01914213972992243, 0.0746431233616758, -0.030947080793878895},
			{-0.0012986564809878694, -0.030947080793878885, 0.028043481704190288}
		},
		{
			{0.023571224452256824, -0.014295659740551603, -0.003677017895845354},
			{-0.014295659740551603, 0.04583047001188059, -0.023069624006775216},
			{-0.003677017895845352, -0.023069624006775216, 0.02841637811247099}
		},
		{
			{0.02913300687572678, -0.018431169168890905, -6.982274754676367E-4},
			{-0.01843116916889091, 0.06904337431734157, -0.018029661930964305},
			{-6.982274754676349E-4, -0.018029661930964298, 0.0321736064101641}
		},
		{
			{0.00362244163517716, -0.003098353895263547, 0.0030190719109935895},
			{-0.003098353895263564, 0.0651463229158306, -0.043863554221526206},
			{0.0030190719109936064, -0.043863554221526206, 0.051151318285275214}
		},
		{
			{0.05324309209761242, -0.010655524564936604, -0.017915950124155908},
			{-0.01065552456493659, 0.04469027174700639, -0.011879338715194511},
			{-0.017915950124155897, -0.011879338715194521, 0.025796036307145907}
		},
		{
			{0.043970874718117316, -0.012704090453528822, -9.22990043504165E-4},
			{-0.012704090453528823, 0.0618993024518618, -0.012318399741179903},
			{-9.229900435041632E-4, -0.012318399741179906, 0.018538126244232497}
		},
		{
			{0.09640662908551355, -0.020251121671389614, 0.002398344193605329},
			{-0.020251121671389608, 0.07900340563454845, 0.010831496371616988},
			{0.0023983441936053303, 0.010831496371616987, 0.0187132112221703}
		},
		{
			{0.08961574887586178, 0.003946769556022193, -0.051038191629040795},
			{0.0039467695560221824, 0.09464391276889389, 0.02276341883947187},
			{-0.0510381916290408, 0.02276341883947187, 0.0514045411965773}
		},
		{
			{0.011411671715441102, -0.002440016175883594, -0.009289655393926104},
			{-0.0024400161758835887, 0.030162708677856684, -0.011798315960334494},
			{-0.009289655393926106, -0.011798315960334493, 0.022383759765834413}
		},
		{
			{0.05159281858360253, -0.03789870217510931, -0.01165496446067619},
			{-0.03789870217510931, 0.07708646413395592, -0.013601603906353909},
			{-0.011654964460676199, -0.013601603906353909, 0.030983419390317592}
		},
		{
			{0.028114338163036236, -0.027404186475549642, 0.0021760125985476448},
			{-0.027404186475549625, 0.0647609307906875, -0.007123346961789422},
			{0.0021760125985476435, -0.007123346961789423, 0.0015624250500669208}
		},
		{
			{0.04706172998989402, -0.010621336055705307, -0.013585630824520313},
			{-0.010621336055705304, 0.16140566179540503, -0.018095719760643753},
			{-0.013585630824520311, -0.01809571976064373, 0.05054897456906875}
		},
		{
			{0.050362824645646745, -0.047423677406034585, 0.00410264638136165},
			{-0.04742367740603457, 0.10712368266946898, -0.021799096314798695},
			{0.004102646381361649, -0.02179909631479869, 0.012188314870075496}
		},
		{
			{0.021888728187419076, -0.011980145332574996, -0.009611025642580463},
			{-0.01198014533257501, 0.029711566199780905, -0.009273721262231227},
			{-0.009611025642580463, -0.009273721262231228, 0.016970569267231075}
		},
		{
			{0.06309260458912085, -0.03453133743953754, -7.93416493177376E-4},
			{-0.03453133743953756, 0.062368991778889854, -0.026217768268413714},
			{-7.934164931773817E-4, -0.026217768268413717, 0.031057412834195525}
		},
		{
			{0.01468419186000022, -0.01785505055170991, 0.005054251170376892},
			{-0.01785505055170992, 0.06027887484842279, -0.03913571957197941},
			{0.005054251170376908, -0.03913571957197943, 0.04072435494505929}
		},
		{
			{0.021251810204695607, 0.0036217054274012696, -0.00639767982659954},
			{0.0036217054274012696, 0.014146533429454504, 0.003963329260629663},
			{-0.006397679826599542, 0.003963329260629666, 0.008336561003936017}
		},
		{
			{0.04901453554249652, -0.02311836161030701, -0.00969949435556444},
			{-0.02311836161030701, 0.04697149892706757, -0.01742480901069479},
			{-0.009699494355564442, -0.01742480901069479, 0.0325611775527464}
		},
		{
			{0.04530467068981948, -0.03949659185995278, 0.00598337960435363},
			{-0.03949659185995279, 0.0889061413189314, -0.04226483639329058},
			{0.005983379604353637, -0.04226483639329057, 0.03932314115262589}
		},
		{
			{0.026763385254055205, -0.005269169103428077, -0.004512535828738859},
			{-0.005269169103428078, 0.03482498577125919, 0.0010739600780990013},
			{-0.0045125358287388655, 0.0010739600780990044, 0.005958099917665335}
		},
		{
			{0.051622798162510544, -0.04234651033634423, -0.003601487664035702},
			{-0.04234651033634421, 0.09082721856292547, -0.02889660855734238},
			{-0.0036014876640356984, -0.028896608557342385, 0.058402378751511705}
		},
		{
			{0.04425093065447499, -0.01938641487917349, -0.012479872365156696},
			{-0.019386414879173468, 0.038642552694514665, -3.321467406734342E-4},
			{-0.012479872365156693, -3.321467406734394E-4, 0.018194630398944506}
		},
		{
			{0.02755763387104268, -0.013374217317283487, -0.00648674622026965},
			{-0.013374217317283487, 0.0504129322979142, -0.009704272211428592},
			{-0.006486746220269642, -0.0097042722114286, 0.015768057851421605}
		}
	};

	double barycentre[34][3] =
	{
		{178.1657060518732, 162.64697406340056, 202.9048991354467},
		{184.95145631067962, 204.8705501618123, 170.47249190938513},
		{213.95637583892616, 184.20469798657717, 138.76845637583892},
		{221.58636363636364, 99.17272727272727, 25.486363636363638},
		{101.54448398576513, 108.82918149466192, 108.64234875444839},
		{128.2696335078534, 177.31675392670158, 141.81413612565444},
		{98.71458773784356, 128.43763213530656, 171.7061310782241},
		{165.2469135802469, 114.50953984287318, 107.09203142536475},
		{175.62337662337663, 196.16103896103897, 227.57922077922078},
		{157.5603328710125, 141.62968099861303, 70.28571428571429},
		{30.17948717948718, 156.95156695156695, 171.46438746438747},
		{127.49034749034749, 193.74517374517376, 191.88545688545688},
		{92.32270531400967, 168.9768115942029, 180.10917874396137},
		{143.19611307420496, 101.31625441696113, 77.42579505300354},
		{26.711409395973153, 119.20134228187919, 98.09395973154362},
		{149.7444589308996, 120.85658409387223, 149.85267275097783},
		{120.77798507462687, 85.0223880597015, 50.973880597014926},
		{83.54767184035477, 75.33481152993348, 86.26164079822617},
		{55.65217391304348, 39.95434782608696, 53.72391304347826},
		{88.17933130699087, 149.95440729483283, 134.3890577507599},
		{103.62861491628615, 157.55403348554034, 215.84170471841705},
		{146.68393782383419, 111.85492227979275, 22.808290155440414},
		{28.995203836930454, 25.213429256594726, 29.741007194244606},
		{139.90358126721762, 145.4917355371901, 196.03856749311294},
		{121.51466275659824, 149.4516129032258, 100.4633431085044},
		{202.08925318761385, 130.11657559198542, 94.46812386156648},
		{95.94172185430463, 196.17086092715232, 231.90596026490067},
		{208.2814371257485, 165.47305389221557, 9.634730538922156},
		{185.14456391875746, 139.77658303464756, 171.32138590203107},
		{193.56024096385542, 133.2132530120482, 134.62409638554217},
		{197.46987951807228, 182.83534136546186, 70.58232931726907},
		{134.40493468795356, 180.64876632801162, 237.45137880986937},
		{80.13492063492063, 82.60317460317461, 51.82010582010582},
		{166.13920454545453, 169.4502840909091, 109.05823863636364}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<34;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<34;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance35clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027299570458821018, -0.0197882083361204, -0.002149360928758784},
		{-0.019788208336120397, 0.04115032034999962, -0.012727120416135202},
		{-0.0021493609287587794, -0.012727120416135195, 0.014529653333826003}
	};

	double matrix[35][3][3] =
	{
		{
			{0.017492900367179806, -0.002098382101748007, -0.011488893673627907},
			{-0.0020983821017480156, 0.024647203007329012, -0.008330886894467229},
			{-0.011488893673627912, -0.008330886894467229, 0.017788034144407203}
		},
		{
			{0.07739695289883373, -0.059944455393926434, -0.009425605835019042},
			{-0.0599444553939264, 0.09885414166930791, -0.02180630825572261},
			{-0.009425605835019049, -0.02180630825572261, 0.025499671098447415}
		},
		{
			{0.03992597571896189, -0.02661172910510839, -6.592994994795071E-4},
			{-0.02661172910510839, 0.07144113210597806, -0.03637007763093461},
			{-6.592994994795136E-4, -0.03637007763093461, 0.03710670312350502}
		},
		{
			{0.0632335606423237, -0.03351757174142071, -0.0014099424762179821},
			{-0.03351757174142071, 0.059108414863878564, -0.024784023076390882},
			{-0.0014099424762179778, -0.024784023076390896, 0.031247543957668683}
		},
		{
			{0.1057051689521791, -0.04767736178740411, 0.0014613119190848396},
			{-0.04767736178740409, 0.1403277001715029, -0.027666785045809193},
			{0.0014613119190848487, -0.027666785045809186, 0.0181627934579355}
		},
		{
			{0.012449194860806595, 8.338775457779656E-4, -0.008816907736035837},
			{8.338775457779673E-4, 0.03537169475919241, -0.01091576712004351},
			{-0.008816907736035835, -0.010915767120043513, 0.02096620571189879}
		},
		{
			{0.028949153651728114, -0.010511113518967698, -0.00905247648678245},
			{-0.010511113518967703, 0.028024825652837503, -0.005165799864908336},
			{-0.009052476486782441, -0.005165799864908335, 0.016938166580702196}
		},
		{
			{0.060752304781574736, -0.0430167954538091, -0.007210315007292886},
			{-0.04301679545380909, 0.08176742071090806, -0.016753787085409814},
			{-0.007210315007292884, -0.016753787085409803, 0.0319281044103149}
		},
		{
			{0.02453362868731325, -0.01549656579502836, -5.923268402370503E-4},
			{-0.015496565795028372, 0.046771914506124, -0.0235102993833294},
			{-5.923268402370551E-4, -0.023510299383329394, 0.02925436148842481}
		},
		{
			{0.04973863890055359, -0.024252400146345002, -0.005425540324921199},
			{-0.024252400146345006, 0.036822152207982205, -0.0017164502850078277},
			{-0.005425540324921201, -0.0017164502850078285, 0.013908667819371199}
		},
		{
			{0.015420685944487386, 0.001370844961271424, -0.014052201323839395},
			{0.0013708449612714283, 0.016580448478337204, -0.004844772013051435},
			{-0.014052201323839388, -0.004844772013051429, 0.0163905172737376}
		},
		{
			{0.10006149002841505, -0.01626704804629367, -3.09116653410919E-5},
			{-0.016267048046293673, 0.06126054773235085, 0.007657156103715271},
			{-3.091166534109125E-5, 0.007657156103715272, 0.018433135874810404}
		},
		{
			{0.0038641231236651095, -0.00800583438348455, 0.003077849677833794},
			{-0.008005834383484543, 0.06861273813533422, -0.04092235914210271},
			{0.003077849677833793, -0.04092235914210273, 0.04886117361595893}
		},
		{
			{0.0485171100416491, -0.012868055597205233, -0.012863181526840206},
			{-0.012868055597205226, 0.057371040041940026, 0.005840603706659742},
			{-0.012863181526840205, 0.005840603706659754, 0.0187144045268998}
		},
		{
			{0.01630925042842829, 0.0012387815933139566, -0.007765754988355493},
			{0.0012387815933139592, 0.041318117939362506, -0.01650867039945402},
			{-0.007765754988355493, -0.01650867039945399, 0.024135294928333204}
		},
		{
			{0.028647994286022386, -0.013599131466068363, -0.007389026790630953},
			{-0.013599131466068361, 0.051015731613212954, -0.00857581171523594},
			{-0.007389026790630947, -0.008575811715235948, 0.014715771936042092}
		},
		{
			{0.04934368987878951, -0.02190531373516539, -0.011218320930845696},
			{-0.0219053137351654, 0.050419096041911034, -0.01998933649348711},
			{-0.011218320930845701, -0.01998933649348711, 0.032746751380780016}
		},
		{
			{0.041521691881228236, -0.013010839754874121, -0.005274871260962685},
			{-0.013010839754874116, 0.06617029415001069, -0.010231433166659495},
			{-0.005274871260962679, -0.010231433166659499, 0.020170289876664797}
		},
		{
			{0.004298732359560978, -0.0025840672755419324, 0.0019108200338387726},
			{-0.002584067275541925, 0.05954311925712082, -0.04622090517869036},
			{0.0019108200338387687, -0.046220905178690354, 0.05892760620371456}
		},
		{
			{0.034208208398963, -0.009974918460104827, 0.0019431998715883575},
			{-0.009974918460104823, 0.03387070564819623, -0.004077064343695794},
			{0.0019431998715883567, -0.004077064343695795, 0.007168973063902019}
		},
		{
			{0.024948253068827038, -0.014516620126116254, 0.002730982427279576},
			{-0.014516620126116266, 0.04583715686484564, -0.034394954861463316},
			{0.0027309824272795887, -0.03439495486146333, 0.034026479988710015}
		},
		{
			{0.02065901479123509, 0.0027594605365163336, -0.00652205166653168},
			{0.0027594605365163323, 0.013619104662515097, 0.0029216956887275977},
			{-0.00652205166653168, 0.0029216956887275955, 0.007894593920103164}
		},
		{
			{0.08583277545429348, -0.06731244056160701, 0.015151393290212117},
			{-0.06731244056160704, 0.12743801557372386, -0.034814952649100984},
			{0.015151393290212116, -0.03481495264910097, 0.05106953397241052}
		},
		{
			{0.02990785006299739, -0.027892147978279595, 0.007408202138476103},
			{-0.027892147978279595, 0.08361776261213195, -0.0320524931990597},
			{0.007408202138476103, -0.0320524931990597, 0.02970854537174031}
		},
		{
			{0.052542841726352, -0.0051576644692791825, -0.016973676124916636},
			{-0.005157664469279184, 0.046394086301546004, -0.014585902281086298},
			{-0.01697367612491664, -0.01458590228108629, 0.028580124226037246}
		},
		{
			{0.053466443858482995, -0.03337088111658152, -0.008836146720451986},
			{-0.03337088111658152, 0.05946208670469591, -0.03003389066924499},
			{-0.008836146720452003, -0.030033890669245007, 0.049269712028764484}
		},
		{
			{0.029036139644848316, -0.024966011392259003, 6.254926470339373E-4},
			{-0.024966011392259013, 0.04996808663618168, -0.012260576695726496},
			{6.254926470339382E-4, -0.012260576695726494, 0.013927914180915098}
		},
		{
			{0.03477754678142187, -0.024507343940610105, 3.975205385294044E-4},
			{-0.024507343940610115, 0.07266900149386149, -0.024150531797317618},
			{3.975205385293966E-4, -0.02415053179731761, 0.029931461158289294}
		},
		{
			{0.05969470002331066, -0.022779264212845797, -0.030935664307594694},
			{-0.02277926421284581, 0.10761588771007397, -0.019284259781793805},
			{-0.030935664307594667, -0.019284259781793826, 0.0666428097564455}
		},
		{
			{0.03286533797135569, -0.03485189215943182, 0.0020951508425251907},
			{-0.034851892159431845, 0.06310647904438216, -0.004749230663627207},
			{0.002095150842525192, -0.0047492306636272045, 4.011424433219713E-4}
		},
		{
			{0.014585374402929797, -0.01877440263244432, 0.005987460127087348},
			{-0.0187744026324443, 0.06309106620016736, -0.04102472754009133},
			{0.0059874601270873355, -0.041024727540091344, 0.04288382361865943}
		},
		{
			{0.051895678357403954, -0.040832733380878464, -0.0032718837424010015},
			{-0.04083273338087851, 0.08787334231512121, -0.028819188292513218},
			{-0.003271883742400998, -0.02881918829251321, 0.0586133087586176}
		},
		{
			{0.1081203063986789, -0.0576943275380078, -0.014292543540454887},
			{-0.0576943275380078, 0.054769236500332795, 0.002982429845081517},
			{-0.014292543540454885, 0.0029824298450815126, 0.01648480069650761}
		},
		{
			{0.07065201694239576, -0.04125847855315527, 0.0015458061417137755},
			{-0.0412584785531553, 0.08087282404506764, -0.03451316656627572},
			{0.0015458061417137868, -0.03451316656627573, 0.031757326921964014}
		},
		{
			{0.04800258112481255, -0.045273473848509736, 0.004038304559616305},
			{-0.04527347384850971, 0.10870822638535788, -0.024247192701556494},
			{0.0040383045596163, -0.024247192701556494, 0.013312992171136604}
		}
	};

	double barycentre[35][3] =
	{
		{123.84398216939078, 161.77563150074295, 118.1738484398217},
		{107.21123595505618, 127.49662921348315, 171.33932584269664},
		{180.90084643288998, 122.92865779927449, 123.4993954050786},
		{203.22245762711864, 128.52118644067798, 91.52966101694915},
		{115.27293064876957, 100.93736017897092, 113.05816554809843},
		{97.13446676970634, 163.99227202472952, 153.63987635239567},
		{115.20202020202021, 133.7070707070707, 84.89090909090909},
		{107.14212328767124, 154.9845890410959, 218.22260273972603},
		{97.50060168471721, 174.22262334536703, 189.77256317689532},
		{222.72037914691944, 98.44549763033176, 24.265402843601894},
		{134.93223140495869, 186.77520661157024, 153.87603305785123},
		{81.09, 75.988, 86.084},
		{14.140703517587939, 159.9396984924623, 169.6281407035176},
		{81.06880733944953, 76.64449541284404, 50.908256880733944},
		{81.67170626349892, 135.71922246220302, 124.97840172786177},
		{167.53188180404354, 171.22706065318818, 109.80870917573873},
		{184.506432748538, 137.51228070175438, 169.0046783625731},
		{125.08037094281298, 85.78825347758887, 55.179289026275114},
		{24.746376811594203, 117.83333333333333, 94.9927536231884},
		{204.42436974789916, 189.4327731092437, 79.25210084033614},
		{64.2139423076923, 153.26442307692307, 178.61298076923077},
		{206.75, 166.04444444444445, 11.833333333333334},
		{176.4724409448819, 195.96587926509187, 227.4278215223097},
		{130.27184466019418, 195.36245954692558, 200.0097087378641},
		{150.06715328467152, 120.84379562043796, 149.97664233576643},
		{179.61063218390805, 162.05316091954023, 201.81896551724137},
		{159.42011019283746, 145.91873278236915, 73.00413223140495},
		{158.48745519713262, 110.35483870967742, 93.0836320191159},
		{40.24528301886792, 31.19119496855346, 40.432704402515725},
		{148.93115942028984, 113.6340579710145, 31.985507246376812},
		{96.00710227272727, 196.28551136363637, 233.5880681818182},
		{134.6629570747218, 180.97774244833067, 238.9046104928458},
		{197.20057306590257, 203.3810888252149, 166.63896848137537},
		{205.409009009009, 151.56756756756758, 137.1891891891892},
		{142.19081779053084, 146.45624103299858, 196.63271162123385}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<35;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<35;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance36clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027067870534294932, -0.019326151985690314, -0.001993973012482401},
		{-0.019326151985690314, 0.04117015437304639, -0.013770386320911699},
		{-0.001993973012482405, -0.0137703863209117, 0.015885104579899806}
	};

	double matrix[36][3][3] =
	{
		{
			{0.044417731697725504, -0.025018010724958586, -0.004250253533738811},
			{-0.02501801072495859, 0.06137704424844304, -0.01976180551870759},
			{-0.004250253533738814, -0.0197618055187076, 0.031856259156471514}
		},
		{
			{0.055655074934509496, -0.04098727996996053, -0.007784433594259076},
			{-0.04098727996996054, 0.08679039140010025, -0.026161294372555304},
			{-0.007784433594259076, -0.026161294372555304, 0.05664718341614709}
		},
		{
			{0.0035362967807102243, -0.0012271761704553258, 9.696565983190539E-4},
			{-0.0012271761704553397, 0.06840094473265941, -0.04184207272007871},
			{9.696565983190636E-4, -0.0418420727200787, 0.0435427405617605}
		},
		{
			{0.014291925853067104, -0.0022930710944459648, -0.008719171429883914},
			{-0.002293071094445962, 0.0316467834791326, -0.012560879550863002},
			{-0.00871917142988391, -0.012560879550862995, 0.022244970961367405}
		},
		{
			{0.09570887090194063, -0.008605122247886628, -0.06630549241725742},
			{-0.008605122247886628, 0.09379122194291213, 0.02305768865487608},
			{-0.06630549241725742, 0.023057688654876052, 0.05824844647840655}
		},
		{
			{0.039154824728281495, -0.020970860724287395, -0.0030284103071812696},
			{-0.020970860724287388, 0.06357280087516254, -0.02447433167993448},
			{-0.0030284103071812575, -0.02447433167993448, 0.0323481960072469}
		},
		{
			{0.024323805904355678, -0.022322061300532464, 0.004294968075177123},
			{-0.02232206130053246, 0.07384679900976825, -0.03155415726065176},
			{0.004294968075177109, -0.03155415726065175, 0.031967425468983776}
		},
		{
			{0.024808566931992918, -0.015647099325581997, 0.0018726940778987895},
			{-0.01564709932558199, 0.05232403731184915, -0.0369815605029372},
			{0.0018726940778987925, -0.036981560502937195, 0.03325737134746372}
		},
		{
			{0.05454651413627433, -0.03380830378930731, -0.009344264836895273},
			{-0.0338083037893073, 0.05526597675266728, -0.0235089483681251},
			{-0.009344264836895277, -0.0235089483681251, 0.04398686237014831}
		},
		{
			{0.056525868153626584, -0.029067394955451055, -0.005928011673004107},
			{-0.029067394955451038, 0.037277160783966826, -0.003548306728849384},
			{-0.005928011673004104, -0.003548306728849387, 0.012705080297306496}
		},
		{
			{0.05140210369042458, -0.04023538027049542, 0.0038020557656956357},
			{-0.04023538027049544, 0.08739595231802598, -0.03978048318807342},
			{0.0038020557656956297, -0.03978048318807341, 0.03758305545433818}
		},
		{
			{0.030446655080158314, -0.0173114349458239, -0.005058706524304216},
			{-0.0173114349458239, 0.048467576923036715, -0.006403358901850464},
			{-0.005058706524304221, -0.006403358901850464, 0.013321780928661993}
		},
		{
			{0.029294701664666897, -0.025740304165171306, 0.0018239231457484093},
			{-0.025740304165171302, 0.05164010335004278, -0.01407970528241809},
			{0.0018239231457484123, -0.01407970528241809, 0.0153184739459229}
		},
		{
			{0.05004921654378426, -0.02053649819503147, -0.01039800295691451},
			{-0.020536498195031484, 0.04933841635130532, -0.015740584606200505},
			{-0.010398002956914508, -0.015740584606200494, 0.028282315603941403}
		},
		{
			{0.01927972004790552, -0.014526896715788436, 0.002022465262516181},
			{-0.014526896715788449, 0.04954293157761065, -0.031056599068790942},
			{0.002022465262516181, -0.031056599068790935, 0.030725045250982422}
		},
		{
			{0.04266279711594381, -0.0065568435285809044, -0.022503643093459702},
			{-0.0065568435285809044, 0.04540420602108618, -0.0165621798923091},
			{-0.02250364309345969, -0.016562179892309098, 0.0348415093648048}
		},
		{
			{0.10972634191712108, -0.03220629317447763, -0.005289774338821979},
			{-0.03220629317447763, 0.04828301578470043, -0.015150615514307395},
			{-0.00528977433882198, -0.015150615514307401, 0.01796839147370809}
		},
		{
			{0.017808001409196618, -0.0021709612394925012, -0.011882614335740211},
			{-0.0021709612394924995, 0.023355948259235294, -0.008612464128014332},
			{-0.011882614335740215, -0.008612464128014327, 0.017976907356131205}
		},
		{
			{0.017097074039323135, -0.02113268415058805, 0.006828074763297904},
			{-0.021132684150588055, 0.06747045751536736, -0.04500791145951535},
			{0.0068280747632979005, -0.04500791145951535, 0.04735290517730822}
		},
		{
			{0.022824705950575022, 0.0035729448579453777, -0.0030347390420910674},
			{0.003572944857945389, 0.019277370322398908, 0.0036313192523614473},
			{-0.003034739042091071, 0.003631319252361444, 0.0030244537705520647}
		},
		{
			{0.016044034580033454, -3.35949456698594E-4, -0.013818036385485781},
			{-3.3594945669859896E-4, 0.013400995632745109, -0.0016633222076923668},
			{-0.013818036385485791, -0.0016633222076923655, 0.014852592245273508}
		},
		{
			{0.02570421270325121, -0.011506919443988607, -0.008483502255323398},
			{-0.0115069194439886, 0.0368238484291947, -0.007384263807486089},
			{-0.008483502255323407, -0.007384263807486083, 0.017684297477870828}
		},
		{
			{0.02781114091593511, -0.027364441267101705, 0.0023455930340005207},
			{-0.027364441267101712, 0.06483635489253597, -0.007377697494969178},
			{0.002345593034000521, -0.007377697494969178, 0.0027456368857504297}
		},
		{
			{0.06327695414118387, -0.03329350907742808, -0.0013065758902894688},
			{-0.03329350907742805, 0.05867397296258391, -0.025034032524730163},
			{-0.0013065758902894727, -0.025034032524730163, 0.030773894632572983}
		},
		{
			{0.0731263003206183, -0.0541932515193724, -0.011397674083460211},
			{-0.054193251519372404, 0.11467397977364299, -0.0363780849339024},
			{-0.011397674083460225, -0.036378084933902426, 0.03162648290019303}
		},
		{
			{0.08542119611757154, -0.06663604802987705, 0.014460576137822959},
			{-0.06663604802987703, 0.12998626751524406, -0.033401920865471696},
			{0.014460576137822947, -0.03340192086547168, 0.04995656932624819}
		},
		{
			{0.07402370442467962, -0.03611158636406677, -0.00297113776955651},
			{-0.036111586364066764, 0.05580229983514763, -0.006413621781854534},
			{-0.0029711377695565105, -0.0064136217818545355, 0.008421443627741769}
		},
		{
			{0.020408110529578482, -0.011924092869753496, -0.005904305168291827},
			{-0.011924092869753489, 0.0360974509962326, -0.012575561550246408},
			{-0.00590430516829183, -0.0125755615502464, 0.02374245116280641}
		},
		{
			{0.13122053513193993, -0.10114093338587798, -0.014236577608029396},
			{-0.10114093338587804, 0.11397775087425208, -0.011330141924580699},
			{-0.014236577608029407, -0.011330141924580695, 0.02291739542484821}
		},
		{
			{0.04742860211883732, -0.04624219605884281, 0.0053174912261287205},
			{-0.04624219605884277, 0.11901803823176593, -0.027274431735078576},
			{0.005317491226128712, -0.02727443173507858, 0.013575756315150593}
		},
		{
			{0.04135040851776272, -0.016220380649190402, -0.0018788463438264651},
			{-0.016220380649190402, 0.07091355169609824, -0.008511719664154956},
			{-0.0018788463438264634, -0.008511719664154958, 0.0180403074734091}
		},
		{
			{0.06753521963551369, -0.040680761196875914, -0.008402342659422146},
			{-0.04068076119687591, 0.08870853450093888, -0.017357084844275592},
			{-0.008402342659422139, -0.017357084844275603, 0.03128009003549621}
		},
		{
			{0.04940943784610296, -0.019718709241465203, -0.01166340031110771},
			{-0.019718709241465206, 0.03963973977656772, 5.2103520694390774E-5},
			{-0.011663400311107712, 5.210352069438644E-5, 0.01721939904301831}
		},
		{
			{0.002883346843609731, -0.0032331517231059177, 0.001583849249683325},
			{-0.0032331517231059207, 0.0640844722810748, -0.04153606367277139},
			{0.0015838492496833244, -0.04153606367277139, 0.050530736551367285}
		},
		{
			{0.10927788867592095, -0.022662801362447884, 0.00544343866068884},
			{-0.02266280136244788, 0.05931061165193032, 1.0995654792318656E-4},
			{0.005443438660688837, 1.0995654792318472E-4, 0.018063360000559504}
		},
		{
			{0.04585919566448195, -0.0073979039169949894, -0.015277446558467703},
			{-0.007397903916994983, 0.15842661812399003, -0.02538914323934341},
			{-0.01527744655846771, -0.025389143239343423, 0.0618858147957881}
		}
	};

	double barycentre[36][3] =
	{
		{155.05891719745222, 107.72770700636943, 84.31210191082802},
		{135.53846153846155, 180.82692307692307, 238.25},
		{26.523489932885905, 118.9261744966443, 96.81208053691275},
		{88.70151770657672, 145.71163575042158, 128.51602023608768},
		{57.062780269058294, 40.426008968609864, 55.266816143497756},
		{170.5438373570521, 118.16010165184244, 113.0279542566709},
		{128.184249628529, 194.71619613670134, 198.55720653789004},
		{64.76428571428572, 147.9142857142857, 168.16904761904763},
		{178.2052067381317, 163.44563552833077, 203.75650842266464},
		{220.08300395256916, 104.47826086956522, 22.035573122529645},
		{196.6090425531915, 137.00797872340425, 134.8869680851064},
		{169.0042194092827, 170.08157524613222, 103.72292545710268},
		{159.5375552282769, 144.82326951399116, 69.62444771723122},
		{188.96326530612245, 142.5768707482993, 172.7360544217687},
		{83.63497453310696, 172.98471986417658, 202.79966044142614},
		{159.0093209054594, 122.91744340878829, 153.61118508655127},
		{119.68094218415418, 104.7473233404711, 118.85224839400428},
		{124.5266272189349, 164.67011834319527, 121.89497041420118},
		{99.18681318681318, 197.4348508634223, 236.23547880690737},
		{207.61032863849766, 178.74647887323943, 28.187793427230048},
		{142.2116504854369, 188.89708737864078, 150.91844660194175},
		{116.75757575757575, 136.2026515151515, 87.02462121212122},
		{145.70319634703196, 109.95890410958904, 23.831050228310502},
		{203.57053941908714, 129.79253112033194, 92.12448132780084},
		{111.75257731958763, 127.5340206185567, 169.44742268041236},
		{176.36901408450703, 196.75774647887323, 228.28169014084506},
		{212.56015037593986, 189.12781954887217, 123.49248120300751},
		{102.85428253615127, 171.31479421579533, 170.63515016685207},
		{198.21611721611723, 203.32967032967034, 175.13186813186815},
		{144.1891472868217, 146.45271317829457, 196.25271317829458},
		{124.78548387096774, 85.84354838709677, 56.098387096774196},
		{110.07226890756303, 153.78151260504202, 216.42352941176472},
		{82.82532751091703, 81.72270742358079, 53.351528384279476},
		{13.141361256544503, 160.90575916230367, 171.82722513089004},
		{83.94262295081967, 81.21311475409836, 92.18442622950819},
		{29.662921348314608, 26.06741573033708, 30.552808988764045}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<36;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<36;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance37clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02684804330453691, -0.018904976048810616, -0.002312848748126591},
		{-0.018904976048810602, 0.04140293199975551, -0.013517141127500808},
		{-0.0023128487481265843, -0.013517141127500808, 0.015493941605944915}
	};

	double matrix[37][3][3] =
	{
		{
			{0.02598819366114039, -0.021942662024930573, 0.005291690527955647},
			{-0.021942662024930573, 0.060585483988377, -0.04178233735884},
			{0.0052916905279556435, -0.04178233735884, 0.0407989620346993}
		},
		{
			{0.017977561038555308, -0.0018479798240022376, -0.012177820252333908},
			{-0.0018479798240022462, 0.024663346912835206, -0.008593416650066342},
			{-0.01217782025233391, -0.00859341665006634, 0.017463147924059806}
		},
		{
			{0.03263125389055936, -0.03204623230753634, 0.009095055184005097},
			{-0.03204623230753634, 0.056282645244056365, -0.016691095319557397},
			{0.009095055184005097, -0.016691095319557397, 0.010805449253164302}
		},
		{
			{0.0319636620915011, -0.01686492526868138, -0.004733333700905468},
			{-0.016864925268681375, 0.05113395773179124, -0.009060722261282498},
			{-0.004733333700905468, -0.009060722261282503, 0.01415744818693969}
		},
		{
			{0.05049508378485782, -0.03742981494107179, -0.004559592307217305},
			{-0.03742981494107176, 0.08533188558000455, -0.03511015334745324},
			{-0.004559592307217301, -0.03511015334745324, 0.0789977637002919}
		},
		{
			{0.04984303456752369, -0.013668320902803292, -0.0035182434101286705},
			{-0.013668320902803302, 0.04871591475407561, -4.1405388061105906E-4},
			{-0.003518243410128671, -4.140538806110543E-4, 0.0022875346878719195}
		},
		{
			{0.04706172998754831, -0.010621336060771404, -0.013585630823408123},
			{-0.0106213360607714, 0.16140566177969706, -0.018095719753685714},
			{-0.013585630823408114, -0.018095719753685693, 0.05054897457379052}
		},
		{
			{0.05437611538900684, -0.026722390745313008, -0.004048218704475041},
			{-0.026722390745313004, 0.03608552543018707, -0.007045544836630826},
			{-0.004048218704475043, -0.007045544836630826, 0.012521734523035706}
		},
		{
			{0.030023058920285846, -0.01695660023740934, 0.014668066336341622},
			{-0.016956600237409337, 0.0678151904618149, -0.019222650749997922},
			{0.014668066336341622, -0.01922265074999792, 0.014142362825590206}
		},
		{
			{0.0440591122736982, -0.012183333351733168, -0.009959221108307478},
			{-0.012183333351733178, 0.05805377063803592, 0.008060691405016888},
			{-0.009959221108307471, 0.008060691405016881, 0.017711478944927896}
		},
		{
			{0.033964347443719886, -0.023496855673525274, -9.492825727300657E-4},
			{-0.023496855673525267, 0.07134548462458008, -0.026205085429810898},
			{-9.492825727300562E-4, -0.0262050854298109, 0.0338531491212174}
		},
		{
			{0.09824684692762277, -0.014907345270838271, 3.223672827636395E-4},
			{-0.014907345270838264, 0.07270885832629331, 0.011009262175346611},
			{3.2236728276364014E-4, 0.011009262175346608, 0.018063360005435895}
		},
		{
			{0.02797414944041372, -0.01196072759654421, -0.007299691507559172},
			{-0.01196072759654421, 0.03698343220357581, -0.0038021196645918656},
			{-0.007299691507559171, -0.003802119664591863, 0.013296365673010796}
		},
		{
			{0.028878975397535103, 2.569533112498426E-4, -0.009836031860490261},
			{2.5695331124984434E-4, 0.044620179095526305, -0.013165554728856802},
			{-0.009836031860490254, -0.01316555472885678, 0.026688906558020697}
		},
		{
			{0.056195401315633865, -0.042327844956021564, 0.0011812062099939382},
			{-0.04232784495602156, 0.08399567652688818, -0.03591459791646305},
			{0.0011812062099939248, -0.03591459791646305, 0.03707380181665791}
		},
		{
			{0.0242927526143058, -0.011621240428925598, -0.0032668966191016077},
			{-0.011621240428925596, 0.0355344032667598, -0.01604881844577399},
			{-0.0032668966191016, -0.016048818445774, 0.024802330477961192}
		},
		{
			{0.0037230270812398368, -0.0031615494438097737, 0.0029099679624695445},
			{-0.003161549443809782, 0.0648933421709231, -0.04398957214931251},
			{0.0029099679624695514, -0.0439895721493125, 0.0510684211098932}
		},
		{
			{0.019183205282075302, 8.592015341212589E-4, -0.0068393598075081625},
			{8.59201534121258E-4, 0.016333384195446596, 0.00474053992591462},
			{-0.006839359807508162, 0.0047405399259146195, 0.008976146754429298}
		},
		{
			{0.06065723521817695, -0.03870114340483063, -0.01317000306107742},
			{-0.03870114340483062, 0.08523602070154257, -0.015585492841370613},
			{-0.013170003061077414, -0.015585492841370608, 0.03211255277386773}
		},
		{
			{0.02796171160890413, -0.022394889642407014, 0.003812874359055683},
			{-0.02239488964240702, 0.0676038913842315, -0.030260334845687603},
			{0.0038128743590556896, -0.030260334845687603, 0.0332530880581461}
		},
		{
			{0.047651460067492026, -0.020176717002721292, -0.015226944156247292},
			{-0.020176717002721292, 0.05787427671059162, -0.037439308872465216},
			{-0.015226944156247292, -0.03743930887246523, 0.05816034716409871}
		},
		{
			{0.01425076163830201, -0.017973814720158007, 0.005689946270914559},
			{-0.01797381472015801, 0.05973803499396765, -0.03865057931962133},
			{0.0056899462709145655, -0.03865057931962133, 0.04071474123621208}
		},
		{
			{0.0391810287763968, -0.014235377592474589, -0.0012159869559087012},
			{-0.014235377592474594, 0.07025345632937001, -0.004731581692936981},
			{-0.0012159869559087064, -0.004731581692936979, 0.019654524311733902}
		},
		{
			{0.02753329175335161, -0.012120048966380914, -0.011916119333014615},
			{-0.012120048966380904, 0.0370417600418287, -0.010399420242423699},
			{-0.011916119333014612, -0.010399420242423699, 0.02222686093809372}
		},
		{
			{0.062315134993201175, -0.0371360523741467, -1.287237482409413E-4},
			{-0.037136052374146696, 0.07213871248270833, -0.030825668153307093},
			{-1.2872374824094085E-4, -0.0308256681533071, 0.03395162604203321}
		},
		{
			{0.00357735739540337, -0.0053935020783903095, 0.0021531598374996174},
			{-0.0053935020783903165, 0.06493297134381769, -0.03946599646049688},
			{0.0021531598374996204, -0.039465996460496866, 0.04809258251293376}
		},
		{
			{0.015653345740778816, 3.355326047235832E-4, -0.014164504464781213},
			{3.3553260472358234E-4, 0.015740086062446, -0.004010148694621056},
			{-0.014164504464781211, -0.004010148694621051, 0.016553207139477503}
		},
		{
			{0.1293149148731839, -0.08506909906215275, -0.018945005984589793},
			{-0.08506909906215283, 0.08591726016026313, -0.004866804991536135},
			{-0.0189450059845898, -0.004866804991536144, 0.0215097435112955}
		},
		{
			{0.010179405109198895, -0.0020237651683057563, -0.007556578255181646},
			{-0.00202376516830576, 0.03096619073860622, -0.013971978798801297},
			{-0.007556578255181648, -0.013971978798801294, 0.0228264276573895}
		},
		{
			{0.07077430659818458, -0.0347804651144717, -0.0030559129018492065},
			{-0.0347804651144717, 0.04987283126111511, -0.006322353244275098},
			{-0.0030559129018492065, -0.0063223532442750995, 0.00846940054110424}
		},
		{
			{0.04590769180291984, -0.01660286272469492, -0.014581510703735298},
			{-0.01660286272469494, 0.05103190500575645, -0.006128297897012636},
			{-0.014581510703735312, -0.006128297897012632, 0.02170931710774221}
		},
		{
			{0.07294633024219101, -0.052858437610711455, -0.007373426204202634},
			{-0.0528584376107114, 0.110445005969336, -0.029609772530952597},
			{-0.007373426204202649, -0.029609772530952597, 0.023328390455569697}
		},
		{
			{0.051471265408298134, -0.048868629468600155, -4.065647282249596E-4},
			{-0.04886862946860012, 0.10695572480572704, -0.02659730377207861},
			{-4.065647282249609E-4, -0.026597303772078612, 0.016901287084510004}
		},
		{
			{0.08706164198339957, -0.003557460353544095, -0.053830967345225154},
			{-0.003557460353544071, 0.06807576731462908, 0.019610512909398883},
			{-0.05383096734522508, 0.019610512909398862, 0.058736659923735945}
		},
		{
			{0.13605461477524014, -0.05069952957867295, -0.027839302502993643},
			{-0.050699529578672985, 0.09821524641193245, -0.008955515146784297},
			{-0.02783930250299365, -0.008955515146784292, 0.02646003702228751}
		},
		{
			{0.07750411318166912, -0.06381405413814932, 0.014367573631212384},
			{-0.06381405413814936, 0.11829758967225808, -0.050743524705192215},
			{0.014367573631212391, -0.050743524705192194, 0.05756852120004479}
		},
		{
			{0.024552170221725705, -0.017871850449579382, -0.00564788736165204},
			{-0.01787185044957938, 0.04292530987532517, -0.00463988746089437},
			{-0.005647887361652042, -0.0046398874608943675, 0.014592931010721606}
		}
	};

	double barycentre[37][3] =
	{
		{72.05451127819549, 156.49624060150376, 186.17857142857142},
		{120.36402266288952, 163.10056657223797, 122.86402266288952},
		{153.92248062015503, 127.84689922480621, 61.945736434108525},
		{168.98611111111111, 173.30902777777777, 115.02777777777777},
		{133.2532679738562, 183.4607843137255, 240.51633986928104},
		{223.3370786516854, 197.3370786516854, 23.730337078651687},
		{29.04306220095694, 25.198564593301434, 29.772727272727273},
		{221.97356828193833, 98.60352422907489, 29.73127753303965},
		{133.78923766816143, 97.74887892376681, 22.59641255605381},
		{84.70794392523365, 82.59813084112149, 50.47196261682243},
		{161.54267515923567, 111.59108280254777, 95.54140127388536},
		{82.98326359832636, 76.88075313807532, 87.49372384937239},
		{182.8716577540107, 163.1657754010695, 72.76737967914438},
		{164.6597510373444, 117.49100968188105, 131.71784232365144},
		{197.38082556591212, 139.04127829560585, 147.47270306258324},
		{102.19426048565121, 172.60485651214128, 176.14128035320087},
		{27.276315789473685, 118.91447368421052, 98.11842105263158},
		{197.5531914893617, 146.68794326241135, 11.617021276595745},
		{106.14372163388805, 156.72768532526476, 215.56127080181543},
		{128.328, 195.5664, 199.6144},
		{185.85733512786004, 154.57469717362045, 190.5706594885599},
		{94.73684210526316, 195.45013850415512, 231.92382271468145},
		{128.0085910652921, 86.87113402061856, 62.90721649484536},
		{101.58612440191388, 131.44258373205741, 91.72966507177034},
		{199.11436541143655, 129.80195258019526, 103.99581589958159},
		{17.969298245614034, 159.27631578947367, 168.91666666666666},
		{136.77372262773721, 187.507299270073, 152.9507299270073},
		{197.95348837209303, 202.54152823920265, 172.88039867109634},
		{83.15798319327732, 147.30420168067226, 138.62857142857143},
		{215.7, 190.78636363636363, 119.42272727272727},
		{162.6628075253256, 129.4819102749638, 167.18668596237336},
		{114.20676691729324, 127.24624060150376, 168.67857142857142},
		{145.11281337047353, 152.70891364902508, 203.6183844011142},
		{55.74678111587983, 40.377682403433475, 53.75321888412017},
		{113.50556792873051, 103.48552338530067, 117.72605790645879},
		{176.5179282868526, 189.5438247011952, 223.9003984063745},
		{143.98532110091742, 150.52660550458717, 87.8954128440367}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<37;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<37;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance38clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027550587107560684, -0.01935725213897997, -0.0022644053449164337},
		{-0.019357252138979993, 0.03951354546819828, -0.011966564101122398},
		{-0.002264405344916432, -0.011966564101122394, 0.014299355212186596}
	};

	double matrix[38][3][3] =
	{
		{
			{0.019439879349917193, -0.00999608195688877, -0.006852306696485438},
			{-0.00999608195688877, 0.0344271337423771, -0.013110888108529695},
			{-0.006852306696485437, -0.013110888108529692, 0.025329010951066995}
		},
		{
			{0.056059424307367614, -0.031849523961795106, -0.0063316089225896426},
			{-0.0318495239617951, 0.04295561382668038, 0.002658198569812375},
			{-0.006331608922589639, 0.0026581985698123757, 0.014598444902220602}
		},
		{
			{0.0178401017407813, -0.0020585334918296096, -0.012123570813151095},
			{-0.002058533491829608, 0.02359089037560439, -0.008802209100833396},
			{-0.012123570813151095, -0.008802209100833394, 0.017623369747454497}
		},
		{
			{0.0036171440670076027, -0.005523296336481817, 0.00228098081039905},
			{-0.005523296336481822, 0.06160297861736367, -0.038368274535258096},
			{0.002280980810399058, -0.038368274535258096, 0.0480447876485743}
		},
		{
			{0.0375659578214895, -0.017821282732614605, 9.801460224018845E-4},
			{-0.01782128273261459, 0.041001054961201586, -0.0076347919163358225},
			{9.801460224018867E-4, -0.007634791916335823, 0.008516358077717131}
		},
		{
			{0.05610284766066616, -0.041080436693876995, -0.009201822082639137},
			{-0.041080436693877, 0.0843421829288893, -0.024552026305505188},
			{-0.009201822082639134, -0.024552026305505195, 0.055293951568522695}
		},
		{
			{0.051101819461522376, -0.023373268650091372, -0.011253971397115996},
			{-0.023373268650091365, 0.043294300765856775, -0.015112234387334108},
			{-0.011253971397116003, -0.015112234387334103, 0.03228290642479312}
		},
		{
			{0.04069335717606863, -0.01623167846567533, -0.0030664432180088088},
			{-0.01623167846567533, 0.0728468496872222, -0.009054387074723287},
			{-0.003066443218008808, -0.00905438707472329, 0.018840307600512106}
		},
		{
			{0.05546578919449702, -0.05640067893825683, 0.005694200218624034},
			{-0.05640067893825689, 0.11422090275548706, -0.032372359540012406},
			{0.005694200218624038, -0.0323723595400124, 0.019840932288767203}
		},
		{
			{0.047055989075847966, -0.018588966121837386, -0.01847874450427359},
			{-0.018588966121837393, 0.058491924529625657, -0.0389816077044171},
			{-0.018478744504273597, -0.0389816077044171, 0.06255185555541352}
		},
		{
			{0.06565535940563583, -0.03282501533899019, -0.009491522281307879},
			{-0.0328250153389902, 0.08059844585450955, -0.016921589853299217},
			{-0.00949152228130787, -0.01692158985329921, 0.029887741253682522}
		},
		{
			{0.09572030514148322, -0.007449245078972239, 0.0015229061256116297},
			{-0.007449245078972243, 0.05123696293637141, 0.0027530317903029225},
			{0.0015229061256116301, 0.0027530317903029216, 0.0196446963097471}
		},
		{
			{0.016949729165451777, -0.020587997263651972, 0.006782060446393731},
			{-0.020587997263651972, 0.06730029975976584, -0.0462932227867269},
			{0.006782060446393737, -0.046293222786726894, 0.04853435692036564}
		},
		{
			{0.0573614076461253, -0.01314672725697761, -0.018110492918258315},
			{-0.01314672725697761, 0.039587992155158215, -0.008150248743717899},
			{-0.018110492918258312, -0.008150248743717902, 0.0238012611838747}
		},
		{
			{0.04706172998754831, -0.010621336060771404, -0.013585630823408123},
			{-0.0106213360607714, 0.16140566177969706, -0.018095719753685714},
			{-0.013585630823408114, -0.018095719753685693, 0.05054897457379052}
		},
		{
			{0.03447570163689723, -0.024490916515220895, 2.816084613958738E-5},
			{-0.02449091651522091, 0.07200441474569264, -0.024446854262860085},
			{2.8160846139584778E-5, -0.024446854262860092, 0.031230440482977597}
		},
		{
			{0.12265306512811701, -0.07803932765747343, -0.016196122042765097},
			{-0.07803932765747343, 0.09310718255661564, -0.007348159873127723},
			{-0.0161961220427651, -0.007348159873127725, 0.0184031021918633}
		},
		{
			{0.023034836621247067, -0.015921141108348764, 0.00235495836622883},
			{-0.01592114110834876, 0.05478238997769426, -0.03835464168977438},
			{0.002354958366228839, -0.0383546416897744, 0.03435746382053481}
		},
		{
			{0.08269826189639609, -0.0705640861162087, 0.01634617938768821},
			{-0.07056408611620868, 0.12310170342040107, -0.051735423637750015},
			{0.016346179387688203, -0.05173542363775001, 0.052653861569833496}
		},
		{
			{0.04437638493461569, 0.010136125143967712, -0.008216415898439864},
			{0.010136125143967709, 0.0244795423689297, -6.304916623122276E-4},
			{-0.008216415898439862, -6.304916623122268E-4, 0.0032444727957869823}
		},
		{
			{0.0273429038901401, -0.013057151902879292, -0.006595598031840249},
			{-0.01305715190287928, 0.045527772666026006, -0.008903975667186639},
			{-0.006595598031840242, -0.008903975667186644, 0.01578927782132139}
		},
		{
			{0.030119149943887112, -0.030820078564971303, 0.008457470233769115},
			{-0.03082007856497131, 0.06818295381327721, -0.013266811468616212},
			{0.008457470233769117, -0.013266811468616212, 0.005858982183192414}
		},
		{
			{0.016181742626768088, -0.002866945852591281, -0.012811795412289998},
			{-0.002866945852591278, 0.019233223773346395, -0.0027279072975595216},
			{-0.012811795412289998, -0.0027279072975595242, 0.01511059241453301}
		},
		{
			{0.08706164198339957, -0.003557460353544095, -0.053830967345225154},
			{-0.003557460353544071, 0.06807576731462908, 0.019610512909398883},
			{-0.05383096734522508, 0.019610512909398862, 0.058736659923735945}
		},
		{
			{0.03656716166510672, -0.0112751429995278, -0.0073908694542347214},
			{-0.011275142999527813, 0.048702473100341495, -0.023638948860042207},
			{-0.007390869454234719, -0.023638948860042207, 0.034786782982415505}
		},
		{
			{0.11965711604002907, -0.05658248380836621, -0.009960459022717598},
			{-0.056582483808366196, 0.1401681728790482, -0.034090391450383735},
			{-0.009960459022717603, -0.03409039145038374, 0.021346960971564816}
		},
		{
			{0.02566440881754633, -0.011974998703333291, -0.008340716824579793},
			{-0.0119749987033333, 0.03681031250293761, -0.00721761811670376},
			{-0.008340716824579783, -0.007217618116703766, 0.017635694907655507}
		},
		{
			{0.06327300610568558, -0.04061565523903052, 0.001368448158396866},
			{-0.04061565523903054, 0.08131913837750346, -0.03418816990233298},
			{0.001368448158396882, -0.03418816990233296, 0.0323501375813185}
		},
		{
			{0.07690463338386815, -0.06692896320127553, -0.004900801888240597},
			{-0.06692896320127553, 0.104908042203844, -0.0240076723353687},
			{-0.004900801888240595, -0.0240076723353687, 0.029410607059530407}
		},
		{
			{0.07706088402303822, -0.028338417990166908, -0.006701106432745418},
			{-0.028338417990166904, 0.033601992828169405, -0.0178007774723457},
			{-0.006701106432745416, -0.01780077747234571, 0.0273160738196308}
		},
		{
			{0.02226819112289339, -0.01464065435666531, 8.828756713235326E-4},
			{-0.014640654356665304, 0.04929155037991081, -0.030620053641574926},
			{8.828756713235291E-4, -0.030620053641574926, 0.030790316294750444}
		},
		{
			{0.04714329841695884, -0.01621161235808938, -0.011446225681244397},
			{-0.0162116123580894, 0.0406825532349466, 2.9133421699592934E-4},
			{-0.0114462256812444, 2.913342169959315E-4, 0.0160405648123264}
		},
		{
			{0.014779550854757906, -0.00241686543349569, -0.007647731565071641},
			{-0.002416865433495692, 0.0350343997773059, -0.014511089744732093},
			{-0.007647731565071644, -0.014511089744732092, 0.023081886499649498}
		},
		{
			{0.029781515901101396, -0.02609530072682016, 0.00117489238987663},
			{-0.02609530072682017, 0.050565248513971976, -0.012731612709561},
			{0.00117489238987663, -0.012731612709560997, 0.014701221824285892}
		},
		{
			{0.020571015687254106, 0.003216781828279998, -0.00642052615114379},
			{0.003216781828280002, 0.014218062908644202, 0.00198613958389299},
			{-0.0064205261511438, 0.0019861395838929883, 0.007078746429076053}
		},
		{
			{0.02367874827710222, -0.019408279588160014, 0.0014263203073770292},
			{-0.01940827958816, 0.07177899879126538, -0.03335900277450551},
			{0.0014263203073770214, -0.0333590027745055, 0.0324427195644834}
		},
		{
			{0.06295426517769881, -0.0379039343808682, 2.003868721882204E-4},
			{-0.0379039343808682, 0.073360788519335, -0.029586496530761595},
			{2.0038687218821E-4, -0.029586496530761588, 0.0320055306311228}
		},
		{
			{0.0035171265776710995, -0.002285523000036917, 0.0022612513093890102},
			{-0.0022855230000369316, 0.06597229472740208, -0.042580252651713335},
			{0.002261251309389022, -0.04258025265171333, 0.04806082357260901}
		}
	};

	double barycentre[38][3] =
	{
		{101.86744186046512, 170.80116279069767, 169.37674418604652},
		{223.09876543209876, 97.19753086419753, 15.802469135802468},
		{123.07352941176471, 164.53676470588235, 122.19411764705882},
		{12.313513513513513, 161.1135135135135, 171.42702702702704},
		{203.61943319838056, 187.5425101214575, 84.31174089068826},
		{135.578073089701, 182.53986710963454, 239.06146179401992},
		{177.85813630041724, 132.05980528511822, 165.6856745479833},
		{126.91349480968859, 85.47923875432527, 59.36159169550173},
		{150.02142857142857, 150.99714285714285, 198.97142857142856},
		{187.41889763779528, 157.10236220472441, 193.07401574803148},
		{114.16808149405773, 154.31409168081495, 217.32427843803055},
		{82.76814516129032, 78.08467741935483, 86.76612903225806},
		{99.13636363636364, 197.2742946708464, 236.19278996865205},
		{142.0767857142857, 121.59107142857142, 151.01785714285714},
		{29.04306220095694, 25.198564593301434, 29.772727272727273},
		{158.52699228791775, 110.31233933161954, 90.74035989717224},
		{202.76901408450703, 200.15774647887324, 165.19154929577465},
		{62.485788113695094, 148.4625322997416, 168.6046511627907},
		{176.66735966735968, 191.0977130977131, 223.92723492723493},
		{223.7910447761194, 198.46268656716418, 12.656716417910447},
		{165.59603658536585, 170.1310975609756, 108.29573170731707},
		{142.53256704980842, 105.50574712643679, 28.168582375478927},
		{141.48336594911936, 189.39334637964774, 152.37377690802347},
		{55.74678111587983, 40.377682403433475, 53.75321888412017},
		{172.5013661202186, 118.35655737704919, 124.89480874316939},
		{112.17798594847775, 101.18032786885246, 115.01405152224824},
		{116.5984990619137, 135.71669793621012, 86.7560975609756},
		{201.5801282051282, 144.85096153846155, 140.95192307692307},
		{107.56441717791411, 131.38241308793457, 177.41513292433538},
		{220.0891719745223, 115.27388535031847, 69.40127388535032},
		{84.70347003154573, 172.24921135646687, 203.20977917981074},
		{84.8906976744186, 83.54418604651163, 50.26279069767442},
		{87.6955017301038, 144.219723183391, 128.86159169550174},
		{159.2625538020086, 144.3428981348637, 70.02008608321377},
		{196.25342465753425, 151.47260273972603, 15.95890410958904},
		{127.06962962962963, 194.7585185185185, 197.66074074074075},
		{195.58430717863106, 132.41402337228715, 102.62938230383973},
		{26.56756756756757, 119.12837837837837, 97.16891891891892}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<38;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<38;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance39clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02611888933156988, -0.0196458701904398, -0.0013465200599601112},
		{-0.019645870190439795, 0.04184693035494066, -0.013348607166688597},
		{-0.0013465200599601154, -0.01334860716668859, 0.014787897729746004}
	};

	double matrix[39][3][3] =
	{
		{
			{0.00465339022260556, -0.0028730327180650867, 0.004255159048219872},
			{-0.0028730327180650876, 0.0618568130053807, -0.042692104704561494},
			{0.004255159048219874, -0.042692104704561494, 0.05414059250080398}
		},
		{
			{0.08706164198339957, -0.003557460353544095, -0.053830967345225154},
			{-0.003557460353544071, 0.06807576731462908, 0.019610512909398883},
			{-0.05383096734522508, 0.019610512909398862, 0.058736659923735945}
		},
		{
			{0.047391090772808495, -0.030253712898236407, -0.007628158654812665},
			{-0.03025371289823642, 0.08590089582737045, -0.0362719886313639},
			{-0.007628158654812655, -0.03627198863136391, 0.07628358162082707}
		},
		{
			{0.07808191788029274, -0.060886713972361575, -0.003108806963039095},
			{-0.06088671397236156, 0.11002139587684204, -0.02682347912456081},
			{-0.0031088069630390938, -0.026823479124560817, 0.02823351847398641}
		},
		{
			{0.04683300056655327, -0.0198521541920722, -0.018417360250299396},
			{-0.019852154192072192, 0.0517856089505713, -0.031545496852456216},
			{-0.0184173602502994, -0.03154549685245619, 0.0556645577699516}
		},
		{
			{0.11621663211988789, -0.05770847495078321, -0.005136726471472196},
			{-0.05770847495078319, 0.14883941490060187, -0.039639815183846565},
			{-0.005136726471472199, -0.03963981518384656, 0.022270358872661294}
		},
		{
			{0.062006884802932344, -0.03370434125589692, 5.534972496137915E-4},
			{-0.03370434125589694, 0.06165356138102074, -0.0260316608208596},
			{5.534972496137997E-4, -0.026031660820859597, 0.029137301428712497}
		},
		{
			{0.040217423082530256, -0.01565182932063729, -0.0036502721806475963},
			{-0.015651829320637307, 0.07104188147874019, -0.010797482681277901},
			{-0.0036502721806475954, -0.0107974826812779, 0.019708662774811595}
		},
		{
			{0.05009557353705035, -0.01856194497612377, -0.011098353826245695},
			{-0.018561944976123783, 0.03628338363120732, 0.002786169798550495},
			{-0.0110983538262457, 0.002786169798550506, 0.016742781063795405}
		},
		{
			{0.020323062012805385, 0.0012419634683816724, -0.012111075640372995},
			{0.0012419634683816794, 0.026447866190995224, -0.007237068124443622},
			{-0.012111075640373004, -0.007237068124443628, 0.017102418330981417}
		},
		{
			{0.09639406506176322, -0.008263976380932217, 0.0010405498099666712},
			{-0.008263976380932219, 0.05066789736647317, 0.004946585144743683},
			{0.0010405498099666703, 0.0049465851447436805, 0.019272903978618694}
		},
		{
			{0.02702085850555037, -0.012132591858626595, -0.010888503529015596},
			{-0.012132591858626592, 0.035197564280872014, -0.005646318403593829},
			{-0.010888503529015598, -0.0056463184035938216, 0.022451132522297707}
		},
		{
			{0.055024108874171654, -0.00824643067679712, -0.020106259885605278},
			{-0.008246430676797117, 0.04015292992697318, -0.009048740788351854},
			{-0.020106259885605278, -0.009048740788351847, 0.023508855804029}
		},
		{
			{0.021391068568955614, -0.007234282666332326, -0.007828196045282437},
			{-0.007234282666332316, 0.03297319249634459, -0.009561146560467214},
			{-0.007828196045282435, -0.009561146560467219, 0.0214384286042951}
		},
		{
			{0.013975820292887811, -0.017731176409945218, 0.006299048214810266},
			{-0.017731176409945235, 0.06156786351641837, -0.04215591706540754},
			{0.006299048214810274, -0.04215591706540753, 0.04582327337272931}
		},
		{
			{0.03170684850681677, -0.034139118840130864, 0.007342171332158068},
			{-0.034139118840130885, 0.06765899491712905, -0.008627080003070388},
			{0.007342171332158069, -0.008627080003070388, 0.004089496174007211}
		},
		{
			{0.0510345325530256, -0.02589063219027629, -0.00789891257010631},
			{-0.025890632190276295, 0.047140197731032195, -0.01887103706277899},
			{-0.007898912570106312, -0.01887103706277899, 0.03649006753042348}
		},
		{
			{0.06058700909810337, -0.06343574672817331, 0.006772883062286713},
			{-0.06343574672817334, 0.13607130159608796, -0.0354868098065826},
			{0.006772883062286711, -0.035486809806582593, 0.025683297357526308}
		},
		{
			{0.03433205733991691, -0.02567056273443702, 7.705192552579024E-4},
			{-0.025670562734437033, 0.06851587068880756, -0.023513843639664404},
			{7.70519255257911E-4, -0.02351384363966441, 0.032334317324186}
		},
		{
			{0.016127312407185408, -0.010188136843477495, 7.006283197724687E-4},
			{-0.010188136843477498, 0.05017701105174328, -0.03776704591036048},
			{7.006283197724679E-4, -0.037767045910360474, 0.03517356695578139}
		},
		{
			{0.042834909986209604, -0.010142779991312507, -0.009725607020151452},
			{-0.010142779991312504, 0.1565751596550041, -0.02040196346028047},
			{-0.00972560702015145, -0.020401963460280465, 0.05163955384501496}
		},
		{
			{0.050051755741045326, -0.0446207293315118, -3.3423376425148097E-4},
			{-0.044620729331511795, 0.10041503998459701, -0.010234135012785804},
			{-3.342337642514812E-4, -0.010234135012785806, 0.006452648329783571}
		},
		{
			{0.06730487464062157, -0.04198327401376389, -0.0037490907764339554},
			{-0.04198327401376384, 0.08258011997334849, -0.0238102988331537},
			{-0.003749090776433965, -0.023810298833153706, 0.037137059359432886}
		},
		{
			{0.030506876834716846, -0.024433327524255644, 0.0021054384246107947},
			{-0.024433327524255657, 0.049924830411748757, -0.011302841999511808},
			{0.0021054384246107947, -0.01130284199951181, 0.014597790243653796}
		},
		{
			{0.01599599056548721, -0.001931252619539775, -0.006546903447383226},
			{-0.0019312526195397785, 0.0355613611222994, -0.013814571783826089},
			{-0.006546903447383229, -0.013814571783826094, 0.022736838322534814}
		},
		{
			{0.0182874556552126, -0.008868131956797093, -0.003575908306873537},
			{-0.008868131956797094, 0.05412082994824186, -0.028252379021819103},
			{-0.003575908306873543, -0.0282523790218191, 0.03021602805416332}
		},
		{
			{0.08403762332926587, -0.06785071166742561, 0.014363583449636674},
			{-0.0678507116674256, 0.1204121110474559, -0.05044237647287046},
			{0.014363583449636669, -0.05044237647287045, 0.05509890293925289}
		},
		{
			{0.055550181201511166, -0.03573761243589216, 0.0040772866452210375},
			{-0.03573761243589218, 0.08072738776694752, -0.03670429724410341},
			{0.004077286645221039, -0.03670429724410342, 0.03564115573054002}
		},
		{
			{0.052820152684314545, -0.02795061955203907, -0.0020676658743313796},
			{-0.027950619552039084, 0.05104838085372423, -0.0038902670968402105},
			{-0.0020676658743313805, -0.0038902670968402114, 0.00858322950457579}
		},
		{
			{0.022200305558111304, 0.004497218172043634, -0.005102671170171531},
			{0.0044972181720436336, 0.01746616216819371, 0.0027005959692510606},
			{-0.005102671170171531, 0.002700595969251058, 0.0038931932897758046}
		},
		{
			{0.0460135986863689, -0.016220299681005065, -0.01103280892304781},
			{-0.016220299681005065, 0.043509518526360466, -4.20517107912995E-5},
			{-0.011032808923047808, -4.2051710791296895E-5, 0.015913047108774402}
		},
		{
			{0.056965103371790095, -0.03114628982048159, -0.0060260089481337376},
			{-0.03114628982048157, 0.04123223602610975, -0.001309229934059191},
			{-0.006026008948133731, -0.001309229934059188, 0.012864455843084512}
		},
		{
			{0.004423589190076266, -0.006529900303346832, 0.002054854184718597},
			{-0.00652990030334684, 0.07250010643354324, -0.04484667967545233},
			{0.002054854184718594, -0.04484667967545232, 0.04995270898857343}
		},
		{
			{0.03725825079318649, -0.014999600685874404, -0.0032936471858326793},
			{-0.0149996006858744, 0.05278368333795921, -0.0253745534924823},
			{-0.0032936471858326776, -0.025374553492482306, 0.03360074402251549}
		},
		{
			{0.026758120112910067, -0.014307611198078243, -0.0068664615021417985},
			{-0.014307611198078243, 0.045311483470814574, -0.007713937849009655},
			{-0.006866461502141804, -0.007713937849009658, 0.015787136085368515}
		},
		{
			{0.11080317185757405, -0.04879502764657389, -0.019513563088428196},
			{-0.04879502764657385, 0.08575542919323458, -0.024169791022189396},
			{-0.019513563088428196, -0.02416979102218941, 0.0285434976208636}
		},
		{
			{0.014220625751321894, 0.002122144049264839, -0.012862773578661797},
			{0.00212214404926484, 0.018375492904232904, -0.005805470386044939},
			{-0.0128627735786618, -0.005805470386044941, 0.01707716356054861}
		},
		{
			{0.02429469688654329, -0.018239177804376373, 0.0025314151462419755},
			{-0.018239177804376373, 0.05516361838371877, -0.029396011108851892},
			{0.002531415146241973, -0.029396011108851882, 0.028171698737550398}
		},
		{
			{0.03277604232971994, -0.010241438120459228, -0.008864972312977455},
			{-0.010241438120459226, 0.03598770479654033, -0.002558444403571108},
			{-0.008864972312977459, -0.002558444403571107, 0.00677758101248956}
		}
	};

	double barycentre[39][3] =
	{
		{25.496503496503497, 118.3986013986014, 95.93006993006993},
		{56.077922077922075, 40.24025974025974, 53.86796536796537},
		{132.56130268199234, 187.55555555555554, 241.71647509578543},
		{99.94630872483222, 130.35570469798657, 174.8881431767338},
		{184.3136966126657, 157.02503681885125, 194.61708394698084},
		{112.13868613138686, 100.79318734793188, 114.61800486618004},
		{201.65009940357854, 127.9324055666004, 93.80715705765408},
		{128.68524590163935, 86.75081967213114, 59.221311475409834},
		{178.2295719844358, 207.2373540856031, 168.715953307393},
		{117.88943089430894, 160.73821138211383, 120.5691056910569},
		{82.94081632653061, 77.45918367346938, 86.64693877551021},
		{115.02453987730061, 134.64212678936605, 86.1840490797546},
		{143.2233502538071, 120.86971235194585, 149.3451776649746},
		{100.65020576131687, 168.5363511659808, 165.49245541838135},
		{96.55968992248062, 197.3674418604651, 233.9581395348837},
		{142.68949771689498, 106.0730593607306, 22.4337899543379},
		{181.38881829733165, 133.05336721728082, 164.66963151207116},
		{149.99633027522935, 166.64770642201836, 213.93761467889908},
		{158.77272727272728, 110.92424242424242, 93.15277777777777},
		{56.45945945945946, 152.32732732732734, 165.46546546546546},
		{29.05924170616114, 25.42654028436019, 29.914691943127963},
		{139.0880829015544, 141.67875647668393, 191.24870466321244},
		{109.89071038251366, 156.99635701275045, 221.13114754098362},
		{154.6710743801653, 139.43471074380165, 67.9702479338843},
		{84.64978902953587, 139.58860759493672, 127.0},
		{124.43586005830903, 194.37755102040816, 193.52915451895043},
		{178.55527638190955, 194.34170854271358, 225.86180904522612},
		{200.1688524590164, 144.81475409836065, 133.09180327868853},
		{210.4318181818182, 200.2215909090909, 106.72727272727273},
		{208.9494382022472, 168.85955056179776, 12.241573033707866},
		{85.4269406392694, 83.42465753424658, 50.166666666666664},
		{221.41964285714286, 99.70535714285714, 25.075892857142858},
		{8.452830188679245, 160.77358490566039, 172.93710691823898},
		{175.5980795610425, 119.24142661179698, 124.07818930041152},
		{161.95735294117648, 167.61764705882354, 107.11176470588235},
		{215.76548672566372, 180.641592920354, 163.10176991150442},
		{135.25185185185185, 183.3740740740741, 146.21296296296296},
		{85.91185410334346, 170.44224924012158, 197.49088145896656},
		{185.28, 167.58333333333334, 71.56}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<39;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<39;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance40clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026598226840747325, -0.019200319539539518, -0.002067733222913627},
		{-0.019200319539539518, 0.042568407608577385, -0.013646639427264297},
		{-0.0020677332229136333, -0.013646639427264289, 0.015181222598463497}
	};

	double matrix[40][3][3] =
	{
		{
			{0.012999713785862017, -7.68728403507485E-4, -0.009803354673167432},
			{-7.687284035074876E-4, 0.026724473630708893, -0.008292702796379326},
			{-0.009803354673167428, -0.008292702796379335, 0.020663563261560915}
		},
		{
			{0.018204593715325908, -0.0021903782886104183, -0.0121833466432172},
			{-0.002190378288610422, 0.023751517308806806, -0.009668352282396923},
			{-0.012183346643217196, -0.009668352282396925, 0.019292607403769396}
		},
		{
			{0.12342115789128491, -0.07879472983266754, -0.015542799288159808},
			{-0.07879472983266754, 0.09455878353742901, -0.010805579499941213},
			{-0.0155427992881598, -0.010805579499941202, 0.02117264208568781}
		},
		{
			{0.048443097837903654, -0.017968025903518887, -0.011558431083164},
			{-0.017968025903518883, 0.06758410070581507, -0.0321903288797327},
			{-0.011558431083164001, -0.0321903288797327, 0.04381837960754381}
		},
		{
			{0.05173214807841214, -0.028962292493151316, -0.014858211491633189},
			{-0.028962292493151305, 0.06113688363996303, -0.03370094659532191},
			{-0.014858211491633168, -0.03370094659532193, 0.056957279731654716}
		},
		{
			{0.04336615842142206, -0.015284763482669113, -0.010101536510323403},
			{-0.015284763482669113, 0.039661178770085216, -5.818391229742586E-4},
			{-0.010101536510323403, -5.818391229742608E-4, 0.015838230568264895}
		},
		{
			{0.0422272593076417, -0.02422885654020991, -8.560708524474087E-4},
			{-0.024228856540209905, 0.06456416458316563, -0.02809617340439581},
			{-8.560708524474056E-4, -0.028096173404395814, 0.03240762174236923}
		},
		{
			{0.13430438772526287, -0.06639192529446149, 0.002663679960121733},
			{-0.06639192529446152, 0.17449876075320495, 0.005807055043811248},
			{0.002663679960121733, 0.005807055043811249, 0.005379044956368147}
		},
		{
			{0.033407407870543, -0.035177373244897656, 0.0013308771887279899},
			{-0.03517737324489767, 0.06325674696409067, -0.005224544023294745},
			{0.0013308771887279905, -0.005224544023294747, 6.105688307918189E-4}
		},
		{
			{0.04673649033666056, -0.017957099900200363, -0.013877825624423978},
			{-0.017957099900200366, 0.03980960684748264, -0.00881856434451439},
			{-0.013877825624423976, -0.008818564344514397, 0.02946387671714189}
		},
		{
			{0.005530544586768564, -0.0023801629535320293, 0.005049575169664689},
			{-0.002380162953532012, 0.05856001445276447, -0.03989073819369508},
			{0.00504957516966467, -0.0398907381936951, 0.05368231906079439}
		},
		{
			{0.04914588941448085, -0.02364726208862259, 0.003429610050016715},
			{-0.023647262088622573, 0.04557437160025844, -0.009771587357337668},
			{0.0034296100500167143, -0.00977158735733767, 0.008681088475476141}
		},
		{
			{0.01514862068319699, -0.007223917155125222, -0.0028688075309275802},
			{-0.0072239171551252215, 0.053241664546831914, -0.024321546495591595},
			{-0.002868807530927579, -0.0243215464955916, 0.03320432479393849}
		},
		{
			{0.0655756316136941, -0.03892453901211768, -0.006207423867472265},
			{-0.03892453901211767, 0.08396786976640472, -0.019147416773703307},
			{-0.0062074238674722625, -0.019147416773703303, 0.03227533897840562}
		},
		{
			{0.02116407397697809, -0.012207490012967396, -0.0057882012856866625},
			{-0.01220749001296739, 0.0339050245262332, -0.005272040022853759},
			{-0.005788201285686664, -0.005272040022853759, 0.0206112873144693}
		},
		{
			{0.023543278370019943, -0.020530382418806045, 0.0022310757262711148},
			{-0.02053038241880604, 0.06496513609904957, -0.034234433794975316},
			{0.0022310757262711074, -0.03423443379497531, 0.029677134350292282}
		},
		{
			{0.03024343890884352, -0.016239165119894594, -0.006128712198446625},
			{-0.016239165119894598, 0.05225232131654598, -0.008779089084948335},
			{-0.006128712198446622, -0.008779089084948332, 0.015109241518517011}
		},
		{
			{0.04985079910470368, -0.04586263805232969, -0.0028151818100431996},
			{-0.04586263805232971, 0.0994284276388512, -0.009978414496511396},
			{-0.002815181810043208, -0.009978414496511396, 0.006283174379873916}
		},
		{
			{0.062250356189781204, -0.014972782383560205, -0.010907327659343907},
			{-0.014972782383560208, 0.03712016354556523, -0.014407773504781582},
			{-0.010907327659343914, -0.014407773504781587, 0.026424447959106208}
		},
		{
			{0.0547925946618198, -0.028210134626328816, -0.006084911224786127},
			{-0.028210134626328827, 0.03698719526407442, -0.003319262694321744},
			{-0.006084911224786128, -0.0033192626943217445, 0.0128907430402764}
		},
		{
			{0.04595847733803988, -0.028716402771055607, -0.005200200471078303},
			{-0.028716402771055603, 0.0873997367367362, -0.04928960205403571},
			{-0.0052002004710783, -0.04928960205403571, 0.103596108715274}
		},
		{
			{0.05021956908488369, -0.0029616158677076574, -0.005183659796437805},
			{-0.002961615867707661, 0.23928552734946815, -0.0066812805518149145},
			{-0.005183659796437811, -0.006681280551814882, 0.013228696594687804}
		},
		{
			{0.014822390316230916, -0.020183204846605705, 0.007513863579905646},
			{-0.02018320484660571, 0.06591528980269246, -0.044466547961655334},
			{0.007513863579905647, -0.04446654796165534, 0.04729388667873581}
		},
		{
			{0.0808375811327343, 0.0014380472632814362, -0.05080525002592599},
			{0.0014380472632814223, 0.12180218708826104, -0.06252263442700794},
			{-0.05080525002592598, -0.06252263442700792, 0.129826939016006}
		},
		{
			{0.058058101443115455, -0.03766407459264591, 0.0016174525059592442},
			{-0.037664074592645924, 0.08430275939305994, -0.038496381222748906},
			{0.0016174525059592408, -0.03849638122274889, 0.037523472574061086}
		},
		{
			{0.019407514417156907, -0.003371400937259741, -0.007866470589825654},
			{-0.0033714009372597382, 0.03575588380733518, -0.014445809087852614},
			{-0.007866470589825654, -0.01444580908785261, 0.0227023798217334}
		},
		{
			{0.09898665836846893, -0.016445958678309933, 4.7731443503772346E-4},
			{-0.01644595867830994, 0.06767842901996232, 0.009475595327863797},
			{4.7731443503772444E-4, 0.009475595327863795, 0.0180633600005954}
		},
		{
			{0.02177135193000129, -0.01308492323846159, 6.47813400896149E-4},
			{-0.013084923238461601, 0.05169682948851452, -0.03495772368001312},
			{6.478134008961494E-4, -0.03495772368001312, 0.032708084501248805}
		},
		{
			{0.06387945395553984, -0.03421657203412331, -3.1935971375370714E-4},
			{-0.03421657203412332, 0.05985919242759751, -0.0264598496366638},
			{-3.193597137537128E-4, -0.0264598496366638, 0.031148108618810982}
		},
		{
			{0.08804992677791294, -0.0225138444811114, -0.06474062819084905},
			{-0.02251384448111138, 0.06994326846267399, 0.025909554789632295},
			{-0.06474062819084904, 0.02590955478963229, 0.05780038417634533}
		},
		{
			{0.04387570734366799, -0.015937248427548904, -0.004130231622976002},
			{-0.01593724842754889, 0.06793053898912715, -0.011036826127960605},
			{-0.004130231622976003, -0.011036826127960609, 0.020505219254597314}
		},
		{
			{0.0034647160616541922, -0.0053398209572087215, 6.621568975267405E-4},
			{-0.005339820957208696, 0.06416734018094061, -0.043475083848082366},
			{6.621568975267379E-4, -0.04347508384808238, 0.05229307770158301}
		},
		{
			{0.028875066301857603, -0.023767989685228218, 2.395475322589406E-5},
			{-0.02376798968522821, 0.04623215256338129, -0.011660247837998801},
			{2.395475322588842E-5, -0.0116602478379988, 0.014083582640056595}
		},
		{
			{0.0209847347762764, 0.0047411672127346755, -0.00446461972899297},
			{0.004741167212734675, 0.018573204558385098, 0.003430302878309478},
			{-0.004464619728992973, 0.0034303028783094804, 0.004267467574218635}
		},
		{
			{0.08570422996929433, -0.06657231982518026, 0.01176493190386154},
			{-0.06657231982518026, 0.1281479071695449, -0.033957834870818174},
			{0.011764931903861542, -0.03395783487081816, 0.04681719670852331}
		},
		{
			{0.03493857528595179, -0.026256166640907873, 0.0017284468817569398},
			{-0.0262561666409079, 0.07074282960248393, -0.0209228644435015},
			{0.0017284468817569407, -0.02092286444350151, 0.0287376183286749}
		},
		{
			{0.07975338156944473, -0.06267760342577305, 7.567632452446355E-4},
			{-0.06267760342577305, 0.10831754232407899, -0.027932358617811008},
			{7.567632452446312E-4, -0.027932358617810994, 0.0295890608970417}
		},
		{
			{0.016271206883735293, -0.0026893193902808835, -0.013210288706041304},
			{-0.002689319390280885, 0.018418880854815713, -0.003091817105609123},
			{-0.013210288706041313, -0.0030918171056091245, 0.014932216728437014}
		},
		{
			{0.026905282617433683, -0.014235186897477579, -0.0019440041661715028},
			{-0.014235186897477586, 0.03975509113742002, -0.017015843864889888},
			{-0.0019440041661715015, -0.017015843864889878, 0.02646343277484988}
		},
		{
			{0.05393389805738363, -0.060316484034969066, 0.0045850783851402325},
			{-0.06031648403496905, 0.1313202240404269, -0.03280365377985008},
			{0.004585078385140234, -0.03280365377985008, 0.026704127863102504}
		}
	};

	double barycentre[40][3] =
	{
		{98.76315789473684, 164.63815789473685, 151.3125},
		{125.41626016260163, 163.1528455284553, 118.80325203252032},
		{201.19298245614036, 199.61988304093566, 167.66081871345028},
		{189.58500914076782, 144.67276051188298, 176.7404021937843},
		{181.62476547842402, 162.5234521575985, 202.17260787992495},
		{84.4829268292683, 84.38536585365854, 50.41951219512195},
		{175.68211920529802, 120.31788079470199, 118.63708609271524},
		{108.18357487922705, 98.82850241545894, 108.61352657004831},
		{148.11698113207547, 114.40377358490566, 30.471698113207548},
		{168.96744186046513, 126.54573643410853, 158.95658914728682},
		{25.52857142857143, 118.59285714285714, 95.54285714285714},
		{212.02645502645504, 195.88888888888889, 99.66666666666667},
		{128.56029684601114, 198.06679035250463, 199.16141001855289},
		{108.93478260869566, 157.09420289855072, 219.56702898550725},
		{125.72627737226277, 137.21167883211677, 82.25547445255475},
		{78.17338709677419, 168.23790322580646, 199.09274193548387},
		{167.4003164556962, 169.94145569620252, 108.94303797468355},
		{140.36363636363637, 140.64705882352942, 190.80035650623887},
		{137.77325581395348, 117.32558139534883, 141.7248062015504},
		{221.10087719298247, 100.25438596491227, 24.837719298245613},
		{131.74847870182555, 186.3346855983773, 243.21703853955376},
		{27.539033457249072, 20.029739776951672, 23.53159851301115},
		{96.6882911392405, 197.24208860759492, 234.22310126582278},
		{37.86624203821656, 37.01273885350319, 43.84394904458599},
		{200.28810975609755, 142.77591463414635, 138.7484756097561},
		{89.02713987473904, 138.17536534446765, 118.05219206680584},
		{82.38325991189427, 76.66740088105728, 85.44493392070484},
		{58.9969696969697, 147.03636363636363, 160.4090909090909},
		{204.03012048192772, 129.73493975903614, 94.71887550200803},
		{62.96190476190476, 41.51428571428571, 58.457142857142856},
		{126.4866220735786, 84.97324414715719, 55.214046822742475},
		{11.255681818181818, 161.55113636363637, 172.7215909090909},
		{167.25785123966944, 151.60826446280993, 70.63140495867769},
		{207.83838383838383, 171.61111111111111, 17.338383838383837},
		{177.61408450704226, 197.10985915492958, 227.35211267605635},
		{157.702634880803, 110.534504391468, 88.83814303638646},
		{101.06637168141593, 130.84513274336283, 174.8495575221239},
		{140.40377358490565, 188.4679245283019, 151.51509433962264},
		{105.40756914119359, 176.00873362445415, 182.45997088791847},
		{147.7874762808349, 166.44212523719165, 214.99240986717268}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<40;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<40;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance41clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02764405077908221, -0.020174823554500423, -0.0023004676981659166},
		{-0.020174823554500423, 0.04188546520205711, -0.0126065322879471},
		{-0.0023004676981659205, -0.012606532287947102, 0.014503941915151196}
	};

	double matrix[41][3][3] =
	{
		{
			{0.0716940956882362, -0.029408519006843527, -0.00228651131227015},
			{-0.029408519006843506, 0.041371919827371706, -0.022314934805247995},
			{-0.002286511312270149, -0.022314934805247995, 0.026658015445547086}
		},
		{
			{0.043510136646046464, -0.03918821601041686, 5.511558330442796E-4},
			{-0.03918821601041684, 0.08079818833713695, -0.01886081267194271},
			{5.51155833044284E-4, -0.018860812671942704, 0.025367605346753495}
		},
		{
			{0.05188737614000527, -0.04139278833229918, -0.003509906566500423},
			{-0.04139278833229919, 0.0896388986155203, -0.030302233818711888},
			{-0.003509906566500416, -0.030302233818711888, 0.06471173445328215}
		},
		{
			{0.0274587105633489, -0.020312213728989007, 2.7504486477685896E-4},
			{-0.020312213728989007, 0.047037115098309844, -0.008934073004852026},
			{2.7504486477685636E-4, -0.008934073004852022, 0.014433238163634898}
		},
		{
			{0.011043372501954397, 1.6992278211468061E-4, -0.009149359508967662},
			{1.6992278211468495E-4, 0.03358953866088221, -0.007946206694576786},
			{-0.009149359508967664, -0.007946206694576777, 0.02051632252437622}
		},
		{
			{0.08609051084323835, -0.06608685750638961, 0.01469967092903105},
			{-0.06608685750638968, 0.12826921121639218, -0.033428704950369856},
			{0.014699670929031057, -0.03342870495036985, 0.05062805333141575}
		},
		{
			{0.060343867462075394, -0.017747131672572, 0.005520855520241958},
			{-0.017747131672572, 0.029964226778307224, -0.007201963826757232},
			{0.005520855520241956, -0.007201963826757234, 0.007085311259729134}
		},
		{
			{0.09405359581684514, -0.04426051227872723, -0.018106099426464396},
			{-0.04426051227872721, 0.06784896483320743, -0.007732971885442886},
			{-0.0181060994264644, -0.007732971885442889, 0.021071074416889803}
		},
		{
			{0.0240490715777579, -0.0149171545158354, -0.0012041309285055926},
			{-0.014917154515835406, 0.04137846258915993, -0.01923330286035229},
			{-0.001204130928505596, -0.019233302860352297, 0.027611566793768402}
		},
		{
			{0.09725905414247119, -0.020159700005676594, 0.0022629080825986468},
			{-0.020159700005676594, 0.08280436778392233, 0.009010860540412644},
			{0.0022629080825986468, 0.009010860540412651, 0.018063359977288005}
		},
		{
			{0.04027899867765949, -0.015657694509638456, -0.010180059161706199},
			{-0.015657694509638463, 0.056131454252127996, 0.004132963675453436},
			{-0.010180059161706194, 0.00413296367545343, 0.016759583123422298}
		},
		{
			{0.05047926381334081, -0.04314826129589381, -0.0022477876953424687},
			{-0.04314826129589381, 0.09773112532135755, -0.016985035925317304},
			{-0.002247787695342467, -0.0169850359253173, 0.012389172873323402}
		},
		{
			{0.025126626199283117, -0.01772165695471161, 0.002820893881479345},
			{-0.017721656954711628, 0.0528853749566866, -0.03730688141315371},
			{0.0028208938814793536, -0.03730688141315371, 0.03821932132530882}
		},
		{
			{0.0037404428561839433, -0.007000649041627831, 0.0017922446104462028},
			{-0.007000649041627824, 0.06747614507071872, -0.03967588785478289},
			{0.0017922446104462033, -0.03967588785478289, 0.047803252188165994}
		},
		{
			{0.044812911105136174, -0.011502181978488547, -0.004830175703470653},
			{-0.011502181978488539, 0.058096207288374765, -0.008615425893204354},
			{-0.0048301757034706514, -0.008615425893204347, 0.020935544470561496}
		},
		{
			{0.05766333568152907, -0.037958856151380775, -0.0015444183412258593},
			{-0.03795885615138075, 0.08440149791634532, -0.03720938457772532},
			{-0.001544418341225871, -0.0372093845777253, 0.03947982754835634}
		},
		{
			{0.06198869844383231, -0.019147844178668397, -0.012463749436558608},
			{-0.01914784417866839, 0.040165350466242575, -0.009561288991838075},
			{-0.012463749436558601, -0.009561288991838075, 0.020947115812159696}
		},
		{
			{0.08110547995174487, -0.06984680508095065, -0.0061101487471767225},
			{-0.06984680508095056, 0.10972972076286194, -0.027290098277536697},
			{-0.006110148747176726, -0.027290098277536704, 0.02810447388488043}
		},
		{
			{0.042834909897535016, -0.010142780168160108, -0.00972560701740233},
			{-0.010142780168160117, 0.15657515938627106, -0.020401963358226173},
			{-0.009725607017402346, -0.020401963358226183, 0.05163955393765993}
		},
		{
			{0.026434076846196895, -0.01050457735650509, -0.010726132179875596},
			{-0.010504577356505097, 0.03471129855830238, -0.011474602365699504},
			{-0.010726132179875603, -0.011474602365699504, 0.022895846572346105}
		},
		{
			{0.02708128806498649, -0.02732466820077438, 0.0070743787244738525},
			{-0.027324668200774366, 0.08455319593318535, -0.03267974894616343},
			{0.007074378724473858, -0.03267974894616342, 0.031723421068370006}
		},
		{
			{0.015928851624379882, -0.0011016789649331417, -0.013241611353261894},
			{-0.001101678964933149, 0.01622063578745401, -0.004238296240446728},
			{-0.013241611353261901, -0.004238296240446731, 0.016286902712142216}
		},
		{
			{0.027268029262925604, -0.028688588296481597, 0.00204067180936609},
			{-0.028688588296481587, 0.05833217838079183, -0.005116700466804755},
			{0.00204067180936609, -0.005116700466804756, 0.0011358830520386098}
		},
		{
			{0.051000151151899084, -0.012214213909273509, -0.014689061628725809},
			{-0.012214213909273509, 0.0344709555230505, -0.005872085204766954},
			{-0.014689061628725804, -0.0058720852047669594, 0.0214391730517089}
		},
		{
			{0.02813411282226038, -0.0132935525807301, -0.006336568234874776},
			{-0.013293552580730093, 0.0394408404951516, -0.0050867986957731474},
			{-0.006336568234874773, -0.005086798695773139, 0.0087947959046871}
		},
		{
			{0.04921086093263439, -0.02417122001752148, -0.005599240177878184},
			{-0.02417122001752148, 0.036829726022903485, 8.93047365750434E-4},
			{-0.005599240177878184, 8.93047365750434E-4, 0.014917038395261806}
		},
		{
			{0.1501562499695029, -0.125890179744662, -0.026850255953801187},
			{-0.125890179744662, 0.13229806247455114, 0.010440178989709711},
			{-0.026850255953801187, 0.010440178989709703, 0.023317740450629898}
		},
		{
			{0.014307597385001895, -0.01797441706537669, 0.005791381084098394},
			{-0.01797441706537669, 0.06171170636026779, -0.04059034081645585},
			{0.005791381084098394, -0.040590340816455836, 0.042523117115183716}
		},
		{
			{0.03277668354013533, -0.0186278437564865, 0.001363581265887647},
			{-0.01862784375648652, 0.07343849967186278, -0.022565650983291025},
			{0.0013635812658876513, -0.022565650983291028, 0.02739305224881672}
		},
		{
			{0.014017423214187504, 4.521310952468674E-5, -0.008426048403238375},
			{4.5213109524685005E-5, 0.040758409686077385, -0.018312156245846894},
			{-0.008426048403238377, -0.018312156245846898, 0.023594495930721916}
		},
		{
			{0.08961574887586178, 0.003946769556022193, -0.051038191629040795},
			{0.0039467695560221824, 0.09464391276889389, 0.02276341883947187},
			{-0.0510381916290408, 0.02276341883947187, 0.0514045411965773}
		},
		{
			{0.01824687298531559, -0.0017381096034078652, -0.01163743940082309},
			{-0.0017381096034078617, 0.02440247189901068, -0.008473968447076787},
			{-0.011637439400823086, -0.008473968447076787, 0.018299108186291987}
		},
		{
			{0.003518801086773969, -0.0014854291214086042, 0.0017318135725418447},
			{-0.0014854291214086092, 0.06031569977747589, -0.04369474083291889},
			{0.0017318135725418475, -0.043694740832918896, 0.05662041990140948}
		},
		{
			{0.13256725631786218, -0.08586114834778104, -0.0028254563937434385},
			{-0.08586114834778098, 0.19591442437132803, -0.030740990167634895},
			{-0.002825456393743436, -0.030740990167634895, 0.01928649668242649}
		},
		{
			{0.05460174362599149, -0.03291087076764377, -0.008454155483139528},
			{-0.032910870767643784, 0.08527835744893351, -0.0165757042563294},
			{-0.008454155483139516, -0.01657570425632941, 0.029387453475997395}
		},
		{
			{0.02144800129360341, 0.003111596663236999, -0.007741565579911826},
			{0.0031115966632369973, 0.014911862518078998, 0.005232777377892544},
			{-0.007741565579911826, 0.0052327773778925455, 0.009961113873688362}
		},
		{
			{0.028727163752777885, -0.014803996676143289, -0.006541400501717173},
			{-0.014803996676143284, 0.05434799989333121, -0.0234523121086128},
			{-0.006541400501717173, -0.023452312108612795, 0.03735495369246791}
		},
		{
			{0.060065735691148106, -0.037046130203174404, -0.003421114475930994},
			{-0.037046130203174384, 0.07860667494722576, -0.034513923589930606},
			{-0.0034211144759309976, -0.03451392358993061, 0.03957101583916678}
		},
		{
			{0.04028003083821551, -0.029412328264166798, 0.003565043094179254},
			{-0.029412328264166804, 0.08336072889113764, -0.013010838503583907},
			{0.0035650430941792537, -0.013010838503583904, 0.01840537055344}
		},
		{
			{0.0527563476229899, -0.03173878456309259, -0.009919971947957497},
			{-0.0317387845630926, 0.05830835040364816, -0.028572731322730194},
			{-0.009919971947957493, -0.028572731322730197, 0.04880176768064017}
		},
		{
			{0.028844127273832815, -0.015759275521338493, -0.0061161865896161285},
			{-0.015759275521338507, 0.05455267937712341, -0.00944899523674046},
			{-0.00611618658961613, -0.009448995236740452, 0.0156612341614787}
		}
	};

	double barycentre[41][3] =
	{
		{219.5367231638418, 121.0225988700565, 78.11299435028249},
		{176.28699551569505, 119.74439461883408, 84.70403587443946},
		{134.25728155339806, 181.39967637540454, 239.16343042071196},
		{145.64992389649925, 142.1461187214612, 76.5144596651446},
		{99.81697171381032, 165.66722129783693, 153.23627287853577},
		{175.72922252010724, 195.67024128686327, 228.16890080428954},
		{210.45454545454547, 201.46212121212122, 82.0530303030303},
		{213.39240506329114, 184.88185654008439, 140.91139240506328},
		{102.8686730506156, 176.95075239398085, 185.90697674418604},
		{84.04978354978356, 76.37878787878788, 87.34199134199135},
		{79.49595687331536, 81.60646900269542, 52.43935309973046},
		{138.0698757763975, 148.25310559006212, 200.5885093167702},
		{69.76923076923077, 159.04700854700855, 186.0363247863248},
		{17.513392857142858, 159.30803571428572, 168.94642857142858},
		{118.99786324786325, 84.0042735042735, 47.9508547008547},
		{198.4695652173913, 142.50608695652173, 159.6713043478261},
		{139.19161676646706, 122.05988023952096, 150.86027944111777},
		{101.71753986332574, 130.06150341685648, 175.95671981776766},
		{28.9618138424821, 25.381861575179, 29.82577565632458},
		{103.95454545454545, 131.56313131313132, 89.46464646464646},
		{131.01360544217687, 196.10884353741497, 199.6139455782313},
		{139.2770870337478, 187.3392539964476, 150.39609236234458},
		{148.14285714285714, 113.87619047619047, 24.957142857142856},
		{169.24506578947367, 137.17927631578948, 176.08881578947367},
		{180.8294117647059, 158.71764705882353, 67.08235294117647},
		{222.01612903225808, 97.83333333333333, 18.9247311827957},
		{193.35537190082644, 206.3181818181818, 176.9504132231405},
		{95.830242510699, 196.62767475035665, 233.10413694721825},
		{160.8655834564254, 113.28655834564255, 108.80206794682422},
		{79.04357298474946, 140.4488017429194, 132.119825708061},
		{55.689277899343544, 39.87746170678337, 53.8074398249453},
		{122.99526813880126, 161.31703470031545, 117.99369085173501},
		{24.656934306569344, 117.98540145985402, 95.27737226277372},
		{108.89182058047493, 102.25065963060686, 116.99736147757255},
		{105.23268206039076, 158.52042628774421, 219.30373001776198},
		{208.91772151898735, 167.51898734177215, 9.10759493670886},
		{175.06532663316582, 121.55778894472361, 141.38023450586266},
		{198.87306501547988, 134.95510835913313, 117.06965944272446},
		{140.4949494949495, 96.02222222222223, 74.56767676767677},
		{179.6896046852123, 162.66617862371888, 202.34553440702783},
		{167.4796238244514, 170.13166144200628, 109.65203761755485}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<41;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<41;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance42clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027005682870023005, -0.019703137415363083, -0.002112976714048283},
		{-0.019703137415363083, 0.042572264218450014, -0.013224788778450004},
		{-0.0021129767140482805, -0.013224788778450009, 0.014805410410789185}
	};

	double matrix[42][3][3] =
	{
		{
			{0.01601989660091561, -0.006188471392110384, -0.003140669066425182},
			{-0.006188471392110386, 0.05756168008946392, -0.028480856868131094},
			{-0.003140669066425182, -0.028480856868131097, 0.0346303469738228}
		},
		{
			{0.03184190015213758, -0.017000356819557395, -0.003912580733231996},
			{-0.017000356819557395, 0.05208895178558756, -0.011416260458271304},
			{-0.003912580733231988, -0.011416260458271297, 0.016597679131856197}
		},
		{
			{0.11178900330440907, -0.052074561413381, -0.025610303847800518},
			{-0.052074561413380946, 0.07210240359009458, -0.012222190758845133},
			{-0.025610303847800504, -0.012222190758845126, 0.03173125684426713}
		},
		{
			{0.07519338514701893, -0.03165519535396278, -0.003315637883970763},
			{-0.03165519535396277, 0.04338984674526974, -0.02458649088987513},
			{-0.00331563788397076, -0.024586490889875124, 0.02971397999946402}
		},
		{
			{0.004115564817199766, -0.0024253403149197264, 0.0017615998598593677},
			{-0.002425340314919722, 0.05987883211622225, -0.04646531276237938},
			{0.0017615998598593651, -0.046465312762379356, 0.05939067481465217}
		},
		{
			{0.011662396169012604, -8.155743056548247E-4, -0.007691267581151386},
			{-8.155743056548273E-4, 0.03585536158860729, -0.010540334112689804},
			{-0.007691267581151387, -0.010540334112689804, 0.020622444153042617}
		},
		{
			{0.04921889044624035, -0.0157584550836677, -0.009950804157405149},
			{-0.015758455083667702, 0.04000108227830985, 0.0026607434303049992},
			{-0.009950804157405145, 0.0026607434303049992, 0.016875008947825}
		},
		{
			{0.05112055217323972, -0.020439642247368515, 0.0023066813478282685},
			{-0.020439642247368515, 0.04160983746640473, -0.008366516424144748},
			{0.0023066813478282667, -0.008366516424144751, 0.008544651426543504}
		},
		{
			{0.011854311894546114, -0.01667138325465123, 0.005653815368198925},
			{-0.01667138325465123, 0.060813301339944816, -0.039579141508385915},
			{0.0056538153681989275, -0.039579141508385915, 0.042309709716751916}
		},
		{
			{0.027065795806209, -0.014779057400032205, -0.001389186060160882},
			{-0.0147790574000322, 0.03845591873203558, -0.01907962486990139},
			{-0.0013891860601608842, -0.019079624869901394, 0.027779594139608704}
		},
		{
			{0.0166626086269886, 4.993593733580029E-4, -0.007226023145878082},
			{4.993593733580003E-4, 0.04147763827037282, -0.016970767518962322},
			{-0.0072260231458780855, -0.016970767518962322, 0.024179375229923923}
		},
		{
			{0.0179162030861681, -0.0016607145811292929, -0.012628798839308791},
			{-0.0016607145811293016, 0.0242796216112369, -0.008031032809559633},
			{-0.012628798839308793, -0.008031032809559635, 0.018519020687285396}
		},
		{
			{0.01946387942921909, 0.0023054940257047933, -0.005856447771783626},
			{0.002305494025704793, 0.014613881848058702, 0.0032935867722639262},
			{-0.005856447771783625, 0.0032935867722639267, 0.007711298055218701}
		},
		{
			{0.06179546852005874, -0.03461626603845421, -0.006322075702460156},
			{-0.03461626603845424, 0.0865383724409007, -0.019223705550621306},
			{-0.006322075702460159, -0.019223705550621306, 0.027201635906960103}
		},
		{
			{0.04651326838533301, -0.019104947752058017, -0.019277383049154218},
			{-0.019104947752058017, 0.05390790698443498, -0.034053524018759086},
			{-0.01927738304915422, -0.03405352401875909, 0.05685464422911081}
		},
		{
			{0.01446584765766442, 0.003358811556918607, -0.014211148301709014},
			{0.0033588115569186026, 0.014720293146847602, -0.004120122769408325},
			{-0.014211148301709005, -0.004120122769408318, 0.016440641642377407}
		},
		{
			{0.05777919536933253, -0.012187011192645376, -0.037947987706710706},
			{-0.012187011192645376, 0.11538124610572695, -0.03659928472030817},
			{-0.03794798770671069, -0.036599284720308184, 0.10378252967436298}
		},
		{
			{0.030615479870835828, -0.010114976027347716, -0.01259766263108671},
			{-0.010114976027347714, 0.0323689807402042, -0.007029998431882218},
			{-0.01259766263108671, -0.007029998431882226, 0.019097743454949717}
		},
		{
			{0.04078297126025549, -0.014085502899425496, -0.003906326510610445},
			{-0.01408550289942548, 0.06782457486929167, -0.0071867409244577764},
			{-0.003906326510610445, -0.007186740924457778, 0.0201062161737351}
		},
		{
			{0.0035294716311680334, -0.006185125830295759, 0.0023807233247818862},
			{-0.006185125830295746, 0.0675633859324645, -0.037558786251789704},
			{0.002380723324781881, -0.0375587862517897, 0.04702346071230141}
		},
		{
			{0.08207085582961945, -0.06276230020093954, 0.013019672301039637},
			{-0.0627623002009396, 0.11700809830480108, -0.050247791026378136},
			{0.013019672301039637, -0.05024779102637812, 0.057590327897983906}
		},
		{
			{0.020252805117571545, -0.011170444306573664, 0.003219676184007961},
			{-0.011170444306573657, 0.06786922967259415, -0.008553731744390865},
			{0.003219676184007958, -0.008553731744390867, 0.00411118713805394}
		},
		{
			{0.08098171648806943, -0.06425499582743129, -0.0034510781641614503},
			{-0.06425499582743131, 0.1077880992326201, -0.024959054406192407},
			{-0.0034510781641614507, -0.0249590544061924, 0.02756971660813329}
		},
		{
			{0.059667033293423793, -0.03927747706499151, -2.903974926741662E-4},
			{-0.03927747706499148, 0.08134389909368539, -0.034739340264026995},
			{-2.9039749267417963E-4, -0.03473934026402701, 0.038215684099028605}
		},
		{
			{0.02549819880135899, -0.017172878841212883, -0.005316467379984462},
			{-0.017172878841212883, 0.033843165825878, -0.0064513164577832995},
			{-0.005316467379984458, -0.0064513164577832995, 0.016545816469421794}
		},
		{
			{0.025192951978824117, -0.018789769998774495, 0.003804280277977647},
			{-0.018789769998774495, 0.05194436096000955, -0.03819713589802932},
			{0.0038042802779776385, -0.03819713589802931, 0.03943806217138968}
		},
		{
			{0.03442537344351392, -0.005207383148613907, -0.010648040113614615},
			{-0.005207383148613901, 0.043277472101976376, -0.02013456990890071},
			{-0.010648040113614615, -0.020134569908900696, 0.03189307072038162}
		},
		{
			{0.0567255975385638, -0.018558402807402802, -0.016438407849951504},
			{-0.018558402807402802, 0.02984491128540401, 0.007807925999919876},
			{-0.016438407849951504, 0.007807925999919885, 0.0182632715823636}
		},
		{
			{0.05360327920845553, -0.03031279378326511, -0.005388648381082096},
			{-0.030312793783265114, 0.04425024279439159, 0.0018575273998563758},
			{-0.005388648381082104, 0.001857527399856368, 0.013822247243586896}
		},
		{
			{0.027536977910793396, -0.010839473644791184, -0.0041310584603769275},
			{-0.010839473644791178, 0.035123556197201665, -0.0044878072189508365},
			{-0.004131058460376923, -0.004487807218950838, 0.01657804073576811}
		},
		{
			{0.1176866100026429, -0.035221540424040985, 0.009132683827496194},
			{-0.03522154042404102, 0.08020112634979679, -0.006175200350510109},
			{0.009132683827496197, -0.006175200350510106, 0.011789093602100698}
		},
		{
			{0.040107345177618485, -0.01895160121637428, -3.993056817039823E-4},
			{-0.0189516012163743, 0.06273902742711823, -0.020304842706409983},
			{-3.993056817039732E-4, -0.020304842706409986, 0.025744893451175373}
		},
		{
			{0.05948036571921781, -0.03616764833490525, -0.0050185419345056236},
			{-0.03616764833490526, 0.07811766484492973, -0.03520852840081968},
			{-0.005018541934505634, -0.03520852840081969, 0.042647834986845885}
		},
		{
			{0.06906997611888299, -0.0204130303337249, -0.0185141979716116},
			{-0.0204130303337249, 0.04030243275459529, -0.007450807510652168},
			{-0.0185141979716116, -0.00745080751065216, 0.025697402878388304}
		},
		{
			{0.05162076436463003, -0.04354742450029969, -0.004284618124487896},
			{-0.04354742450029971, 0.11046813553226295, -0.012742243647391101},
			{-0.004284618124487891, -0.012742243647391101, 0.008227046898990564}
		},
		{
			{0.059365236970330464, -0.05891415079655185, 0.003802666480429968},
			{-0.05891415079655185, 0.12190673047570398, -0.025378846006160187},
			{0.003802666480429969, -0.025378846006160187, 0.020661975317182092}
		},
		{
			{0.03693605350721349, -0.028654228944198473, -0.0027761698101761508},
			{-0.028654228944198463, 0.07459228452988714, -0.029260906696353697},
			{-0.0027761698101761456, -0.02926090669635372, 0.03890181091675952}
		},
		{
			{0.03368769520182014, -0.035977248467514246, 0.008436363750201303},
			{-0.03597724846751425, 0.055048590709120084, -0.013289107342404396},
			{0.008436363750201306, -0.013289107342404394, 0.012293062134546794}
		},
		{
			{0.08750230946905571, -0.035949347696196704, -0.06005350484162979},
			{-0.035949347696196676, 0.06470315457472975, 0.030499466252653144},
			{-0.06005350484162976, 0.030499466252653144, 0.05573785781382811}
		},
		{
			{0.04512467757869751, -0.011721862254989487, -0.01646083891415299},
			{-0.011721862254989487, 0.03910170885821318, -0.008351283290465215},
			{-0.016460838914152995, -0.008351283290465215, 0.0296990626249128}
		},
		{
			{0.03299908333661398, 3.2019587182118914E-4, -0.0063201126254339305},
			{3.2019587182118947E-4, 0.04650803091029261, -1.871802656240703E-4},
			{-0.006320112625433931, -1.8718026562406949E-4, 0.003191303849420461}
		},
		{
			{0.04630796497856379, -0.03319634134408702, -0.0027014769923959306},
			{-0.03319634134408702, 0.09697730777926894, -0.05848465130945216},
			{-0.0027014769923959306, -0.05848465130945216, 0.10942741128573295}
		}
	};

	double barycentre[42][3] =
	{
		{128.69060773480663, 197.4401473296501, 198.92081031307552},
		{168.80831826401447, 173.92224231464738, 116.12115732368898},
		{217.4139534883721, 181.05116279069767, 159.32558139534885},
		{214.14883720930231, 122.6046511627907, 79.41395348837209},
		{24.927007299270073, 117.76642335766424, 94.69343065693431},
		{96.0, 163.9467554076539, 153.92179700499167},
		{83.31176470588235, 81.34509803921569, 56.037254901960786},
		{212.89655172413794, 200.73103448275862, 99.48965517241379},
		{94.51598173515981, 196.36529680365297, 232.8614916286149},
		{100.90846047156727, 175.7975034674064, 188.14424410540914},
		{80.67692307692307, 136.74945054945056, 128.378021978022},
		{121.71725239616613, 162.17571884984025, 120.02396166134186},
		{196.3181818181818, 147.99242424242425, 11.31060606060606},
		{106.81238615664846, 157.77231329690346, 220.4408014571949},
		{184.47445255474452, 156.592700729927, 193.55182481751825},
		{132.03423423423425, 185.43783783783783, 153.72792792792794},
		{32.61764705882353, 28.082720588235293, 32.89705882352941},
		{109.55282555282555, 132.57985257985257, 87.01965601965603},
		{125.74131944444444, 85.63715277777777, 57.10243055555556},
		{17.894736842105264, 158.87280701754386, 168.23245614035088},
		{179.20448877805487, 193.49625935162095, 225.89027431421445},
		{137.8901098901099, 100.75824175824175, 19.060439560439562},
		{99.33496332518338, 130.21026894865525, 175.79462102689487},
		{195.96226415094338, 138.66209262435677, 154.41509433962264},
		{146.98418972332016, 152.28853754940712, 87.79644268774703},
		{68.28337236533957, 158.7775175644028, 186.62060889929742},
		{170.6206896551724, 118.1888341543514, 132.183908045977},
		{182.03112840466926, 208.1828793774319, 168.5058365758755},
		{222.5891891891892, 96.4972972972973, 20.886486486486486},
		{182.29775280898878, 162.24157303370785, 72.46629213483146},
		{90.61680327868852, 88.55122950819673, 99.28483606557377},
		{142.66138613861386, 102.2910891089109, 98.6059405940594},
		{200.24444444444444, 136.87692307692308, 117.66666666666667},
		{130.60167714884696, 118.57442348008385, 144.50314465408806},
		{135.8210332103321, 142.88376383763838, 193.25830258302582},
		{150.6536312849162, 165.87337057728118, 214.43016759776538},
		{172.8854961832061, 119.09618320610687, 97.38931297709924},
		{154.28880157170923, 125.67583497053045, 62.616895874263264},
		{62.37652811735941, 43.32762836185819, 62.770171149144254},
		{166.62131147540984, 130.49344262295082, 168.17377049180328},
		{222.5897435897436, 197.24358974358975, 17.96153846153846},
		{131.47761194029852, 186.6417910447761, 242.38619402985074}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<42;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<42;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance43clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026339627957402103, -0.019188923242912503, -0.0016828973056697237},
		{-0.019188923242912513, 0.04211388155833723, -0.014032340648132299},
		{-0.0016828973056697237, -0.014032340648132302, 0.015682977969793597}
	};

	double matrix[43][3][3] =
	{
		{
			{0.05939237532610377, -0.030076415341732984, -0.0016585558091925358},
			{-0.03007641534173299, 0.060458785171615, -0.026213341625437314},
			{-0.0016585558091925389, -0.02621334162543732, 0.034345481965250405}
		},
		{
			{0.051298898238736505, -0.02634928793288081, -0.00351130308544793},
			{-0.02634928793288081, 0.04993935536541797, -0.003023557491966388},
			{-0.003511303085447927, -0.0030235574919663844, 0.00866357131190697}
		},
		{
			{0.03357935002724698, -0.0029926681682324184, -0.0012057600787595006},
			{-0.0029926681682324167, 0.03487041065881075, -0.0011924635993373206},
			{-0.0012057600787594995, -0.0011924635993373163, 0.0102615276320332}
		},
		{
			{0.019146363695443494, 0.002111827435660477, -0.006462499748155456},
			{0.0021118274356604775, 0.014665959445964697, 0.0036889712233102072},
			{-0.006462499748155456, 0.0036889712233102085, 0.00881438433460078}
		},
		{
			{0.05441659101759843, -0.028920711944660237, -0.005918970372834674},
			{-0.028920711944660237, 0.04152760582951603, -0.001082608635292786},
			{-0.005918970372834674, -0.0010826086352927842, 0.012583487853712699}
		},
		{
			{0.04359999193617051, -0.01667412226696679, -0.0200975062309979},
			{-0.01667412226696678, 0.06040906887802737, -0.03983025346319449},
			{-0.020097506230997896, -0.03983025346319449, 0.0634970937734189}
		},
		{
			{0.07674169584672304, -0.061553257626338, 4.866690136203539E-4},
			{-0.06155325762633799, 0.11045101961456895, -0.02851525931902549},
			{4.8666901362035735E-4, -0.02851525931902549, 0.02972795585001}
		},
		{
			{0.014869165910155574, -0.020454012893002353, 0.007687166259674677},
			{-0.02045401289300234, 0.0675472291375924, -0.045492667709508584},
			{0.007687166259674677, -0.045492667709508605, 0.0478824859814596}
		},
		{
			{0.014441548944332108, -0.002071603365561633, -0.009236660861591296},
			{-0.002071603365561627, 0.027696406081355273, -0.010999307931538912},
			{-0.009236660861591292, -0.010999307931538912, 0.021699320170577997}
		},
		{
			{0.135773275289716, -0.09211663241139312, -0.0148734139923788},
			{-0.09211663241139313, 0.09514258324634964, -0.00622891222146359},
			{-0.014873413992378804, -0.006228912221463594, 0.026866216930607704}
		},
		{
			{0.04492319431280249, -0.04362731530098152, 0.0036965466770106405},
			{-0.04362731530098152, 0.06651577636900924, -0.014846399910607806},
			{0.003696546677010642, -0.014846399910607806, 0.0214482136890789}
		},
		{
			{0.07057913884269251, -0.0026852414621263403, -0.027876988189963443},
			{-0.002685241462126349, 0.10465426944761302, -0.001930591988184742},
			{-0.027876988189963446, -0.00193059198818473, 0.07676043251402669}
		},
		{
			{0.004177672392475131, -0.007273267242488826, 0.0020382381258929024},
			{-0.007273267242488833, 0.06890005507468097, -0.04448465972321444},
			{0.002038238125892904, -0.04448465972321444, 0.05149249467198022}
		},
		{
			{0.028446888538775306, -0.021384344799263617, -3.271336816556194E-4},
			{-0.021384344799263617, 0.04587878394982892, -0.008744683838261241},
			{-3.2713368165561895E-4, -0.008744683838261245, 0.013769368919925008}
		},
		{
			{0.020455462959791407, -0.011100410959270198, -0.005231586801642387},
			{-0.011100410959270193, 0.03521475127236068, -0.013791778996194413},
			{-0.005231586801642386, -0.01379177899619441, 0.02545094642815631}
		},
		{
			{0.06648326354382397, -0.06762108374614167, 0.00957320116521031},
			{-0.06762108374614162, 0.13446433749598596, -0.04066555473132338},
			{0.009573201165210298, -0.040665554731323376, 0.03091363806672769}
		},
		{
			{0.0273657802973314, -0.01661864354679391, 0.001383933884423027},
			{-0.016618643546793918, 0.06664129339337392, -0.037336182918292424},
			{0.0013839338844230278, -0.037336182918292424, 0.0412595067014812}
		},
		{
			{0.048184735103537206, -0.013202174269919298, -0.00487475299325218},
			{-0.013202174269919308, 0.04879417997799982, -1.3785171649953156E-4},
			{-0.00487475299325218, -1.3785171649953042E-4, 0.0031831414049742993}
		},
		{
			{0.1308830961714285, -0.04459513280532932, -0.026953925567009204},
			{-0.04459513280532926, 0.16984879033779982, -0.05535077375406608},
			{-0.026953925567009214, -0.055350773754066065, 0.03248012181776609}
		},
		{
			{0.06531831189792933, -0.03525677762259952, -0.009546508595354712},
			{-0.03525677762259952, 0.08078717869854547, -0.0177933034307204},
			{-0.009546508595354723, -0.017793303430720414, 0.0324924619938142}
		},
		{
			{0.08476401784492071, -0.06836554031705147, 0.012362641132042367},
			{-0.06836554031705144, 0.12058094486932111, -0.04802963191555493},
			{0.012362641132042364, -0.04802963191555493, 0.055291312530692804}
		},
		{
			{0.01932878403220712, -0.011137873383313804, -3.538162407693219E-4},
			{-0.011137873383313799, 0.0503318558429054, -0.0372108239319398},
			{-3.5381624076932024E-4, -0.03721082393193982, 0.033892437147768115}
		},
		{
			{0.016958400833729095, -0.0020904934163024887, -0.012830799336770594},
			{-0.0020904934163024896, 0.014898965876733894, -0.0012383349351065655},
			{-0.012830799336770603, -0.0012383349351065601, 0.016250009235698904}
		},
		{
			{0.022930066994930796, -0.017695065509461913, 0.001439070993568444},
			{-0.017695065509461917, 0.05613710843740597, -0.02843931495109608},
			{0.0014390709935684493, -0.028439314951096088, 0.02812714963927338}
		},
		{
			{0.04094206464057616, -0.015281218598344946, -0.0018980102215243105},
			{-0.015281218598344956, 0.07032236135708052, -0.007034552269104636},
			{-0.0018980102215243105, -0.007034552269104632, 0.023317707110338308}
		},
		{
			{0.03400889631127774, -0.03574232994526053, 0.003990288973404131},
			{-0.03574232994526053, 0.07152662328183314, -0.0053458758883170145},
			{0.0039902889734041306, -0.005345875888317008, 0.0023750331684668797}
		},
		{
			{0.01668227268262562, -0.001054886376221597, -0.012049511416050117},
			{-0.0010548863762215952, 0.0203137183431749, -0.0058610356437580535},
			{-0.012049511416050115, -0.00586103564375805, 0.016569761469692506}
		},
		{
			{0.04743881527732538, -0.019539762037922202, -0.009464340922928204},
			{-0.019539762037922185, 0.05726440052820616, 0.004195233998780597},
			{-0.009464340922928197, 0.004195233998780599, 0.0167574485090404}
		},
		{
			{0.027712891232502927, -0.0123323128449515, -0.006597244448706564},
			{-0.0123323128449515, 0.03874338349791958, -0.005553480521207208},
			{-0.006597244448706567, -0.005553480521207214, 0.010790581082382303}
		},
		{
			{0.24868028408980092, -0.03457844771444018, -0.11178260744747993},
			{-0.03457844771444019, 0.05047456663155711, 0.02758138624221499},
			{-0.11178260744747995, 0.027581386242214994, 0.05577636541409596}
		},
		{
			{0.017507011643531592, -0.007270471712670356, -0.00222707560719267},
			{-0.007270471712670354, 0.05144492714764469, -0.0279749183144632},
			{-0.002227075607192671, -0.0279749183144632, 0.032923501458141206}
		},
		{
			{0.05399507059341644, -0.00819304402161463, -0.019485931876564114},
			{-0.00819304402161463, 0.04202852547230657, -0.013799002886145505},
			{-0.019485931876564125, -0.013799002886145509, 0.0293100350687983}
		},
		{
			{0.049732591796885724, -0.04760833881852271, 0.0017250758018752513},
			{-0.0476083388185227, 0.1225604144210351, -0.024603102706896387},
			{0.0017250758018752487, -0.024603102706896394, 0.010779669404652694}
		},
		{
			{0.05065766251907057, -0.02207867099400039, -0.006924249462159464},
			{-0.0220786709940004, 0.04849713980237482, -0.01603395672723322},
			{-0.006924249462159457, -0.01603395672723321, 0.03324474062003321}
		},
		{
			{0.056294837807910024, -7.214884531349099E-4, 2.8618574803357258E-5},
			{-7.214884531349302E-4, 0.14782679743436902, -0.024313673198777804},
			{2.8618574803361378E-5, -0.024313673198777794, 0.04916828352169078}
		},
		{
			{0.03960713377872671, -0.029346942177906805, 0.0017934703150885587},
			{-0.02934694217790681, 0.08165957923577369, -0.03022086516200648},
			{0.0017934703150885708, -0.03022086516200648, 0.0326400051266048}
		},
		{
			{0.027694658257508505, -0.012336651604554803, -0.00828708317259571},
			{-0.012336651604554804, 0.049699763271945516, -0.007796821660109695},
			{-0.008287083172595713, -0.00779682166010969, 0.0143536645798839}
		},
		{
			{0.005445872319633517, -0.0011892121115561192, 0.004896727905373485},
			{-0.001189212111556108, 0.0653307593556136, -0.041398791356277956},
			{0.004896727905373486, -0.041398791356277956, 0.052655239880645896}
		},
		{
			{0.025391371041551293, -0.010973208433514797, -0.01023801556942521},
			{-0.010973208433514792, 0.0337804952864713, -0.006801115381320654},
			{-0.010238015569425208, -0.006801115381320651, 0.016815456869396717}
		},
		{
			{0.040058555661425084, -0.0165826112290499, -8.167921643685364E-4},
			{-0.0165826112290499, 0.059418478626159114, -0.021019801576239006},
			{-8.16792164368532E-4, -0.021019801576239, 0.02511303572171441}
		},
		{
			{0.08248936889871805, -0.016957578650891085, 0.004267382757168387},
			{-0.016957578650891078, 0.05164589693610957, 0.003953324674858696},
			{0.004267382757168388, 0.003953324674858698, 0.017476996403211795}
		},
		{
			{0.0477277238139975, -0.029725408332884423, -0.0031002884417572762},
			{-0.029725408332884427, 0.08100216664749355, -0.03764823216647309},
			{-0.0031002884417572728, -0.03764823216647308, 0.08869905183715796}
		},
		{
			{0.07210201341039361, -0.04687888055932364, 0.004718017058022183},
			{-0.04687888055932365, 0.08508209447916566, -0.032703152038436226},
			{0.004718017058022186, -0.03270315203843622, 0.027449862176667207}
		}
	};

	double barycentre[43][3] =
	{
		{205.9875, 131.25625, 98.57083333333334},
		{208.53631284916202, 200.56983240223462, 108.81005586592178},
		{111.59649122807018, 102.67368421052632, 52.83859649122807},
		{198.29457364341084, 148.6201550387597, 11.875968992248062},
		{223.4656862745098, 98.37745098039215, 24.67156862745098},
		{187.4621710526316, 157.30427631578948, 193.6003289473684},
		{100.90783410138249, 131.43548387096774, 175.63133640552996},
		{97.64573268921094, 197.56038647342996, 235.20933977455718},
		{90.8886925795053, 149.40812720848058, 131.73144876325088},
		{199.6816479400749, 202.9812734082397, 174.62172284644194},
		{162.62530413625305, 111.7323600973236, 68.54014598540147},
		{52.61643835616438, 37.19178082191781, 47.842465753424655},
		{10.473684210526315, 161.53216374269005, 172.66081871345028},
		{149.31922398589066, 143.91358024691357, 74.51499118165785},
		{103.18128654970761, 172.09824561403508, 171.29941520467835},
		{154.21691176470588, 165.79044117647058, 212.16360294117646},
		{184.76682316118936, 124.08607198748044, 134.75586854460093},
		{223.09302325581396, 197.3372093023256, 22.162790697674417},
		{97.45625, 106.10625, 122.33125},
		{111.82136602451838, 156.1646234676007, 219.7460595446585},
		{178.9946949602122, 194.71883289124668, 226.47480106100795},
		{58.5948275862069, 149.98850574712642, 164.85632183908046},
		{144.54233409610984, 192.35926773455378, 156.1121281464531},
		{82.7815699658703, 170.66894197952217, 201.24744027303754},
		{129.0721153846154, 79.91586538461539, 57.90625},
		{142.03529411764706, 106.19411764705882, 18.6},
		{125.85119047619048, 168.26636904761904, 126.42410714285714},
		{79.16620498614958, 78.84764542936288, 51.64265927977839},
		{183.32, 161.80307692307693, 69.53538461538461},
		{68.36150234741784, 54.63849765258216, 80.72300469483568},
		{125.44426229508197, 195.4704918032787, 199.11967213114755},
		{143.44147157190636, 120.30267558528428, 148.33779264214047},
		{140.14721723518852, 141.51346499102334, 190.73070017953322},
		{179.34375, 133.90767045454547, 167.7784090909091},
		{26.512893982808023, 23.66189111747851, 28.103151862464184},
		{170.447782546495, 119.22889842632333, 105.1788268955651},
		{164.74542429284526, 169.39267886855242, 108.23460898502496},
		{26.404109589041095, 119.13698630136986, 97.22602739726027},
		{112.62683438155136, 138.90356394129978, 92.70230607966457},
		{141.24400871459696, 102.05664488017429, 101.15904139433552},
		{89.89578163771712, 86.47394540942928, 87.66004962779157},
		{133.27756653992395, 185.7281368821293, 241.87832699619773},
		{203.37474541751527, 155.05906313645622, 140.63747454175152}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<43;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<43;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance44clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027905702507893298, -0.020767347294480112, -0.0019851909244504354},
		{-0.020767347294480137, 0.04415548031896981, -0.013932305485602599},
		{-0.001985190924450434, -0.013932305485602592, 0.015461862330430998}
	};

	double matrix[44][3][3] =
	{
		{
			{0.08007828674349958, -0.04052989246879891, -4.5125281657975875E-4},
			{-0.04052989246879891, 0.07762338810568596, -0.0140446321400307},
			{-4.512528165797618E-4, -0.014044632140030707, 0.02174512942347289}
		},
		{
			{0.028904644451220707, -0.012493049265911927, -0.00646409667937119},
			{-0.012493049265911924, 0.045603939994438604, -0.008666478519654488},
			{-0.006464096679371189, -0.008666478519654491, 0.015191418461548088}
		},
		{
			{0.015746423484855197, 0.00405684865549365, -0.00873924177030182},
			{0.0040568486554936525, 0.05000971299163856, -0.021299563820943588},
			{-0.008739241770301831, -0.021299563820943605, 0.026670923184604404}
		},
		{
			{0.07317714928501554, -0.05530602982951809, 0.01652260894265039},
			{-0.05530602982951809, 0.09034252986272581, -0.035674406269359214},
			{0.016522608942650396, -0.03567440626935921, 0.026626093767992007}
		},
		{
			{0.024895646181350997, -0.015586474185187979, -0.0018611868091910266},
			{-0.015586474185187969, 0.04138152539436909, -0.018551682812404477},
			{-0.0018611868091910123, -0.018551682812404484, 0.026807379766280795}
		},
		{
			{0.03519365219976641, -0.006450092654954505, -0.007023480644304072},
			{-0.006450092654954505, 0.04669675773851229, -0.018380368739239705},
			{-0.007023480644304072, -0.01838036873923971, 0.03211368759851}
		},
		{
			{0.04340879778513528, -0.011723331159210182, -0.009098396718337384},
			{-0.011723331159210176, 0.0562394171275365, 0.007325014255927733},
			{-0.00909839671833738, 0.0073250142559277455, 0.017555908147291004}
		},
		{
			{0.04893167321818999, -0.04353201872168598, 0.0014496005892035734},
			{-0.04353201872168601, 0.09609187367203716, -0.017785783654333205},
			{0.0014496005892035738, -0.0177857836543332, 0.011623359753033198}
		},
		{
			{0.096446115353913, -0.004115590237523788, 0.0022242139515906523},
			{-0.004115590237523788, 0.05064107523954806, 0.004641405818964151},
			{0.002224213951590651, 0.004641405818964142, 0.018895355768818702}
		},
		{
			{0.02826427689329789, -0.009356577982125198, -0.011094993172699706},
			{-0.009356577982125205, 0.030530466293255898, -0.00909685367991688},
			{-0.011094993172699704, -0.009096853679916878, 0.023232612064891703}
		},
		{
			{0.07832210334784097, -0.051146677300527674, -0.017721411439686904},
			{-0.051146677300527674, 0.05657517457661494, -0.008986250104260424},
			{-0.017721411439686897, -0.008986250104260426, 0.0273679779695182}
		},
		{
			{0.08065081793664493, -0.024523695413789497, 0.0027497816441964472},
			{-0.024523695413789494, 0.04905410726911287, -0.013995027938269993},
			{0.002749781644196451, -0.013995027938269993, 0.011055547172355695}
		},
		{
			{0.026287914485054534, -0.01982943045577312, -0.0033598857907750296},
			{-0.0198294304557731, 0.04482985965532517, -0.0029060609677786712},
			{-0.0033598857907750257, -0.002906060967778671, 0.0126535498717}
		},
		{
			{0.14896632156019904, -0.08772196356878852, 0.002504861323599932},
			{-0.08772196356878856, 0.17356443964516588, -0.0376932738041807},
			{0.0025048613235999218, -0.03769327380418069, 0.021664696385337093}
		},
		{
			{0.07071036394423545, -0.050245991784099706, -0.016962702819562036},
			{-0.050245991784099685, 0.1100783969832489, -0.029503504472862895},
			{-0.016962702819562036, -0.02950350447286291, 0.02728941240965555}
		},
		{
			{0.09153809870348958, -0.06054096369944431, -2.66286300804215E-4},
			{-0.06054096369944431, 0.11974405797096202, -0.047736695452200634},
			{-2.662863008042124E-4, -0.047736695452200655, 0.07734857431925822}
		},
		{
			{0.036541964765998185, -0.031027063575812686, 0.009008459685079814},
			{-0.031027063575812686, 0.055182150681339866, -0.013643239603921697},
			{0.009008459685079816, -0.013643239603921692, 0.007589820723386768}
		},
		{
			{0.017260145948135915, -0.008328053976523463, 0.0016718693589813155},
			{-0.00832805397652348, 0.0639543393104541, -0.0081273829272258},
			{0.001671869358981318, -0.0081273829272258, 0.004017335922898051}
		},
		{
			{0.029580521895902025, -0.01314398695504962, -0.007338811096761511},
			{-0.013143986955049616, 0.037385565951579915, -0.0019150235940744217},
			{-0.007338811096761506, -0.001915023594074417, 0.006234195933678676}
		},
		{
			{0.05774844663830149, -0.045236994414473986, -0.009657778863278892},
			{-0.04523699441447402, 0.10573398485858009, -0.03515974131202418},
			{-0.009657778863278881, -0.0351597413120242, 0.0664414712509543}
		},
		{
			{0.04732406903692408, -0.01474986267719577, -0.01513007668216969},
			{-0.014749862677195767, 0.0633560598753703, -0.027910055440868917},
			{-0.01513007668216969, -0.027910055440868928, 0.0377926202268557}
		},
		{
			{0.022548044905637596, 0.004748511300287411, -0.005258265234699111},
			{0.004748511300287412, 0.017616074264623603, 0.0024724183686311166},
			{-0.005258265234699107, 0.0024724183686311157, 0.0037023917562245615}
		},
		{
			{0.10955569383393789, -0.008603902930889957, -0.03247037380846864},
			{-0.008603902930889968, 0.042701535291315006, 0.00846280719385734},
			{-0.03247037380846866, 0.008462807193857313, 0.06997795875528219}
		},
		{
			{0.06882957041918888, -0.03816675925218756, -0.012743799873817562},
			{-0.03816675925218757, 0.08715871558110853, -0.029957816698235006},
			{-0.012743799873817553, -0.02995781669823502, 0.04519570501789964}
		},
		{
			{0.05520663005794826, -0.03596929060564482, -0.007404242546241849},
			{-0.03596929060564479, 0.05880709815179535, 0.0038124995889820424},
			{-0.0074042425462418435, 0.003812499588982043, 0.007316207529960738}
		},
		{
			{0.004256614347162616, -0.002524884117031523, 0.001835934974458942},
			{-0.0025248841170315214, 0.05941200141938353, -0.046371992328295905},
			{0.0018359349744589404, -0.046371992328295905, 0.059387452963121985}
		},
		{
			{0.012914919438399309, -0.011657762734403419, 0.0024918884322056335},
			{-0.011657762734403415, 0.04877350099985151, -0.029450696149483008},
			{0.0024918884322056353, -0.02945069614948302, 0.030920710392784222}
		},
		{
			{0.11257222900786003, -0.05334034768090279, -0.02049603569440662},
			{-0.053340347680902775, 0.07031860280030561, -0.018773554460170223},
			{-0.02049603569440661, -0.018773554460170223, 0.03510926584384891}
		},
		{
			{0.045414458536883806, -0.009691316704198413, -0.020463697254888998},
			{-0.009691316704198406, 0.052033363775066586, -0.01272042161318461},
			{-0.020463697254888998, -0.012720421613184608, 0.029981520414248803}
		},
		{
			{0.018968751717290018, -0.0018475224128837037, -0.011213358773909611},
			{-0.0018475224128837106, 0.023671544654240304, -0.008404125051524984},
			{-0.011213358773909611, -0.008404125051524986, 0.0183360388875216}
		},
		{
			{0.036619448197807145, -0.0203698002181238, -0.007209083282372804},
			{-0.02036980021812379, 0.06858024391952672, -0.0255949340940708},
			{-0.0072090832823728055, -0.025594934094070793, 0.0402688961174416}
		},
		{
			{0.0220230676463818, -0.01309038593226729, 0.0023158973994870293},
			{-0.01309038593226728, 0.047692669577895065, -0.03891055690274718},
			{0.0023158973994870297, -0.03891055690274718, 0.03829133949626129}
		},
		{
			{0.014207723772946382, 0.001837059103460022, -0.012750877688922189},
			{0.0018370591034600281, 0.01651334203440112, -0.005175458518710669},
			{-0.012750877688922186, -0.005175458518710667, 0.016882441994253195}
		},
		{
			{0.06622211667670906, -0.041943959299252036, -0.0031412136292766463},
			{-0.041943959299252064, 0.07847187443347098, -0.028118301028448894},
			{-0.003141213629276639, -0.02811830102844888, 0.031464172335361106}
		},
		{
			{0.0762846809852522, 0.013883096954748736, -0.04185340725467456},
			{0.013883096954748769, 0.19734374053539935, 0.015141383523218234},
			{-0.04185340725467463, 0.015141383523218253, 0.025621370834641062}
		},
		{
			{0.04737780425335825, -0.028261892451991042, 0.0020790752736593466},
			{-0.028261892451991025, 0.07516591851031369, -0.03412658045850422},
			{0.002079075273659337, -0.03412658045850421, 0.03435626942199322}
		},
		{
			{0.04054370860096865, -0.013762603412553778, -0.00373573784794954},
			{-0.01376260341255378, 0.06734822043980991, -0.008169311315339312},
			{-0.0037357378479495346, -0.008169311315339307, 0.0207237337671414}
		},
		{
			{0.004012772126403119, -0.00675127202247922, 0.003353452153579683},
			{-0.006751272022479209, 0.061350140102421985, -0.03820222829589879},
			{0.003353452153579673, -0.03820222829589879, 0.04849819292549088}
		},
		{
			{0.07998065020651378, -0.009331993886993642, -0.0271039416380855},
			{-0.009331993886993633, 0.13608074527407898, -0.007271330772241914},
			{-0.027103941638085507, -0.007271330772241898, 0.05033857480440612}
		},
		{
			{0.013199529562409, 0.0020079765486253707, -0.012744402470784993},
			{0.002007976548625367, 0.021872158803937787, -0.011666904866080092},
			{-0.012744402470784993, -0.011666904866080085, 0.024181399090780473}
		},
		{
			{0.05596240774402976, -0.028061030746130488, -0.006620320996460684},
			{-0.028061030746130502, 0.03638652226858563, -0.0031512853200616467},
			{-0.006620320996460679, -0.0031512853200616423, 0.013064880110782407}
		},
		{
			{0.021799361730054135, -0.01793715212917465, 0.0010072751400315282},
			{-0.017937152129174648, 0.08115576092398016, -0.03388156937052634},
			{0.0010072751400315274, -0.03388156937052633, 0.03386365933435492}
		},
		{
			{0.05451310453184336, -0.033598550512792286, -0.009572062482135062},
			{-0.033598550512792265, 0.05864451084823521, -0.025620413358673936},
			{-0.009572062482135078, -0.02562041335867391, 0.04509105300813902}
		},
		{
			{0.0198167899753695, -0.02304986443331554, 0.010693742052724728},
			{-0.02304986443331552, 0.07667438123020644, -0.05923171401361849},
			{0.010693742052724716, -0.05923171401361852, 0.06075828093822329}
		}
	};

	double barycentre[44][3] =
	{
		{115.6159844054581, 161.9766081871345, 225.91812865497076},
		{165.72484599589322, 172.51334702258728, 111.68377823408625},
		{81.31486146095718, 132.85390428211588, 125.04030226700252},
		{195.76967930029156, 156.84839650145773, 134.67055393586006},
		{102.27225806451612, 173.0193548387097, 178.22838709677418},
		{163.40619621342512, 114.9552495697074, 122.57142857142857},
		{83.33495145631068, 82.4368932038835, 50.55339805825243},
		{141.15128593040848, 145.62027231467474, 196.41754916792738},
		{82.91528925619835, 76.92355371900827, 86.91735537190083},
		{109.46601941747574, 130.92961165048544, 85.83495145631068},
		{179.1509433962264, 209.18396226415095, 177.37264150943398},
		{224.53299492385787, 151.06091370558374, 101.89340101522842},
		{147.39350912778906, 150.42190669371197, 85.96754563894524},
		{116.33080808080808, 101.11363636363636, 113.13888888888889},
		{115.23205741626795, 123.53588516746412, 159.91866028708134},
		{184.62403100775194, 196.3217054263566, 228.48062015503876},
		{156.58461538461538, 129.43296703296704, 59.95384615384615},
		{139.76216216216216, 103.57297297297298, 18.524324324324326},
		{185.35691318327974, 167.95819935691318, 70.63987138263666},
		{144.76347826086956, 183.97565217391303, 234.2313043478261},
		{187.2095531587057, 142.57164869029276, 175.1109399075501},
		{209.0614525139665, 169.15083798882682, 12.441340782122905},
		{48.086513994910945, 41.07124681933842, 55.42748091603053},
		{95.36091954022989, 144.5977011494253, 196.86666666666667},
		{197.5103448275862, 209.64137931034483, 119.47586206896551},
		{24.78102189781022, 118.04379562043796, 95.36496350364963},
		{83.69166666666666, 180.26458333333332, 211.56458333333333},
		{218.98387096774192, 183.1720430107527, 164.6505376344086},
		{158.75728155339806, 124.86731391585761, 157.91747572815535},
		{123.65018315018315, 161.00732600732601, 117.02564102564102},
		{156.86688851913476, 108.54742096505824, 90.64891846921797},
		{62.85532994923858, 151.2715736040609, 169.53553299492387},
		{135.21572212065814, 185.0457038391225, 149.74771480804387},
		{190.08674304418986, 126.72831423895254, 97.55155482815057},
		{72.3037037037037, 33.27407407407407, 38.62222222222222},
		{193.3458904109589, 127.86986301369863, 138.45034246575344},
		{126.47602739726027, 85.85445205479452, 58.169520547945204},
		{12.157608695652174, 160.72282608695653, 171.09782608695653},
		{26.464387464387464, 23.797720797720796, 28.501424501424502},
		{98.31075697211155, 162.25498007968127, 143.33067729083666},
		{221.65106382978723, 99.93191489361702, 27.123404255319148},
		{128.49248747913188, 195.51085141903172, 197.80801335559266},
		{177.72082018927443, 163.05520504731862, 203.44637223974763},
		{103.93069306930693, 198.75907590759076, 239.0775577557756}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<44;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<44;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance45clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02638994928206058, -0.019794671940667297, -0.0016416432883715997},
		{-0.01979467194066728, 0.042281908383484605, -0.012926267878144099},
		{-0.0016416432883716056, -0.012926267878144106, 0.014413163785778598}
	};

	double matrix[45][3][3] =
	{
		{
			{0.02916035905791987, -0.024232307167087977, 0.0033295648088678986},
			{-0.02423230716708798, 0.05923886954816832, -0.0030994531990382614},
			{0.003329564808867897, -0.0030994531990382597, 0.00225039113286024}
		},
		{
			{0.01972680733991901, -0.0030756014528707815, -0.012889970898039615},
			{-0.003075601452870785, 0.02399795120018161, -0.008029367703880751},
			{-0.012889970898039624, -0.008029367703880748, 0.018980114140272928}
		},
		{
			{0.0185183086943728, -0.013109793288531006, 0.0029625007926040686},
			{-0.013109793288531006, 0.05147233459842339, -0.032158866690950985},
			{0.0029625007926040664, -0.032158866690950985, 0.030957395384927394}
		},
		{
			{0.013088414829418096, 9.783710681205773E-4, -0.009545848558261346},
			{9.783710681205773E-4, 0.040843260085627206, -0.016785804741906815},
			{-0.009545848558261344, -0.016785804741906815, 0.026789374541276806}
		},
		{
			{0.051947418822804445, -0.023490992368975387, 0.00231455209027716},
			{-0.0234909923689754, 0.04381227330629353, -0.009026367225270972},
			{0.0023145520902771613, -0.009026367225270972, 0.008579208888795407}
		},
		{
			{0.06698828268430877, -0.07104106963314827, 0.01010000834840909},
			{-0.07104106963314828, 0.13662154128737802, -0.04673373136051052},
			{0.01010000834840908, -0.0467337313605105, 0.03536052864084721}
		},
		{
			{0.07129415400434064, -0.02989658423926384, -0.008858369195907208},
			{-0.029896584239263845, 0.07998860732751367, -0.01950549032340971},
			{-0.008858369195907212, -0.019505490323409716, 0.02915676322737971}
		},
		{
			{0.004642523401410156, -0.00690727228841793, 0.0019351121449096287},
			{-0.006907272288417922, 0.0680411278763737, -0.04211015993288409},
			{0.0019351121449096209, -0.0421101599328841, 0.05044231339571509}
		},
		{
			{0.030837936278582914, -0.010592893263449796, -0.011717471239541496},
			{-0.010592893263449803, 0.027980426258892195, -0.007145754656523409},
			{-0.011717471239541501, -0.007145754656523409, 0.022579972174435102}
		},
		{
			{0.02023090533324282, -0.010991029566438295, -9.766942815145037E-4},
			{-0.010991029566438291, 0.043442696343264676, -0.03259257217808301},
			{-9.766942815144985E-4, -0.03259257217808302, 0.03217510874487712}
		},
		{
			{0.11311554721213, -0.05033011641183126, -0.022279503558297206},
			{-0.05033011641183127, 0.08233237740493853, -0.020381949656095095},
			{-0.022279503558297203, -0.020381949656095088, 0.02724836446329018}
		},
		{
			{0.048026693112701704, -0.014602660437995706, -0.00631442760902473},
			{-0.014602660437995716, 0.062242869457563424, -0.009413589412852915},
			{-0.006314427609024722, -0.009413589412852908, 0.01924897496553681}
		},
		{
			{0.015363837306329977, -0.021149704729343854, 0.008368658403762275},
			{-0.021149704729343848, 0.068326901845913, -0.04617886520492724},
			{0.008368658403762271, -0.04617886520492725, 0.04842634983643938}
		},
		{
			{0.059075250903801245, -0.027798488394644896, -0.0019111434398567844},
			{-0.027798488394644896, 0.02857328041715431, -0.008545809036276327},
			{-0.0019111434398567829, -0.008545809036276329, 0.016438890612994403}
		},
		{
			{0.08804992726739536, -0.02251384452344706, -0.06474062846731991},
			{-0.022513844523447086, 0.06994326773401671, 0.025909554998951888},
			{-0.06474062846731994, 0.025909554998951905, 0.057800384569492144}
		},
		{
			{0.026470893437873795, -0.0159614582754156, -0.0065739353105907575},
			{-0.015961458275415612, 0.02592751503022278, -0.0010991077532969034},
			{-0.006573935310590757, -0.0010991077532969034, 0.014559186031315195}
		},
		{
			{0.0812731441583939, 0.0013870007932832579, -0.05065089940774105},
			{0.0013870007932832579, 0.12072878888775604, -0.06184622031797196},
			{-0.050650899407741076, -0.061846220317971955, 0.12944499755848102}
		},
		{
			{0.0136243631163089, 0.0018474637507661477, -0.012898651169991405},
			{0.0018474637507661443, 0.017918654072818292, -0.005444049634726872},
			{-0.012898651169991405, -0.005444049634726877, 0.017744205179573206}
		},
		{
			{0.05572377695408013, -0.03256303918385931, -0.0031480674635204643},
			{-0.03256303918385933, 0.08162188583417333, -0.03887042158446569},
			{-0.003148067463520453, -0.03887042158446571, 0.0417461479010328}
		},
		{
			{0.05021956908488369, -0.0029616158677076574, -0.005183659796437805},
			{-0.002961615867707661, 0.23928552734946815, -0.0066812805518149145},
			{-0.005183659796437811, -0.006681280551814882, 0.013228696594687804}
		},
		{
			{0.025937844210724717, 0.00322349975407684, -0.004356841891352502},
			{0.0032234997540768373, 0.016666491588357785, 0.0019894042258701145},
			{-0.004356841891352505, 0.001989404225870115, 0.0037779314681904985}
		},
		{
			{0.0035188009330422328, -0.0014854289670054093, 0.0017318134924657292},
			{-0.0014854289670054098, 0.06031569964002527, -0.04369474145781199},
			{0.0017318134924657323, -0.04369474145781199, 0.0566204205990932}
		},
		{
			{0.04707479155853865, -0.03680695205765437, -0.007128979529503891},
			{-0.03680695205765435, 0.07636909867532754, -0.022970431481989906},
			{-0.007128979529503896, -0.0229704314819899, 0.03770792827282951}
		},
		{
			{0.055892464603177636, -0.01118393527067501, -0.017358481047569905},
			{-0.01118393527067501, 0.03827688490527711, -0.012828031680199907},
			{-0.0173584810475699, -0.012828031680199893, 0.030757745237068007}
		},
		{
			{0.011927727993753613, 0.001053293973293951, -0.011897276943851905},
			{0.0010532939732939587, 0.028341736189497698, -0.014906735271776703},
			{-0.011897276943851905, -0.014906735271776696, 0.025727085344272406}
		},
		{
			{0.04016987403994619, -0.028456175269078662, -0.002585670999262002},
			{-0.028456175269078673, 0.08794852739922489, -0.002317817033963486},
			{-0.0025856709992620056, -0.0023178170339634885, 0.019670059248323588}
		},
		{
			{0.032332230757318794, -0.009909330184493591, -0.008167314174445326},
			{-0.009909330184493578, 0.0506535718319121, -0.02394637270917331},
			{-0.008167314174445325, -0.023946372709173304, 0.03333203680908591}
		},
		{
			{0.05674093316480406, -0.029760502887552092, -0.0017131829172021933},
			{-0.0297605028875521, 0.07179253402364197, -0.03162444852886199},
			{-0.0017131829172022002, -0.03162444852886198, 0.03583453094355219}
		},
		{
			{0.035037631752033456, -0.02148725267148423, 2.905194806497903E-4},
			{-0.02148725267148422, 0.0662207918186417, -0.02522665837263729},
			{2.905194806498042E-4, -0.02522665837263731, 0.029887329079103603}
		},
		{
			{0.05488325823841765, -0.0185546299355503, -0.0159325660159098},
			{-0.01855462993555029, 0.030264526548116504, 0.007709377713571488},
			{-0.0159325660159098, 0.007709377713571486, 0.018145507725026398}
		},
		{
			{0.08404941152084136, -0.068048282792412, 0.01404255726035842},
			{-0.068048282792412, 0.12001723318364295, -0.04794027152003708},
			{0.014042557260358416, -0.04794027152003709, 0.0559884665214929}
		},
		{
			{0.048555509132948774, -0.03161887515269685, -0.0038239426894212114},
			{-0.03161887515269686, 0.08527373360310575, -0.044132276461835734},
			{-0.003823942689421215, -0.044132276461835734, 0.09627283298157648}
		},
		{
			{0.05121344962631316, -0.018226659103928088, -0.012488459610853299},
			{-0.0182266591039281, 0.040765808051730475, -0.009324550573637},
			{-0.012488459610853313, -0.009324550573636986, 0.027929598756722213}
		},
		{
			{0.07226718406248497, -0.034208530066954144, -0.022697289570562922},
			{-0.03420853006695415, 0.03728842341420823, -9.339497230766367E-4},
			{-0.022697289570562915, -9.339497230766297E-4, 0.028667465162474794}
		},
		{
			{0.05217807129338158, -0.04365824278951236, -0.0037429600442176487},
			{-0.043658242789512344, 0.10719113803879907, -0.011362734593873994},
			{-0.003742960044217654, -0.011362734593874001, 0.008037747592105373}
		},
		{
			{0.0443880651637866, -0.017897361300073723, -0.020467033506310413},
			{-0.01789736130007372, 0.05609993121556902, -0.037506485694323285},
			{-0.020467033506310413, -0.03750648569432328, 0.06237237210581441}
		},
		{
			{0.11087246647027904, -0.06116289448752415, -0.004241568427558346},
			{-0.061162894487524155, 0.30026101561443913, -0.049581426527339205},
			{-0.004241568427558375, -0.049581426527339205, 0.022437690214993214}
		},
		{
			{0.04073979290543214, -0.018530743346047433, -0.010698003507637412},
			{-0.018530743346047433, 0.055243135081921094, 0.005228320009003863},
			{-0.010698003507637412, 0.005228320009003864, 0.01697752126888401}
		},
		{
			{0.030184225299440294, -0.016989592595513713, -0.004533636194215385},
			{-0.016989592595513713, 0.03755161926635622, -0.006902794549526904},
			{-0.004533636194215379, -0.006902794549526905, 0.014876493195931692}
		},
		{
			{0.07557013741597698, -0.062007977468382366, -0.002688995252942052},
			{-0.062007977468382325, 0.10903480673335687, -0.028372287123330172},
			{-0.0026889952529420614, -0.02837228712333019, 0.032126862184362406}
		},
		{
			{0.034774098972083264, -0.02136301528796218, -0.002812678823041873},
			{-0.021363015287962174, 0.05869795179668301, -0.013434785565351787},
			{-0.0028126788230418763, -0.013434785565351784, 0.0166342710161031}
		},
		{
			{0.024324554325831086, -0.014869801254885077, -0.0031176456447914594},
			{-0.014869801254885094, 0.0404028780911274, -0.015842447923622698},
			{-0.003117645644791458, -0.015842447923622698, 0.025843629520165393}
		},
		{
			{0.10029954948352, -0.020066827835165814, 0.002480578949652681},
			{-0.02006682783516581, 0.07637251650536196, 0.005827486657393074},
			{0.002480578949652681, 0.005827486657393074, 0.018407553405267698}
		},
		{
			{0.0179061077855737, -0.007922483297742925, -0.002689106106362262},
			{-0.007922483297742922, 0.057523595244146276, -0.028998229724923608},
			{-0.002689106106362264, -0.02899822972492362, 0.034630346981535234}
		},
		{
			{0.0313420944057215, -0.02660458156239459, 0.005259994240573005},
			{-0.026604581562394584, 0.05243232921940735, -0.009689836965180054},
			{0.005259994240573003, -0.009689836965180054, 0.014065114126507695}
		}
	};

	double barycentre[45][3] =
	{
		{147.01818181818183, 111.04848484848485, 18.993939393939392},
		{123.67272727272727, 161.79090909090908, 118.38363636363637},
		{81.81553398058253, 172.1883495145631, 205.70291262135922},
		{82.68877551020408, 137.64030612244898, 124.47448979591837},
		{213.39597315436242, 200.1744966442953, 100.18120805369128},
		{154.73970037453182, 165.59925093632958, 212.42322097378278},
		{112.05719557195572, 157.8450184501845, 221.81365313653137},
		{10.017751479289942, 160.88757396449705, 171.8343195266272},
		{109.67396593673966, 131.2214111922141, 86.23114355231144},
		{58.94571428571429, 151.59428571428572, 168.37714285714284},
		{216.57142857142858, 183.17511520737327, 160.68663594470047},
		{117.0324074074074, 84.23842592592592, 46.2337962962963},
		{98.65767284991568, 198.4080944350759, 235.92074198988195},
		{219.80254777070064, 107.10191082802548, 60.82165605095541},
		{63.24761904761905, 41.523809523809526, 59.21904761904762},
		{146.57362637362638, 153.41318681318683, 90.46373626373627},
		{38.041009463722396, 37.01261829652997, 43.829652996845425},
		{133.93542435424354, 185.2029520295203, 151.0719557195572},
		{197.7113043478261, 138.99652173913043, 150.6017391304348},
		{27.539033457249072, 20.029739776951672, 23.53159851301115},
		{209.2027027027027, 181.11486486486487, 18.12162162162162},
		{24.691176470588236, 118.19852941176471, 95.65441176470588},
		{174.72379367720467, 119.61564059900167, 92.81863560732113},
		{139.3682092555332, 121.16297786720322, 148.53923541247485},
		{98.27708333333334, 162.92916666666667, 145.30208333333334},
		{139.10250569476082, 92.63325740318906, 70.4874715261959},
		{175.46307692307693, 120.24153846153847, 128.78307692307692},
		{204.41338582677164, 136.83661417322836, 110.91338582677166},
		{149.4840182648402, 105.92009132420091, 105.47945205479452},
		{180.3780487804878, 208.70325203252034, 168.5487804878049},
		{179.26912928759896, 194.51187335092348, 226.39313984168865},
		{133.95019920318725, 186.30677290836653, 241.94621513944224},
		{170.51269841269843, 131.7904761904762, 168.98888888888888},
		{219.24309392265192, 109.7292817679558, 9.03867403314917},
		{136.4841121495327, 142.80934579439253, 193.25046728971964},
		{186.75867507886434, 156.73501577287067, 192.82334384858044},
		{105.7078313253012, 100.92168674698796, 116.92168674698796},
		{78.89204545454545, 82.26420454545455, 53.0625},
		{182.68421052631578, 161.57309941520467, 72.94444444444444},
		{100.08333333333333, 130.42824074074073, 175.5185185185185},
		{170.4454887218045, 173.3890977443609, 115.61278195488721},
		{101.70882740447958, 172.28853754940712, 178.8840579710145},
		{84.46756152125279, 77.55257270693512, 87.20134228187919},
		{127.16638655462185, 196.1529411764706, 198.4453781512605},
		{153.30701754385964, 133.34868421052633, 63.219298245614034}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<45;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<45;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance46clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.025862896675727606, -0.01905630203043891, -0.002161685280091983},
		{-0.019056302030438912, 0.041958535638864335, -0.01300403784129931},
		{-0.0021616852800919835, -0.013004037841299306, 0.01483561859214941}
	};

	double matrix[46][3][3] =
	{
		{
			{0.05593117637795269, -0.03284355031426284, 4.5213474569054564E-4},
			{-0.03284355031426285, 0.08272546027107172, -0.039930697760617494},
			{4.5213474569054087E-4, -0.03993069776061747, 0.03931193233350486}
		},
		{
			{0.05571438732474033, -0.02830806058320201, -0.005984723549027381},
			{-0.02830806058320199, 0.037244326223906686, -0.0033847240867830686},
			{-0.005984723549027381, -0.0033847240867830694, 0.0126946735462992}
		},
		{
			{0.05671183573815392, -0.011607069705168697, -0.016548478224910908},
			{-0.011607069705168697, 0.03823379856395348, -0.01271899546794332},
			{-0.0165484782249109, -0.012718995467943322, 0.030230393184890403}
		},
		{
			{0.05085037438373348, -0.02960836062958576, 0.004157251436659381},
			{-0.02960836062958571, 0.06785004934241576, -0.02652307447519791},
			{0.004157251436659382, -0.026523074475197923, 0.029818244444114916}
		},
		{
			{0.05086527227449691, -0.024414507453988397, -0.010981239494546696},
			{-0.024414507453988404, 0.033362607988267595, -0.007595473572398932},
			{-0.010981239494546704, -0.0075954735723989305, 0.029444052026844802}
		},
		{
			{0.02844894265956013, -0.028370848511625312, 0.0017426682612490208},
			{-0.028370848511625302, 0.06270548743576103, -0.005010676985795197},
			{0.0017426682612490202, -0.005010676985795196, 0.00245571459832521}
		},
		{
			{0.01839499722778019, -0.0028506214974796974, -0.007404257468658258},
			{-0.0028506214974797018, 0.03522903603442179, -0.013372250780384403},
			{-0.0074042574686582615, -0.013372250780384405, 0.0222688908385592}
		},
		{
			{0.06623986274153651, -0.0038347287446601486, -0.035866921115986064},
			{-0.0038347287446601416, 0.10785245607091101, -0.014118139723912147},
			{-0.03586692111598608, -0.014118139723912126, 0.09988837971103989}
		},
		{
			{0.056253881222888075, -0.06510466924502807, 0.007671469259699134},
			{-0.06510466924502809, 0.13583261390184007, -0.036038429500904134},
			{0.007671469259699142, -0.03603842950090412, 0.0303315729935377}
		},
		{
			{0.015913530253412595, -7.282139165522604E-4, -0.014154003672632592},
			{-7.282139165522596E-4, 0.016217993802208498, -0.0039337860201887715},
			{-0.01415400367263259, -0.003933786020188774, 0.016424338265681175}
		},
		{
			{0.008738867306830536, -7.556536533507388E-4, 0.004049417603575708},
			{-7.556536533507487E-4, 0.0570577712225304, -0.041838316619357},
			{0.004049417603575718, -0.04183831661935699, 0.05562759422460102}
		},
		{
			{0.02652951628343133, -0.005115710016621985, -0.004487318825318077},
			{-0.005115710016621988, 0.03480228683545291, 0.001117383424769939},
			{-0.004487318825318076, 0.0011173834247699458, 0.005979072387347583}
		},
		{
			{0.09814346324718543, -0.04842732096122174, -0.011555832539084997},
			{-0.048427320961221806, 0.27809186083469295, -0.04965229862611269},
			{-0.011555832539085008, -0.04965229862611267, 0.02234704100046621}
		},
		{
			{0.035405369925613654, -0.017554155874759204, -0.00534888111737123},
			{-0.017554155874759208, 0.046527258244891734, -0.006649357019607555},
			{-0.005348881117371229, -0.00664935701960756, 0.014107758390208093}
		},
		{
			{0.026411868394637127, -0.016283363451384612, -0.0016139009053145557},
			{-0.016283363451384602, 0.04197900761211097, -0.016383181503135204},
			{-0.00161390090531456, -0.016383181503135204, 0.026540928373680116}
		},
		{
			{0.04082258589126048, -0.0257832643286471, -0.0035514907829937836},
			{-0.025783264328647085, 0.0781386157161431, -0.002751416531469113},
			{-0.00355149078299378, -0.002751416531469113, 0.022292836951598297}
		},
		{
			{0.05589631647771451, -0.016006487890388294, -0.011516022239616602},
			{-0.0160064878903883, 0.055176780654943906, 0.004562094739927958},
			{-0.011516022239616591, 0.004562094739927966, 0.016515620688949705}
		},
		{
			{0.09489072512409027, -0.012093145144019697, 0.0026854175976411313},
			{-0.012093145144019699, 0.050465510393184226, 0.005216243809827667},
			{0.0026854175976411313, 0.005216243809827665, 0.019698064253334896}
		},
		{
			{0.0273681447331691, -0.013613690671973008, -0.006954719659466861},
			{-0.013613690671973013, 0.034307026572245915, -0.004108272841691716},
			{-0.006954719659466864, -0.004108272841691713, 0.014900051471226795}
		},
		{
			{0.04234311938780148, -0.005666783625182212, -0.0026857543837396905},
			{-0.00566678362518221, 0.03671146777870259, -0.003665577242662343},
			{-0.002685754383739692, -0.003665577242662342, 0.010710445564844103}
		},
		{
			{0.03558513166568367, -0.01917743440117335, 7.842333783871858E-4},
			{-0.01917743440117334, 0.06780498434441275, -0.02585264993912712},
			{7.842333783871841E-4, -0.02585264993912712, 0.02803427468417822}
		},
		{
			{0.011920492540166007, -0.0020406498388326833, -0.009217598395225023},
			{-0.0020406498388326815, 0.0272076119588509, -0.008798524778127374},
			{-0.00921759839522502, -0.00879852477812738, 0.0210769938924471}
		},
		{
			{0.033741298711095796, -0.027251805341992907, 0.004666632273614095},
			{-0.027251805341992914, 0.052104745000653575, -0.01310203403253531},
			{0.0046666322736141005, -0.013102034032535313, 0.0134222198842067}
		},
		{
			{0.04958323679292662, -0.0211761654664646, -0.021450113452565304},
			{-0.02117616546646461, 0.05046864094890349, -0.029045640439704694},
			{-0.021450113452565315, -0.029045640439704687, 0.05772230112202399}
		},
		{
			{0.027336418986421314, -0.02312907464688072, 8.325592733279125E-6},
			{-0.023129074646880708, 0.04157878355460259, -0.006373530430682571},
			{8.325592733279992E-6, -0.006373530430682571, 0.019778104284157196}
		},
		{
			{0.016155134886425688, -0.00540492580312988, -0.003056231357431696},
			{-0.005404925803129878, 0.05195723097140139, -0.0255667926453525},
			{-0.0030562313574317, -0.0255667926453525, 0.033796978932040915}
		},
		{
			{0.06482216741681802, -0.035346509906736406, -0.008641171318006744},
			{-0.03534650990673641, 0.08755168196471426, -0.015806959209968},
			{-0.00864117131800674, -0.01580695920996799, 0.026584407368246597}
		},
		{
			{0.2322220346667667, -0.04466107331275532, -0.11122037755090018},
			{-0.04466107331275534, 0.05215342216025175, 0.02522284756861244},
			{-0.11122037755090022, 0.025222847568612424, 0.053605092837282535}
		},
		{
			{0.08423192038537597, -0.06234831336695379, 0.01215600063566363},
			{-0.06234831336695379, 0.12882887300601803, -0.029957658494448005},
			{0.012156000635663626, -0.029957658494447998, 0.050585980461608004}
		},
		{
			{0.08010926714178747, -0.06193891872869594, -2.610148335197731E-4},
			{-0.06193891872869595, 0.10676315369048706, -0.026468870185408104},
			{-2.610148335197666E-4, -0.026468870185408108, 0.029123198076878704}
		},
		{
			{0.021659289485202713, -0.01643170233636604, 0.0010769730394966314},
			{-0.01643170233636603, 0.060890994793650496, -0.03792900623662523},
			{0.0010769730394966349, -0.03792900623662525, 0.03319773063774904}
		},
		{
			{0.01824597918706019, -0.0014758630861899623, -0.012896968411253104},
			{-0.0014758630861899658, 0.0231030006469427, -0.008303582829033297},
			{-0.012896968411253108, -0.008303582829033299, 0.01848357396431351}
		},
		{
			{0.05023227129242302, -0.03383382887059078, -0.011604692228247825},
			{-0.03383382887059082, 0.07377007315987166, -0.020640988357297985},
			{-0.011604692228247832, -0.020640988357297975, 0.042701915274520205}
		},
		{
			{0.042903183212619454, -0.013594200598733543, -8.283049140737518E-4},
			{-0.01359420059873355, 0.06743317576847606, -0.012517494180522896},
			{-8.283049140737526E-4, -0.012517494180522896, 0.025276842958546798}
		},
		{
			{0.03865867852795816, -0.014819907990282485, -0.00522673675577499},
			{-0.014819907990282493, 0.05023299372999871, -0.025789736234349506},
			{-0.00522673675577499, -0.025789736234349506, 0.03491280547821961}
		},
		{
			{0.016090594077525115, -0.021378156282827746, 0.009618289607119853},
			{-0.021378156282827746, 0.07816418943384507, -0.058695094350845314},
			{0.009618289607119851, -0.058695094350845314, 0.0600984999595207}
		},
		{
			{0.10213896132930704, -0.05464676669174953, -0.026984247282451416},
			{-0.0546467666917495, 0.06798626826264481, 0.006739421427310787},
			{-0.02698424728245141, 0.006739421427310787, 0.013340219167812806}
		},
		{
			{0.1473834267381531, -0.12009191812703608, -0.026416435567179115},
			{-0.12009191812703608, 0.12081414560476907, 0.008953995545411477},
			{-0.026416435567179108, 0.00895399554541148, 0.023471701426987804}
		},
		{
			{0.050787561444189847, -0.015896444517479208, -0.012197083387958513},
			{-0.01589644451747923, 0.05628598281511812, -0.024344298282418186},
			{-0.012197083387958529, -0.02434429828241819, 0.0377390802797703}
		},
		{
			{0.015731918790864736, -0.010084166969861228, -4.330788421838829E-4},
			{-0.010084166969861239, 0.05194342050388558, -0.024116173314456424},
			{-4.3307884218388246E-4, -0.024116173314456407, 0.023963996565490718}
		},
		{
			{0.02194981590377601, 0.00360036867633105, -0.006316549724013737},
			{0.0036003686763310524, 0.013608463300813098, 0.0033741958761871202},
			{-0.006316549724013743, 0.003374195876187116, 0.007930664794769466}
		},
		{
			{0.04999866007409606, -0.045399779214724524, -0.0018115854109742443},
			{-0.045399779214724545, 0.10688569084201192, -0.0203988280264375},
			{-0.0018115854109742417, -0.020398828026437502, 0.013171560399477908}
		},
		{
			{0.056294837807910024, -7.214884531349099E-4, 2.8618574803357258E-5},
			{-7.214884531349302E-4, 0.14782679743436902, -0.024313673198777804},
			{2.8618574803361378E-5, -0.024313673198777794, 0.04916828352169078}
		},
		{
			{0.004372352427235821, -0.006228496933338766, 0.0020700747122301766},
			{-0.006228496933338773, 0.06949640013694461, -0.04464910391845109},
			{0.0020700747122301853, -0.044649103918451095, 0.051373001441797586}
		},
		{
			{0.05212230840596407, -0.02917379324473987, -0.01650876299505369},
			{-0.029173793244739857, 0.08129960851631884, -0.0442910324634502},
			{-0.016508762995053678, -0.04429103246345021, 0.11308579965757298}
		},
		{
			{0.025218671148300648, -0.01824607791995856, 0.004460903608498802},
			{-0.018246077919958567, 0.06657651100107949, -0.04010521615753896},
			{0.004460903608498802, -0.04010521615753895, 0.038340164796691445}
		}
	};

	double barycentre[46][3] =
	{
		{199.58453237410072, 139.81474820143885, 141.6474820143885},
		{221.91363636363636, 99.28181818181818, 25.60909090909091},
		{138.85714285714286, 120.81876332622602, 147.36460554371},
		{206.75757575757575, 133.53030303030303, 99.02380952380952},
		{170.4406779661017, 127.12033898305084, 160.60169491525423},
		{146.77710843373495, 110.98795180722891, 20.08433734939759},
		{89.07865168539325, 139.6561797752809, 118.75730337078652},
		{51.51877934272301, 37.394366197183096, 47.37323943661972},
		{148.52259332023576, 165.94106090373282, 213.88801571709234},
		{137.59674134419552, 188.64358452138492, 154.85947046843177},
		{24.221374045801525, 117.93893129770993, 93.51908396946565},
		{197.6153846153846, 182.98785425101215, 70.28744939271255},
		{105.36666666666666, 101.36060606060606, 117.26666666666667},
		{170.95698924731184, 176.2516129032258, 117.76559139784946},
		{105.01438848920863, 174.8546762589928, 181.70647482014388},
		{138.5770925110132, 92.49339207048457, 69.66960352422907},
		{77.1125, 78.759375, 52.771875},
		{86.81296758104739, 84.46882793017457, 86.75810473815461},
		{119.65357967667437, 137.50346420323325, 86.39030023094688},
		{108.56206896551724, 98.28275862068965, 53.13103448275862},
		{149.2662192393736, 106.12527964205816, 105.40044742729306},
		{98.84330985915493, 164.2588028169014, 149.56690140845072},
		{156.7780082987552, 137.0186721991701, 62.93153526970954},
		{182.2015503875969, 163.29263565891472, 202.81782945736435},
		{159.2304609218437, 157.37274549098197, 91.3687374749499},
		{128.19101123595505, 197.80149812734084, 200.1947565543071},
		{110.18330308529946, 153.47731397459165, 216.78402903811252},
		{66.47938144329896, 51.149484536082475, 79.65463917525773},
		{176.07758620689654, 197.0316091954023, 228.91091954022988},
		{101.04975124378109, 129.21641791044777, 172.93034825870646},
		{55.832089552238806, 145.2910447761194, 154.87686567164178},
		{126.46231155778895, 164.73869346733667, 120.07035175879398},
		{173.364161849711, 118.02697495183044, 89.26782273603082},
		{121.64928909952607, 71.77725118483413, 39.947867298578196},
		{177.28201219512195, 120.97408536585365, 122.92835365853658},
		{101.3913043478261, 201.26304347826087, 239.22608695652173},
		{215.93248945147678, 188.1054852320675, 137.88185654008439},
		{193.43032786885246, 206.02459016393442, 176.93852459016392},
		{189.7422480620155, 146.11434108527132, 177.55232558139534},
		{87.49435665914221, 182.64334085778782, 217.3995485327314},
		{208.1437125748503, 165.34131736526948, 9.48502994011976},
		{142.3230174081238, 140.5396518375242, 190.02901353965183},
		{26.411078717201168, 23.314868804664723, 27.93586005830904},
		{9.838323353293413, 161.1556886227545, 172.97005988023952},
		{131.75708502024293, 183.45344129554655, 242.414979757085},
		{74.46190476190476, 160.1904761904762, 188.25238095238095}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<46;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<46;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance47clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02647129938825624, -0.019137691016548632, -0.0018029671503000696},
		{-0.01913769101654862, 0.0408683547958406, -0.0128488327709458},
		{-0.0018029671503000681, -0.012848832770945801, 0.014717787179719215}
	};

	double matrix[47][3][3] =
	{
		{
			{0.012406738868882003, 0.001240685366295572, -0.01305300462596711},
			{0.0012406853662955738, 0.027843004127555804, -0.012523042887152402},
			{-0.01305300462596711, -0.012523042887152398, 0.022894461057593327}
		},
		{
			{0.09487558051298904, -0.01066800878082549, -1.940184230871416E-4},
			{-0.010668008780825492, 0.052149044486571615, 0.004747962970552702},
			{-1.940184230871415E-4, 0.0047479629705527, 0.019728404954721}
		},
		{
			{0.014525050940850603, -0.020785874709628407, 0.008638803819608057},
			{-0.02078587470962842, 0.07433376207273919, -0.05526334881013882},
			{0.00863880381960807, -0.055263348810138835, 0.057582689701948915}
		},
		{
			{0.03316713537330469, -0.019339981198744485, 0.002629321911926988},
			{-0.01933998119874448, 0.06567967817519038, -0.0045014218773787255},
			{0.0026293219119269875, -0.004501421877378725, 0.0015604845169560992}
		},
		{
			{0.00613691483942674, -0.00839307138583122, 0.008229036166119906},
			{-0.008393071385831227, 0.03846010122443551, -0.025902548692515508},
			{0.008229036166119913, -0.025902548692515508, 0.03196987454366631}
		},
		{
			{0.06624319662040776, -0.03425725769583136, -0.002929369423658242},
			{-0.034257257695831336, 0.05725340252673277, -0.02382497063590329},
			{-0.002929369423658242, -0.023824970635903296, 0.030679265916668606}
		},
		{
			{0.022639682489674802, 0.004481442512192428, -0.0051122191026590404},
			{0.004481442512192428, 0.016897169722301805, 0.0025294216325279007},
			{-0.00511221910265905, 0.002529421632527896, 0.0038681784966508844}
		},
		{
			{0.04475991378420766, -0.026746993676973654, -0.0011146073769251323},
			{-0.026746993676973675, 0.07766717821240623, -0.029905774848067904},
			{-0.001114607376925143, -0.029905774848067893, 0.032970981037476595}
		},
		{
			{0.06254060811942666, -0.03812453843025781, 0.0024666303417700776},
			{-0.038124538430257815, 0.0652075819702937, -0.016263670808124714},
			{0.00246663034177008, -0.016263670808124707, 0.03398833664665021}
		},
		{
			{0.0038967000357681384, -0.007020595529220507, 0.003020537554706609},
			{-0.007020595529220517, 0.07412145278218656, -0.04402144641672077},
			{0.0030205375547066077, -0.044021446416720775, 0.05035091212873258}
		},
		{
			{0.03172188424885301, -0.010930869336678398, -0.010119357877704991},
			{-0.010930869336678396, 0.028940483423797892, -0.004273539455867588},
			{-0.01011935787770499, -0.004273539455867585, 0.019481348427406196}
		},
		{
			{0.015962547928974405, -0.0018040341917701088, -0.0129456996518474},
			{-0.0018040341917701054, 0.01694395282141019, -0.004095658174215252},
			{-0.012945699651847395, -0.004095658174215254, 0.016022123527847088}
		},
		{
			{0.04978740738991465, -0.02416286632409248, -0.005645568225858166},
			{-0.024162866324092494, 0.035976466408821704, -6.874027197459774E-4},
			{-0.005645568225858171, -6.874027197459756E-4, 0.014404604772979402}
		},
		{
			{0.03095320309084893, -0.015743132644506025, 2.0912734749952127E-4},
			{-0.015743132644506032, 0.0536672409851135, -0.027296898227833707},
			{2.0912734749952474E-4, -0.027296898227833707, 0.033480016578090105}
		},
		{
			{0.020706361322632996, -0.012864165824843407, -0.004423259151360045},
			{-0.012864165824843399, 0.04031873213926788, -0.015094862810017408},
			{-0.004423259151360041, -0.015094862810017406, 0.029378531436120202}
		},
		{
			{0.030872196535758893, -0.020484325773720398, -0.0010375570298861055},
			{-0.020484325773720377, 0.07348283073330932, -0.019586649338487312},
			{-0.001037557029886102, -0.019586649338487312, 0.03243432726736782}
		},
		{
			{0.08205021827525545, -0.0625432960564404, 0.011799939447714},
			{-0.06254329605644032, 0.1289102502926199, -0.03756277917955428},
			{0.011799939447713991, -0.03756277917955428, 0.05356327722242291}
		},
		{
			{0.047803787570265203, -0.03534252725025318, -4.311537462308411E-4},
			{-0.03534252725025317, 0.09543271222000793, -0.05004219727212798},
			{-4.311537462308411E-4, -0.05004219727212798, 0.09628199276309571}
		},
		{
			{0.04089709676457853, -0.013946128831464295, -0.011182159980379705},
			{-0.013946128831464292, 0.039820139056447136, -0.013528620291949787},
			{-0.011182159980379705, -0.013528620291949787, 0.031293995086092395}
		},
		{
			{0.0727497461109311, -0.0388777424732482, -0.004377666033882477},
			{-0.03887774247324818, 0.05579198896027697, -0.0023178470908968487},
			{-0.00437766603388248, -0.002317847090896847, 0.00873169524640948}
		},
		{
			{0.05310848878163099, -0.011284164021827603, -0.001573798192100843},
			{-0.01128416402182761, 0.03988661675503082, -0.006836637221693248},
			{-0.001573798192100843, -0.006836637221693252, 0.024894528084036985}
		},
		{
			{0.018224425542502087, -0.00221253098116324, -0.01216774330516539},
			{-0.00221253098116324, 0.024378776279854412, -0.010646976729706905},
			{-0.01216774330516539, -0.010646976729706908, 0.020699183607147197}
		},
		{
			{0.028424841342142976, -0.019385102513991472, -0.005003656721182688},
			{-0.019385102513991476, 0.03872007249586055, -0.004654229356977168},
			{-0.005003656721182689, -0.0046542293569771685, 0.015045071819940001}
		},
		{
			{0.055007019481445436, -0.03714452631886391, 5.614092060645969E-4},
			{-0.037144526318863905, 0.08328792481396309, -0.0383689042692482},
			{5.614092060645909E-4, -0.0383689042692482, 0.04005129557216631}
		},
		{
			{0.11359859733074985, -0.04170282115780993, -0.004855656095456837},
			{-0.04170282115780997, 0.3306432672444909, -0.05476865378843161},
			{-0.004855656095456841, -0.0547686537884316, 0.022972848149951902}
		},
		{
			{0.215568071216143, -0.07274842898644128, -0.09337608060908643},
			{-0.07274842898644127, 0.03353645459428861, 0.02173488732557882},
			{-0.0933760806090864, 0.021734887325578822, 0.05384492742327482}
		},
		{
			{0.045524199463366645, -0.004778973601098944, -0.015600211680681913},
			{-0.004778973601098932, 0.06992153404774917, -0.011988582815761196},
			{-0.015600211680681897, -0.011988582815761206, 0.015580415755249901}
		},
		{
			{0.03561033837304065, -0.022598753318538153, -0.003264748530333903},
			{-0.02259875331853814, 0.061250146383541725, -0.013020961754963208},
			{-0.003264748530333898, -0.013020961754963216, 0.016424430338667306}
		},
		{
			{0.04804014617020123, -0.020986246509479403, -0.01899242152363011},
			{-0.0209862465094794, 0.0525376849072432, -0.0324725373027343},
			{-0.018992421523630103, -0.032472537302734285, 0.059944511026343905}
		},
		{
			{0.09005777873460845, -0.016718448012527577, -0.011680899070558798},
			{-0.016718448012527566, 0.1563320421267, 0.002965293598413022},
			{-0.011680899070558791, 0.002965293598413045, 0.019570325156078722}
		},
		{
			{0.012965384291355896, -0.007157595670645068, -0.003004889452942459},
			{-0.00715759567064507, 0.047863730120973384, -0.0315615540930773},
			{-0.003004889452942461, -0.0315615540930773, 0.032416004549571505}
		},
		{
			{0.026823853190745314, -0.009817368564758183, -0.006242973800202202},
			{-0.009817368564758172, 0.03322020341735689, -0.0034066836733448267},
			{-0.0062429738002021985, -0.0034066836733448215, 0.009406191504475234}
		},
		{
			{0.015938659792182615, -0.006171043848921368, -0.005089035082079577},
			{-0.006171043848921368, 0.05764502254476263, -0.026280628724120722},
			{-0.005089035082079579, -0.026280628724120726, 0.03328737371610461}
		},
		{
			{0.03179739757460409, -0.029960149194519094, 0.007798444324445894},
			{-0.029960149194519073, 0.05707233335451297, -0.018307513803217303},
			{0.007798444324445882, -0.018307513803217303, 0.013153094568417407}
		},
		{
			{0.06190486734067085, -0.06438270922892465, 0.009185510777419513},
			{-0.06438270922892464, 0.14482361654617806, -0.048058594474051315},
			{0.009185510777419508, -0.04805859447405135, 0.03529173887359513}
		},
		{
			{0.02413058069739929, -0.019359471644442468, 0.003621246187090486},
			{-0.019359471644442492, 0.054927520771732144, -0.03715284695195571},
			{0.0036212461870904957, -0.037152846951955705, 0.03980771019661669}
		},
		{
			{0.05347986100106103, -0.0467277083684297, -0.007816499273566075},
			{-0.04672770836842971, 0.100493223049357, -0.006508288301480801},
			{-0.007816499273566079, -0.006508288301480806, 0.014364543351228595}
		},
		{
			{0.04384749006063359, -0.011716312604662214, -0.010210712384199402},
			{-0.011716312604662198, 0.05262236453503349, 0.007486451996379719},
			{-0.01021071238419941, 0.0074864519963797095, 0.017814662540377096}
		},
		{
			{0.057863092330434726, -0.013641213890918904, -0.019169020448460007},
			{-0.013641213890918904, 0.10443756672233595, -0.03568312406086063},
			{-0.019169020448460007, -0.03568312406086063, 0.029756753854636817}
		},
		{
			{0.01818019975105131, -0.003018418111937626, -0.008809344544511707},
			{-0.0030184181119376234, 0.036581681628773594, -0.013379992795405804},
			{-0.008809344544511714, -0.013379992795405795, 0.024711187530202808}
		},
		{
			{0.07147431577367183, 0.01201572245986136, -0.04061270161191036},
			{0.012015722459861353, 0.20994690303154664, 0.0036899126153103236},
			{-0.0406127016119104, 0.003689912615310286, 0.023608697212466792}
		},
		{
			{0.058235778608436595, -0.03758119723224745, -4.140194260958837E-4},
			{-0.037581197232247454, 0.07922907581754507, -0.03423773795603241},
			{-4.140194260958733E-4, -0.03423773795603242, 0.0394034628777948}
		},
		{
			{0.0022012031226160004, -1.9254600947446804E-4, -4.5610659896258825E-4},
			{-1.9254600947446812E-4, 0.08095600264986477, -0.03364256418759261},
			{-4.5610659896258836E-4, -0.03364256418759262, 0.044213192490074826}
		},
		{
			{0.07275257432772145, -0.054252235106024595, -0.0030819808752159308},
			{-0.0542522351060246, 0.0984630568406899, -0.024364942932895605},
			{-0.0030819808752159243, -0.024364942932895598, 0.028297448491569607}
		},
		{
			{0.09659725331673868, -0.011674351646799613, -0.040314530852481587},
			{-0.011674351646799613, 0.07727736196088164, -0.032971423347163534},
			{-0.04031453085248157, -0.03297142334716355, 0.10640498782918299}
		},
		{
			{0.1357832880978079, -0.10084700316635198, -0.017508145359666695},
			{-0.10084700316635203, 0.10972145965416309, -0.007291623766863566},
			{-0.017508145359666695, -0.00729162376686357, 0.02457454187355019}
		},
		{
			{0.045674088850162824, -0.014125383318130704, -0.0040308737786065195},
			{-0.014125383318130713, 0.06135501683955026, -0.010265235592767097},
			{-0.004030873778606519, -0.010265235592767099, 0.0225849591159272}
		}
	};

	double barycentre[47][3] =
	{
		{100.67924528301887, 163.94549266247378, 143.79454926624737},
		{85.88106796116504, 83.4004854368932, 84.93932038834951},
		{97.18134715025907, 198.6286701208981, 235.9706390328152},
		{142.76, 106.8, 18.114285714285714},
		{16.925373134328357, 108.73134328358209, 75.19402985074628},
		{207.70461538461538, 127.22153846153846, 84.69846153846154},
		{209.19774011299435, 169.42372881355934, 12.299435028248588},
		{172.55510752688173, 118.92204301075269, 104.34543010752688},
		{111.51034482758621, 160.08045977011494, 228.14022988505747},
		{9.353658536585366, 160.78658536585365, 172.7987804878049},
		{113.38974358974359, 132.4128205128205, 84.62307692307692},
		{140.34824902723736, 187.8774319066148, 149.96303501945525},
		{222.34653465346534, 98.16831683168317, 21.846534653465348},
		{96.98326359832636, 176.47280334728035, 203.663179916318},
		{103.28635014836796, 173.17359050445103, 174.44510385756678},
		{147.31171548117155, 102.39121338912133, 87.38702928870293},
		{178.39118457300276, 195.35537190082644, 227.0055096418733},
		{134.17857142857142, 188.4033613445378, 241.59453781512605},
		{171.2320819112628, 123.16211604095564, 147.1023890784983},
		{216.44927536231884, 191.89371980676327, 122.66666666666667},
		{144.6759776536313, 110.31284916201118, 128.0195530726257},
		{125.64801444043322, 162.36101083032491, 117.64801444043322},
		{149.04123711340208, 152.35257731958762, 86.8659793814433},
		{198.7245696400626, 135.12050078247262, 124.52738654147105},
		{104.01898734177215, 99.87341772151899, 116.2626582278481},
		{64.69130434782609, 49.15652173913043, 76.47826086956522},
		{162.85512367491165, 136.7773851590106, 179.65194346289752},
		{170.52264150943395, 172.22830188679245, 114.10566037735849},
		{185.20108695652175, 160.3605072463768, 198.48007246376812},
		{25.20149253731343, 20.869402985074625, 24.69402985074627},
		{58.3205574912892, 149.94773519163763, 158.02090592334494},
		{187.5, 171.51612903225808, 71.7483870967742},
		{128.875226039783, 197.27848101265823, 196.76491862567812},
		{158.10337552742615, 130.46835443037975, 61.59071729957806},
		{150.82926829268294, 165.4953095684803, 213.0206378986867},
		{69.90032154340837, 166.00321543408361, 197.20257234726688},
		{126.87117903930131, 144.5873362445415, 197.4170305676856},
		{83.7948717948718, 82.78205128205128, 49.88974358974359},
		{125.25365853658536, 124.47317073170731, 158.81463414634146},
		{87.59183673469387, 138.87244897959184, 120.40306122448979},
		{70.57594936708861, 34.392405063291136, 41.32911392405063},
		{196.61669505962521, 143.9403747870528, 162.5792163543441},
		{37.31, 123.88, 113.57},
		{90.82172701949861, 135.84679665738162, 181.43454038997214},
		{39.617283950617285, 37.592592592592595, 45.91358024691358},
		{197.83393501805054, 203.38628158844764, 174.16606498194946},
		{125.94964028776978, 85.36870503597122, 55.34892086330935}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<47;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<47;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance48clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028177748618540582, -0.02091605413989799, -0.0018539106481548955},
		{-0.020916054139897992, 0.04268473907765559, -0.0132785726050746},
		{-0.0018539106481549, -0.013278572605074602, 0.015056804467686199}
	};

	double matrix[48][3][3] =
	{
		{
			{0.03227306264698008, -0.02529558337045118, -3.5391495833766214E-4},
			{-0.02529558337045116, 0.07164012322624297, -0.02546957637497289},
			{-3.5391495833765607E-4, -0.025469576374972897, 0.03207226986431641}
		},
		{
			{0.01991350735911569, -0.0031538068514579635, -0.012716622225767995},
			{-0.0031538068514579696, 0.035649827874543794, -0.0114079708157133},
			{-0.012716622225767997, -0.011407970815713304, 0.022234173570857406}
		},
		{
			{0.08075799164542373, -0.018943997406589856, -0.0203251138792127},
			{-0.018943997406589815, 0.20599269939713502, 0.009409924055063003},
			{-0.020325113879212705, 0.00940992405506302, 0.025195925207796024}
		},
		{
			{0.05524798921216666, -0.052540484076480876, 0.0031190474282932895},
			{-0.05254048407648087, 0.13138838373657502, -0.0355237297599449},
			{0.0031190474282932895, -0.0355237297599449, 0.020477780665097086}
		},
		{
			{0.0532672894608137, -0.02833892448723141, -0.006406361128142196},
			{-0.02833892448723141, 0.04132272684938193, -0.0016587590895397095},
			{-0.0064063611281421975, -0.0016587590895397113, 0.0136598456423804}
		},
		{
			{0.03652851759882901, -0.01873663443847828, -0.004432341992113568},
			{-0.018736634438478287, 0.05665085191538867, -0.010426889660511104},
			{-0.004432341992113573, -0.010426889660511106, 0.015760005461591203}
		},
		{
			{0.014648029608766317, -0.020685299664473838, 0.008507790865872132},
			{-0.020685299664473838, 0.07172024673829715, -0.052337997351631006},
			{0.008507790865872125, -0.052337997351631, 0.055660075885435686}
		},
		{
			{0.026799149577593287, -0.010420757583382205, -0.0057636033613188455},
			{-0.010420757583382212, 0.03867732747669937, -0.004182568240317885},
			{-0.005763603361318839, -0.004182568240317886, 0.009261693949964258}
		},
		{
			{0.05729768148367975, -0.0355418227140136, -0.001568070103659596},
			{-0.035541822714013606, 0.06646624453578806, -0.0274562862493127},
			{-0.001568070103659606, -0.027456286249312706, 0.03826745029968852}
		},
		{
			{0.01587687890723579, 7.496562585884992E-4, -0.013648697355998395},
			{7.496562585884957E-4, 0.015267754511128794, -0.004195371407696365},
			{-0.013648697355998392, -0.004195371407696362, 0.01847096792526359}
		},
		{
			{0.11326861732568602, -0.07572527181174098, -0.0034444174165653863},
			{-0.07572527181174095, 0.24760510790679008, -0.024882317004168722},
			{-0.003444417416565378, -0.024882317004168708, 0.013689726710981795}
		},
		{
			{0.017090889624116295, -0.001352019767787484, -0.0117233902869221},
			{-0.0013520197677874893, 0.01855797996308402, -0.005107650402206742},
			{-0.011723390286922104, -0.0051076504022067445, 0.018598233907594207}
		},
		{
			{0.10154628577305003, -0.051431507432727744, -0.01657578539539092},
			{-0.051431507432727716, 0.0836680641630744, -0.028293455611442364},
			{-0.016575785395390903, -0.028293455611442392, 0.05863703409667932}
		},
		{
			{0.09363966335276215, -0.01767583487150729, 0.004697781456493137},
			{-0.017675834871507264, 0.08296934590434364, 0.00681003788261419},
			{0.004697781456493134, 0.006810037882614195, 0.017611682475186807}
		},
		{
			{0.04542640214448451, -0.026456070015522904, -0.00898883046695983},
			{-0.026456070015522887, 0.0793218362336684, -0.04389522823029981},
			{-0.00898883046695982, -0.043895228230299815, 0.109319256814949}
		},
		{
			{0.04583081187820536, -0.01263245741900509, -0.0036964953222726905},
			{-0.012632457419005101, 0.04902232744131561, -4.976635953984219E-4},
			{-0.0036964953222726913, -4.976635953984232E-4, 0.00235159686498362}
		},
		{
			{0.09196864791716343, -0.006902400433984893, -0.04493971064111065},
			{-0.0069024004339849135, 0.08746787671900703, -0.034680038796569196},
			{-0.04493971064111063, -0.034680038796569224, 0.10726588420602902}
		},
		{
			{0.0566394424578593, -0.02515758590827271, -0.015264157641317003},
			{-0.025157585908272693, 0.02869169705302569, 0.00613592328264141},
			{-0.015264157641317002, 0.006135923282641412, 0.018445277916095404}
		},
		{
			{0.06562379319096041, -0.03505841571144643, -0.00347781983315361},
			{-0.035058415711446446, 0.05944968886899893, -0.024087277065000006},
			{-0.0034778198331536156, -0.02408727706500001, 0.03131456087978129}
		},
		{
			{0.027863314022498063, -0.024861998351860065, 0.011292939464320887},
			{-0.024861998351860082, 0.07621155307514829, -0.025136853148910298},
			{0.01129293946432089, -0.02513685314891029, 0.012906365868704101}
		},
		{
			{0.0412115498782716, -0.0120713882575125, -0.010886951128383079},
			{-0.0120713882575125, 0.0431743411237656, -0.020122063186530002},
			{-0.010886951128383084, -0.020122063186530006, 0.03193641824764019}
		},
		{
			{0.015404869157915599, 0.00321883999829249, -0.0058131756219601035},
			{0.003218839998292488, 0.054022659377380516, -0.02665636812855963},
			{-0.005813175621960103, -0.026656368128559624, 0.030363397853733324}
		},
		{
			{0.07651966623238682, -0.04971673646243199, -0.020713916695035525},
			{-0.049716736462431986, 0.11018753034451303, -0.028721354781704893},
			{-0.020713916695035518, -0.028721354781704896, 0.03553513230041891}
		},
		{
			{0.012831917092461618, -0.011202723385311817, 0.0025119061279747085},
			{-0.011202723385311808, 0.05356422237223704, -0.02939171423951192},
			{0.0025119061279747093, -0.029391714239511913, 0.030072482008211696}
		},
		{
			{0.049977556523926395, -0.018489564659186084, -0.007172271462613834},
			{-0.018489564659186074, 0.0540524057615199, -0.009263615488936575},
			{-0.007172271462613827, -0.009263615488936566, 0.012952380936737793}
		},
		{
			{0.013557655742936594, -0.0039364082965609925, -0.0015962529680649518},
			{-0.00393640829656099, 0.05338402400679996, -0.02972662972679098},
			{-0.0015962529680649464, -0.02972662972679098, 0.03686760439762658}
		},
		{
			{0.0460620815763138, -0.018351333517811184, -0.021363793530882982},
			{-0.018351333517811194, 0.05132481094346563, -0.034165750403294205},
			{-0.02136379353088299, -0.03416575040329419, 0.06156593319414358}
		},
		{
			{0.019463879775637998, 0.0023054940427137934, -0.005856447740012177},
			{0.0023054940427137917, 0.0146138816643837, 0.0032935867562798793},
			{-0.005856447740012173, 0.0032935867562798827, 0.007711298040964099}
		},
		{
			{0.02503134230412848, -0.013069192774228295, 0.004197973893297261},
			{-0.013069192774228295, 0.04437298788049064, -0.038875501771965415},
			{0.00419797389329726, -0.038875501771965415, 0.04184064271115327}
		},
		{
			{0.05240801821971201, -0.02510295483890938, -8.345711264471495E-4},
			{-0.025102954838909383, 0.043810375969932064, -0.008384401344204373},
			{-8.345711264471509E-4, -0.008384401344204376, 0.008057434118781355}
		},
		{
			{0.112896640808616, -0.05055697918356122, -0.021917983322746897},
			{-0.05055697918356122, 0.08451511024347119, -0.021813489832355884},
			{-0.021917983322746897, -0.02181348983235591, 0.031702286861403986}
		},
		{
			{0.03078841550469422, -0.0335741717255413, 0.010860930263965705},
			{-0.03357417172554131, 0.05575169765853508, -0.014987283535829206},
			{0.010860930263965703, -0.014987283535829196, 0.00947881170366072}
		},
		{
			{0.026546639909138185, -0.02228812954774938, 0.001137026877007466},
			{-0.02228812954774938, 0.04769782532594149, -0.010814403268280304},
			{0.001137026877007466, -0.010814403268280304, 0.017287774951476}
		},
		{
			{0.030998301139479677, -0.014326941548098208, -0.013992706119139905},
			{-0.01432694154809821, 0.042719457651629655, -0.0040212748765423145},
			{-0.013992706119139909, -0.0040212748765423145, 0.016673170116232015}
		},
		{
			{0.07763632271296601, 0.03741435691781377, -0.0601858561648038},
			{0.037414356917813724, 0.25550178285294206, -0.052479767392738824},
			{-0.060185856164803785, -0.0524797673927388, 0.0616583574871525}
		},
		{
			{0.0210602248178163, 0.005117337694027592, 0.0023156526903148743},
			{0.005117337694027589, 0.05851581715636087, -0.0387557240236102},
			{0.002315652690314872, -0.03875572402361019, 0.039100308068511}
		},
		{
			{0.024371650519511692, -0.013929998590106683, -0.003297841207143822},
			{-0.01392999859010668, 0.03866671043149666, -0.015670557547391314},
			{-0.003297841207143817, -0.015670557547391314, 0.02569342018336502}
		},
		{
			{0.04020729967537738, -0.015194490234858558, -0.002247027541013221},
			{-0.015194490234858561, 0.07208667999003693, -0.006808386441754317},
			{-0.0022470275410132303, -0.006808386441754325, 0.0188768403445276}
		},
		{
			{0.011383180416829097, 0.002339796039954994, -0.010658658688154108},
			{0.0023397960399549967, 0.02443105485520531, -0.013712110869854814},
			{-0.01065865868815411, -0.013712110869854808, 0.025501739428642024}
		},
		{
			{0.04401677318480627, -0.01256987016370841, -0.010138829343077804},
			{-0.01256987016370842, 0.05692586451940555, 0.0074534803957901335},
			{-0.010138829343077813, 0.007453480395790136, 0.0175772995700898}
		},
		{
			{0.062194365030834434, -0.0381812412506339, 5.879095494125677E-4},
			{-0.03818124125063391, 0.06956107371066347, -0.020527820585582116},
			{5.87909549412559E-4, -0.02052782058558211, 0.03945114098914441}
		},
		{
			{0.07009310644689859, -0.07074277924889472, 0.020448599447934666},
			{-0.07074277924889469, 0.14520986302748304, -0.04866007106505008},
			{0.020448599447934666, -0.048660071065050055, 0.06768504243667356}
		},
		{
			{0.059102968281881094, -0.015671335245216085, -0.013509408764628698},
			{-0.0156713352452161, 0.037458745893964224, -0.013077978262648091},
			{-0.013509408764628701, -0.013077978262648093, 0.028255015503381397}
		},
		{
			{0.0698372102079376, -0.052017304239211186, -0.010960024136527385},
			{-0.05201730423921123, 0.0948642584207124, 0.0010942504945453064},
			{-0.0109600241365274, 0.0010942504945453072, 0.014972628754497598}
		},
		{
			{0.0035749077142962484, -0.004719645739067396, 0.002685924661218483},
			{-0.00471964573906739, 0.05456519251928439, -0.03710247595445949},
			{0.0026859246612184785, -0.03710247595445949, 0.047898931601336}
		},
		{
			{0.02285656453166828, -0.009621013456125687, -0.0073852936387080025},
			{-0.009621013456125687, 0.023429172050299492, -0.003811742972162512},
			{-0.007385293638708002, -0.0038117429721625084, 0.021273708528093904}
		},
		{
			{0.05820819915333416, -0.03679565915461889, -0.002232248616943665},
			{-0.03679565915461886, 0.07950749937857605, -0.036486533419277906},
			{-0.002232248616943671, -0.036486533419277885, 0.0391321983077131}
		},
		{
			{0.23087807551612327, -0.08880708445677145, -0.1136759365604672},
			{-0.08880708445677153, 0.05366266992492644, 0.031982574703870094},
			{-0.11367593656046725, 0.03198257470387008, 0.0630402057286514}
		}
	};

	double barycentre[48][3] =
	{
		{162.13309352517985, 111.86810551558753, 99.97002398081534},
		{102.91005291005291, 147.88095238095238, 113.9973544973545},
		{25.0, 20.57471264367816, 24.56704980842912},
		{147.60885608856088, 159.27121771217713, 209.66236162361625},
		{222.67, 97.17, 23.52},
		{172.28854625550662, 175.90528634361235, 118.55947136563877},
		{98.6648451730419, 199.26047358834245, 236.6903460837887},
		{183.0990099009901, 166.1089108910891, 70.85808580858085},
		{192.45871559633028, 138.06880733944953, 159.83180428134557},
		{131.5168776371308, 187.41350210970464, 158.5295358649789},
		{113.11466666666666, 100.40533333333333, 112.496},
		{131.2007434944238, 168.56691449814127, 123.07063197026022},
		{193.32512315270935, 198.9408866995074, 223.807881773399},
		{84.98759305210918, 80.46401985111663, 87.09429280397022},
		{132.06843267108167, 185.42163355408388, 243.4878587196468},
		{223.4578313253012, 197.0120481927711, 20.819277108433734},
		{38.85625, 37.6625, 45.084375},
		{177.64473684210526, 207.98684210526315, 167.89473684210526},
		{203.6638888888889, 125.18611111111112, 85.54722222222222},
		{133.82743362831857, 98.19026548672566, 23.07079646017699},
		{172.90693739424705, 119.585448392555, 136.06768189509307},
		{70.72638436482085, 133.25732899022802, 134.6058631921824},
		{106.83596214511041, 123.96845425867508, 165.10410094637223},
		{82.50456621004567, 176.07534246575344, 207.55251141552512},
		{159.62852112676057, 134.3767605633803, 177.01760563380282},
		{125.23529411764706, 196.00735294117646, 199.98345588235293},
		{184.81098546042003, 158.32148626817448, 196.05492730210017},
		{196.58333333333334, 148.21212121212122, 11.363636363636363},
		{68.22279792746114, 151.31865284974094, 179.0259067357513},
		{214.125, 201.63194444444446, 106.65277777777777},
		{216.11353711790392, 180.31441048034935, 161.1353711790393},
		{156.61859582542695, 127.67172675521822, 62.51043643263757},
		{156.73019271948607, 155.39614561027838, 92.72805139186295},
		{95.73777777777778, 121.97777777777777, 83.46222222222222},
		{70.86, 33.84, 40.166666666666664},
		{23.48739495798319, 116.71428571428571, 89.5546218487395},
		{101.10616929698709, 172.25538020086083, 179.20229555236727},
		{129.22924187725633, 86.2057761732852, 62.31046931407942},
		{97.4679089026915, 163.28571428571428, 146.27329192546583},
		{84.46228710462287, 82.35036496350365, 50.26520681265207},
		{109.44255319148937, 160.44893617021276, 224.0468085106383},
		{160.79674796747966, 188.64769647696477, 223.3360433604336},
		{139.9063231850117, 120.13583138173303, 144.6791569086651},
		{116.8488888888889, 141.58666666666667, 195.61555555555555},
		{15.080568720379146, 159.43601895734596, 168.84834123222748},
		{128.35616438356163, 139.7835616438356, 83.86849315068493},
		{199.22906793048972, 136.4265402843602, 120.70774091627172},
		{62.27947598253275, 47.56768558951965, 74.03930131004367}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<48;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<48;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance49clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027363195459034963, -0.02040558551612227, -0.0016957918921975755},
		{-0.020405585516122288, 0.04258125328077163, -0.013503194322083805},
		{-0.0016957918921975765, -0.013503194322083804, 0.01536653647164429}
	};

	double matrix[49][3][3] =
	{
		{
			{0.044300117594404116, -0.010689832613545903, -0.014308649620175315},
			{-0.0106898326135459, 0.07338572655846419, -0.010179327459191607},
			{-0.014308649620175307, -0.010179327459191598, 0.014703270084835305}
		},
		{
			{0.09529661349583395, -0.009838288419607575, 0.0018341430921579014},
			{-0.009838288419607573, 0.04654943057495078, 0.004996493163325122},
			{0.0018341430921579012, 0.004996493163325122, 0.020223586764410804}
		},
		{
			{0.06293645444038007, -0.002416613117027174, -0.034317394372002985},
			{-0.002416613117027143, 0.11744392123528202, -0.011342765154123392},
			{-0.03431739437200297, -0.011342765154123365, 0.08712899319660283}
		},
		{
			{0.015222436323903174, -0.021584111178097255, 0.008715544525598112},
			{-0.021584111178097262, 0.07152991241278459, -0.04914692324833163},
			{0.008715544525598123, -0.04914692324833162, 0.05056816810813825}
		},
		{
			{0.05802215201591831, -0.009114104400933949, -0.019124659792112215},
			{-0.009114104400933947, 0.050983210302009294, -0.013410218456758993},
			{-0.01912465979211221, -0.013410218456758993, 0.029436190026748202}
		},
		{
			{0.049978121712204324, -0.023445363363783608, -0.019040909072985692},
			{-0.023445363363783597, 0.053384561749309764, -0.02792558823735041},
			{-0.01904090907298569, -0.027925588237350408, 0.05389176597827118}
		},
		{
			{0.11152813621341084, -0.07590150548859488, -0.003420864340864035},
			{-0.07590150548859488, 0.3038428103789867, -0.050403599332404375},
			{-0.0034208643408640427, -0.050403599332404396, 0.0225009941206067}
		},
		{
			{0.01692177004543021, -0.003922021439440326, -0.009978224007019731},
			{-0.003922021439440324, 0.033877567681298, -0.009968968949479847},
			{-0.009978224007019733, -0.009968968949479844, 0.01801066426355941}
		},
		{
			{0.061603165295546616, -0.024883375285164527, -0.00678965143463338},
			{-0.02488337528516452, 0.026931466442286948, -0.009217394211340796},
			{-0.006789651434633377, -0.009217394211340798, 0.020483572647340197}
		},
		{
			{0.004121047233682147, -0.0076138678673183715, 0.003287525023622049},
			{-0.007613867867318351, 0.0723718860481799, -0.04267159537558299},
			{0.00328752502362204, -0.04267159537558297, 0.04937648945054382}
		},
		{
			{0.05570118486343878, -0.036057991435791296, -5.769004355466829E-4},
			{-0.036057991435791296, 0.07969447308694827, -0.03735304956749483},
			{-5.769004355466842E-4, -0.03735304956749486, 0.036822053502934014}
		},
		{
			{0.0416412643420221, 0.008692308713209243, -0.007993293895262276},
			{0.008692308713209243, 0.03435496392835473, -0.0010284496234467927},
			{-0.007993293895262278, -0.0010284496234467886, 0.0031361349061760093}
		},
		{
			{0.013816295712899794, 0.0014357071791589078, -0.012936364679086794},
			{0.0014357071791588974, 0.02781547251933477, -0.013935926192278483},
			{-0.012936364679086793, -0.013935926192278488, 0.024216802706646588}
		},
		{
			{0.04897295752778441, -0.0185930303739672, -0.012587266750548706},
			{-0.018593030373967222, 0.057924947657615924, -0.029128571245922497},
			{-0.012587266750548718, -0.029128571245922514, 0.043319036300408204}
		},
		{
			{0.05956216036709755, -0.06062245245090695, 0.006189517427680483},
			{-0.06062245245090691, 0.13850834611680996, -0.041035324189308706},
			{0.006189517427680485, -0.041035324189308706, 0.030954280481607508}
		},
		{
			{0.014100010889743494, -0.006167434663799012, -0.001129290918278283},
			{-0.006167434663799009, 0.042963739088130684, -0.0370341507750127},
			{-0.0011292909182782787, -0.037034150775012716, 0.03777421831654461}
		},
		{
			{0.022288021441417102, -0.012307010187845586, -0.003435602319585275},
			{-0.012307010187845576, 0.037034587015008474, -0.015199198923145611},
			{-0.003435602319585275, -0.015199198923145613, 0.0257086299531619}
		},
		{
			{0.13739849663366593, -0.10121935690835802, -0.011735249243421897},
			{-0.10121935690835794, 0.11124700633419995, -0.010883550674981198},
			{-0.011735249243421895, -0.010883550674981196, 0.024704115001049798}
		},
		{
			{0.040044153377076924, -0.01408044872273786, -0.0023285047760127505},
			{-0.014080448722737848, 0.06297960470778649, -0.03080882281664282},
			{-0.002328504776012754, -0.030808822816642805, 0.03691888288135629}
		},
		{
			{0.111357601637495, -0.05622593063194532, -0.0022604946593678607},
			{-0.05622593063194531, 0.07916927321017844, -0.02398238893541201},
			{-0.002260494659367865, -0.023982388935412012, 0.0234753506520897}
		},
		{
			{0.020149478684340992, -0.004565941398741414, -0.016626455514297096},
			{-0.004565941398741419, 0.0160949667022198, 0.002465567498748789},
			{-0.016626455514297096, 0.0024655674987487867, 0.016522169056254806}
		},
		{
			{0.016060707445856803, -0.006195093656879163, -0.00397505025121482},
			{-0.006195093656879159, 0.0585950935899525, -0.030697328935543094},
			{-0.003975050251214819, -0.030697328935543094, 0.03390002148958668}
		},
		{
			{0.024886561730113402, -0.026770509852760815, 0.002068341236541871},
			{-0.026770509852760815, 0.06572585606596934, -0.0125879167721552},
			{0.002068341236541868, -0.012587916772155202, 0.0035791637433597386}
		},
		{
			{0.07908596977622673, -0.05166732399656967, -0.009675972981704134},
			{-0.05166732399656969, 0.10999703403054996, -0.024450452159187095},
			{-0.009675972981704146, -0.02445045215918711, 0.019869867586151693}
		},
		{
			{0.04598925975273247, -0.027469663303676894, -0.006499857912887486},
			{-0.027469663303676888, 0.08082647700465705, -0.04494924723287854},
			{-0.006499857912887487, -0.04494924723287855, 0.104200516899959}
		},
		{
			{0.0388030126002707, -0.009815793403911657, -0.01696114334995231},
			{-0.009815793403911664, 0.04656516249463304, -0.01792061210101009},
			{-0.016961143349952315, -0.017920612101010085, 0.03601990996188789}
		},
		{
			{0.029384054980541804, -0.022268578951163694, 3.4880130599897414E-4},
			{-0.0222685789511637, 0.047212563322165405, -0.008360563142109858},
			{3.488013059989724E-4, -0.008360563142109857, 0.013148923453711898}
		},
		{
			{0.017624423352172496, -0.0039289246018629174, -0.007189986557626719},
			{-0.003928924601862917, 0.0364241185097375, -0.01233859228157391},
			{-0.007189986557626715, -0.012338592281573912, 0.022739466814896497}
		},
		{
			{0.035313302562086125, -0.021210428918186898, 8.413280113122412E-4},
			{-0.021210428918186898, 0.061477636931561164, -0.024898506671844307},
			{8.413280113122425E-4, -0.024898506671844307, 0.02921383009378651}
		},
		{
			{0.03211994704226864, -0.007720733910716592, -0.014384102025161206},
			{-0.00772073391071659, 0.02492269772384159, -0.0019368284526003407},
			{-0.014384102025161199, -0.0019368284526003424, 0.02003255202151899}
		},
		{
			{0.026170897013168493, -0.008859497104844224, -0.008620327077791196},
			{-0.008859497104844235, 0.04200292360169919, -0.0061641512548351604},
			{-0.008620327077791194, -0.006164151254835168, 0.0142686382588809}
		},
		{
			{0.05462211798986335, -0.031890381047604395, 8.969836693607739E-4},
			{-0.03189038104760439, 0.07054649705654807, -0.026285581929035077},
			{8.969836693607713E-4, -0.026285581929035073, 0.03312970397632241}
		},
		{
			{0.012804030481834192, 0.003719906544583994, -0.011250333059190902},
			{0.0037199065445839936, 0.012567063204623603, -0.007117795511019077},
			{-0.0112503330591909, -0.007117795511019079, 0.019646071786651318}
		},
		{
			{0.06759637090904638, -0.050146201722740744, -0.006938998559715799},
			{-0.050146201722740764, 0.10066096938992405, -0.006659506194129045},
			{-0.0069389985597158015, -0.006659506194129047, 0.014423550403502391}
		},
		{
			{0.05057613496026007, -0.02551928908764655, 0.0015924706143498632},
			{-0.02551928908764655, 0.05067310913657317, -0.006448062711349978},
			{0.0015924706143498654, -0.006448062711349976, 0.008292805055735469}
		},
		{
			{0.056294837807910024, -7.214884531349099E-4, 2.8618574803357258E-5},
			{-7.214884531349302E-4, 0.14782679743436902, -0.024313673198777804},
			{2.8618574803361378E-5, -0.024313673198777794, 0.04916828352169078}
		},
		{
			{0.021559724954785597, 0.0028269003170521088, -0.00638989988772444},
			{0.0028269003170521105, 0.013040309191517203, 0.0023367498440493226},
			{-0.006389899887724443, 0.0023367498440493234, 0.007478522924397681}
		},
		{
			{0.08532567894523291, -0.06412437546655064, 0.012625386289310769},
			{-0.06412437546655063, 0.1261672349773891, -0.034433738769508705},
			{0.012625386289310777, -0.0344337387695087, 0.051048806796165476}
		},
		{
			{0.04063583738571751, -0.029905848517343982, -0.0020613778941541523},
			{-0.029905848517343993, 0.08889564001314666, -8.728103211260072E-4},
			{-0.002061377894154153, -8.728103211260052E-4, 0.018534334229595908}
		},
		{
			{0.04127141417198802, -0.017737464174276716, -0.0103163862447611},
			{-0.017737464174276723, 0.05556449647623558, 0.005175824314090053},
			{-0.010316386244761104, 0.005175824314090066, 0.016815846914253}
		},
		{
			{0.03922396702925654, -0.03338140464464756, 0.007344153116560069},
			{-0.033381404644647575, 0.08125950450633378, -0.02712299834658985},
			{0.007344153116560072, -0.027122998346589842, 0.028000380136274025}
		},
		{
			{0.002998778874598148, -0.0018813974126817002, 0.0020580804108756004},
			{-0.001881397412681719, 0.0678919165860504, -0.041423998578766864},
			{0.002058080410875618, -0.041423998578766885, 0.05328251791533216}
		},
		{
			{0.006136914848590034, -0.008393071379711995, 0.008229036155665887},
			{-0.008393071379711996, 0.038460101229215976, -0.025902548700992484},
			{0.008229036155665892, -0.025902548700992498, 0.0319698745470209}
		},
		{
			{0.018936094067940605, -0.01487916759806108, 0.003306761696185475},
			{-0.014879167598061066, 0.05343881113090472, -0.03263546933130427},
			{0.003306761696185467, -0.032635469331304276, 0.0314538146676508}
		},
		{
			{0.23222203452139764, -0.044661072889172614, -0.1112203778656106},
			{-0.04466107288917265, 0.05215342151329346, 0.025222847851966122},
			{-0.11122037786561062, 0.02522284785196611, 0.05360509324842282}
		},
		{
			{0.07229518248578116, -0.03402683780336563, -0.02372504656520901},
			{-0.03402683780336563, 0.03778641410137541, 0.003923238677447904},
			{-0.02372504656520901, 0.003923238677447904, 0.028217350382932896}
		},
		{
			{0.0469205476120249, -0.014321354879508504, -0.005298617357549284},
			{-0.014321354879508499, 0.060147772461205624, -0.006547784844198623},
			{-0.005298617357549282, -0.006547784844198632, 0.018840307576094402}
		},
		{
			{0.027167116514302696, -0.010962165305380507, -0.004593685702429966},
			{-0.010962165305380507, 0.03746574647313507, -0.00473051603751855},
			{-0.004593685702429965, -0.004730516037518548, 0.0120724032666098}
		},
		{
			{0.07593924191680562, -0.03094438150570466, 0.0020710673927137645},
			{-0.03094438150570467, 0.0691229882747087, -0.018354502637027894},
			{0.0020710673927137567, -0.018354502637027904, 0.0313596030243366}
		}
	};

	double barycentre[49][3] =
	{
		{157.84156378600824, 138.54732510288065, 183.46296296296296},
		{86.86189258312021, 83.35805626598466, 86.18414322250639},
		{52.52, 36.95058823529412, 47.21411764705882},
		{98.30350877192983, 198.9719298245614, 236.1315789473684},
		{130.26139088729016, 123.2158273381295, 153.59952038369303},
		{184.55888223552896, 162.84231536926148, 201.79441117764472},
		{105.94025157232704, 101.0377358490566, 116.83333333333333},
		{124.86990291262136, 157.81747572815533, 110.48155339805825},
		{219.74647887323943, 107.37323943661971, 60.25352112676056},
		{7.980769230769231, 160.48717948717947, 172.81410256410257},
		{196.68559837728193, 132.16227180527383, 140.43813387423936},
		{222.5064935064935, 197.72727272727272, 17.636363636363637},
		{98.30718954248366, 162.33333333333334, 142.84531590413943},
		{190.99267399267399, 143.02564102564102, 172.5915750915751},
		{148.9820788530466, 164.41397849462365, 212.42831541218638},
		{56.042345276872965, 156.15960912052117, 166.4885993485342},
		{102.1222366710013, 172.9479843953186, 177.13133940182055},
		{202.2633744855967, 203.5102880658436, 175.02880658436214},
		{175.75583482944344, 121.82226211849192, 115.47396768402155},
		{203.22151898734177, 167.09177215189874, 137.34177215189874},
		{154.34397163120568, 198.57801418439718, 161.29432624113474},
		{125.36442141623489, 195.93609671848014, 198.24870466321244},
		{146.10050251256283, 111.03517587939699, 25.100502512562816},
		{88.14367816091954, 132.01436781609195, 169.132183908046},
		{134.54507337526206, 187.74004192872118, 241.8574423480084},
		{166.18669131238448, 121.59519408502773, 149.93715341959336},
		{149.6779359430605, 142.30071174377224, 72.41103202846975},
		{87.69436997319035, 138.71045576407508, 118.58176943699732},
		{147.8361858190709, 105.75061124694376, 111.5281173594132},
		{112.94647887323944, 129.25352112676057, 82.28732394366197},
		{165.6512027491409, 170.35223367697594, 107.8573883161512},
		{203.79540229885058, 134.2344827586207, 103.73563218390805},
		{131.04356435643564, 179.15049504950494, 141.64356435643563},
		{118.80492813141684, 141.86242299794662, 196.0965092402464},
		{212.83098591549296, 202.21830985915494, 99.33098591549296},
		{26.452173913043477, 23.443478260869565, 27.973913043478262},
		{197.70967741935485, 149.61290322580646, 11.911290322580646},
		{177.5668604651163, 196.44476744186048, 227.71511627906978},
		{138.10089686098655, 92.36995515695067, 70.53811659192826},
		{79.1470588235294, 81.14411764705882, 52.294117647058826},
		{168.59735349716445, 116.54253308128544, 85.54442344045368},
		{40.11304347826087, 123.43478260869566, 117.07826086956521},
		{17.309859154929576, 107.85915492957747, 74.87323943661971},
		{81.87712665406427, 170.99054820415878, 205.40264650283555},
		{66.80597014925372, 51.4228855721393, 79.0049751243781},
		{223.3525179856115, 98.88489208633094, 11.359712230215827},
		{116.68226600985221, 83.0295566502463, 45.54187192118226},
		{182.65408805031447, 161.35849056603774, 69.31132075471699},
		{111.12314225053079, 161.9171974522293, 225.88535031847132}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<49;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<49;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance50clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.0258074816838431, -0.01954332416797141, -0.0018559375495936137},
		{-0.0195433241679714, 0.04236611874758879, -0.013339604924973898},
		{-0.0018559375495936152, -0.013339604924973896, 0.015148264621159003}
	};

	double matrix[50][3][3] =
	{
		{
			{0.07147431577367183, 0.01201572245986136, -0.04061270161191036},
			{0.012015722459861353, 0.20994690303154664, 0.0036899126153103236},
			{-0.0406127016119104, 0.003689912615310286, 0.023608697212466792}
		},
		{
			{0.04817549486857162, -0.013231575080856305, -0.004038469144346382},
			{-0.013231575080856308, 0.04883534089669134, -4.2398130215154107E-4},
			{-0.0040384691443463815, -4.239813021515301E-4, 0.0023988362434666103}
		},
		{
			{0.12168681922799204, -0.06276634228399537, -0.01278359532359277},
			{-0.06276634228399536, 0.29695362987405305, -0.05249000001778598},
			{-0.012783595323592759, -0.05249000001778599, 0.022469198428651}
		},
		{
			{0.0159022505441853, -0.008623686691331185, -0.003685953055739175},
			{-0.008623686691331189, 0.05115710774933505, -0.03280099652380541},
			{-0.0036859530557391764, -0.03280099652380541, 0.032329882144606886}
		},
		{
			{0.012372666921054385, 0.00470530135444764, -0.011437381142814394},
			{0.004705301354447643, 0.032793489439356296, -0.008992340293090918},
			{-0.011437381142814392, -0.008992340293090914, 0.0190423851250771}
		},
		{
			{0.041028422304255796, -0.01639926998998388, -0.0022766176215027406},
			{-0.016399269989983874, 0.07420721709052275, -0.00822856285540504},
			{-0.0022766176215027424, -0.008228562855405037, 0.020303419305992096}
		},
		{
			{0.03877776149776991, -0.019838641533034888, 2.5531871705013545E-4},
			{-0.019838641533034867, 0.0627736379413347, -0.02104602073021018},
			{2.553187170501363E-4, -0.021046020730210176, 0.027726854970088685}
		},
		{
			{0.03122755105801067, -0.01760205379286131, -0.0016236878022607725},
			{-0.017602053792861314, 0.045386304652821806, -0.021726093703056008},
			{-0.001623687802260772, -0.021726093703056008, 0.027634684195067916}
		},
		{
			{0.012842873644210105, 0.0015623190968586257, -0.010581098388474198},
			{0.0015623190968586291, 0.017672824506283005, -0.005239471172325195},
			{-0.010581098388474201, -0.005239471172325186, 0.019838673490641116}
		},
		{
			{0.06465670921968027, -0.04314703723681944, -0.0070920184975715814},
			{-0.043147037236819466, 0.08903954593499692, -0.019166666360621493},
			{-0.007092018497571578, -0.0191666663606215, 0.0322365345845781}
		},
		{
			{0.04317622672782749, -0.0523714878579726, 0.006433246200920841},
			{-0.052371487857972576, 0.13852274329027, -0.026481014454239005},
			{0.006433246200920837, -0.026481014454239008, 0.0430709694773322}
		},
		{
			{0.05760124585866048, -0.020185645361662022, -0.0152941889135167},
			{-0.020185645361662008, 0.02973542597925827, 0.007448800762217299},
			{-0.015294188913516697, 0.0074488007622172964, 0.018245186280701195}
		},
		{
			{0.040517340945882996, -0.015643278812037118, -0.009939059092199363},
			{-0.01564327881203711, 0.04978604413419954, 0.002626683688348258},
			{-0.00993905909219937, 0.0026266836883482615, 0.016482160247570703}
		},
		{
			{0.21762626674174088, -0.08050734646222837, -0.09416924276008556},
			{-0.08050734646222836, 0.043737267940143584, 0.022145307286681886},
			{-0.09416924276008556, 0.02214530728668189, 0.05533097040433269}
		},
		{
			{0.03334730162981748, -0.010177852003813197, -0.01002097868136639},
			{-0.010177852003813197, 0.05131384700882619, -0.02159646462792691},
			{-0.01002097868136639, -0.02159646462792691, 0.032629519458878604}
		},
		{
			{0.0827798476838049, -0.06332904904890084, -0.006619160559565846},
			{-0.06332904904890084, 0.10755596928323206, -0.0251822640365003},
			{-0.006619160559565848, -0.025182264036500295, 0.029242495372476987}
		},
		{
			{0.058743677810305255, -0.037160330105162065, -0.001796346186168816},
			{-0.037160330105162086, 0.08364721053215296, -0.03849729769851534},
			{-0.0017963461861688302, -0.03849729769851533, 0.041597498333935626}
		},
		{
			{0.018906357458485512, -5.955971700766713E-4, -0.010434284749925114},
			{-5.955971700766678E-4, 0.0239046730974821, -0.007964458847143696},
			{-0.010434284749925107, -0.007964458847143696, 0.018800492715395304}
		},
		{
			{0.05337387156257269, -0.028721799855071912, -6.772794761682871E-4},
			{-0.028721799855071898, 0.04714739628158429, -0.008734092520264001},
			{-6.772794761682848E-4, -0.008734092520264001, 0.008344127382312772}
		},
		{
			{0.05125278583845791, -0.02744110343948653, -0.004274764769510718},
			{-0.02744110343948652, 0.041058933926991614, 5.247038260319443E-4},
			{-0.00427476476951072, 5.24703826031943E-4, 0.0132993073066347}
		},
		{
			{0.0608244985613663, -0.03626787416227807, -0.0049376132524468815},
			{-0.036267874162278044, 0.07512176962906683, -0.03229971805043026},
			{-0.004937613252446869, -0.032299718050430276, 0.04180629514338789}
		},
		{
			{0.029675860245371992, -0.016958422078506594, -0.004314659655273964},
			{-0.016958422078506594, 0.0327226891231598, -0.003459316700759675},
			{-0.004314659655273962, -0.0034593167007596804, 0.0134254957021252}
		},
		{
			{0.05184358876290683, -0.04397959471369564, -0.005076383634620115},
			{-0.04397959471369562, 0.10569171707999017, -0.011583791425079315},
			{-0.005076383634620107, -0.011583791425079303, 0.010357542217730598}
		},
		{
			{0.015407894172956571, -0.021624119394222336, 0.009478209398257536},
			{-0.021624119394222336, 0.07783871549271915, -0.05696281222170437},
			{0.00947820939825754, -0.056962812221704365, 0.05953264451080229}
		},
		{
			{0.09421992409304514, -0.021561856488834307, 0.0026762852531823644},
			{-0.02156185648883431, 0.07854760676498465, 0.007895440780913894},
			{0.0026762852531823657, 0.007895440780913896, 0.024027958600684}
		},
		{
			{0.03278836024341848, -0.006974941563812418, -0.011993513759704297},
			{-0.006974941563812417, 0.027866415887193383, -0.009074977438032815},
			{-0.011993513759704299, -0.00907497743803281, 0.022032972168358596}
		},
		{
			{0.07138468489416794, -0.030239585691797483, -0.0035391451502917058},
			{-0.03023958569179746, 0.04450408198605898, -0.025653744720405297},
			{-0.0035391451502917127, -0.0256537447204053, 0.0305355866205313}
		},
		{
			{0.03187117645233915, 0.009500504900191671, -0.015506940383002947},
			{0.009500504900191666, 0.0370615915307516, -0.020612931377929807},
			{-0.015506940383002946, -0.020612931377929796, 0.028687742356700203}
		},
		{
			{0.05693854764846613, -0.012202659078803005, -0.017852753283383607},
			{-0.01220265907880299, 0.03920132526186878, -0.00988234199545691},
			{-0.017852753283383597, -0.009882341995456907, 0.023605154086626105}
		},
		{
			{0.01768769474755471, -0.004155603772298105, -0.006402061920877396},
			{-0.004155603772298105, 0.029256602053243083, -0.009894142691766286},
			{-0.006402061920877392, -0.009894142691766286, 0.020201598505395005}
		},
		{
			{0.04626043383399279, -0.019825225341880998, -0.0193374792603303},
			{-0.019825225341880998, 0.052154865839456686, -0.03375548499589688},
			{-0.0193374792603303, -0.03375548499589689, 0.0583574436064309}
		},
		{
			{0.09991325785482388, -0.014831957916784804, -0.037329704758318344},
			{-0.014831957916784821, 0.07042795161126555, -0.03220791837939645},
			{-0.037329704758318316, -0.032207918379396454, 0.10639178777215294}
		},
		{
			{0.05017603477186908, -0.0245864244470574, -0.010232064576819116},
			{-0.024586424447057397, 0.07242612848805943, -0.028265367359682894},
			{-0.010232064576819116, -0.0282653673596829, 0.040099950444071525}
		},
		{
			{0.04974963678644949, -0.01942747110555435, -0.01136821040038739},
			{-0.019427471105554345, 0.04570910363479201, -0.013698380269886689},
			{-0.011368210400387393, -0.01369838026988668, 0.03316336076484738}
		},
		{
			{0.0358980324417184, -0.024567404447334965, -0.00350310639645094},
			{-0.024567404447334993, 0.06565724577528369, -0.01390893149960079},
			{-0.0035031063964509395, -0.013908931499600784, 0.016518441138780107}
		},
		{
			{0.026565985491606638, -0.009906226485375598, -0.0067923335414741045},
			{-0.0099062264853756, 0.0384375558818052, -0.005325769184482807},
			{-0.006792333541474106, -0.005325769184482805, 0.009996725363288106}
		},
		{
			{0.0041228131518677305, -0.009181018657860893, 0.0021720611215323756},
			{-0.009181018657860893, 0.07130144938128444, -0.04419769661644318},
			{0.0021720611215323795, -0.04419769661644318, 0.0512321631908165}
		},
		{
			{0.01473691255644981, 3.859096679320732E-4, 0.007067111008818558},
			{3.859096679320762E-4, 0.05986803602901119, -0.04071501269668729},
			{0.007067111008818565, -0.04071501269668729, 0.040049672370632616}
		},
		{
			{0.02565755405334584, -0.01691363841840293, 0.005534973440622726},
			{-0.01691363841840294, 0.0643019743548395, -0.03998871627946531},
			{0.0055349734406227365, -0.039988716279465326, 0.03903859595406032}
		},
		{
			{0.03849826676390429, -0.03709031977437009, 0.0101408473914612},
			{-0.03709031977437007, 0.05577397475411396, -0.013041804038931694},
			{0.010140847391461193, -0.013041804038931692, 0.008174380244867777}
		},
		{
			{0.022035353887725696, -0.00938037445984495, -0.00352034196223717},
			{-0.009380374459844949, 0.05320433779003698, -0.030904762799282302},
			{-0.0035203419622371708, -0.03090476279928231, 0.03575388283681651}
		},
		{
			{0.08395422866140935, -0.06197206389241883, 0.020395160142167707},
			{-0.06197206389241883, 0.10230321057277089, -0.05599467949834925},
			{0.020395160142167718, -0.05599467949834924, 0.0759097157794475}
		},
		{
			{0.020205126422094793, 0.0024483913977038224, -0.0056463856292883466},
			{0.0024483913977038202, 0.0143772469986532, 0.0029566224968039217},
			{-0.005646385629288345, 0.002956622496803923, 0.007033889662840293}
		},
		{
			{0.0162022495938293, -0.008087122479251457, -3.4735900432044373E-4},
			{-0.008087122479251467, 0.04946021300611984, -0.025556507585020916},
			{-3.4735900432044916E-4, -0.025556507585020913, 0.023451271491632508}
		},
		{
			{0.053760936297279495, -0.034026295518194485, -0.01384691839592004},
			{-0.0340262955181945, 0.07967759811516242, -0.03228004391567858},
			{-0.013846918395920015, -0.03228004391567861, 0.08619589002361103}
		},
		{
			{0.030656406377403116, -0.02003488663357521, 0.0128381288545733},
			{-0.020034886633575208, 0.07461299440489504, -0.0183094087876809},
			{0.012838128854573295, -0.01830940878768091, 0.009919615758919564}
		},
		{
			{0.061763803239559836, -0.06355927618900406, 0.006123458666865672},
			{-0.0635592761890041, 0.12712403665556202, -0.033939500996180795},
			{0.006123458666865676, -0.03393950099618079, 0.029584488934733904}
		},
		{
			{0.016202501431596687, -0.0010415157677092033, -0.013042027559927201},
			{-0.0010415157677092102, 0.026734976921464898, -0.013130436567542592},
			{-0.013042027559927198, -0.013130436567542602, 0.026946009015327104}
		},
		{
			{0.11014618595134285, -0.04882888367475016, -0.024561695154175216},
			{-0.04882888367475016, 0.07739635836331808, -0.017425260300453882},
			{-0.024561695154175237, -0.017425260300453875, 0.0334548761307743}
		},
		{
			{0.06590687633581187, 0.00664214859804586, -0.017341807004830616},
			{0.006642148598045867, 0.19283784792599704, -0.004102461130610866},
			{-0.017341807004830626, -0.004102461130610892, 0.02251133640561002}
		}
	};

	double barycentre[50][3] =
	{
		{70.725, 34.64375, 41.45},
		{222.9047619047619, 197.20238095238096, 21.107142857142858},
		{108.77914110429448, 102.28220858895706, 117.18098159509202},
		{53.386178861788615, 146.3089430894309, 154.5772357723577},
		{101.55531914893616, 166.87446808510637, 148.5255319148936},
		{127.308957952468, 85.54296160877514, 58.52468007312614},
		{147.81947261663285, 102.84381338742394, 98.17241379310344},
		{100.07485029940119, 170.4685628742515, 180.61377245508982},
		{138.5174825174825, 179.46853146853147, 136.65268065268066},
		{109.02879078694818, 154.61804222648752, 218.62188099808063},
		{150.26530612244898, 201.23673469387754, 214.86938775510205},
		{182.0875, 207.73333333333332, 169.42083333333332},
		{84.14567901234568, 83.72592592592592, 49.94320987654321},
		{62.90783410138249, 48.39170506912443, 75.6589861751152},
		{173.2168284789644, 118.72168284789645, 129.86084142394822},
		{100.38345864661655, 129.09774436090225, 173.203007518797},
		{197.04293381037567, 138.66368515205724, 152.42754919499106},
		{122.07359307359307, 159.36796536796535, 114.84415584415585},
		{212.05844155844156, 201.46753246753246, 106.58441558441558},
		{222.19021739130434, 96.54347826086956, 20.29891304347826},
		{201.52408477842005, 137.90751445086704, 115.82851637764932},
		{148.26970954356847, 151.59336099585062, 86.37759336099585},
		{137.80353634577602, 141.93909626719056, 192.16110019646365},
		{100.57293868921776, 200.14799154334037, 239.553911205074},
		{87.25515463917526, 79.52577319587628, 84.8298969072165},
		{113.80939947780679, 132.1514360313316, 84.9242819843342},
		{215.16504854368932, 121.74757281553399, 78.49514563106796},
		{76.7810650887574, 115.04733727810651, 103.01775147928994},
		{138.64255319148936, 121.15531914893617, 148.32340425531916},
		{88.83969465648855, 143.97964376590332, 128.0941475826972},
		{184.46307692307693, 155.64153846153846, 192.25538461538463},
		{39.21296296296296, 37.92901234567901, 45.68827160493827},
		{173.84940778341794, 120.20135363790186, 96.1590524534687},
		{170.03722504230117, 130.86463620981388, 167.917089678511},
		{171.17450980392158, 171.8921568627451, 113.06274509803922},
		{182.59281437125748, 163.0688622754491, 70.80838323353294},
		{9.185185185185185, 161.2469135802469, 173.34567901234567},
		{22.647540983606557, 117.51639344262296, 92.43442622950819},
		{71.18518518518519, 159.12250712250713, 188.85754985754986},
		{155.09302325581396, 125.62579281183932, 60.881606765327696},
		{118.94168466522679, 193.72138228941685, 202.52483801295895},
		{185.066091954023, 189.2528735632184, 225.22701149425288},
		{196.37209302325581, 148.41860465116278, 10.937984496124031},
		{85.47814910025707, 182.32647814910027, 215.95629820051414},
		{132.73858921161826, 183.45435684647302, 243.21784232365144},
		{136.0614525139665, 100.10614525139665, 19.223463687150836},
		{151.10291262135922, 164.80582524271844, 213.06990291262136},
		{130.64358974358976, 191.71794871794873, 169.9128205128205},
		{217.03317535545023, 180.85781990521326, 160.20853080568722},
		{25.202247191011235, 20.808988764044944, 24.65917602996255}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<50;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<50;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance51clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026444289985606606, -0.0194237944802535, -0.0019678556574967776},
		{-0.019423794480253512, 0.041758873888646006, -0.01347533846078782},
		{-0.001967855657496777, -0.013475338460787807, 0.01542871007096231}
	};

	double matrix[51][3][3] =
	{
		{
			{0.04736912365693752, -0.016313089175341296, -0.008802412623243236},
			{-0.01631308917534128, 0.05470852945937482, 0.00481730762923999},
			{-0.008802412623243225, 0.004817307629239993, 0.0163406598691737}
		},
		{
			{0.05089959874116482, -0.02696891723778281, -0.0046548509195836535},
			{-0.02696891723778281, 0.041807945287404114, -0.0012167484326347624},
			{-0.004654850919583653, -0.0012167484326347624, 0.013050641254134104}
		},
		{
			{0.06608332494287472, -0.03301409405130091, -0.002657125718468758},
			{-0.033014094051300916, 0.05666677415792697, -0.023550806595722586},
			{-0.0026571257184687643, -0.023550806595722586, 0.027275092273658298}
		},
		{
			{0.0036403792612601164, -0.008136399453813722, 0.0028996429454803308},
			{-0.008136399453813737, 0.07130144023683231, -0.04419769718498541},
			{0.0028996429454803407, -0.04419769718498542, 0.051232166017964986}
		},
		{
			{0.0268315960403118, -0.012690990712914308, -0.005307083650266172},
			{-0.012690990712914296, 0.038755884728803015, -0.01664584186448619},
			{-0.005307083650266168, -0.016645841864486196, 0.02900553228966709}
		},
		{
			{0.09898907204197581, -0.015960860300780498, 2.767164428301253E-4},
			{-0.015960860300780484, 0.06618945570402278, 0.009565791420332603},
			{2.767164428301252E-4, 0.009565791420332608, 0.018350960628899994}
		},
		{
			{0.02584411481168203, -0.008509995830367753, -0.007986607778245988},
			{-0.008509995830367751, 0.03933477734383187, -0.0015706112473321404},
			{-0.007986607778245988, -0.0015706112473321448, 0.006888300600396748}
		},
		{
			{0.011412027955442602, -0.0026716193427754314, 0.004441547873586316},
			{-0.0026716193427754322, 0.06190082036054728, -0.04095211288334291},
			{0.004441547873586311, -0.04095211288334291, 0.04020221532634782}
		},
		{
			{0.06011590514259509, -0.05987804545912068, 0.004783187678686283},
			{-0.05987804545912069, 0.122400166558185, -0.02684149417433581},
			{0.004783187678686283, -0.026841494174335814, 0.023334702249264608}
		},
		{
			{0.06561762315438745, -0.03677695185763521, -0.005314142607289599},
			{-0.036776951857635194, 0.08815960438893479, -0.0205634051525962},
			{-0.0053141426072896, -0.0205634051525962, 0.027423550786635595}
		},
		{
			{0.034073497270736844, -0.020613523530335118, 0.0012834111675338643},
			{-0.020613523530335104, 0.06108000864355051, -0.025252718310691},
			{0.0012834111675338487, -0.025252718310691005, 0.029467076359795105}
		},
		{
			{0.05910376226701223, -0.014323029133296122, 0.009591420879184914},
			{-0.014323029133296118, 0.06374627964414588, 5.99175644676303E-4},
			{0.009591420879184909, 5.991756446762952E-4, 0.002403085580193163}
		},
		{
			{0.044376387786659005, 0.010136129720728805, -0.007393833468799825},
			{0.010136129720728795, 0.024479547571810194, -6.047867412658413E-4},
			{-0.007393833468799822, -6.04786741265845E-4, 0.003064532817620512}
		},
		{
			{0.047425468408109295, -0.018129055601871318, -0.0031584930610491077},
			{-0.018129055601871332, 0.05615716830319165, -0.0019088172999816822},
			{-0.003158493061049109, -0.0019088172999816866, 0.013918068272519698}
		},
		{
			{0.024368476783852417, -0.008674314624087142, -0.008329803693926396},
			{-0.008674314624087149, 0.021053129268886715, -0.003041136572481465},
			{-0.008329803693926404, -0.0030411365724814605, 0.014422227284609002}
		},
		{
			{0.036227282909200825, -0.01502213357274312, -0.01010949078118831},
			{-0.015022133572743113, 0.046144418214359294, -0.016207493955688778},
			{-0.010109490781188306, -0.016207493955688775, 0.03567823183712071}
		},
		{
			{0.06025611489046839, -0.007251126538245382, -0.021391534022561783},
			{-0.007251126538245377, 0.043265161267636486, -0.021932853274655696},
			{-0.021391534022561786, -0.0219328532746557, 0.03562245163257449}
		},
		{
			{0.08385152103720118, -0.06990497083077078, -0.003301890448111695},
			{-0.06990497083077071, 0.11288600255847304, -0.025388095897830712},
			{-0.0033018904481117027, -0.02538809589783072, 0.0272651457082789}
		},
		{
			{0.04491525810786629, -0.03432542452174309, -0.0010068475398334492},
			{-0.03432542452174309, 0.07906902801293048, -0.015692364393709794},
			{-0.0010068475398334492, -0.015692364393709798, 0.015242773664215292}
		},
		{
			{0.10650021590908199, -0.0660797107456978, -1.022738496073601E-4},
			{-0.06607971074569777, 0.31023892086665966, -0.040718541384316444},
			{-1.0227384960735317E-4, -0.04071854138431645, 0.02036737917432279}
		},
		{
			{0.04839823936191173, -0.020753245747148423, -0.020002209957368722},
			{-0.020753245747148413, 0.05237910423922498, -0.0324297330616128},
			{-0.02000220995736872, -0.03242973306161279, 0.0605364749370756}
		},
		{
			{0.044365218993683314, -0.03157732307828979, -0.006487802916451013},
			{-0.03157732307828978, 0.07320406874376371, -0.020613495776551298},
			{-0.006487802916451013, -0.02061349577655129, 0.04032103928288781}
		},
		{
			{0.03408052828794911, -0.009834574245251752, -0.002173132367241048},
			{-0.009834574245251733, 0.17034956573134988, -0.027939196550636237},
			{-0.0021731323672410496, -0.02793919655063622, 0.051367985381215016}
		},
		{
			{0.013533988021176993, 0.003949715936117227, -0.014876298316233785},
			{0.003949715936117225, 0.013811756266834098, -0.006601468708180025},
			{-0.014876298316233785, -0.00660146870818003, 0.02159085742515109}
		},
		{
			{0.09038834411283744, 0.012988801449297318, -0.04639744146934152},
			{0.01298880144929732, 0.08044039256369515, 0.019194956388494788},
			{-0.04639744146934152, 0.019194956388494777, 0.05543740688626672}
		},
		{
			{0.05215047727284469, -0.026143740074865612, -0.0071395822102134215},
			{-0.026143740074865605, 0.044241025899137414, 9.935848204266351E-6},
			{-0.007139582210213423, 9.935848204270471E-6, 0.0084818535587896}
		},
		{
			{0.04840449029049033, -0.0267785975921348, -0.0157686442766385},
			{-0.026778597592134787, 0.07926302877314699, -0.04900399973460291},
			{-0.01576864427663849, -0.04900399973460293, 0.12578292398590998}
		},
		{
			{0.012378481634847895, -0.0050063324769953855, -0.00876476900354224},
			{-0.005006332476995384, 0.027865273151700686, -0.005934341784612952},
			{-0.008764769003542242, -0.005934341784612954, 0.01863817409359138}
		},
		{
			{0.015275078702955915, 0.005467730893860077, -0.009863620433819756},
			{0.00546773089386007, 0.0488229437384553, -0.02063789253893921},
			{-0.009863620433819744, -0.020637892538939207, 0.026490367799799595}
		},
		{
			{0.03971696982274162, -0.017802070185315644, -8.958249661197605E-4},
			{-0.01780207018531566, 0.07491292729481251, -0.003557827475295938},
			{-8.958249661197648E-4, -0.0035578274752959406, 0.022660508701646806}
		},
		{
			{0.014729757570536284, -0.009959002819922643, 0.0026053407129811904},
			{-0.009959002819922647, 0.05333285136829098, -0.027967723172995635},
			{0.0026053407129811904, -0.027967723172995635, 0.029191858910875713}
		},
		{
			{0.01871029052536603, -0.009706432580585796, 0.001286841082055186},
			{-0.0097064325805858, 0.06724663260310854, -0.03717721503685992},
			{0.0012868410820551885, -0.03717721503685992, 0.03927383097057129}
		},
		{
			{0.014798964266159027, -0.021685742991257424, 0.010513199277808624},
			{-0.021685742991257424, 0.07847443673070656, -0.05857633196114724},
			{0.010513199277808631, -0.05857633196114724, 0.06279340569715047}
		},
		{
			{0.011978003963243087, 0.0015473515943794404, -0.008622856525778214},
			{0.001547351594379449, 0.03469803357525494, -0.012157041739172834},
			{-0.00862285652577822, -0.012157041739172833, 0.02197225847823892}
		},
		{
			{0.043449243161674415, -0.017786128534328715, -0.002897260106298788},
			{-0.01778612853432873, 0.06897099033324088, -0.029762462494986684},
			{-0.002897260106298793, -0.029762462494986694, 0.03630717507072297}
		},
		{
			{0.01961017145625532, -0.013691164962376321, -0.0011774032087971506},
			{-0.013691164962376328, 0.055679143679293136, -0.03400607473544392},
			{-0.0011774032087971524, -0.034006074735443925, 0.031683171624340624}
		},
		{
			{0.03293230101595761, -0.007480061197993839, -0.012689724913012096},
			{-0.007480061197993835, 0.025396294254775482, -0.0051134839073640696},
			{-0.012689724913012096, -0.005113483907364073, 0.0211241887368532}
		},
		{
			{0.07743597351018383, -0.0015742795571484529, -0.0029011982208711476},
			{-0.0015742795571484624, 0.0522510913323641, -0.01548725362371482},
			{-0.0029011982208711727, -0.015487253623714801, 0.00975779478263627}
		},
		{
			{0.019146363685264685, 0.0021118274406560066, -0.0064624997430087015},
			{0.002111827440656007, 0.014665959462578594, 0.003688971219986241},
			{-0.0064624997430087015, 0.0036889712199862416, 0.00881438431760665}
		},
		{
			{0.025277581366807123, -0.017478206238825334, 0.004006371938704256},
			{-0.017478206238825348, 0.06883543328778476, -0.04324005480305199},
			{0.004006371938704253, -0.043240054803052, 0.040414109501272465}
		},
		{
			{0.08459643285506746, -0.06372705192369499, 0.013668970383646093},
			{-0.06372705192369499, 0.12682104500243602, -0.03738695181883119},
			{0.013668970383646095, -0.03738695181883119, 0.055300828049780676}
		},
		{
			{0.05180806495006269, -0.042762820514083935, -0.00512715395037759},
			{-0.042762820514083935, 0.10583754579256516, -0.011289043317671905},
			{-0.005127153950377585, -0.0112890433176719, 0.008688606371366822}
		},
		{
			{0.018277780002386595, 0.0010002928548952326, -0.010434276016702394},
			{0.0010002928548952308, 0.028870332896446277, -0.011902885143403395},
			{-0.010434276016702396, -0.011902885143403392, 0.019780291954239193}
		},
		{
			{0.15575553081347904, -0.15339874617348204, -0.0277656381789426},
			{-0.15339874617348195, 0.17116323691117502, 0.0132522863047332},
			{-0.02776563817894259, 0.013252286304733197, 0.02806619366021881}
		},
		{
			{0.0142960655701664, -0.0021608688828358407, -0.013366193874317995},
			{-0.0021608688828358416, 0.02929111152206939, -0.0128561181203251},
			{-0.013366193874317993, -0.012856118120325104, 0.027655167231354683}
		},
		{
			{0.02901084808013332, -0.028378153461174623, 0.009004030114140037},
			{-0.028378153461174643, 0.05574500109509554, -0.015369497857712414},
			{0.009004030114140043, -0.01536949785771241, 0.011261420581722106}
		},
		{
			{0.056620191857458424, -0.03446590403339368, 0.0020934027552675406},
			{-0.03446590403339366, 0.0806213665099366, -0.036721490609560065},
			{0.0020934027552675454, -0.03672149060956005, 0.038034224242180975}
		},
		{
			{0.029718024730247303, -0.01877596770520352, -0.0043307110147655535},
			{-0.018775967705203542, 0.03567356905343185, -6.212208507306088E-4},
			{-0.0043307110147655595, -6.212208507306101E-4, 0.0123644370766843}
		},
		{
			{0.054714700611563916, -0.028350482830046198, -0.006487350821949615},
			{-0.02835048283004621, 0.06327379495467189, -0.02746550722566999},
			{-0.0064873508219496084, -0.02746550722566999, 0.036812031684311505}
		},
		{
			{0.04971084922402957, -0.009099984229508092, -0.012915092938359407},
			{-0.0090999842295081, 0.04053879147610241, -0.00632571172661562},
			{-0.012915092938359409, -0.00632571172661562, 0.020658148509349113}
		},
		{
			{0.11895605688878395, -0.05602958912240665, -0.029294870604012282},
			{-0.056029589122406666, 0.07517277800449344, -0.007635812367369925},
			{-0.02929487060401227, -0.007635812367369927, 0.027235870702876988}
		}
	};

	double barycentre[51][3] =
	{
		{77.0632530120482, 80.44578313253012, 53.76204819277108},
		{222.86010362694302, 96.98445595854922, 22.647668393782382},
		{206.95737704918034, 125.74754098360656, 85.21311475409836},
		{9.310975609756097, 161.07926829268294, 173.2012195121951},
		{103.49586776859505, 175.11735537190083, 184.35867768595043},
		{83.74774774774775, 76.11711711711712, 86.95045045045045},
		{181.54861111111111, 164.76736111111111, 67.81597222222223},
		{24.2015503875969, 117.06976744186046, 91.59689922480621},
		{150.69590643274853, 165.8830409356725, 213.92007797270955},
		{108.32040816326531, 156.38571428571427, 220.9612244897959},
		{147.46410256410257, 104.45128205128205, 110.39487179487179},
		{143.16463414634146, 105.17073170731707, 19.835365853658537},
		{224.23076923076923, 198.52307692307693, 11.63076923076923},
		{112.27937336814621, 84.75718015665797, 45.50130548302872},
		{159.01626016260164, 187.5528455284553, 138.5},
		{173.00371747211895, 121.63011152416357, 145.9442379182156},
		{136.858407079646, 122.57300884955752, 149.9867256637168},
		{100.51428571428572, 128.90649350649352, 175.08051948051948},
		{177.33254716981133, 167.95754716981133, 108.81367924528301},
		{104.56, 100.24923076923076, 116.36},
		{184.79963898916967, 160.51805054151623, 198.82671480144404},
		{164.286836935167, 114.65029469548134, 86.43025540275049},
		{28.8910411622276, 25.1864406779661, 29.573849878934624},
		{123.02475247524752, 176.1361386138614, 142.6089108910891},
		{55.16923076923077, 39.573626373626375, 53.753846153846155},
		{198.16260162601625, 211.10569105691056, 116.70731707317073},
		{132.88702928870293, 184.66108786610877, 243.03138075313808},
		{141.4065934065934, 166.20604395604394, 114.13461538461539},
		{83.23100303951368, 136.25531914893617, 124.59270516717325},
		{135.03255813953487, 88.65116279069767, 68.09767441860465},
		{86.40664961636828, 183.383631713555, 216.5473145780051},
		{126.42505133470226, 197.2381930184805, 204.83367556468173},
		{100.60175054704595, 200.71772428884026, 239.6652078774617},
		{93.17193675889328, 162.5513833992095, 156.8695652173913},
		{177.69204152249134, 121.72837370242215, 113.09342560553634},
		{52.02575107296137, 145.46351931330472, 155.3390557939914},
		{109.625, 129.61989795918367, 85.08418367346938},
		{227.22222222222223, 180.64444444444445, 87.36666666666666},
		{197.9375, 148.125, 11.0078125},
		{72.84782608695652, 159.8233695652174, 190.0108695652174},
		{177.6027777777778, 194.92777777777778, 227.7277777777778},
		{133.24425887265136, 143.60542797494782, 195.0},
		{110.04460093896714, 156.12910798122067, 118.72065727699531},
		{190.2460732984293, 208.434554973822, 181.4502617801047},
		{133.68767908309457, 193.9541547277937, 170.9942693409742},
		{154.2025641025641, 131.8025641025641, 60.02051282051282},
		{201.95793499043978, 137.8585086042065, 126.94646271510516},
		{145.8466819221968, 150.78718535469108, 86.24256292906179},
		{195.91489361702128, 141.89361702127658, 164.2359767891683},
		{165.71676300578034, 136.4894026974952, 177.364161849711},
		{217.36216216216215, 180.3945945945946, 154.6216216216216}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<51;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<51;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance52clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027649324363095196, -0.02028727754478779, -0.0017544829083860499},
		{-0.02028727754478779, 0.04320749636696657, -0.0135353688780922},
		{-0.001754482908386047, -0.013535368878092195, 0.01505266213679141}
	};

	double matrix[52][3][3] =
	{
		{
			{0.05058788831263447, -0.018480962993632877, 0.0013595221077412978},
			{-0.018480962993632877, 0.04028885520555051, -0.00754714577799297},
			{0.0013595221077412991, -0.007547145777992965, 0.008008808165576753}
		},
		{
			{0.02369573819433701, -0.017807254810340397, -5.381440430816831E-4},
			{-0.01780725481034039, 0.035939057513200166, -0.0075732003207284754},
			{-5.381440430816779E-4, -0.007573200320728479, 0.021192281718567}
		},
		{
			{0.0359944025290086, -0.018942112700524816, 0.001840452762106452},
			{-0.018942112700524805, 0.06431008106234513, -0.027662591052957625},
			{0.0018404527621064528, -0.027662591052957625, 0.030090784669881417}
		},
		{
			{0.049870217901278865, -0.013424519302558226, -0.005225093208365526},
			{-0.013424519302558226, 0.060974405663903705, -0.0090156031353651},
			{-0.005225093208365526, -0.009015603135365105, 0.01991062839780841}
		},
		{
			{0.03230623924928067, -0.013360746794259689, -0.00597039201366764},
			{-0.013360746794259696, 0.04720384160646842, -0.008541359517971183},
			{-0.005970392013667637, -0.008541359517971185, 0.015220901177279401}
		},
		{
			{0.018656202814683893, -0.01126276398635619, 3.871588950773593E-4},
			{-0.011262763986356178, 0.0438436697654908, -0.0369943288508673},
			{3.871588950773425E-4, -0.036994328850867314, 0.04228087691865242}
		},
		{
			{0.0588991701644604, 0.00427525070252022, -0.0025294978484064422},
			{0.004275250702520231, 0.06030474123413241, 0.007702769885859308},
			{-0.002529497848406441, 0.007702769885859313, 0.010771154955967402}
		},
		{
			{0.06641104608471946, -0.048251887372390195, -0.009282615351868327},
			{-0.04825188737239018, 0.11121369065218009, -0.015109665767570207},
			{-0.00928261535186832, -0.015109665767570203, 0.012767833839160109}
		},
		{
			{0.03290693956769729, -0.024230055969763478, 0.0027693683586475924},
			{-0.024230055969763478, 0.050317240693929885, -0.012691437597456695},
			{0.002769368358647591, -0.012691437597456693, 0.012989163743196596}
		},
		{
			{0.03771825933760895, -0.012352673743974, -0.019393301613143118},
			{-0.012352673743974004, 0.048180245251128795, -0.019753784198731396},
			{-0.019393301613143114, -0.0197537841987314, 0.039438944616546595}
		},
		{
			{0.023469848697229536, -0.018213239363431034, -3.423020867494228E-4},
			{-0.018213239363431038, 0.04683496259557775, -0.011702998631942012},
			{-3.4230208674942107E-4, -0.011702998631942012, 0.023801390698757696}
		},
		{
			{0.004490799617880778, -0.009636452348416376, 2.1924964498033685E-4},
			{-0.009636452348416352, 0.06946801492387256, -0.04196468125956098},
			{2.1924964498032298E-4, -0.041964681259560994, 0.052716986837082196}
		},
		{
			{0.10255913819923007, -0.04812447827004136, -0.02297135213842878},
			{-0.048124478270041404, 0.07640447928637817, -0.027402410154664415},
			{-0.0229713521384288, -0.02740241015466442, 0.07371972572462329}
		},
		{
			{0.05185907490102555, -0.054014214444820734, 0.004664872219342624},
			{-0.054014214444820755, 0.1314067963467471, -0.042380284429564125},
			{0.0046648722193426365, -0.04238028442956411, 0.033314931847462696}
		},
		{
			{0.048753681150763284, -0.014770622591606698, -0.014961549768574712},
			{-0.014770622591606698, 0.0603213134833418, -0.02966961323055099},
			{-0.014961549768574715, -0.029669613230550992, 0.04297328993572481}
		},
		{
			{0.07268781688413181, -0.011551082569284488, -0.041831724065353224},
			{-0.011551082569284523, 0.10737195020237503, -0.055416506296211865},
			{-0.04183172406535322, -0.05541650629621188, 0.128004389056499}
		},
		{
			{0.04238039644787117, -0.021234127776635556, -0.0037745012771748937},
			{-0.021234127776635567, 0.07700406828684352, -0.007127273828343989},
			{-0.003774501277174897, -0.007127273828343985, 0.02525927606261341}
		},
		{
			{0.01619168177503709, -0.010665355821643577, 3.5576225648117E-4},
			{-0.010665355821643572, 0.05451136020752531, -0.03011482451565357},
			{3.557622564811717E-4, -0.03011482451565358, 0.034395941252181615}
		},
		{
			{0.09367524356174275, -0.06142599218787129, -0.020798570704238305},
			{-0.0614259921878713, 0.06812268669242111, 0.010215996644146083},
			{-0.020798570704238302, 0.010215996644146078, 0.021088683668356804}
		},
		{
			{0.11221270790227304, -0.04813359534584553, -0.024114091561140607},
			{-0.04813359534584549, 0.0692661009747438, -0.012894635301376611},
			{-0.024114091561140586, -0.012894635301376616, 0.031352782928278505}
		},
		{
			{0.06440602010428872, -0.03250672902818166, -0.009073194658774996},
			{-0.03250672902818167, 0.06470662968616268, -0.016327287983132602},
			{-0.009073194658775005, -0.016327287983132602, 0.036831698111891034}
		},
		{
			{0.04235241400549623, -0.012347836410666797, -0.0137128382099372},
			{-0.012347836410666807, 0.0758613808940126, -0.007564567167073606},
			{-0.013712838209937198, -0.007564567167073606, 0.013803682716644207}
		},
		{
			{0.0489429784667033, -0.021837153938151405, -0.02044950509109461},
			{-0.021837153938151405, 0.0503857203795324, -0.025589821769100407},
			{-0.020449505091094604, -0.025589821769100414, 0.05293051207271922}
		},
		{
			{0.04570219594796071, -0.03635534864244273, -0.006913111237571573},
			{-0.03635534864244271, 0.0763100785583924, -0.022765735577690724},
			{-0.006913111237571563, -0.02276573557769071, 0.04123587450942529}
		},
		{
			{0.05021956908488369, -0.0029616158677076574, -0.005183659796437805},
			{-0.002961615867707661, 0.23928552734946815, -0.0066812805518149145},
			{-0.005183659796437811, -0.006681280551814882, 0.013228696594687804}
		},
		{
			{0.0425842369912685, -0.021981092627783715, -8.515290325192795E-4},
			{-0.0219810926277837, 0.0529527041279185, -0.022185288575840293},
			{-8.515290325192821E-4, -0.022185288575840303, 0.03136697788110719}
		},
		{
			{0.10937224115296715, -0.010273819142954449, -0.00734829140319309},
			{-0.010273819142954438, 0.08829383066547081, 0.007396501200658732},
			{-0.00734829140319309, 0.00739650120065874, 0.01631860799340521}
		},
		{
			{0.06472584331169168, -0.017448906343124515, -0.016024415135178917},
			{-0.017448906343124515, 0.03800077492750652, -0.010874277157112998},
			{-0.016024415135178913, -0.010874277157112996, 0.023557479478840418}
		},
		{
			{0.01583537493730999, 0.0016403466676212183, -0.015413622966523493},
			{0.0016403466676212205, 0.013545502459621515, -0.004679906188062478},
			{-0.015413622966523497, -0.004679906188062479, 0.02082156436148091}
		},
		{
			{0.07428651680462577, -0.035229561756476, -0.0207101157717421},
			{-0.03522956175647599, 0.03870344727076198, 0.0035771241823916236},
			{-0.020710115771742088, 0.00357712418239162, 0.026780935726608092}
		},
		{
			{0.0416412643420221, 0.008692308713209243, -0.007993293895262276},
			{0.008692308713209243, 0.03435496392835473, -0.0010284496234467927},
			{-0.007993293895262278, -0.0010284496234467886, 0.0031361349061760093}
		},
		{
			{0.11178922270418613, -0.05824619949618599, -0.01768160025804693},
			{-0.058246199496186056, 0.29907690656268215, -0.06291877724477103},
			{-0.017681600258046954, -0.06291877724477102, 0.025497421341135036}
		},
		{
			{0.025541199276273324, -0.008286609147256947, -0.012047455239997309},
			{-0.00828660914725695, 0.031359924567523505, -0.0111604086792166},
			{-0.012047455239997316, -0.011160408679216596, 0.019889827715199804}
		},
		{
			{0.018003729132194345, -0.018388374010296436, 0.017705547597315144},
			{-0.01838837401029644, 0.028698462908163826, -0.01109241690982311},
			{0.017705547597315137, -0.011092416909823096, 0.02234107631407895}
		},
		{
			{0.05487393485483365, -0.032411069122055214, 0.001809361245717581},
			{-0.032411069122055214, 0.08227718409124209, -0.03975442129186639},
			{0.0018093612457175806, -0.03975442129186638, 0.039505206028270415}
		},
		{
			{0.015588319434159588, 5.720480871572661E-4, -0.01290785501543261},
			{5.720480871572679E-4, 0.01932354339539851, -0.0062254869697481036},
			{-0.012907855015432615, -0.006225486969748105, 0.017256203726425126}
		},
		{
			{0.020891292354537107, 0.002631566268729374, -0.005727518659901032},
			{0.0026315662687293744, 0.013951983380920305, 0.0026865222445746446},
			{-0.005727518659901031, 0.0026865222445746463, 0.006884385359775754}
		},
		{
			{0.04398374876901421, -0.026664701391920603, -0.006201237347950177},
			{-0.0266647013919206, 0.08553646846609847, -0.04768043227026292},
			{-0.006201237347950174, -0.04768043227026293, 0.10663858992655698}
		},
		{
			{0.07849070469540877, -0.05966616185221745, -0.011056770275705003},
			{-0.05966616185221748, 0.12153042867668606, -0.028758303033199206},
			{-0.011056770275705013, -0.028758303033199185, 0.027658392380682274}
		},
		{
			{0.027977294828320384, -0.006110960006355149, -0.006795492506333038},
			{-0.006110960006355149, 0.03472486796430352, -0.001500199746052624},
			{-0.0067954925063330365, -0.0015001997460526236, 0.014383401007502308}
		},
		{
			{0.05309112282421387, -0.030951190560334633, 0.001384983353757052},
			{-0.03095119056033463, 0.07224875516021631, -0.02803401658119979},
			{0.0013849833537570512, -0.028034016581199785, 0.03356177322344878}
		},
		{
			{0.07270772379117606, -0.027000191442106712, -0.010030417149381004},
			{-0.027000191442106716, 0.027597500140687882, -0.00860817962402834},
			{-0.010030417149381007, -0.00860817962402834, 0.0209071255805908}
		},
		{
			{0.013477714661899102, -0.002722200410307069, -0.00869030723353106},
			{-0.0027222004103070706, 0.026360611930546292, -0.010693620161353602},
			{-0.00869030723353106, -0.010693620161353603, 0.022242685834736906}
		},
		{
			{0.014981141499593804, -0.021006998440415686, 0.008181777579608404},
			{-0.021006998440415686, 0.07062310184154734, -0.04823421984143967},
			{0.008181777579608416, -0.048234219841439684, 0.0496761989368405}
		},
		{
			{0.08165858692908448, -0.026051500423883735, -0.06246301535551211},
			{-0.026051500423883767, 0.07668533219531312, 0.026241915505825893},
			{-0.06246301535551215, 0.026241915505825907, 0.05827210436685887}
		},
		{
			{0.005855742993689875, -0.006148652789347588, 0.0018064832548708794},
			{-0.00614865278934758, 0.06516989783592712, -0.04984377373596071},
			{0.0018064832548708746, -0.049843773735960696, 0.055943510984074164}
		},
		{
			{0.06579235961739936, -0.05169398873698789, 0.004084184384480565},
			{-0.051693988736987856, 0.16244319645500793, -0.055851188656569205},
			{0.004084184384480549, -0.055851188656569205, 0.06894675541730139}
		},
		{
			{0.023203932707022507, -0.009541318771998666, -0.006564721609164472},
			{-0.00954131877199867, 0.0361011242365557, -0.012306648410710299},
			{-0.006564721609164463, -0.012306648410710306, 0.02442052684946571}
		},
		{
			{0.020090900813667007, -0.013617516538585018, 0.002382745579260306},
			{-0.013617516538585013, 0.04787942894192776, -0.029474068549732307},
			{0.0023827455792603085, -0.029474068549732307, 0.03037275795663423}
		},
		{
			{0.010348048547213282, 0.012858475873732988, -0.017955915288799074},
			{0.012858475873732999, 0.029686566392029733, -0.013817824380166344},
			{-0.017955915288799074, -0.013817824380166327, 0.052940577764863425}
		},
		{
			{0.03162523334366818, -0.028475172670554497, 0.0041542867105483295},
			{-0.028475172670554497, 0.06341773196912454, -0.003881411010536495},
			{0.0041542867105483295, -0.003881411010536495, 0.0024070714539430015}
		},
		{
			{0.048276068751801945, -0.021683033819725247, -0.011682763076552891},
			{-0.021683033819725264, 0.055080499000891084, 0.005799660102105495},
			{-0.011682763076552891, 0.005799660102105493, 0.017192678496682698}
		}
	};

	double barycentre[52][3] =
	{
		{213.78571428571428, 201.60714285714286, 101.43571428571428},
		{145.81927710843374, 157.10441767068272, 97.35742971887551},
		{147.7116704805492, 104.69107551487414, 106.59725400457666},
		{116.5814606741573, 82.70224719101124, 43.46348314606742},
		{170.69375, 176.50208333333333, 119.28125},
		{59.59016393442623, 156.3344262295082, 173.60983606557377},
		{105.06291390728477, 97.26821192052981, 80.10596026490066},
		{118.71757322175732, 142.38493723849373, 194.97280334728035},
		{160.21052631578948, 141.32456140350877, 61.98830409356725},
		{168.89173228346456, 121.64370078740157, 151.75787401574803},
		{134.8306010928962, 130.77868852459017, 74.89890710382514},
		{8.335570469798657, 162.20805369127515, 174.70469798657717},
		{191.08152173913044, 198.69021739130434, 228.54347826086956},
		{147.5792563600783, 161.5283757338552, 211.85714285714286},
		{189.9132075471698, 142.96981132075473, 173.82075471698113},
		{38.383116883116884, 36.08116883116883, 43.746753246753244},
		{140.51413881748073, 90.77634961439588, 66.90488431876607},
		{120.77699115044248, 193.7787610619469, 198.72389380530973},
		{186.9144144144144, 209.3063063063063, 173.04504504504504},
		{218.19, 180.275, 157.525},
		{109.53243847874721, 159.60402684563758, 225.0201342281879},
		{157.23260869565217, 138.35652173913044, 182.98260869565217},
		{183.51287128712872, 162.97425742574256, 202.13267326732674},
		{172.3388888888889, 118.72777777777777, 89.13148148148149},
		{27.471910112359552, 19.98876404494382, 23.45318352059925},
		{176.609756097561, 121.35540069686411, 120.04006968641114},
		{80.1204481792717, 73.30532212885154, 88.19887955182072},
		{135.39816933638443, 122.75972540045767, 149.63844393592677},
		{135.9188596491228, 190.94956140350877, 162.25},
		{223.30714285714285, 98.69285714285714, 11.571428571428571},
		{222.8684210526316, 197.96052631578948, 17.407894736842106},
		{101.77966101694915, 102.35932203389831, 120.38305084745762},
		{101.9070351758794, 138.99497487437185, 100.43467336683418},
		{25.096774193548388, 94.80645161290323, 55.87096774193548},
		{198.63829787234042, 139.24564796905221, 141.2359767891683},
		{124.55362776025237, 169.32965299684543, 129.28864353312304},
		{197.64566929133858, 150.20472440944883, 12.590551181102363},
		{131.94247787610618, 185.9137168141593, 243.51769911504425},
		{94.52631578947368, 128.43653250773994, 168.80185758513932},
		{183.61846153846153, 165.74769230769232, 75.77846153846154},
		{204.6159090909091, 135.19772727272726, 106.05},
		{219.6206896551724, 108.18620689655172, 60.84137931034483},
		{89.43610547667343, 150.10344827586206, 134.74847870182555},
		{97.99649122807017, 198.80701754385964, 236.1298245614035},
		{62.42809364548495, 40.80936454849498, 57.90969899665552},
		{39.792307692307695, 134.72307692307692, 138.53076923076924},
		{157.1857585139319, 192.58204334365325, 222.35913312693498},
		{99.93333333333334, 169.8517006802721, 171.8639455782313},
		{84.27289719626168, 172.34205607476636, 204.17383177570093},
		{26.211764705882352, 118.52941176470588, 89.10588235294118},
		{145.33333333333334, 109.35087719298245, 21.70175438596491},
		{79.39067055393586, 80.68221574344024, 53.19533527696793}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<52;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<52;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance53clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02688810656229379, -0.01958076946805479, -0.002190763430602579},
		{-0.01958076946805478, 0.04255403316233152, -0.013550108563090286},
		{-0.0021907634306025815, -0.013550108563090288, 0.01534828699551231}
	};

	double matrix[53][3][3] =
	{
		{
			{0.022158308162114632, -0.011211810444741526, -0.00584052230284759},
			{-0.011211810444741527, 0.03408392652710652, -0.0018818622630820793},
			{-0.005840522302847592, -0.0018818622630820776, 0.017655046284822895}
		},
		{
			{0.05537177376494143, -0.012232859996816623, -0.009672671883325637},
			{-0.012232859996816614, 0.053878167795136114, 0.0040744828566787565},
			{-0.009672671883325643, 0.004074482856678751, 0.016780170605240105}
		},
		{
			{0.04398992912487473, -0.04129092054204622, 0.0012311689113339765},
			{-0.041290920542046194, 0.06887380375115544, -0.019027044467362194},
			{0.0012311689113339696, -0.0190270444673622, 0.029876543085105213}
		},
		{
			{0.04550888208235668, -0.00793913886887439, -0.012549155170774859},
			{-0.007939138868874387, 0.06275252696226577, -0.007158326664174306},
			{-0.012549155170774859, -0.007158326664174309, 0.014813838755764992}
		},
		{
			{0.04080289241193974, -0.01898852828674368, 6.972255343966689E-4},
			{-0.0189885282867437, 0.05362996059293071, -0.021115344803657805},
			{6.972255343966746E-4, -0.0211153448036578, 0.027755230889949904}
		},
		{
			{0.05155026149781344, -0.021914958102462998, -0.010771593326819097},
			{-0.021914958102463005, 0.055878104112501596, -0.027122549798417987},
			{-0.010771593326819106, -0.027122549798418, 0.04045076141063649}
		},
		{
			{0.017294599429940213, -0.01117905235274612, 0.002103215934023242},
			{-0.011179052352746115, 0.045156612722517794, -0.038799597947982406},
			{0.00210321593402324, -0.03879959794798239, 0.03995820256508689}
		},
		{
			{0.05185990915044055, -0.023493321449197996, 0.00266073135538108},
			{-0.023493321449198, 0.048132854384736, -0.006874507928523876},
			{0.00266073135538108, -0.006874507928523878, 0.00831777379520112}
		},
		{
			{0.03393469348396174, -0.003564961001293352, -0.0012093334944528911},
			{-0.00356496100129335, 0.03418667296482581, -0.0015698090859883585},
			{-0.0012093334944528913, -0.0015698090859883572, 0.010221022971851998}
		},
		{
			{0.06622943982493598, -0.05079686380299087, -0.006887297425521121},
			{-0.05079686380299091, 0.09895780773747648, -0.010626775555580616},
			{-0.0068872974255211215, -0.010626775555580618, 0.011565057367301101}
		},
		{
			{0.016036737260012417, -0.0053558401893231055, -0.013294450917926016},
			{-0.005355840189323106, 0.028151814714189705, -0.012712135464894386},
			{-0.013294450917926023, -0.01271213546489439, 0.028823277344652308}
		},
		{
			{0.04187420816984793, -0.011287688306628296, -0.015412175921311505},
			{-0.01128768830662829, 0.04619274274295558, -0.019487709396580195},
			{-0.015412175921311503, -0.019487709396580195, 0.03760658688573861}
		},
		{
			{0.04071556629752536, -0.01602830946664903, -0.0012472665662073973},
			{-0.016028309466649023, 0.07325304762034227, -0.014325671301216219},
			{-0.0012472665662073982, -0.014325671301216217, 0.02465984888277571}
		},
		{
			{0.03981945390243677, -0.01876306849959899, -0.011022936675331201},
			{-0.01876306849959898, 0.02387216668276297, 0.005048919741471172},
			{-0.01102293667533119, 0.005048919741471166, 0.012969572180351392}
		},
		{
			{0.05956929147928226, -0.060247217179164016, 0.006265070886797142},
			{-0.06024721717916404, 0.13076218136395912, -0.036743586367199835},
			{0.006265070886797151, -0.03674358636719983, 0.0281435561509356}
		},
		{
			{0.020077348786676108, -4.624890924635021E-4, -0.009918048992677442},
			{-4.624890924635038E-4, 0.028081094382672, -0.00931801694879738},
			{-0.009918048992677442, -0.00931801694879738, 0.018472498620967892}
		},
		{
			{0.0378109974804784, -0.016015211658214214, -0.002771622189998672},
			{-0.01601521165821423, 0.07917024704603202, -0.03156339824345977},
			{-0.002771622189998659, -0.03156339824345977, 0.03356847100627778}
		},
		{
			{0.023057600753228095, 6.780326604551659E-4, -0.006326808072454334},
			{6.780326604551763E-4, 0.03846825036555679, -0.02549133386847038},
			{-0.006326808072454348, -0.02549133386847039, 0.031786709963966986}
		},
		{
			{0.01595324099018932, -0.009143612050707451, 0.0022156259659916787},
			{-0.00914361205070744, 0.07865909386542069, -0.039885353944471076},
			{0.002215625965991671, -0.039885353944471076, 0.03984047073599469}
		},
		{
			{0.019786101793113606, 0.0024760428779520387, -0.006352253688185829},
			{0.0024760428779520365, 0.014071690138680504, 0.0032362125949636973},
			{-0.006352253688185825, 0.003236212594963697, 0.008434257758488939}
		},
		{
			{0.09680869100086519, -0.05889113702535363, 0.008224437095479004},
			{-0.05889113702535363, 0.08413216528834275, -0.028909945975189207},
			{0.008224437095479004, -0.028909945975189213, 0.024435291292015906}
		},
		{
			{0.04184100779662991, -0.023678203067502568, -0.0020025779927981676},
			{-0.023678203067502554, 0.08954391549837179, -0.005616842202116997},
			{-0.002002577992798165, -0.005616842202116998, 0.0243995515891837}
		},
		{
			{0.03924259982654513, 0.006368602465957553, -0.007455955388173509},
			{0.006368602465957553, 0.03772808589990208, -6.938338563973203E-4},
			{-0.007455955388173503, -6.938338563973164E-4, 0.0030444204211984623}
		},
		{
			{0.07786354155606884, 0.01097434917090409, -0.06780155366302204},
			{0.010974349170904119, 0.17281929352861405, -0.014585415584755443},
			{-0.06780155366302207, -0.014585415584755478, 0.07100122036830762}
		},
		{
			{0.027446954683318123, -0.014391979631334924, -0.012781285975270215},
			{-0.014391979631334928, 0.04986316432154274, -0.01634052646059028},
			{-0.012781285975270217, -0.016340526460590282, 0.02426913593723231}
		},
		{
			{0.06510162252960419, -0.03613515381806881, -0.002948278289516165},
			{-0.036135153818068796, 0.06642312055512448, -0.017998927258093197},
			{-0.002948278289516169, -0.017998927258093194, 0.03346288814466902}
		},
		{
			{0.04918572693516652, -0.02113604574827761, -0.020817468957491404},
			{-0.021136045748277606, 0.052219158771628395, -0.02956144468850898},
			{-0.020817468957491404, -0.029561444688508985, 0.05636098034292779}
		},
		{
			{0.025310496182000517, -0.009558511272459177, -0.005837830764097276},
			{-0.009558511272459179, 0.03872074397776712, -0.0197516549981412},
			{-0.00583783076409728, -0.019751654998141202, 0.03256334244843022}
		},
		{
			{0.05128727200522837, -0.02812277741985518, -0.0168056730101555},
			{-0.02812277741985521, 0.0788399134061707, -0.04590095069257341},
			{-0.01680567301015551, -0.045900950692573404, 0.12275611135002401}
		},
		{
			{0.05575992086340872, -0.03160640750854611, -0.005701219466837285},
			{-0.0316064075085461, 0.04305558265603077, 0.0015129596869427574},
			{-0.0057012194668372845, 0.001512959686942759, 0.014745382313446605}
		},
		{
			{0.07773209445263204, -0.06391447504123887, -0.009749453999097688},
			{-0.06391447504123887, 0.11281083671292898, -0.0206661098425858},
			{-0.009749453999097683, -0.020666109842585795, 0.025103747852346585}
		},
		{
			{0.06261112978321959, -0.016826802675718493, -0.01665025290495508},
			{-0.016826802675718497, 0.04605074054117862, -0.01413589754292911},
			{-0.016650252904955084, -0.01413589754292911, 0.029731452105001072}
		},
		{
			{0.031136721822320933, -0.005572116318961838, -0.010442659950101102},
			{-0.005572116318961838, 0.03504852761961696, 2.8589498809721697E-6},
			{-0.010442659950101095, 2.858949880973037E-6, 0.0053276063310593496}
		},
		{
			{0.014480585438817497, 7.341749688893609E-4, -0.010691700893170486},
			{7.341749688893643E-4, 0.035571593879278406, -0.008009250061804696},
			{-0.010691700893170487, -0.008009250061804687, 0.020732348309975078}
		},
		{
			{0.06403589269339995, -0.039266619880031876, -0.0019002509632414129},
			{-0.03926661988003191, 0.07517625313160045, -0.019844710090405504},
			{-0.0019002509632414085, -0.01984471009040549, 0.0282388249140252}
		},
		{
			{0.11290421710177183, -0.060121815651410004, -0.009097228236409476},
			{-0.060121815651410004, 0.30218432724956107, -0.04650489066036039},
			{-0.009097228236409474, -0.04650489066036042, 0.0212411834172491}
		},
		{
			{0.07710339570098726, -0.02812689929205351, -0.006400286014221365},
			{-0.0281268992920535, 0.03536882901764271, -0.0179364209229445},
			{-0.00640028601422138, -0.017936420922944497, 0.024973574469427}
		},
		{
			{0.030740814839579075, -0.025981851212148483, 0.0032704910129139797},
			{-0.025981851212148473, 0.0528285443529045, -0.012435586625925312},
			{0.0032704910129139823, -0.012435586625925308, 0.013784478721903606}
		},
		{
			{0.026948023114311815, -0.026191521604064925, 0.003236000067742451},
			{-0.02619152160406493, 0.062180247907354824, -0.0028121493410312236},
			{0.003236000067742451, -0.0028121493410312236, 0.0020536473582767906}
		},
		{
			{0.036901793471187834, -0.02607378402791642, 0.002346590988366077},
			{-0.026073784027916443, 0.06786463818336264, -0.02994436880840481},
			{0.0023465909883660834, -0.02994436880840481, 0.030549516250091217}
		},
		{
			{0.140900905560064, -0.11352991026380904, -0.0150903784366171},
			{-0.1135299102638091, 0.12547238187761708, -0.010116245204660312},
			{-0.015090378436617095, -0.010116245204660307, 0.023629311295784106}
		},
		{
			{0.08569867881030592, -0.06383058446392804, 0.013138583244434105},
			{-0.06383058446392793, 0.1264859865005209, -0.03389410412074599},
			{0.013138583244434085, -0.033894104120746, 0.049730396666073706}
		},
		{
			{0.08543996070744503, -0.018146774041723927, -0.02971106323308249},
			{-0.018146774041723948, 0.13546768832661807, -0.0016930482398163482},
			{-0.029711063233082487, -0.0016930482398163395, 0.050801111933925454}
		},
		{
			{0.09869239863775042, -0.012613907645292395, -4.98027904348397E-4},
			{-0.012613907645292388, 0.0705677961860119, 0.011407163481965599},
			{-4.980279043483955E-4, 0.011407163481965603, 0.01806335998453729}
		},
		{
			{0.017215629128326408, -0.002278531765345993, -0.006283171401220466},
			{-0.0022785317653459904, 0.030352581724414407, -0.010313846442853492},
			{-0.006283171401220469, -0.010313846442853492, 0.0207009839297913}
		},
		{
			{0.04730865754065445, -0.024828735424807957, 0.0035785612993080363},
			{-0.024828735424807947, 0.07759996648094344, -0.040941228971739775},
			{0.0035785612993080368, -0.040941228971739775, 0.03986580096523758}
		},
		{
			{0.013026918729451085, 0.001125494527094417, -0.009614740229831656},
			{0.0011254945270944162, 0.016023448860610297, -0.004491634639395281},
			{-0.009614740229831654, -0.004491634639395282, 0.01925546753525838}
		},
		{
			{0.0039944293453807985, -0.008312503702214008, 0.0036172192025404},
			{-0.008312503702214013, 0.07193593226637104, -0.040404970210731125},
			{0.003617219202540404, -0.040404970210731125, 0.05003093448234282}
		},
		{
			{0.02516869258009051, -0.010146553675780691, -0.007065455153415421},
			{-0.01014655367578069, 0.0460531473470178, -0.008793424156574666},
			{-0.007065455153415426, -0.008793424156574662, 0.0165473001658066}
		},
		{
			{0.012663047656364996, -0.011497005496866103, 0.0029207801680050174},
			{-0.011497005496866103, 0.049102240597552915, -0.029600373636910694},
			{0.0029207801680050183, -0.029600373636910694, 0.030072519962197487}
		},
		{
			{0.09623003425258449, -0.00616393232285564, -0.02962937923329308},
			{-0.006163932322855632, 0.05919403758340658, 0.015599595283386185},
			{-0.029629379233293084, 0.015599595283386164, 0.06061695171738116}
		},
		{
			{0.005783400815788916, -0.006534440596927188, 0.0014256538448199738},
			{-0.006534440596927191, 0.06978985490709484, -0.046130056180132925},
			{0.001425653844819975, -0.04613005618013293, 0.05144663612098774}
		},
		{
			{0.01480044406710478, -0.02145029789179067, 0.01000385933070087},
			{-0.021450297891790655, 0.07869988834689813, -0.05824786299290317},
			{0.010003859330700866, -0.05824786299290315, 0.061481636313042286}
		}
	};

	double barycentre[53][3] =
	{
		{133.65753424657535, 143.3013698630137, 86.0730593607306},
		{78.49565217391304, 78.21739130434783, 52.243478260869566},
		{158.4820143884892, 108.82494004796163, 75.15347721822542},
		{160.80154142581887, 137.39884393063585, 181.1849710982659},
		{146.37978142076503, 105.4153005464481, 112.09289617486338},
		{193.0549645390071, 141.36170212765958, 168.12056737588654},
		{55.18315018315018, 155.98534798534797, 168.83150183150184},
		{215.0708661417323, 201.17322834645668, 96.65354330708661},
		{110.1070110701107, 101.31365313653137, 52.00738007380074},
		{122.50429184549357, 142.00858369098714, 194.63948497854076},
		{134.02197802197801, 193.5686813186813, 169.87637362637363},
		{168.8085501858736, 121.09665427509293, 146.8996282527881},
		{128.0851851851852, 76.58888888888889, 44.6037037037037},
		{177.21857923497268, 203.95081967213116, 146.01639344262296},
		{149.49466192170817, 163.6832740213523, 211.8594306049822},
		{119.58174097664543, 159.24416135881103, 116.50106157112526},
		{171.20949263502456, 118.7823240589198, 106.68576104746317},
		{23.693877551020407, 114.1938775510204, 81.89795918367346},
		{128.325, 198.62045454545455, 205.96818181818182},
		{198.424, 149.608, 12.04},
		{205.5258358662614, 164.27051671732522, 136.5258358662614},
		{126.4231884057971, 88.31304347826087, 78.39710144927537},
		{224.50704225352112, 197.74647887323943, 15.140845070422536},
		{70.98507462686567, 32.06716417910448, 38.69402985074627},
		{95.52233676975945, 129.70103092783506, 93.19243986254295},
		{110.63205417607223, 160.17155756207674, 224.93453724604967},
		{185.01526717557252, 161.65648854961833, 200.13358778625954},
		{105.10771992818671, 178.97307001795332, 186.27468581687612},
		{133.95642701525054, 185.43355119825708, 243.0239651416122},
		{222.82558139534885, 96.52906976744185, 18.302325581395348},
		{95.32659932659932, 126.78451178451178, 168.2020202020202},
		{134.83703703703705, 123.40493827160493, 151.65925925925927},
		{183.40298507462686, 167.3320895522388, 70.83208955223881},
		{100.408014571949, 166.88524590163934, 156.53916211293262},
		{195.92540792540794, 134.2983682983683, 98.05827505827506},
		{101.92926045016077, 101.67202572347267, 118.73633440514469},
		{223.2642857142857, 118.53571428571429, 73.05714285714286},
		{157.56338028169014, 140.50234741784038, 64.9319248826291},
		{145.89375, 111.6625, 20.6125},
		{84.53221957040573, 156.78281622911695, 192.5107398568019},
		{203.5358851674641, 201.76555023923444, 180.4354066985646},
		{177.2709497206704, 195.43016759776538, 227.61731843575419},
		{26.284057971014494, 23.843478260869563, 28.228985507246378},
		{81.44471153846153, 74.91826923076923, 86.86538461538461},
		{86.82038834951456, 145.4902912621359, 131.46116504854368},
		{195.64895635673625, 130.20493358633777, 131.32068311195445},
		{136.01627906976745, 178.3232558139535, 136.74883720930234},
		{8.067567567567568, 161.94594594594594, 174.1891891891892},
		{164.65535714285716, 169.06607142857143, 107.22142857142858},
		{83.65159574468085, 182.89361702127658, 215.9281914893617},
		{47.41732283464567, 40.31758530183727, 55.25459317585302},
		{35.885416666666664, 129.83333333333334, 133.90625},
		{100.50752688172042, 200.6258064516129, 239.30752688172043}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<53;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<53;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance54clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02711875553850499, -0.020820624950298378, -0.0013196285184329684},
		{-0.020820624950298378, 0.045241250727971256, -0.014904112447691097},
		{-0.001319628518432965, -0.014904112447691093, 0.015995576157684707}
	};

	double matrix[54][3][3] =
	{
		{
			{0.11307365456474494, -0.04993854986425141, -0.023520316674520602},
			{-0.049938549864251384, 0.07892697692205164, -0.015192632174730478},
			{-0.023520316674520602, -0.015192632174730481, 0.029628053488469485}
		},
		{
			{0.01632766754540451, -3.9569142941408425E-4, -0.00943923470196515},
			{-3.9569142941408425E-4, 0.0290831554829538, -0.011159526838006905},
			{-0.009439234701965143, -0.011159526838006903, 0.022777454530788097}
		},
		{
			{0.03789166091719426, -0.01151509153773209, -8.166415873461985E-4},
			{-0.011515091537732086, 0.07021484703817507, -0.0059791591228894915},
			{-8.166415873462002E-4, -0.005979159122889491, 0.024344460144801502}
		},
		{
			{0.014777315527448308, -0.012570517563023215, 0.0022796974198382785},
			{-0.012570517563023222, 0.056648065886464594, -0.02974954195036679},
			{0.002279697419838276, -0.02974954195036679, 0.027662499270344892}
		},
		{
			{0.08783520045862823, -0.06816507151613188, 0.004968150273646467},
			{-0.06816507151613191, 0.09979562499836214, -0.023939264285015104},
			{0.0049681502736464754, -0.02393926428501511, 0.028272994904158195}
		},
		{
			{0.06180402966121683, -0.015124620055755158, -0.013483640984094478},
			{-0.015124620055755163, 0.05451459015090459, 0.00397366119907392},
			{-0.013483640984094485, 0.003973661199073925, 0.016745021095695492}
		},
		{
			{0.06231370817051326, -0.029201973239128327, -0.001944931488236698},
			{-0.029201973239128334, 0.02887715807539043, -0.007829049045568803},
			{-0.0019449314882366987, -0.007829049045568803, 0.014701493373142407}
		},
		{
			{0.05767695220822204, -0.03296339190938341, 9.288806828259338E-4},
			{-0.03296339190938343, 0.0672040014517836, -0.024597486162185406},
			{9.288806828259303E-4, -0.024597486162185413, 0.029931475310009486}
		},
		{
			{0.029361946701552913, -0.00964760721659046, -0.0023841262974426854},
			{-0.009647607216590463, 0.05496924228079872, -0.011361280234834991},
			{-0.0023841262974426854, -0.011361280234835004, 0.026489051411622194}
		},
		{
			{0.0598555576466469, -0.014726885541629188, -0.017439719775322896},
			{-0.014726885541629188, 0.053698392672050586, -0.0132732328306693},
			{-0.0174397197753229, -0.013273232830669297, 0.025042160262524597}
		},
		{
			{0.008810758886072278, -0.001332209958958097, 0.007549028314059592},
			{-0.0013322099589580987, 0.061945022443924365, -0.039033318106484555},
			{0.007549028314059585, -0.03903331810648455, 0.05232565139751054}
		},
		{
			{0.05395167288270444, -0.02255147214201098, 0.006132829351755403},
			{-0.02255147214201098, 0.06629090729812283, -0.0018421819257924868},
			{0.0061328293517554, -0.0018421819257924835, 0.0011005459756070297}
		},
		{
			{0.021629831389493776, 0.0027931552765581105, -0.006437155824176762},
			{0.002793155276558109, 0.012927707603878397, 0.0022000200471133822},
			{-0.006437155824176762, 0.0022000200471133827, 0.007352730164131862}
		},
		{
			{0.024410365709868306, -0.014341983777024114, 0.002534557640056659},
			{-0.014341983777024114, 0.05484381528154824, -0.03440007711860709},
			{0.0025345576400566455, -0.034400077118607084, 0.04103634107748607}
		},
		{
			{0.07559668242708911, -0.040798730131603726, -0.01879600833794332},
			{-0.040798730131603726, 0.042471770017659935, 0.004549388997127774},
			{-0.01879600833794331, 0.004549388997127771, 0.021158424361893705}
		},
		{
			{0.09814346330781519, -0.04457545182725332, 1.2944648588376594E-4},
			{-0.044575451827253344, 0.14701435096934112, 3.382781292572979E-4},
			{1.294464858837658E-4, 3.38278129257298E-4, 0.009145825733468076}
		},
		{
			{0.06694824691410112, -0.07473301406016147, 0.008837010592687237},
			{-0.0747330140601614, 0.15078127842655392, -0.03828924593571156},
			{0.008837010592687227, -0.038289245935711584, 0.025705823340928198}
		},
		{
			{0.04902683665092224, -0.023006246684638385, 0.0012494396439604277},
			{-0.023006246684638392, 0.04897358524996003, -0.005842177684191383},
			{0.0012494396439604286, -0.005842177684191386, 0.00820635825280947}
		},
		{
			{0.04390701165039736, -0.02589011558204169, -0.009764344814042036},
			{-0.025890115582041687, 0.08011593288009969, -0.020184993995217497},
			{-0.009764344814042043, -0.0201849939952175, 0.02145369231607629}
		},
		{
			{0.050817748943551504, -0.028487435704202212, 0.0036720176798528603},
			{-0.028487435704202233, 0.08149789417857672, -0.022918764903738807},
			{0.003672017679852861, -0.022918764903738814, 0.0190426945491478}
		},
		{
			{0.0324444913756259, -2.1706509558427466E-4, -0.00606798314400799},
			{-2.1706509558427407E-4, 0.04728792592070792, -2.6901827086422205E-4},
			{-0.006067983144007991, -2.690182708642207E-4, 0.00317172512696484}
		},
		{
			{0.004109596346333532, -0.009888321521072461, 0.0034130679749699603},
			{-0.00988832152107246, 0.07439152121344278, -0.044004566800624284},
			{0.003413067974969964, -0.04400456680062429, 0.0502665154090195}
		},
		{
			{0.05402296171278857, -0.02598478003024013, -0.012156614748865207},
			{-0.025984780030240146, 0.0926590171967251, -0.022768078494364918},
			{-0.012156614748865202, -0.022768078494364907, 0.02825017720944791}
		},
		{
			{0.017386270793793207, -0.006727484671123099, -0.003079636451365947},
			{-0.0067274846711231, 0.0575851134961618, -0.026007828031113202},
			{-0.003079636451365945, -0.026007828031113202, 0.03320794423736019}
		},
		{
			{0.051437155580964206, -0.032470050414572016, 3.1063885608357275E-4},
			{-0.032470050414572016, 0.08278038052266125, -0.04193030333600189},
			{3.106388560835723E-4, -0.04193030333600188, 0.0412954909538026}
		},
		{
			{0.12737317727114814, -0.06559153868827679, -0.009339728225890125},
			{-0.06559153868827673, 0.05897569106117775, 0.00921397055758642},
			{-0.009339728225890121, 0.00921397055758642, 0.014965388623750096}
		},
		{
			{0.021462373265290394, -0.02034114506119228, 0.009666669687557599},
			{-0.020341145061192285, 0.07647095338115796, -0.05843174915746029},
			{0.0096666696875576, -0.05843174915746027, 0.05926060955643822}
		},
		{
			{0.04770452449951182, -0.01602343976835239, -0.015432497619281008},
			{-0.016023439768352406, 0.04176900231502761, -0.009897803533030802},
			{-0.015432497619281007, -0.009897803533030797, 0.029865089012828604}
		},
		{
			{0.016713846580315894, -0.0016824804488085442, -0.012335751106703312},
			{-0.0016824804488085425, 0.022890263611257396, -0.006717176926697568},
			{-0.01233575110670332, -0.006717176926697568, 0.018290378058521423}
		},
		{
			{0.012064645942388291, 0.0018876203078043588, -0.009377750682622317},
			{0.0018876203078043536, 0.03171068382085659, -0.007688412131773969},
			{-0.00937775068262231, -0.007688412131773971, 0.020752893873677163}
		},
		{
			{0.0759671386208637, -0.047069413783864374, -0.0063182465710876256},
			{-0.047069413783864394, 0.09157945944367538, -0.015959586947700114},
			{-0.006318246571087625, -0.01595958694770011, 0.017449029133817802}
		},
		{
			{0.02971776179299298, -0.008169232093876691, -0.008573204534501257},
			{-0.008169232093876693, 0.03657690207531279, -0.002921612037721828},
			{-0.008573204534501257, -0.0029216120377218283, 0.007964429171985725}
		},
		{
			{0.03408052828794911, -0.009834574245251752, -0.002173132367241048},
			{-0.009834574245251733, 0.17034956573134988, -0.027939196550636237},
			{-0.0021731323672410496, -0.02793919655063622, 0.051367985381215016}
		},
		{
			{0.022301922711823286, -0.011840144384398583, -0.005956440308023357},
			{-0.011840144384398595, 0.023532046241803488, -0.0015366803048246103},
			{-0.005956440308023359, -0.0015366803048246173, 0.017613306533785608}
		},
		{
			{0.049380482655413796, -0.016780633001140036, -0.025182210274717926},
			{-0.01678063300114003, 0.04725282518471242, -0.022667310839184576},
			{-0.025182210274717922, -0.022667310839184558, 0.05242689696339796}
		},
		{
			{0.056632287763003976, -0.027334494353331525, -0.028509887323582405},
			{-0.02733449435333153, 0.07768155523948925, -0.04958921871836956},
			{-0.028509887323582405, -0.049589218718369577, 0.146075317635584}
		},
		{
			{0.06256712184736041, -0.02856433709407108, -0.002759080537979207},
			{-0.028564337094071066, 0.060012733143270075, -0.002970518529130854},
			{-0.002759080537979212, -0.0029705185291308642, 0.045522083399594605}
		},
		{
			{0.03246150993885848, -0.027206468758067273, 0.006250278163638753},
			{-0.027206468758067294, 0.052715713838249724, -0.013568675628718198},
			{0.006250278163638757, -0.013568675628718193, 0.011766012326161897}
		},
		{
			{0.029664086045547995, -0.009147922391502018, -0.0094972021880369},
			{-0.00914792239150201, 0.03173172817598878, -0.0023727805848204435},
			{-0.009497202188036895, -0.00237278058482044, 0.012690357875150703}
		},
		{
			{0.04749552208174061, -0.00924477146595977, -0.01735095000809729},
			{-0.009244771465959771, 0.06969200788313332, -0.0333695730478288},
			{-0.017350950008097287, -0.03336957304782881, 0.04461070123942681}
		},
		{
			{0.10056903271252711, -0.025587026511297895, 0.007692222321099791},
			{-0.025587026511297885, 0.08130707855428779, 0.008270565650994103},
			{0.00769222232109979, 0.008270565650994113, 0.021250236160674302}
		},
		{
			{0.04359573376513403, -0.015595530567306438, -0.005002550694338718},
			{-0.015595530567306422, 0.05355861195883837, 9.368113756703556E-4},
			{-0.005002550694338716, 9.368113756703534E-4, 0.013797401923209196}
		},
		{
			{0.07229518027277901, -0.03402683648367089, -0.023725050454327785},
			{-0.0340268364836709, 0.03778641317162611, 0.003923239380468978},
			{-0.023725050454327785, 0.003923239380468986, 0.028217352167216794}
		},
		{
			{0.025672805955628507, -0.02117034618168061, -6.104350410846143E-4},
			{-0.021170346181680625, 0.04170399764851254, -0.005630124006183024},
			{-6.104350410846117E-4, -0.005630124006183025, 0.016178957674217304}
		},
		{
			{0.05806426889222335, -0.03649297851284654, -0.014720037339591305},
			{-0.036492978512846524, 0.09495558346139711, -0.008178303673709635},
			{-0.014720037339591301, -0.008178303673709643, 0.012603471625757909}
		},
		{
			{0.031101718097999297, -0.010661451803504791, -0.015417612169785095},
			{-0.010661451803504784, 0.036376452920526166, -0.007817245563725008},
			{-0.015417612169785091, -0.007817245563725006, 0.021918477103211514}
		},
		{
			{0.00961388926747975, 2.088791143116434E-4, -0.0051198778966559996},
			{2.0887911431164558E-4, 0.04044431889871253, -0.030699392177793217},
			{-0.005119877896656002, -0.030699392177793217, 0.03508898609014621}
		},
		{
			{0.04341315998416699, -0.02397322657473202, 5.643235895113983E-4},
			{-0.023973226574732016, 0.06838103412811704, -0.034095093806006824},
			{5.643235895114065E-4, -0.034095093806006824, 0.03651666170523451}
		},
		{
			{0.08112061969640808, 0.0058009942373449044, -0.04374591027411839},
			{0.0058009942373448906, 0.09251283246832435, 0.020329820837882907},
			{-0.04374591027411839, 0.02032982083788291, 0.052517367861481194}
		},
		{
			{0.033461484946680366, -0.012632956777411304, -0.005843165234425022},
			{-0.012632956777411301, 0.07015863693542528, -0.019472778381302493},
			{-0.005843165234425013, -0.019472778381302513, 0.03650246287340214}
		},
		{
			{0.024486819371962586, -0.013909335517678286, -0.00384357853301049},
			{-0.013909335517678282, 0.03659681165543935, -0.016726081906862096},
			{-0.003843578533010485, -0.016726081906862103, 0.030132492496516217}
		},
		{
			{0.08673288132576279, -0.06295649910697787, 0.008504446409124565},
			{-0.06295649910697791, 0.11747740851778607, -0.02072518282139889},
			{0.008504446409124573, -0.020725182821398895, 0.04183080049227987}
		},
		{
			{0.05491334207477271, -0.0279460850908799, -0.010050264384167508},
			{-0.027946085090879896, 0.07902746032527941, -0.023107124770700097},
			{-0.010050264384167507, -0.02310712477070009, 0.03443438409329191}
		},
		{
			{0.016172932289162507, -2.8910802525483614E-5, -0.013899162850072195},
			{-2.8910802525476675E-5, 0.015988998108302892, -0.00401107543442507},
			{-0.0138991628500722, -0.004011075434425074, 0.01680791266540968}
		}
	};

	double barycentre[54][3] =
	{
		{218.74074074074073, 183.62962962962962, 159.54497354497354},
		{95.96997690531178, 148.38568129330255, 120.83602771362587},
		{134.47630922693267, 87.29426433915212, 62.082294264339154},
		{86.26086956521739, 185.36061381074168, 218.4833759590793},
		{103.18835616438356, 137.7568493150685, 181.07876712328766},
		{75.57741935483871, 79.30967741935484, 53.24193548387097},
		{218.64963503649636, 105.39416058394161, 58.2043795620438},
		{210.1993670886076, 132.21518987341773, 103.83544303797468},
		{156.0358851674641, 110.52870813397129, 124.83253588516746},
		{132.22384428223845, 123.51581508515815, 153.59367396593674},
		{24.3206106870229, 118.1526717557252, 94.41984732824427},
		{142.15384615384616, 104.25443786982248, 19.467455621301774},
		{196.87301587301587, 149.20634920634922, 11.722222222222221},
		{69.11042944785277, 160.16564417177915, 187.65030674846625},
		{183.71304347826086, 208.3521739130435, 171.56521739130434},
		{120.0752688172043, 97.97849462365592, 104.05017921146954},
		{153.3030303030303, 168.32034632034632, 213.93506493506493},
		{214.28682170542635, 203.1860465116279, 100.03875968992249},
		{159.71812080536913, 141.38926174496643, 187.95302013422818},
		{192.63384615384615, 159.76615384615386, 122.39692307692307},
		{224.26666666666668, 196.8, 16.92},
		{8.180645161290322, 161.1483870967742, 173.90967741935484},
		{96.29491525423728, 151.67118644067796, 213.70508474576272},
		{128.29150579150578, 197.42857142857142, 200.22586872586874},
		{199.07589285714286, 136.02232142857142, 147.95089285714286},
		{91.49090909090908, 104.58636363636364, 122.38636363636364},
		{103.92622950819673, 200.31352459016392, 240.31352459016392},
		{169.06238532110092, 125.96146788990826, 157.81284403669724},
		{127.79297597042513, 167.06839186691312, 123.49907578558225},
		{97.6247582205029, 165.54158607350098, 154.642166344294},
		{85.308, 128.912, 155.372},
		{184.25581395348837, 165.91694352159467, 72.0},
		{28.78640776699029, 25.20631067961165, 29.601941747572816},
		{126.01608579088472, 141.56300268096516, 86.22252010723861},
		{185.59024390243903, 165.6560975609756, 204.44390243902438},
		{142.66037735849056, 191.43935309973045, 240.48247978436657},
		{120.16744186046512, 166.2813953488372, 230.87209302325581},
		{155.61486486486487, 135.34234234234233, 61.5045045045045},
		{165.09782608695653, 180.3016304347826, 118.9375},
		{190.61883408071748, 147.27578475336324, 177.84080717488789},
		{83.75592417061611, 74.42654028436019, 85.91469194312796},
		{109.12820512820512, 86.48148148148148, 46.267806267806264},
		{223.55882352941177, 99.36029411764706, 10.764705882352942},
		{154.95215311004785, 157.41626794258374, 94.63636363636364},
		{128.7129411764706, 146.07764705882352, 198.38588235294117},
		{94.48484848484848, 123.58441558441558, 87.31601731601732},
		{50.25242718446602, 150.55825242718447, 152.9368932038835},
		{183.27272727272728, 123.67878787878787, 122.68080808080808},
		{55.09471365638767, 39.429515418502206, 53.5374449339207},
		{152.50469483568074, 106.69014084507042, 88.32394366197182},
		{102.20435510887772, 176.42211055276383, 184.88107202680067},
		{184.71428571428572, 199.83982683982683, 228.74458874458875},
		{175.727634194831, 121.30019880715706, 92.71968190854871},
		{132.6596638655462, 188.2016806722689, 158.5441176470588}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<54;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<54;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance55clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.028370967773912577, -0.021643959960199598, -0.0014918393457400273},
		{-0.0216439599601996, 0.044797445914321436, -0.013671614594712686},
		{-0.0014918393457400262, -0.013671614594712694, 0.014831825744357596}
	};

	double matrix[55][3][3] =
	{
		{
			{0.07941944120788734, -0.05691965401093152, -0.006417389097580306},
			{-0.05691965401093148, 0.10624207210042494, -0.019657876579864394},
			{-0.0064173890975803075, -0.019657876579864394, 0.02310621003428409}
		},
		{
			{0.017044569422343597, -0.008759806851346865, 9.275574570575403E-4},
			{-0.008759806851346849, 0.043451066421728426, -0.03874355742207841},
			{9.275574570575321E-4, -0.03874355742207841, 0.0428583689002716}
		},
		{
			{0.0399746752104708, -0.02444626892895851, -0.004062536651707246},
			{-0.0244462689289585, 0.06205898991409726, -0.01205334264786001},
			{-0.004062536651707243, -0.012053342647860003, 0.015420406506220008}
		},
		{
			{0.0279628287220148, -0.010732218768281808, -0.005286981541120882},
			{-0.010732218768281808, 0.03599379637723768, -0.001612026771085824},
			{-0.005286981541120883, -0.0016120267710858205, 0.013469983750851202}
		},
		{
			{0.03191358218547492, -0.026176231861510923, 0.005307010197969096},
			{-0.026176231861510912, 0.051507000576785, -0.00947650605448869},
			{0.005307010197969095, -0.009476506054488685, 0.013261506042473403}
		},
		{
			{0.04309769032646067, -0.01685355490281597, -0.005226940618287889},
			{-0.016853554902815964, 0.07864857372258716, -0.004743080816795755},
			{-0.005226940618287889, -0.004743080816795755, 0.018131655784888}
		},
		{
			{0.06690163040450905, -0.03115229486087288, -0.0014510541534145168},
			{-0.031152294860872867, 0.029302471118111576, -0.007179978673621584},
			{-0.0014510541534145146, -0.007179978673621579, 0.012978039591010694}
		},
		{
			{0.04334947858158857, -0.023550998684725377, -0.00988531449670709},
			{-0.02355099868472537, 0.07803779890482299, -0.047524075382924316},
			{-0.009885314496707084, -0.047524075382924316, 0.11514567518978697}
		},
		{
			{0.07328154494567694, -0.07401011679861141, 0.02067184728871979},
			{-0.07401011679861146, 0.1480600114050479, -0.036243622654076005},
			{0.02067184728871981, -0.03624362265407599, 0.057488716617102795}
		},
		{
			{0.021960460826891397, 0.0035007116613642738, -0.004819951803226487},
			{0.0035007116613642703, 0.03973939349110054, -0.026727128469216023},
			{-0.0048199518032264865, -0.026727128469216037, 0.03227317952420492}
		},
		{
			{0.07462909292740245, -0.04968652757804762, 0.0071059356886210515},
			{-0.04968652757804762, 0.06474435933436191, -0.021079269031654108},
			{0.007105935688621045, -0.021079269031654104, 0.02096507400167051}
		},
		{
			{0.02568481783322049, -0.014046049154325111, -0.004779229374284906},
			{-0.014046049154325096, 0.041032556093960684, -0.01676047777131322},
			{-0.004779229374284906, -0.01676047777131321, 0.0272726670075219}
		},
		{
			{0.016068602514702997, -0.0010697551343458438, -0.013602782452851908},
			{-0.001069755134345849, 0.02730207874791779, -0.014874576602628704},
			{-0.01360278245285191, -0.014874576602628704, 0.027610722513257916}
		},
		{
			{0.016534724172996382, 0.0023855823785269093, -0.008811993603324075},
			{0.0023855823785269067, 0.03665841233431938, -0.014935375679059677},
			{-0.008811993603324074, -0.01493537567905968, 0.024492549673725387}
		},
		{
			{0.07229518027277901, -0.03402683648367089, -0.023725050454327785},
			{-0.0340268364836709, 0.03778641317162611, 0.003923239380468978},
			{-0.023725050454327785, 0.003923239380468986, 0.028217352167216794}
		},
		{
			{0.004126472128123922, -0.003914817206930139, 0.002687642334420781},
			{-0.003914817206930151, 0.06584353971553787, -0.04461351358527468},
			{0.002687642334420791, -0.04461351358527468, 0.051999403146814}
		},
		{
			{0.03208968384010548, -0.017729386155845295, -0.0010609540667277338},
			{-0.017729386155845288, 0.07197460055398834, -0.019074150728990973},
			{-0.001060954066727732, -0.019074150728990977, 0.03126224427096699}
		},
		{
			{0.11808750057921905, -0.05769105345375232, -0.022002998586653593},
			{-0.05769105345375233, 0.10625503811041802, -0.02888922982159719},
			{-0.02200299858665359, -0.028889229821597175, 0.031264070432597976}
		},
		{
			{0.055873684477705375, -0.039045674815324886, 9.561386560576956E-4},
			{-0.0390456748153249, 0.07033890889569884, -0.025502205524383717},
			{9.561386560577052E-4, -0.025502205524383727, 0.04445118134553902}
		},
		{
			{0.044017499720026734, -0.017597130107597506, -0.0032812748676445368},
			{-0.01759713010759749, 0.07475630775371236, -0.009344459521896739},
			{-0.00328127486764453, -0.009344459521896747, 0.0275637579778054}
		},
		{
			{0.041495788331991926, -0.009646142756146373, -0.01495593497303172},
			{-0.009646142756146376, 0.033075174709388526, -0.005730476715189293},
			{-0.014955934973031723, -0.0057304767151892914, 0.03235640586384893}
		},
		{
			{0.063960070521469, -0.011969049596590689, -0.015004848456445622},
			{-0.011969049596590675, 0.055783425470281395, 0.003419745591613014},
			{-0.01500484845644562, 0.003419745591613014, 0.016586716638144112}
		},
		{
			{0.04619320298373259, -0.009996575046882073, -0.012636117352741203},
			{-0.009996575046882068, 0.16145103471714906, -0.0179808394601297},
			{-0.012636117352741201, -0.017980839460129718, 0.05100098326206043}
		},
		{
			{0.10090694679770199, 0.009684071872622595, -0.06106165474261847},
			{0.009684071872622562, 0.08440722194658705, 0.020622937718825635},
			{-0.061061654742618425, 0.02062293771882561, 0.06789687384482149}
		},
		{
			{0.02568547787998578, -0.015977461673547886, -0.0051820713888028995},
			{-0.015977461673547882, 0.02530879768076346, -0.003048960898586928},
			{-0.005182071388802899, -0.0030489608985869304, 0.015445132205140898}
		},
		{
			{0.021452972477820693, 0.0028782846084427815, -0.006317942283600323},
			{0.002878284608442781, 0.013211770030469803, 0.002544951200251577},
			{-0.006317942283600321, 0.0025449512002515785, 0.007670070240670202}
		},
		{
			{0.04585598755132444, -0.008553985607123255, -0.018865667395961887},
			{-0.00855398560712326, 0.0732980862893584, -0.03513738835927098},
			{-0.018865667395961898, -0.035137388359271, 0.04383669880286179}
		},
		{
			{0.032015244589718106, -0.008211827972847243, -0.012422478390402588},
			{-0.00821182797284724, 0.02752625197609017, -0.004998026207117895},
			{-0.01242247839040259, -0.004998026207117888, 0.022916066757879786}
		},
		{
			{0.04616824199503334, -0.033801992384801034, 0.005260321827542295},
			{-0.03380199238480104, 0.07585564091504594, -0.024040305057387315},
			{0.005260321827542299, -0.024040305057387315, 0.0243222620273097}
		},
		{
			{0.06197386800254543, -0.03907688250610051, -0.008905457160361636},
			{-0.03907688250610053, 0.08505684837376129, -0.041044669925472475},
			{-0.008905457160361625, -0.041044669925472496, 0.051078487486555996}
		},
		{
			{0.0484490736151307, -0.030007157763762803, -0.006342999140559802},
			{-0.030007157763762806, 0.09268947415334647, -0.012541753100253208},
			{-0.006342999140559804, -0.012541753100253204, 0.01004235665275341}
		},
		{
			{0.10078271550741401, -0.05283782459585802, -0.014306169183709203},
			{-0.05283782459585805, 0.07487517671223892, 0.019758927612844195},
			{-0.014306169183709222, 0.019758927612844195, 0.032236828804241904}
		},
		{
			{0.05103265681638067, -0.032115972043768516, 4.8797553423596957E-4},
			{-0.03211597204376851, 0.08136364299877633, -0.04129681419601359},
			{4.879755342359752E-4, -0.04129681419601358, 0.04256055506101997}
		},
		{
			{0.1103328156584001, -0.0650148276029485, -0.0028928712047898812},
			{-0.06501482760294847, 0.3075720429420933, -0.043193821614116536},
			{-0.002892871204789889, -0.043193821614116515, 0.0193930118165929}
		},
		{
			{0.10301836240011591, -0.006174695810018473, -0.0031847232589494656},
			{-0.006174695810018475, 0.047522831041759236, 0.007207582613210221},
			{-0.0031847232589494656, 0.00720758261321022, 0.020998093438383804}
		},
		{
			{0.039242599804854686, 0.006368602452000315, -0.007455955387490595},
			{0.00636860245200031, 0.03772808592716098, -6.938338543044033E-4},
			{-0.007455955387490598, -6.938338543044124E-4, 0.003044420419775738}
		},
		{
			{0.02127825821756752, -0.0018069517873382911, -0.010906666773442293},
			{-0.001806951787338279, 0.0257193537655064, -0.009507921695755636},
			{-0.010906666773442295, -0.00950792169575564, 0.020278164838358988}
		},
		{
			{0.0457794142477603, -0.03389684482569327, -0.01084893974350772},
			{-0.033896844825693294, 0.0744613817779426, -0.022041542847398492},
			{-0.010848939743507712, -0.022041542847398517, 0.045712988273943225}
		},
		{
			{0.015628750667649623, -0.011519641088261147, 0.002690592904745919},
			{-0.011519641088261137, 0.05175330771150729, -0.032277542770352656},
			{0.002690592904745907, -0.03227754277035266, 0.031798240538356025}
		},
		{
			{0.004354689367590778, -0.009446693356867295, 6.07203964484381E-4},
			{-0.009446693356867325, 0.07031963319710402, -0.042338584516717806},
			{6.072039644843888E-4, -0.042338584516717785, 0.052476809068804385}
		},
		{
			{0.052867109917756, -0.021635631174784398, -0.011447093016988605},
			{-0.021635631174784405, 0.023882825755871195, 0.00215312384246915},
			{-0.011447093016988603, 0.00215312384246915, 0.0171432769118383}
		},
		{
			{0.04196574982126618, -0.006590491188354005, -0.005879326770915704},
			{-0.006590491188354017, 0.035104623210540725, -0.001519309694141973},
			{-0.005879326770915705, -0.0015193096941419721, 0.011859919474006293}
		},
		{
			{0.015176027755212124, -0.022063529643237934, 0.009158399292120908},
			{-0.022063529643237927, 0.07006995733984339, -0.04721621244028062},
			{0.009158399292120898, -0.04721621244028062, 0.04933258616357894}
		},
		{
			{0.025747734662144483, -0.024323025111674373, 0.002582437401562558},
			{-0.024323025111674387, 0.06058979694827679, -0.00300802089178201},
			{0.002582437401562558, -0.003008020891782009, 0.002478167480592769}
		},
		{
			{0.0634397781395197, -0.01633835508490745, -0.019698304669064755},
			{-0.01633835508490747, 0.05609751323271002, -0.013062884939731017},
			{-0.019698304669064776, -0.013062884939731007, 0.025395478010046615}
		},
		{
			{0.0484573644009549, -0.011925887259369893, 0.002290248015784848},
			{-0.011925887259369897, 0.029976200623423297, -0.005702224488378222},
			{0.002290248015784849, -0.005702224488378221, 0.007892630787495473}
		},
		{
			{0.014019183436542926, 0.001534724252446518, -0.011594697819846917},
			{0.0015347242524465189, 0.018534639273064903, -0.004901393991330007},
			{-0.011594697819846917, -0.0049013939913300116, 0.020268123839335808}
		},
		{
			{0.013565374237106098, -0.00243865145129009, -0.0017819860507245183},
			{-0.002438651451290089, 0.05187932245467833, -0.03214060635594791},
			{-0.0017819860507245163, -0.03214060635594791, 0.037788280233381794}
		},
		{
			{0.0483843282834362, -0.03130708596996902, 0.002930367487758246},
			{-0.031307085969968985, 0.08026337716589269, -0.039091322231454693},
			{0.002930367487758246, -0.03909132223145468, 0.042494751565117894}
		},
		{
			{0.011847341216483896, 0.002291050121724803, -0.011841647856121691},
			{0.0022910501217248023, 0.02237942836434988, -0.011739770197081473},
			{-0.011841647856121693, -0.011739770197081466, 0.024212242353366668}
		},
		{
			{0.02679983621097938, -0.008501821606530626, -0.006529860121726176},
			{-0.008501821606530627, 0.04589905056545421, -0.015193807509912685},
			{-0.006529860121726176, -0.015193807509912682, 0.031000860836495003}
		},
		{
			{0.04843353436028476, -0.014488473229600469, -0.023504140756500282},
			{-0.014488473229600488, 0.05097352089458383, -0.0208328796469942},
			{-0.023504140756500303, -0.0208328796469942, 0.04722070028099309}
		},
		{
			{0.048899444059053616, -0.04575542264566092, -6.088666374263682E-5},
			{-0.04575542264566092, 0.129587481477486, -0.035505341585069405},
			{-6.088666374263639E-5, -0.035505341585069405, 0.0291356574321662}
		},
		{
			{0.05226079094698879, -0.03762105979640611, -0.002133233607367852},
			{-0.037621059796406106, 0.06952527590974551, -0.018568094795610994},
			{-0.0021332336073678557, -0.018568094795610994, 0.037710169769797006}
		},
		{
			{0.07093000183371016, -0.049878957592532386, -0.009871479498237162},
			{-0.04987895759253238, 0.10526144040961306, -0.009644436679075056},
			{-0.00987147949823717, -0.009644436679075063, 0.0133817173560931}
		}
	};

	double barycentre[55][3] =
	{
		{89.7051282051282, 130.56410256410257, 167.10576923076923},
		{59.192567567567565, 157.19594594594594, 172.73648648648648},
		{173.48400852878464, 172.78251599147123, 113.14285714285714},
		{182.1602564102564, 161.69230769230768, 70.5448717948718},
		{152.8359201773836, 133.69179600886918, 63.494456762749444},
		{137.39678284182307, 90.21179624664879, 64.92225201072387},
		{217.44262295081967, 102.36065573770492, 55.09836065573771},
		{131.72706422018348, 185.80045871559633, 244.19954128440367},
		{159.08529411764707, 191.71176470588236, 223.75588235294117},
		{24.57843137254902, 113.99019607843137, 81.83333333333333},
		{218.41290322580645, 165.48387096774192, 122.43225806451613},
		{99.78382352941176, 170.92205882352943, 179.27941176470588},
		{130.24759615384616, 191.09134615384616, 168.67067307692307},
		{83.61079545454545, 138.01136363636363, 123.50568181818181},
		{223.72592592592594, 99.35555555555555, 10.607407407407408},
		{34.830357142857146, 134.80357142857142, 137.92857142857142},
		{144.9921875, 103.0234375, 94.54166666666667},
		{214.4673913043478, 185.95108695652175, 166.4945652173913},
		{107.62470862470863, 160.54079254079255, 224.52680652680652},
		{122.22527472527473, 70.78571428571429, 37.47802197802198},
		{170.6046511627907, 125.78294573643412, 155.7422480620155},
		{76.37741935483871, 78.29032258064517, 52.99677419354839},
		{28.82920792079208, 24.896039603960396, 29.14851485148515},
		{54.31509846827134, 39.52516411378556, 53.88840262582057},
		{145.50815850815852, 156.0909090909091, 91.16550116550117},
		{197.71875, 150.03125, 12.8203125},
		{188.59154929577466, 146.02012072434607, 178.84909456740442},
		{109.94609164420486, 131.6711590296496, 85.98382749326146},
		{164.57029177718832, 130.19098143236073, 102.9893899204244},
		{167.2982005141388, 159.146529562982, 200.94858611825194},
		{152.03217821782178, 136.64851485148515, 182.95049504950495},
		{194.32539682539684, 208.22222222222223, 229.6031746031746},
		{198.43991416309012, 139.57296137339057, 147.92274678111588},
		{105.60526315789474, 100.8157894736842, 116.14327485380117},
		{82.74766355140187, 75.96261682242991, 87.49299065420561},
		{224.4264705882353, 197.60294117647058, 13.308823529411764},
		{117.27625570776256, 157.60502283105023, 115.58675799086758},
		{178.14594594594595, 114.21351351351352, 88.26756756756757},
		{81.67912087912087, 173.2175824175824, 206.27472527472528},
		{8.391891891891891, 162.41216216216216, 174.86486486486487},
		{179.29310344827587, 208.2198275862069, 162.72413793103448},
		{106.29220779220779, 93.70454545454545, 54.577922077922075},
		{97.99814814814815, 199.08333333333334, 236.8351851851852},
		{143.76973684210526, 110.47368421052632, 19.355263157894736},
		{131.87469287469287, 123.28992628992629, 151.45700245700246},
		{208.9406779661017, 205.42372881355934, 89.67796610169492},
		{138.55066079295153, 177.5704845814978, 134.08149779735683},
		{121.81519507186859, 196.24845995893224, 202.54004106776182},
		{190.71564885496184, 127.34351145038168, 121.12595419847328},
		{100.31884057971014, 164.9047619047619, 146.24016563146998},
		{160.22627737226279, 109.31143552311435, 126.83698296836982},
		{190.42019543973942, 170.6026058631922, 208.0814332247557},
		{139.79084967320262, 161.53159041394335, 213.49891067538127},
		{211.2941176470588, 132.78991596638656, 95.81512605042016},
		{115.03614457831326, 139.41927710843373, 195.10361445783133}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<55;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<55;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance56clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.0262251238778015, -0.0192376348833056, -0.0023637056018266205},
		{-0.01923763488330562, 0.04216646679566239, -0.012874597788401401},
		{-0.002363705601826618, -0.012874597788401394, 0.014889304810557304}
	};

	double matrix[56][3][3] =
	{
		{
			{0.014592218955045195, -0.011280960870530007, 0.0026551296905752207},
			{-0.011280960870530023, 0.059081105003638, -0.028602106479562413},
			{0.0026551296905752237, -0.028602106479562406, 0.0281510853997097}
		},
		{
			{0.016351317938292226, -8.505853450857682E-4, -0.00930014140325835},
			{-8.505853450857695E-4, 0.0158124906578436, -0.0015529292445880386},
			{-0.009300141403258343, -0.0015529292445880388, 0.01927756524245729}
		},
		{
			{0.047605113940856404, -0.035473995462915894, 0.0021640466631003665},
			{-0.035473995462915894, 0.08041065623513588, -0.038910543866768225},
			{0.0021640466631003665, -0.038910543866768225, 0.039981916326746}
		},
		{
			{0.050392425731793845, -0.024481926771117494, -0.022120681541918593},
			{-0.02448192677111748, 0.07778836503390818, -0.05429589639356679},
			{-0.022120681541918576, -0.0542958963935668, 0.14941342608395297}
		},
		{
			{0.03389714516815791, -0.00688278549421812, -0.003024386044371533},
			{-0.006882785494218127, 0.04631131033969119, -0.0015292697529692518},
			{-0.003024386044371533, -0.0015292697529692536, 0.011488210933142205}
		},
		{
			{0.0423366817013191, -0.015037097483841627, -0.012622046275790794},
			{-0.015037097483841626, 0.09349569357931392, -0.016244539841926888},
			{-0.01262204627579079, -0.016244539841926895, 0.016082168559879997}
		},
		{
			{0.04268611276155667, -0.031035445025293044, 1.9289270865516673E-4},
			{-0.031035445025293075, 0.0757775328945042, -0.01722078254781579},
			{1.928927086551676E-4, -0.017220782547815793, 0.017482169019923395}
		},
		{
			{0.04181600630557094, -0.016749443963114206, -0.010491066422840617},
			{-0.016749443963114247, 0.15673708925245303, -0.014252649733115122},
			{-0.01049106642284062, -0.014252649733115071, 0.054727207747737205}
		},
		{
			{0.15089525374287704, -0.12648344417691304, -0.02230432100994521},
			{-0.12648344417691304, 0.1595767026478958, 0.006944943482369409},
			{-0.022304321009945213, 0.006944943482369409, 0.028958858332144607}
		},
		{
			{0.0041765977343027295, -0.004727614522148007, 0.0030450009418808467},
			{-0.004727614522148021, 0.06909181042849451, -0.04445521628942471},
			{0.0030450009418808563, -0.04445521628942471, 0.05185732690877522}
		},
		{
			{0.07428651680462577, -0.035229561756476, -0.0207101157717421},
			{-0.03522956175647599, 0.03870344727076198, 0.0035771241823916236},
			{-0.020710115771742088, 0.00357712418239162, 0.026780935726608092}
		},
		{
			{0.013062836137945514, 0.001564932201217617, -0.011372112156379606},
			{0.0015649322012176196, 0.026182146326876196, -0.01715917119202949},
			{-0.01137211215637961, -0.017159171192029487, 0.030553253943897987}
		},
		{
			{0.0427603486068537, -0.02975318067030489, 0.004380768869054182},
			{-0.02975318067030488, 0.05563780080267094, -0.005003490396495956},
			{0.004380768869054182, -0.005003490396495957, 0.00768331383385667}
		},
		{
			{0.043965718708228796, -0.013184245379496803, -0.01790444898542341},
			{-0.013184245379496806, 0.053519075940867515, -0.022192800544260396},
			{-0.017904448985423406, -0.022192800544260392, 0.03982065671630641}
		},
		{
			{0.012554057999451987, -0.005416871969232136, -0.0015889674720321514},
			{-0.005416871969232138, 0.041833970308876034, -0.03214106461652742},
			{-0.001588967472032151, -0.03214106461652741, 0.0335570149511672}
		},
		{
			{0.062179176495511204, -0.06451626534801198, 0.006871593528261396},
			{-0.06451626534801198, 0.13912557085314986, -0.04448986900447475},
			{0.006871593528261402, -0.04448986900447472, 0.034628521735530673}
		},
		{
			{0.09857194109531987, -0.011329690409191193, -8.066213392252544E-4},
			{-0.011329690409191193, 0.0692679262182706, 0.012997686164351525},
			{-8.066213392252551E-4, 0.012997686164351523, 0.017753926735914808}
		},
		{
			{0.019347622456128213, 0.00289475947158997, -0.017068047631723406},
			{0.0028947594715899643, 0.006893055527039859, 6.09669622656741E-4},
			{-0.01706804763172339, 6.096696226567391E-4, 0.018132122111677185}
		},
		{
			{0.024023537426982027, -0.0055772741253472865, -0.013547964772180917},
			{-0.005577274125347281, 0.034074696004041796, -0.009102541273571645},
			{-0.01354796477218091, -0.00910254127357165, 0.020913542031182016}
		},
		{
			{0.04714376891631724, -0.013236842127234907, -0.016522982991085903},
			{-0.01323684212723491, 0.06137873916459381, -0.029936297753916596},
			{-0.016522982991085917, -0.02993629775391661, 0.0429732899744899}
		},
		{
			{0.003399940181105998, -0.01252877825817527, 0.0030775705437550384},
			{-0.012528778258175255, 0.07422386605839484, -0.04311257079689683},
			{0.0030775705437550305, -0.04311257079689683, 0.05144700029734412}
		},
		{
			{0.038921761600516074, -0.018242374018585857, 0.004443383968832943},
			{-0.018242374018585878, 0.06247189938987106, -0.0242695965249205},
			{0.004443383968832949, -0.024269596524920507, 0.029047491727801602}
		},
		{
			{0.12394355453445009, -0.053757443071724025, -0.032159248011695826},
			{-0.05375744307172402, 0.06818603824738224, -0.004277214602595288},
			{-0.032159248011695826, -0.004277214602595284, 0.027171564757047004}
		},
		{
			{0.035854047365198205, -0.016703924832838925, -0.0027127156731395806},
			{-0.016703924832838918, 0.05275875137157532, -0.02512979172138142},
			{-0.002712715673139581, -0.02512979172138142, 0.03340779732481642}
		},
		{
			{0.0415938419093021, -0.01548437529024099, 0.002676364606343809},
			{-0.015484375290240989, 0.08245698997354015, -0.005559888616584594},
			{0.0026763646063438077, -0.005559888616584593, 0.013771997416490102}
		},
		{
			{0.07496780017548854, -0.06903321688473872, -0.005763174069919002},
			{-0.06903321688473872, 0.11411060049160707, -0.022851728020128886},
			{-0.005763174069919009, -0.022851728020128897, 0.024246590506577785}
		},
		{
			{0.06574233702279883, -0.048788215134665816, -0.010279001406626296},
			{-0.04878821513466583, 0.09657361966301013, -0.0033514266396696066},
			{-0.010279001406626296, -0.0033514266396696044, 0.013713754622199995}
		},
		{
			{0.028913584744624625, -0.017166436118903408, -0.013399314878804622},
			{-0.0171664361189034, 0.05013818175654029, -0.012779233968606397},
			{-0.013399314878804622, -0.012779233968606401, 0.023930878982920015}
		},
		{
			{0.020779643848542168, -0.019446320142031362, 0.009004568215811023},
			{-0.019446320142031383, 0.07268692380386586, -0.054672613270024165},
			{0.00900456821581103, -0.05467261327002415, 0.056886137536084264}
		},
		{
			{0.023057600753228095, 6.780326604551659E-4, -0.006326808072454334},
			{6.780326604551763E-4, 0.03846825036555679, -0.02549133386847038},
			{-0.006326808072454348, -0.02549133386847039, 0.031786709963966986}
		},
		{
			{0.030324562067874785, -0.0240162719093578, 0.0019365088215611403},
			{-0.0240162719093578, 0.050908635554727716, -0.009774019620533245},
			{0.0019365088215611411, -0.009774019620533245, 0.012813297304577604}
		},
		{
			{0.01489549624317712, -0.003114060526108479, -2.6389553189859298E-5},
			{-0.0031140605261084746, 0.0531233343908739, -0.03340200803399539},
			{-2.6389553189861033E-5, -0.0334020080339954, 0.03912975666745479}
		},
		{
			{0.021808738797114206, -0.019714974780007298, 2.5880790594448615E-4},
			{-0.0197149747800073, 0.058181468148766416, -0.006858588027810103},
			{2.588079059444874E-4, -0.006858588027810101, 0.0038319850157347603}
		},
		{
			{0.08513971428840571, -0.06383625423217415, 0.013785257087509951},
			{-0.06383625423217407, 0.12629782000175507, -0.03318614581605955},
			{0.01378525708750993, -0.03318614581605955, 0.05063512098020481}
		},
		{
			{0.11191564269129693, -0.060606156818281826, -0.007631157714653862},
			{-0.0606061568182819, 0.3027803440551848, -0.046295610710041374},
			{-0.007631157714653841, -0.04629561071004138, 0.0208134830024356}
		},
		{
			{0.05924979044899167, -0.014427701952175808, -0.012142174425881298},
			{-0.014427701952175808, 0.05555221431589686, 0.004050484457228008},
			{-0.0121421744258813, 0.004050484457228006, 0.016116172202654398}
		},
		{
			{0.061603165252810205, -0.024883375250033646, -0.006789651420723617},
			{-0.024883375250033653, 0.02693146644391991, -0.009217394221899298},
			{-0.006789651420723622, -0.009217394221899301, 0.020483572668524203}
		},
		{
			{0.04861629710669052, -0.033175467998066956, -0.008018390111064689},
			{-0.033175467998066935, 0.07810621032853186, -0.023383561746096404},
			{-0.008018390111064679, -0.02338356174609641, 0.039216912197212}
		},
		{
			{0.07986043832215943, -0.006289417300707534, -0.051302272399532486},
			{-0.0062894173007075616, 0.09295913223773855, 0.030701587614884104},
			{-0.0513022723995325, 0.030701587614884077, 0.06796883114917794}
		},
		{
			{0.05194410525926808, -0.030923842506711433, 0.0013691340476144872},
			{-0.030923842506711426, 0.07354224426253089, -0.028683109875246308},
			{0.0013691340476144854, -0.02868310987524631, 0.033062562820204824}
		},
		{
			{0.044794244498355874, -0.018511899789531182, -7.27607390496523E-4},
			{-0.018511899789531182, 0.0726491376721262, -0.012218314131824805},
			{-7.2760739049653E-4, -0.012218314131824807, 0.025386528621119002}
		},
		{
			{0.027134732890943883, -0.008667860938103875, -0.008643154584967746},
			{-0.008667860938103872, 0.036337146838727616, -0.0010267874264567652},
			{-0.008643154584967748, -0.0010267874264567626, 0.015024743946925}
		},
		{
			{0.012777329528314521, 0.001553641138404671, -0.013053395963288618},
			{0.0015536411384046728, 0.02215318824907582, -0.007766500572335806},
			{-0.01305339596328861, -0.007766500572335794, 0.020840525814375097}
		},
		{
			{0.06082856914908733, -0.03873391036772798, -0.009427870621398254},
			{-0.03873391036772802, 0.045455960866407075, 0.0045909163555989795},
			{-0.009427870621398254, 0.004590916355598976, 0.008950493847456248}
		},
		{
			{0.018065700640881196, -0.003651636404782276, -0.00523792179491224},
			{-0.0036516364047822743, 0.03609030050478429, -0.011706966779597611},
			{-0.005237921794912236, -0.011706966779597613, 0.01987431795165161}
		},
		{
			{0.028616483118652617, -0.0247555369250192, 0.005246006288032774},
			{-0.02475553692501921, 0.0697107476073518, -0.041431964490005184},
			{0.005246006288032772, -0.041431964490005184, 0.04484308879409179}
		},
		{
			{0.021043585664163884, -0.012278500199180978, -0.0031355665340057643},
			{-0.012278500199180985, 0.03560691445084633, -0.004895226124645858},
			{-0.0031355665340057626, -0.0048952261246458595, 0.0200598912178733}
		},
		{
			{0.04992048191422723, -0.022339996791161387, -0.01980600953396609},
			{-0.022339996791161377, 0.05182792277222868, -0.026836710058688304},
			{-0.019806009533966086, -0.026836710058688304, 0.05328890776430159}
		},
		{
			{0.05972698595639251, -0.008354525155256871, -0.021698914476321916},
			{-0.008354525155256878, 0.04457341772448372, -0.012571720321776794},
			{-0.021698914476321923, -0.012571720321776794, 0.03021744574806861}
		},
		{
			{0.057237911142326264, 0.01377925467457111, -0.015177698921335794},
			{0.013779254674571112, 0.023898112216327684, 0.004836674178692266},
			{-0.015177698921335794, 0.004836674178692268, 0.0075273365712669425}
		},
		{
			{0.025240799051305877, -0.003441170557477822, -0.006966720058251347},
			{-0.0034411705574778234, 0.039671373312481384, -0.012696662698961393},
			{-0.006966720058251349, -0.012696662698961393, 0.024554768547476496}
		},
		{
			{0.05156764125499978, -0.032617375786286, -0.0038727000187931304},
			{-0.03261737578628598, 0.06079528581775915, -0.018024149008022017},
			{-0.003872700018793132, -0.018024149008022017, 0.024090667920059216}
		},
		{
			{0.021452972477668315, 0.002878284608042389, -0.00631794228424993},
			{0.002878284608042389, 0.013211770028466597, 0.002544951198723891},
			{-0.006317942284249926, 0.002544951198723891, 0.007670070238554795}
		},
		{
			{0.02205629335523869, -0.010344915545880896, -0.006347652985765565},
			{-0.0103449155458809, 0.024692973082930114, -0.003637394003796649},
			{-0.006347652985765563, -0.0036373940037966474, 0.020241788617557207}
		},
		{
			{0.0269875187477147, -0.012421786661846498, -0.0020453315070989224},
			{-0.012421786661846497, 0.045455474780367405, -0.020714901893274098},
			{-0.0020453315070989245, -0.020714901893274094, 0.030946301008070096}
		},
		{
			{0.07106372632944533, -0.03109146046940784, 8.683872512029733E-4},
			{-0.031091460469407833, 0.0695667997035361, -0.014311979430922595},
			{8.68387251202969E-4, -0.0143119794309226, 0.027032226846943404}
		}
	};

	double barycentre[56][3] =
	{
		{85.5752688172043, 184.747311827957, 219.79301075268816},
		{142.43333333333334, 176.50512820512822, 130.2076923076923},
		{197.6202783300199, 137.07157057654075, 144.00795228628232},
		{135.76102088167053, 186.8399071925754, 242.34802784222737},
		{108.47426470588235, 96.84558823529412, 50.408088235294116},
		{157.09513274336283, 138.93141592920355, 184.4446902654867},
		{179.66840731070496, 169.63707571801567, 114.35770234986946},
		{28.786069651741293, 24.870646766169155, 29.059701492537314},
		{199.9071038251366, 204.52459016393442, 182.53005464480876},
		{30.47945205479452, 127.26027397260275, 131.12328767123287},
		{223.30714285714285, 98.69285714285714, 11.571428571428571},
		{123.94579945799458, 187.8970189701897, 166.94850948509486},
		{215.0222222222222, 197.87777777777777, 73.44444444444444},
		{165.92412451361866, 122.71206225680933, 152.66926070038912},
		{53.01968503937008, 155.20472440944883, 163.31496062992127},
		{149.68173258003768, 164.65348399246705, 211.86252354048963},
		{81.3067331670823, 74.60099750623442, 87.29925187032418},
		{158.55656108597285, 200.10407239819006, 162.29864253393666},
		{117.81234567901235, 156.07901234567902, 112.75061728395062},
		{189.55728155339807, 143.35339805825242, 174.35145631067962},
		{7.594405594405594, 162.43356643356643, 175.2237762237762},
		{148.3599033816425, 106.22946859903382, 111.66425120772946},
		{219.24867724867724, 174.74074074074073, 145.31216931216932},
		{177.56805807622504, 120.8584392014519, 121.91107078039927},
		{125.2530487804878, 87.0579268292683, 78.5609756097561},
		{91.8, 127.73103448275862, 169.3},
		{120.03896103896103, 142.01298701298703, 196.15367965367966},
		{94.5140562248996, 126.35742971887551, 89.98795180722891},
		{102.31981981981981, 201.17342342342343, 239.96396396396398},
		{23.545454545454547, 113.78787878787878, 81.58585858585859},
		{156.94652406417111, 140.32085561497325, 62.529411764705884},
		{127.83405172413794, 198.2176724137931, 203.76508620689654},
		{144.48591549295776, 111.3169014084507, 17.87323943661972},
		{177.48358208955224, 196.24776119402986, 228.16716417910447},
		{102.38387096774194, 101.45806451612903, 118.45161290322581},
		{77.52439024390245, 78.3719512195122, 52.94512195121951},
		{219.7887323943662, 107.76760563380282, 60.54225352112676},
		{172.78021978021977, 119.75641025641026, 91.58791208791209},
		{54.271929824561404, 39.296052631578945, 53.63377192982456},
		{205.46282973621103, 133.88489208633092, 106.66906474820144},
		{126.66956521739131, 73.17826086956522, 41.721739130434784},
		{184.66058394160584, 162.2919708029197, 71.47445255474453},
		{110.09782608695652, 169.28532608695653, 140.2663043478261},
		{195.39830508474577, 210.20338983050848, 124.08474576271186},
		{85.71801566579634, 142.63446475195823, 129.8172323759791},
		{77.84033613445378, 159.0252100840336, 197.2296918767507},
		{153.6888888888889, 160.51111111111112, 96.8395061728395},
		{184.640243902439, 162.9959349593496, 202.0548780487805},
		{131.6275, 123.065, 152.52},
		{224.625, 197.85714285714286, 6.214285714285714},
		{95.20568927789934, 163.65645514223195, 165.54048140043764},
		{150.52083333333334, 105.05654761904762, 68.48511904761905},
		{197.73809523809524, 150.1904761904762, 12.563492063492063},
		{129.62569832402235, 138.16201117318437, 83.05027932960894},
		{102.72015655577299, 176.84344422700588, 189.39921722113502},
		{113.05842696629213, 160.71011235955055, 227.04044943820224}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<56;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<56;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance57clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02748675055323049, -0.020669075848653382, -0.0018608077029590336},
		{-0.02066907584865337, 0.043212879717925534, -0.013501380778260484},
		{-0.0018608077029590336, -0.013501380778260486, 0.015268996623674602}
	};

	double matrix[57][3][3] =
	{
		{
			{0.015900599805074613, -0.022012902509863017, 0.010524558627591931},
			{-0.022012902509863007, 0.07814509564654985, -0.05776495757642762},
			{0.01052455862759193, -0.05776495757642762, 0.061078736301483263}
		},
		{
			{0.004494913443446314, -0.005232443782291989, 0.003132954281686092},
			{-0.00523244378229199, 0.0694265269183006, -0.045760726170093205},
			{0.0031329542816860914, -0.0457607261700932, 0.05133622039583741}
		},
		{
			{0.058620978060781495, -0.034188925541867726, -0.006523363855821278},
			{-0.03418892554186773, 0.044467275990190853, 0.0027837083339843968},
			{-0.006523363855821279, 0.002783708333984402, 0.014665707149765802}
		},
		{
			{0.014275164773191906, 0.001253954840662928, -0.009445226125484145},
			{0.0012539548406629228, 0.03644114303267387, -0.007929585681237764},
			{-0.009445226125484136, -0.007929585681237764, 0.020524206552688756}
		},
		{
			{0.06512751633415341, -0.03659069318597674, -0.0027853284791375813},
			{-0.036590693185976714, 0.06616736941365882, -0.02412805956031198},
			{-0.002785328479137584, -0.024128059560311985, 0.040943442654839485}
		},
		{
			{0.01847699407251289, -0.009118746740821864, 0.0013698221193055161},
			{-0.009118746740821852, 0.06183199481331073, -0.03396746973745839},
			{0.0013698221193055153, -0.0339674697374584, 0.0372065010592311}
		},
		{
			{0.04854394982509359, -0.027808840545401625, -0.012549374265550396},
			{-0.027808840545401625, 0.08077584241828986, -0.05174000096570069},
			{-0.012549374265550403, -0.051740000965700673, 0.13113142484572501}
		},
		{
			{0.025155920002088883, -0.013693041658642699, -0.004004398903200297},
			{-0.013693041658642699, 0.041163278654781095, -0.018441207374955915},
			{-0.004004398903200293, -0.018441207374955908, 0.031025810541164302}
		},
		{
			{0.11012092734003295, -0.03350500951440786, -0.013485029617501188},
			{-0.03350500951440788, 0.1775927531061681, 0.01862892381555952},
			{-0.013485029617501195, 0.018628923815559518, 0.022730272123944514}
		},
		{
			{0.004607641615852319, -0.009992206030407786, 0.0013224042026888762},
			{-0.009992206030407796, 0.06792143725518072, -0.04046922099058572},
			{0.0013224042026888858, -0.040469220990585725, 0.05200345478764273}
		},
		{
			{0.06346820767879019, -0.02957125798327463, -0.015005336292174909},
			{-0.029571257983274615, 0.02913290130134922, 0.004822922455842937},
			{-0.015005336292174905, 0.004822922455842937, 0.018228103550082402}
		},
		{
			{0.01912485115477201, 0.002129535310830724, -0.006051822287821934},
			{0.002129535310830721, 0.014561369389513691, 0.003214118343540732},
			{-0.006051822287821933, 0.0032141183435407316, 0.007808387042886949}
		},
		{
			{0.04258439142600598, -0.020773347332390998, 7.360655602761734E-4},
			{-0.020773347332391005, 0.04833648859017325, -0.00591756657293615},
			{7.360655602761748E-4, -0.005917566572936151, 0.008381067091247758}
		},
		{
			{0.058363554860209804, -0.059217560007115276, 0.0037757312628606625},
			{-0.05921756000711534, 0.12703536733621712, -0.028503515914847316},
			{0.0037757312628606673, -0.028503515914847326, 0.02247471399591371}
		},
		{
			{0.0768944702384255, -0.028614773500541365, -0.006445249578695538},
			{-0.02861477350054136, 0.034448416202150355, -0.01798204787707009},
			{-0.0064452495786955395, -0.017982047877070105, 0.027179215491609506}
		},
		{
			{0.048459221931575536, -0.0131926575143969, -0.014021898671916297},
			{-0.013192657514396893, 0.0658408793725652, -0.0344504332565355},
			{-0.014021898671916293, -0.0344504332565355, 0.04986612836410931}
		},
		{
			{0.05023222710862113, -0.02092037803276467, -0.023365572195936768},
			{-0.020920378032764676, 0.04574874124163253, -0.022581835764044128},
			{-0.023365572195936768, -0.022581835764044125, 0.0527837513078407}
		},
		{
			{0.02638854878450037, -0.0053102724055872335, -0.0070005287108839635},
			{-0.005310272405587232, 0.03448693649877212, -0.004304658174279153},
			{-0.007000528710883964, -0.004304658174279161, 0.01356434874790271}
		},
		{
			{0.0500810955779858, -0.029685566313145006, -0.0016110742056052113},
			{-0.02968556631314502, 0.08327786815249924, -0.03959107018809279},
			{-0.001611074205605213, -0.03959107018809281, 0.038891142585912}
		},
		{
			{0.014285695623733117, 0.0021129451942683538, -0.013706665100243313},
			{0.0021129451942683546, 0.019613180677898107, -0.011964058165471312},
			{-0.013706665100243319, -0.011964058165471317, 0.027922030152060226}
		},
		{
			{0.023057600754074124, 6.780326608967831E-4, -0.006326808074478456},
			{6.780326608967796E-4, 0.03846825037225434, -0.02549133388148384},
			{-0.006326808074478456, -0.025491333881483842, 0.03178670997828762}
		},
		{
			{0.028396071353166893, -0.013987929035465885, -0.012786333007567607},
			{-0.0139879290354659, 0.040141671080804686, -0.009859978962800508},
			{-0.012786333007567603, -0.009859978962800506, 0.02273079204501211}
		},
		{
			{0.032167693329372804, -0.029010212719882102, 0.004889933144698661},
			{-0.0290102127198821, 0.06292591723567256, -0.0053502726375349256},
			{0.00488993314469866, -0.005350272637534923, 0.002971815788770861}
		},
		{
			{0.04370511177861003, -0.03054667165380252, -0.0016666985979918124},
			{-0.030546671653802517, 0.09946030733155159, 0.00501898361593741},
			{-0.0016666985979918122, 0.005018983615937412, 0.015695998452975295}
		},
		{
			{0.06593123895154222, -0.049362934310300026, -0.009786413074252293},
			{-0.04936293431030007, 0.0934283558826683, -0.0023019308913222454},
			{-0.009786413074252296, -0.002301930891322234, 0.014473427922582102}
		},
		{
			{0.04698539982725407, -0.0351063625820187, 0.003623293052020842},
			{-0.03510636258201869, 0.07700015822597517, -0.023711478088807192},
			{0.0036232930520208447, -0.023711478088807195, 0.018064173049235795}
		},
		{
			{0.03139870550569986, -0.02231717752260217, 0.005419613941736282},
			{-0.02231717752260218, 0.06756316053408166, -0.03966653564672369},
			{0.005419613941736292, -0.039666535646723705, 0.041248929750052496}
		},
		{
			{0.029454833685055068, -0.007477914057274715, -0.00854445303699658},
			{-0.007477914057274722, 0.051085584910497146, -0.029895054120088305},
			{-0.008544453036996582, -0.029895054120088294, 0.039207316679658315}
		},
		{
			{0.10506900633095408, -0.010485512147893799, -0.044105341720185265},
			{-0.010485512147893769, 0.07548670358886525, -0.04549628494691462},
			{-0.04410534172018524, -0.045496284946914586, 0.12333720594527203}
		},
		{
			{0.048142610109106435, -0.022712858941426214, -0.009064864312003503},
			{-0.02271285894142621, 0.055209823363531293, 0.005832552597754264},
			{-0.00906486431200351, 0.005832552597754258, 0.015998302989511402}
		},
		{
			{0.06782198801130243, 0.009494913836169825, -0.04506396490932848},
			{0.009494913836169822, 0.21340029238857897, -0.004739547337874215},
			{-0.0450639649093285, -0.004739547337874207, 0.03583138748564832}
		},
		{
			{0.03553125635818369, -0.024034044587339192, 0.00268470370692452},
			{-0.024034044587339185, 0.060871554906392254, -0.02342826818846861},
			{0.002684703706924514, -0.023428268188468597, 0.0317245895810142}
		},
		{
			{0.09973400088650439, -0.020265170874521194, 0.005358816300791807},
			{-0.0202651708745212, 0.08657967186456779, 0.007941726641576304},
			{0.005358816300791805, 0.007941726641576306, 0.0219978859365515}
		},
		{
			{0.030435281377695415, -0.025258513547689924, 0.0024642751996607113},
			{-0.025258513547689924, 0.05027315978721371, -0.00951397811827288},
			{0.002464275199660712, -0.009513978118272877, 0.01368784611015781}
		},
		{
			{0.1253557402212469, -0.034026120508685066, -0.020867598379558393},
			{-0.03402612050868509, 0.04017259332266171, 0.005242586794378034},
			{-0.020867598379558403, 0.005242586794378029, 0.0232512004204442}
		},
		{
			{0.022356926778644717, 5.014908720756394E-4, -0.0125286011916352},
			{5.014908720756429E-4, 0.025881984748683706, -0.007195999913371085},
			{-0.012528601191635205, -0.007195999913371085, 0.0174521557623648}
		},
		{
			{0.04529251864708098, -0.010967400342933805, -0.003274767538132534},
			{-0.010967400342933795, 0.068418309310528, -0.010193999692836193},
			{-0.003274767538132539, -0.010193999692836207, 0.024298816956597}
		},
		{
			{0.0520254534127163, -0.04362654713845823, -0.002566967008371713},
			{-0.04362654713845822, 0.07357597446599197, -0.015129225325661104},
			{-0.0025669670083717146, -0.015129225325661095, 0.026794777181124187}
		},
		{
			{0.04014015920003911, -0.025012641198905713, -0.0022390855361241425},
			{-0.025012641198905707, 0.06870671829243172, -0.013688045958547806},
			{-0.002239085536124139, -0.013688045958547801, 0.016556657382268795}
		},
		{
			{0.014234562191762109, -0.010321191865360095, 8.531551080622471E-4},
			{-0.010321191865360084, 0.05460747916710949, -0.02737368959579208},
			{8.531551080622445E-4, -0.027373689595792082, 0.025996640313137993}
		},
		{
			{0.1142651128676139, -0.05190349784133934, -0.021313548148369894},
			{-0.05190349784133934, 0.08735421694948546, -0.0218959053528238},
			{-0.021313548148369887, -0.02189590535282379, 0.0270777704289846}
		},
		{
			{0.05872083490871899, -0.06775957903582028, 0.030107580830837973},
			{-0.0677595790358203, 0.3250223366701871, -0.013993720871486322},
			{0.030107580830837956, -0.013993720871486304, 0.019561969051017696}
		},
		{
			{0.014315569435202208, 0.0011303821262613105, -0.010358338576915102},
			{0.0011303821262613105, 0.017131997429698287, -0.004303358235731913},
			{-0.010358338576915102, -0.004303358235731908, 0.019290391496793187}
		},
		{
			{0.07641791542756644, -0.06379535281377671, -0.006002448118858105},
			{-0.0637953528137767, 0.11229397996805497, -0.022697683398448305},
			{-0.006002448118858118, -0.022697683398448302, 0.026710416644453807}
		},
		{
			{0.08036172377342339, -0.05728100764502297, 0.011024398787922926},
			{-0.057281007645022905, 0.13604706189790994, -0.028909499321916082},
			{0.011024398787922919, -0.02890949932191609, 0.050170617364563824}
		},
		{
			{0.05988258584083593, -0.024704420800054493, -0.007905693234657906},
			{-0.02470442080005448, 0.04816505347313317, -0.011012573066562312},
			{-0.007905693234657904, -0.011012573066562312, 0.021870755739844303}
		},
		{
			{0.0416412643420221, 0.008692308713209243, -0.007993293895262276},
			{0.008692308713209243, 0.03435496392835473, -0.0010284496234467927},
			{-0.007993293895262278, -0.0010284496234467886, 0.0031361349061760093}
		},
		{
			{0.021203454486817604, -0.011497116853788406, -0.004368739173771306},
			{-0.011497116853788396, 0.030383780406771994, -0.004597307994139908},
			{-0.004368739173771308, -0.004597307994139905, 0.0199006834562712}
		},
		{
			{0.04889862897468342, -0.02407076366554041, -0.010522116636752697},
			{-0.024070763665540416, 0.05205040051186463, -0.00888772876155797},
			{-0.010522116636752704, -0.008887728761557967, 0.028438395834366192}
		},
		{
			{0.06061197477711344, -0.03951429763302956, -8.144836431914016E-4},
			{-0.039514297633029605, 0.08286840049554464, -0.03286404363893842},
			{-8.144836431913834E-4, -0.03286404363893839, 0.03567554072276239}
		},
		{
			{0.061363788930229306, -0.033104678154865605, -0.0016852570292619348},
			{-0.03310467815486563, 0.07265833506690332, -0.03265688573535342},
			{-0.0016852570292619205, -0.032656885735353434, 0.040060371252815405}
		},
		{
			{0.2566384779292128, -0.1255960505403502, -0.1355271397775153},
			{-0.1255960505403502, 0.10386964617331543, 0.06220250153196493},
			{-0.13552713977751532, 0.062202501531964896, 0.07197084036348284}
		},
		{
			{0.022223232930672798, -0.010600992627122913, -0.006862104807510995},
			{-0.010600992627122913, 0.023865599311199012, -0.003422836630548435},
			{-0.006862104807510998, -0.003422836630548427, 0.021082145560258905}
		},
		{
			{0.04460367672629632, -0.014740516394742498, -0.0031130506581640216},
			{-0.0147405163947425, 0.0538869134335938, -0.001679090853226161},
			{-0.003113050658164019, -0.0016790908532261573, 0.015225774267434903}
		},
		{
			{0.016590413162811703, -0.00117572637960839, -0.007563021010701956},
			{-0.0011757263796083892, 0.029798096345304607, -0.011240704527253802},
			{-0.007563021010701959, -0.011240704527253804, 0.022288743295227502}
		},
		{
			{0.0122299555044551, -0.004421977239826498, -0.003151973762435101},
			{-0.0044219772398265, 0.04200645469325887, -0.03461931193205129},
			{-0.0031519737624351027, -0.0346193119320513, 0.03865859879473832}
		},
		{
			{0.04328028073277995, -0.029811032196092123, -0.00838281727206876},
			{-0.029811032196092133, 0.09464987901362758, -0.024590277216371595},
			{-0.00838281727206875, -0.02459027721637162, 0.02491674232737652}
		}
	};

	double barycentre[57][3] =
	{
		{100.96179775280899, 201.17977528089887, 239.75056179775282},
		{29.56578947368421, 128.56578947368422, 132.93421052631578},
		{222.7530864197531, 96.87654320987654, 16.32716049382716},
		{99.95612431444242, 165.92504570383912, 154.91042047531994},
		{110.86129753914989, 160.3020134228188, 225.04474272930648},
		{126.63135593220339, 197.99364406779662, 204.15677966101694},
		{134.10407239819006, 186.55656108597285, 243.26470588235293},
		{102.52097902097903, 175.65034965034965, 185.01048951048952},
		{24.609375, 20.578125, 24.4609375},
		{8.110344827586207, 162.57931034482758, 175.13793103448276},
		{181.82251082251082, 209.47619047619048, 169.00865800865802},
		{197.93650793650792, 149.06349206349208, 11.753968253968255},
		{215.31060606060606, 202.65151515151516, 100.9469696969697},
		{148.00595238095238, 166.53373015873015, 214.3968253968254},
		{221.48366013071896, 116.7124183006536, 70.13071895424837},
		{190.94104308390024, 148.26757369614512, 179.24036281179139},
		{184.30588235294118, 166.21411764705883, 205.27058823529413},
		{184.80936454849498, 164.752508361204, 72.85284280936455},
		{197.06054279749478, 136.82463465553235, 146.93945720250522},
		{131.0897435897436, 191.60256410256412, 168.94102564102565},
		{24.102040816326532, 114.60204081632654, 82.44897959183673},
		{94.90196078431373, 125.97647058823529, 88.79607843137255},
		{145.03614457831324, 109.01204819277109, 20.542168674698797},
		{121.6842105263158, 92.02631578947368, 90.1015037593985},
		{120.54880694143166, 142.14316702819957, 195.68329718004338},
		{166.88795518207283, 132.5966386554622, 104.63865546218487},
		{78.24603174603175, 158.51322751322752, 194.17989417989418},
		{171.84285714285716, 117.98571428571428, 134.38367346938776},
		{38.651898734177216, 37.651898734177216, 44.936708860759495},
		{76.72185430463576, 80.85761589403974, 53.04635761589404},
		{69.91836734693878, 32.78231292517007, 39.4421768707483},
		{155.38020833333334, 105.28125, 106.48958333333333},
		{83.97222222222223, 75.80833333333334, 85.41944444444445},
		{156.93121693121694, 140.25132275132276, 61.97089947089947},
		{125.78846153846153, 112.22307692307692, 130.71153846153845},
		{117.2483660130719, 157.79738562091504, 115.5925925925926},
		{137.1082621082621, 87.65242165242165, 59.50997150997151},
		{162.46666666666667, 113.23456790123457, 78.7432098765432},
		{176.1013698630137, 176.23835616438356, 118.85753424657534},
		{85.61679790026247, 183.95800524934384, 217.4461942257218},
		{216.66, 183.735, 162.26},
		{90.95327102803738, 100.3411214953271, 116.71028037383178},
		{137.15367965367966, 177.82683982683983, 135.17748917748918},
		{94.25078369905957, 128.12225705329155, 168.12225705329155},
		{177.58878504672896, 197.69470404984423, 228.46105919003116},
		{139.7124681933842, 125.03307888040712, 158.23918575063612},
		{222.5064935064935, 197.72727272727272, 17.636363636363637},
		{153.0, 163.09113924050632, 97.58227848101266},
		{172.23908045977012, 128.97701149425288, 164.4735632183908},
		{192.1846153846154, 122.41098901098901, 104.26153846153846},
		{206.8416149068323, 146.20186335403727, 117.9223602484472},
		{59.53, 45.495, 71.305},
		{128.75414364640883, 138.68508287292818, 82.7707182320442},
		{110.63585434173669, 86.05042016806723, 45.254901960784316},
		{86.41145833333333, 144.02864583333334, 129.2421875},
		{54.45348837209303, 154.45736434108528, 163.75968992248062},
		{157.20330969267138, 143.70921985815602, 190.54137115839242}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<57;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<57;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance58clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026499947756911592, -0.019412267810155783, -0.0021364214593228553},
		{-0.019412267810155783, 0.04317991046513969, -0.013812747805540093},
		{-0.0021364214593228544, -0.013812747805540097, 0.015320135422195715}
	};

	double matrix[58][3][3] =
	{
		{
			{0.03125116120827638, -0.02807036362836667, 0.006243502220534784},
			{-0.028070363628366686, 0.05166491325346039, -0.0119844517926918},
			{0.006243502220534786, -0.011984451792691794, 0.011591851619887992}
		},
		{
			{0.04413050507698756, -0.012962191634248462, -0.005446148797742245},
			{-0.012962191634248468, 0.06859175616885024, -0.00867238760503265},
			{-0.0054461487977422495, -0.008672387605032642, 0.02310870118086799}
		},
		{
			{0.04577631446077713, -0.015718730375069614, -0.013007485011217304},
			{-0.015718730375069625, 0.04442593204746153, 0.0018064901013456057},
			{-0.013007485011217311, 0.0018064901013456023, 0.016360863598135707}
		},
		{
			{0.09281228379545901, -0.05802460404290792, -0.005506062640212556},
			{-0.05802460404290795, 0.10075280262684906, -0.0138540489615902},
			{-0.005506062640212556, -0.013854048961590208, 0.051511311940350676}
		},
		{
			{0.05402063537055367, -0.04095216445869457, 0.0026785576485489075},
			{-0.04095216445869456, 0.08391323792228635, -0.03869148216925957},
			{0.0026785576485489062, -0.038691482169259564, 0.04047979963012109}
		},
		{
			{0.016482130093079122, -0.0016827215237212294, -0.006927400155300257},
			{-0.0016827215237212294, 0.0271967634217058, -0.01061292114323809},
			{-0.006927400155300257, -0.010612921143238092, 0.021891855728167292}
		},
		{
			{0.03486579146859318, -0.02631784487625849, 2.2975384553665032E-4},
			{-0.02631784487625851, 0.07125733806554038, -0.021728665143884978},
			{2.2975384553665726E-4, -0.02172866514388497, 0.03050073716807298}
		},
		{
			{0.10809620081104701, -0.0075390790386156755, -0.003820854323190152},
			{-0.0075390790386156755, 0.04086844748734424, 5.990164716569508E-4},
			{-0.003820854323190152, 5.990164716569474E-4, 0.017708007014671907}
		},
		{
			{0.058536640011211595, -0.0320848629518995, -0.001031990771876099},
			{-0.03208486295189951, 0.07205751212989414, -0.034560262642750764},
			{-0.0010319907718761051, -0.03456026264275077, 0.038849474120021106}
		},
		{
			{0.058490783613116805, -0.012824577563160706, -0.001335835514061111},
			{-0.012824577563160706, 0.03931875927254906, -0.0077702404807511605},
			{-0.001335835514061115, -0.007770240480751169, 0.025153431972970198}
		},
		{
			{0.0043084558506395, -0.005055088705504792, 0.003301424419674196},
			{-0.005055088705504784, 0.06909761203254258, -0.04671596734741548},
			{0.0033014244196741898, -0.046715967347415496, 0.05318667871120028}
		},
		{
			{0.02963550328926979, -0.008322994977338224, -0.008557963368254519},
			{-0.008322994977338224, 0.036702030414171916, -0.003062715677503023},
			{-0.008557963368254524, -0.0030627156775030243, 0.008271103681735094}
		},
		{
			{0.08267170006464754, -0.02135199439972983, -0.014227200766988192},
			{-0.02135199439972983, 0.10144162996103101, -0.026876267222636613},
			{-0.014227200766988194, -0.02687626722263659, 0.06779598553673348}
		},
		{
			{0.039242599821148604, 0.006368602459196444, -0.007455955386425826},
			{0.006368602459196451, 0.0377280859084652, -6.938338568607668E-4},
			{-0.007455955386425827, -6.938338568607673E-4, 0.0030444204203577824}
		},
		{
			{0.04457894468336727, -0.017955860116581405, 2.948250890293817E-4},
			{-0.01795586011658141, 0.07245137890806382, -0.005051744016893031},
			{2.9482508902938247E-4, -0.005051744016893031, 0.015407261217136998}
		},
		{
			{0.004659793701588125, -0.012459303375628653, 0.0017612877261263546},
			{-0.012459303375628642, 0.07185971232048385, -0.043072337720524906},
			{0.0017612877261263486, -0.043072337720524906, 0.05201367752026052}
		},
		{
			{0.027575761134657893, -0.012755675646112397, -0.004170599599938488},
			{-0.01275567564611239, 0.041592469563390785, -0.0198828311165703},
			{-0.004170599599938495, -0.01988283111657029, 0.03164253900540641}
		},
		{
			{0.12217482276220208, -0.04589746125594131, -0.020077654242789844},
			{-0.04589746125594125, 0.24698454994802266, -0.07708161998165407},
			{-0.020077654242789855, -0.07708161998165405, 0.034470296359341124}
		},
		{
			{0.014757955903090281, -0.012351059401793773, 0.0020154797740685516},
			{-0.012351059401793773, 0.05897213938591644, -0.029542320830945712},
			{0.0020154797740685572, -0.02954232083094572, 0.027265617368124804}
		},
		{
			{0.06976548236878696, -0.04600413178396721, -0.01232265205738399},
			{-0.04600413178396718, 0.10185189297695611, 0.0014086579303212456},
			{-0.012322652057383985, 0.0014086579303212402, 0.014340363159397795}
		},
		{
			{0.059941924155487436, -0.024321383603383002, -0.015525289267140103},
			{-0.02432138360338299, 0.027837674193081793, 0.006629884924614049},
			{-0.0155252892671401, 0.006629884924614052, 0.018103754842751}
		},
		{
			{0.021911362757061476, 0.012043450968825095, -0.003965291253095223},
			{0.012043450968825087, 0.033194965985119014, -0.007097888009779779},
			{-0.003965291253095223, -0.007097888009779783, 0.02486099112127131}
		},
		{
			{0.056423792158740715, -0.04207934755538289, -0.0110698475226721},
			{-0.042079347555382896, 0.08735167724358182, -0.0277215644580008},
			{-0.01106984752267209, -0.02772156445800082, 0.07556008367375129}
		},
		{
			{0.24895514217827902, -0.051972496697345466, -0.11889340401474012},
			{-0.05197249669734543, 0.012484193186113894, 0.018870697197778785},
			{-0.11889340401474008, 0.018870697197778764, 0.0784406962448585}
		},
		{
			{0.009602989722042024, -0.0035037962463461605, -0.0024141323168523},
			{-0.0035037962463461587, 0.0419011744479346, -0.0353892432080416},
			{-0.002414132316852299, -0.0353892432080416, 0.039041034322017304}
		},
		{
			{0.06142678830694614, -0.01970315689625617, 0.00983453997854553},
			{-0.01970315689625618, 0.06515062773540899, -0.0013434346994242812},
			{0.009834539978545533, -0.0013434346994242862, 0.0027901886925434495}
		},
		{
			{0.025302493200393725, -0.016830246927040604, -0.0039964697927087865},
			{-0.016830246927040594, 0.040785947598973145, -0.005972151761948128},
			{-0.003996469792708788, -0.005972151761948126, 0.0170489569660597}
		},
		{
			{0.05339444135128526, -0.009298237623850236, -0.022244929951629484},
			{-0.009298237623850247, 0.10102591745409704, -0.038454674742373976},
			{-0.022244929951629494, -0.03845467474237396, 0.03289729384130878}
		},
		{
			{0.07120326023706827, -0.031313093287158325, -0.006496191220365488},
			{-0.031313093287158325, 0.07627459059021958, -0.004192016530348317},
			{-0.006496191220365483, -0.004192016530348317, 0.0340466875927197}
		},
		{
			{0.06544819505678019, -0.023838999150331962, -0.00663767614850545},
			{-0.02383899915033194, 0.036213436364927125, -0.02089770407150169},
			{-0.006637676148505439, -0.0208977040715017, 0.030849271764715896}
		},
		{
			{0.0370794712770829, -0.013837891632712592, -0.003943660566685669},
			{-0.013837891632712578, 0.05002973207282304, -0.025576163831226913},
			{-0.003943660566685669, -0.025576163831226906, 0.03759015942435543}
		},
		{
			{0.022426636738478598, -0.021998364003369384, 0.011061829689895095},
			{-0.021998364003369415, 0.08021162193281788, -0.05995587761698007},
			{0.011061829689895117, -0.05995587761698004, 0.06058872700604416}
		},
		{
			{0.05114993353134417, -0.020740459511179886, -0.013123344500485804},
			{-0.0207404595111799, 0.053645522674005124, -0.012892432466787599},
			{-0.01312334450048581, -0.012892432466787597, 0.031018086227671608}
		},
		{
			{0.06595167774548114, -0.04657915501336256, -0.005077651924733643},
			{-0.04657915501336255, 0.08548742984719132, -0.019169776714446612},
			{-0.005077651924733646, -0.019169776714446606, 0.028683977118887406}
		},
		{
			{0.02218214776326387, -0.010567375354453191, -0.006961545899955073},
			{-0.010567375354453188, 0.022418076319321304, -0.0026901431370339995},
			{-0.006961545899955072, -0.0026901431370339943, 0.022849252929135998}
		},
		{
			{0.013297687853544893, 7.369775179764939E-4, -0.010272754164665896},
			{7.369775179764939E-4, 0.016251087960658998, -0.004546461422675119},
			{-0.01027275416466589, -0.004546461422675118, 0.020458190579206115}
		},
		{
			{0.08116787504217755, -0.029484155181503095, -0.06094484661529621},
			{-0.029484155181503102, 0.07588441157967357, 0.035760041545742145},
			{-0.0609448466152962, 0.03576004154574215, 0.059268484448748056}
		},
		{
			{0.02641496070969734, -0.027865657315070947, 0.007117336910265741},
			{-0.027865657315070957, 0.09040138566731984, -0.033223706494871934},
			{0.00711733691026574, -0.033223706494871934, 0.03363595947011081}
		},
		{
			{0.03998448016236697, -0.027501062419314784, -0.00159283134936304},
			{-0.027501062419314774, 0.07215866658974573, -0.014860839419787494},
			{-0.0015928313493630366, -0.0148608394197875, 0.0166805520102588}
		},
		{
			{0.027263371703134233, -0.023372726604685746, 0.005722585835813978},
			{-0.023372726604685718, 0.06943513678088155, -0.04158550541847253},
			{0.005722585835813965, -0.04158550541847252, 0.044453080663917496}
		},
		{
			{0.021452972467190988, 0.0028782846042199, -0.006317942281382837},
			{0.0028782846042198994, 0.013211770036023595, 0.002544951202470451},
			{-0.006317942281382844, 0.0025449512024704525, 0.007670070244796056}
		},
		{
			{0.07297916663529512, 0.024328066001771217, -8.376950872329599E-4},
			{0.02432806600177123, 0.09568750032860047, -0.06369487076938826},
			{-8.376950872329633E-4, -0.06369487076938823, 0.04592936537365028}
		},
		{
			{0.04091705633179314, -0.026936733475277502, 6.517398687373198E-4},
			{-0.026936733475277502, 0.0536256024581787, -0.008106292815319051},
			{6.51739868737319E-4, -0.008106292815319051, 0.008639518661527481}
		},
		{
			{0.05072704596385983, -0.05023478918166315, 0.005638546242679757},
			{-0.05023478918166318, 0.12211152695633615, -0.03591676519526971},
			{0.005638546242679762, -0.03591676519526972, 0.020210063888781195}
		},
		{
			{0.11238668035593606, -0.0502474704781046, -0.02469293627439039},
			{-0.050247470478104635, 0.08592991018091073, -0.021930301980559307},
			{-0.02469293627439041, -0.021930301980559286, 0.033737431266248404}
		},
		{
			{0.01550626372718469, 9.87495330384663E-4, -0.009588498980323884},
			{9.874953303846664E-4, 0.036605767789653604, -0.008643336447748238},
			{-0.009588498980323887, -0.008643336447748236, 0.020603871362721213}
		},
		{
			{0.0447272754774683, -0.042103254939403666, -0.015153808386276248},
			{-0.04210325493940368, 0.06777232115803214, -0.016657570311403958},
			{-0.015153808386276252, -0.016657570311403944, 0.039115017434404445}
		},
		{
			{0.02208145576209913, 0.0011361709929168622, -0.012215067337481135},
			{0.001136170992916857, 0.0256355516243453, -0.00678087433993052},
			{-0.012215067337481131, -0.006780874339930528, 0.016644265876453533}
		},
		{
			{0.03515870330753771, 4.141127027927809E-4, -0.00204209922350905},
			{4.1411270279278437E-4, 0.03814092960855261, -0.002908965811432768},
			{-0.0020420992235090463, -0.0029089658114327664, 0.010652253886514699}
		},
		{
			{0.044405869665967476, -0.007049666224406814, -0.021258240649925916},
			{-0.00704966622440681, 0.06985465568604193, -0.03936176897501377},
			{-0.021258240649925902, -0.03936176897501377, 0.052846117044190524}
		},
		{
			{0.05664020934120578, -0.0356346892018396, -0.010994318620745389},
			{-0.03563468920183961, 0.062104879660523554, -0.02641961527793591},
			{-0.010994318620745394, -0.026419615277935914, 0.04749594067046318}
		},
		{
			{0.026578943125487402, -0.011597334574320894, -0.013504762465036495},
			{-0.011597334574320894, 0.056331748752974455, -0.020726533688573197},
			{-0.013504762465036497, -0.020726533688573193, 0.026622329498843876}
		},
		{
			{0.01800372913562298, -0.018388374010416268, 0.017705547596889366},
			{-0.018388374010416264, 0.028698462904120717, -0.011092416904261802},
			{0.017705547596889356, -0.011092416904261795, 0.022341076312817388}
		},
		{
			{0.014260770911243519, 0.0022667900849182793, -0.013827868710715617},
			{0.0022667900849182767, 0.018398936422961792, -0.011351520910478401},
			{-0.013827868710715618, -0.011351520910478393, 0.0276564986072831}
		},
		{
			{0.08613628695638408, -0.060209663579024846, -0.007785662440373384},
			{-0.060209663579024846, 0.11165759885180193, -0.020700451723615294},
			{-0.007785662440373379, -0.020700451723615305, 0.021615460195679895}
		},
		{
			{0.07329758574840294, -0.023312653935677573, 0.00608119295212875},
			{-0.02331265393567756, 0.06523200598778606, -0.008741704160409718},
			{0.006081192952128749, -0.00874170416040972, 0.021421321234501797}
		},
		{
			{0.058620978060781495, -0.034188925541867726, -0.006523363855821278},
			{-0.03418892554186773, 0.044467275990190853, 0.0027837083339843968},
			{-0.006523363855821279, 0.002783708333984402, 0.014665707149765802}
		},
		{
			{0.11012092639591396, -0.03350501040190104, -0.013485025842010483},
			{-0.03350501040190106, 0.17759275611789724, 0.01862892394408025},
			{-0.013485025842010478, 0.018628923944080267, 0.022730270104206213}
		}
	};

	double barycentre[58][3] =
	{
		{156.31767337807605, 135.46308724832215, 61.84340044742729},
		{135.53229974160206, 84.36950904392765, 57.093023255813954},
		{75.51209677419355, 81.00403225806451, 49.99596774193548},
		{186.28571428571428, 201.52073732718895, 228.01382488479263},
		{196.62310606060606, 137.4810606060606, 150.34848484848484},
		{86.40759493670886, 145.4227848101266, 131.4886075949367},
		{157.76302521008404, 110.77142857142857, 91.96134453781512},
		{81.95588235294117, 84.58088235294117, 91.13235294117646},
		{206.00980392156862, 141.12254901960785, 116.2328431372549},
		{144.5342105263158, 111.53947368421052, 130.76315789473685},
		{26.88235294117647, 128.2941176470588, 135.5441176470588},
		{183.8758865248227, 166.854609929078, 71.05319148936171},
		{37.63013698630137, 35.96232876712329, 44.034246575342465},
		{224.6027397260274, 197.53424657534248, 16.315068493150687},
		{124.53629032258064, 94.07661290322581, 93.3225806451613},
		{7.453237410071942, 162.86330935251797, 175.88489208633092},
		{103.40273037542661, 176.40443686006827, 187.1740614334471},
		{99.93280632411067, 103.85770750988142, 122.87351778656127},
		{86.2621359223301, 182.90776699029126, 220.72087378640776},
		{114.57603686635944, 142.27188940092165, 199.74654377880185},
		{181.13025210084032, 208.57142857142858, 167.30252100840337},
		{43.85964912280702, 123.80701754385964, 95.19298245614036},
		{146.16594827586206, 186.79956896551724, 236.95689655172413},
		{67.33548387096774, 52.438709677419354, 83.75483870967741},
		{52.934156378600825, 155.41152263374485, 163.7366255144033},
		{141.7361963190184, 103.91411042944786, 18.15950920245399},
		{154.05191873589166, 159.78329571106096, 96.72911963882619},
		{128.89893617021278, 125.9122340425532, 162.81648936170214},
		{119.676, 163.758, 227.992},
		{221.32467532467533, 116.12987012987013, 70.15584415584415},
		{177.3294701986755, 120.55132450331126, 123.58940397350993},
		{105.4416826003824, 199.64435946462714, 240.60420650095602},
		{167.00666666666666, 127.55833333333334, 161.34},
		{185.42890442890442, 124.82051282051282, 92.71095571095572},
		{128.58092485549133, 139.59537572254337, 83.49421965317919},
		{138.4279176201373, 178.45308924485127, 135.6315789473684},
		{62.13389121338912, 40.53556485355649, 54.80334728033473},
		{129.49290060851928, 196.3732251521298, 203.72413793103448},
		{176.36828644501279, 174.38618925831202, 117.17902813299233},
		{77.26229508196721, 161.28142076502732, 195.12568306010928},
		{197.2076923076923, 148.9923076923077, 11.907692307692308},
		{74.74, 23.76, 19.94},
		{215.52631578947367, 202.09022556390977, 101.16541353383458},
		{150.39652173913043, 150.1495652173913, 198.49565217391304},
		{216.3574879227053, 182.66666666666666, 161.93719806763286},
		{99.93659420289855, 166.39673913043478, 157.3786231884058},
		{8.232558139534884, 112.13953488372093, 82.44186046511628},
		{118.40083507306889, 159.5240083507307, 117.91022964509395},
		{109.02777777777777, 99.86507936507937, 49.42857142857143},
		{187.1615969581749, 148.6615969581749, 182.96577946768062},
		{179.33404710920772, 168.52462526766595, 208.25481798715202},
		{96.15328467153284, 130.82481751824818, 94.25912408759125},
		{27.88, 91.92, 53.0},
		{130.90104166666666, 191.5625, 168.52604166666666},
		{88.20727272727272, 129.65818181818182, 169.88363636363636},
		{99.44117647058823, 74.77731092436974, 65.58823529411765},
		{222.7530864197531, 96.87654320987654, 16.32716049382716},
		{23.82304526748971, 20.337448559670783, 24.43621399176955}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<58;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<58;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance59clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026994098855491783, -0.01966694104809049, -0.0021111305278330114},
		{-0.019666941048090483, 0.04243298502832127, -0.013398111140850594},
		{-0.0021111305278330083, -0.013398111140850596, 0.0152765509871221}
	};

	double matrix[59][3][3] =
	{
		{
			{0.04361186942520935, -0.0317898587596796, 8.95128922037441E-4},
			{-0.03178985875967958, 0.07880334778967137, -0.03987145885414411},
			{8.951289220374271E-4, -0.039871458854144094, 0.042538478875457385}
		},
		{
			{0.016686045703161703, -0.002352806383041251, -0.00949622651311734},
			{-0.002352806383041248, 0.0134619267261425, 0.0011229665942976363},
			{-0.009496226513117335, 0.0011229665942976324, 0.016167518749738895}
		},
		{
			{0.018955377088677512, -0.012728502114665217, 6.844010286485907E-4},
			{-0.01272850211466521, 0.05311629090132787, -0.009117348602170882},
			{6.844010286485894E-4, -0.00911734860217088, 0.003997225911630411}
		},
		{
			{0.01737488636033382, -0.0039807014359845945, -0.0071717601971761635},
			{-0.003980701435984594, 0.028245271618136482, -0.011041512106725004},
			{-0.007171760197176165, -0.011041512106725005, 0.022670844346741006}
		},
		{
			{0.06442336077515709, -0.06891119320868312, 0.00804251200764686},
			{-0.06891119320868311, 0.13438958793086192, -0.041428037855374925},
			{0.00804251200764685, -0.04142803785537491, 0.03347546648371352}
		},
		{
			{0.049792127781337, -0.02360866534220011, -0.006339336009565002},
			{-0.02360866534220011, 0.03593567185175861, 9.550384837697483E-4},
			{-0.006339336009565002, 9.5503848376975E-4, 0.015431508545543402}
		},
		{
			{0.019618742699779496, 0.00442902006011319, -0.007740033699918984},
			{0.004429020060113188, 0.03167010337877251, -0.0182849743155175},
			{-0.0077400336999189825, -0.018284974315517507, 0.0589740961170607}
		},
		{
			{0.015289464357274279, -0.005579366366333453, -0.011791565021191695},
			{-0.005579366366333457, 0.0326796457917458, -0.014417272342400393},
			{-0.011791565021191696, -0.014417272342400396, 0.026828326980120394}
		},
		{
			{0.07412188517702549, -0.030469809553619505, -0.005319055445925097},
			{-0.03046980955361952, 0.041076552998332516, -0.021156025135420514},
			{-0.005319055445925088, -0.021156025135420517, 0.029631913160539685}
		},
		{
			{0.036792800806946996, 0.021665992764954223, 0.0063559665235288065},
			{0.021665992764954182, 0.23646339911925812, -0.02596725830693121},
			{0.0063559665235287995, -0.025967258306931227, 0.00504376159689421}
		},
		{
			{0.11272136708999006, -0.05051001047090162, -0.026456110340963},
			{-0.050510010470901645, 0.06892459032448434, -0.010061016955756993},
			{-0.026456110340963, -0.010061016955756974, 0.031085083863836502}
		},
		{
			{0.04523209737775388, -0.020453072092896697, -0.012375777279432102},
			{-0.020453072092896703, 0.07990876552838488, -0.012484924989600393},
			{-0.012375777279432112, -0.012484924989600391, 0.015083064861592114}
		},
		{
			{0.11054570573076303, -0.04854692779728106, -0.01790564278572562},
			{-0.04854692779728109, 0.325230622563233, -0.05966567472517852},
			{-0.01790564278572556, -0.059665674725178454, 0.02400728753159757}
		},
		{
			{0.04058444838940929, -0.029899352373887828, 5.805301420655565E-4},
			{-0.029899352373887814, 0.0776472033653053, -0.026054096606857702},
			{5.80530142065553E-4, -0.026054096606857702, 0.0325270020341388}
		},
		{
			{0.0525145986145526, -0.004404158490720327, -0.02404823576191761},
			{-0.004404158490720324, 0.11634737898745695, -0.04907402100940919},
			{-0.0240482357619176, -0.04907402100940918, 0.039244297309484685}
		},
		{
			{0.024017958063260708, -0.015568582028292725, -2.1950817425634892E-4},
			{-0.015568582028292711, 0.0568316427634281, -0.04299390592538639},
			{-2.195081742563513E-4, -0.042993905925386385, 0.048345433409999694}
		},
		{
			{0.07442878563851764, -0.057671404671600396, 0.002219857403662481},
			{-0.05767140467160037, 0.1195993322245089, -0.027344412848055093},
			{0.0022198574036624828, -0.027344412848055093, 0.018945082168002003}
		},
		{
			{0.18589807976320974, -0.05660785401260878, -0.0749098786003929},
			{-0.05660785401260879, 0.1417158145479509, 0.014555821966136834},
			{-0.07490987860039294, 0.01455582196613682, 0.08974756253834468}
		},
		{
			{0.018003729132194345, -0.018388374010296436, 0.017705547597315144},
			{-0.01838837401029644, 0.028698462908163826, -0.01109241690982311},
			{0.017705547597315137, -0.011092416909823096, 0.02234107631407895}
		},
		{
			{0.06169695470825346, -0.03494342758478999, -0.002311845658255179},
			{-0.03494342758478995, 0.07489781027049897, -0.033146907082027596},
			{-0.0023118456582551755, -0.033146907082027596, 0.0374859818125939}
		},
		{
			{0.015879224881564295, 5.703404299731629E-4, -0.008584178507385087},
			{5.703404299731612E-4, 0.03816509981612751, -0.010032105896677686},
			{-0.008584178507385085, -0.010032105896677693, 0.021588377790733207}
		},
		{
			{0.046138851068180387, -0.01643797527393398, 6.932250743225702E-4},
			{-0.016437975273933998, 0.03926570807907652, -0.006022481155550813},
			{6.932250743225746E-4, -0.006022481155550806, 0.0276875710076639}
		},
		{
			{0.025726108287504094, -0.016734325119378696, -0.0040816997622494244},
			{-0.016734325119378696, 0.04080150359700473, -0.006042580474041133},
			{-0.004081699762249422, -0.006042580474041128, 0.0167238560383237}
		},
		{
			{0.05756782457519263, -0.030134539273030267, -0.004959705269262983},
			{-0.030134539273030232, 0.0771318253570674, -0.011273103901270504},
			{-0.004959705269262981, -0.011273103901270516, 0.021690288512700308}
		},
		{
			{0.08008489679222273, -0.03348165625499587, -0.008086637647776857},
			{-0.03348165625499587, 0.06522258567412345, -0.005961631346791822},
			{-0.008086637647776864, -0.00596163134679183, 0.028861943299710206}
		},
		{
			{0.243417046623158, -0.04523669719458601, -0.12256121658533303},
			{-0.04523669719458602, 0.02334848107247991, 0.022403168029137402},
			{-0.12256121658533303, 0.022403168029137416, 0.06721073411578331}
		},
		{
			{0.08889241219153465, -0.07428986529919428, 0.02099867293632732},
			{-0.07428986529919428, 0.13956759848295824, -0.0544515808378804},
			{0.02099867293632731, -0.0544515808378804, 0.06587046361745703}
		},
		{
			{0.03884804113962851, -0.017130581111291787, -0.004080965903251741},
			{-0.01713058111129179, 0.055881563642565024, -0.025117225600665906},
			{-0.004080965903251731, -0.025117225600665916, 0.03402659782252199}
		},
		{
			{0.026863618905187, -0.006757549339091968, -0.006173699449970731},
			{-0.006757549339091978, 0.03621939469196809, -0.003104281756876586},
			{-0.006173699449970727, -0.0031042817568765826, 0.009860074740997963}
		},
		{
			{0.01338898112139, 0.0040770854145292254, -0.014439650042854107},
			{0.004077085414529224, 0.018113614139778602, -0.006861293142469693},
			{-0.014439650042854106, -0.006861293142469697, 0.019947405691397614}
		},
		{
			{0.00306760715759631, -0.0018604604210202707, 0.0015115528212800377},
			{-0.0018604604210202605, 0.07434379443152558, -0.04243621771685905},
			{0.0015115528212800303, -0.04243621771685905, 0.05067450862138498}
		},
		{
			{0.020420261910478812, -0.00850496783258104, -0.0017883227825900702},
			{-0.00850496783258104, 0.05697713371069627, -0.03169654460819347},
			{-0.0017883227825900702, -0.03169654460819347, 0.03400643964579446}
		},
		{
			{0.04594967552729928, -0.03558163570690797, 3.5859933631840696E-4},
			{-0.03558163570690797, 0.08048481269923632, -0.017295760996362496},
			{3.585993363184035E-4, -0.01729576099636249, 0.017066648566992294}
		},
		{
			{0.08987986702270334, -0.00947713423762507, -0.029538423043971626},
			{-0.009477134237625053, 0.08561928465543212, -0.02565046868488778},
			{-0.029538423043971643, -0.025650468684887788, 0.07967885681642152}
		},
		{
			{0.050147094857069203, -0.05764914987272071, 0.0028729663575849072},
			{-0.05764914987272071, 0.13862178094004005, -0.026489350026911888},
			{0.0028729663575849107, -0.026489350026911895, 0.046253632155625696}
		},
		{
			{0.051184650539519726, -0.032716956411344714, -0.013262880978735674},
			{-0.03271695641134472, 0.10012195462338598, -0.024044541509443223},
			{-0.01326288097873567, -0.024044541509443212, 0.03866185836776488}
		},
		{
			{0.03132150078339954, -0.02635608406419354, 0.00456252626902611},
			{-0.02635608406419352, 0.052081770806722605, -0.012968977913574202},
			{0.0045625262690261095, -0.012968977913574204, 0.0126899423422649}
		},
		{
			{0.015038948642084096, -0.011773708745438871, 0.003619238078402355},
			{-0.011773708745438894, 0.0560068441798237, -0.02976732521478911},
			{0.003619238078402363, -0.029767325214789114, 0.02968123697277751}
		},
		{
			{0.04095691661398339, -0.004946287130230924, -0.005270987908434941},
			{-0.004946287130230903, 0.042217206655315365, 7.09847572735167E-4},
			{-0.005270987908434929, 7.098475727351596E-4, 0.012972210511525407}
		},
		{
			{0.010269796251807201, -0.002898518726454047, -0.005800932925193528},
			{-0.002898518726454047, 0.0505773862143873, -0.0328514201359618},
			{-0.005800932925193528, -0.03285142013596181, 0.0312993932422234}
		},
		{
			{0.109257768327784, -0.08233560460680717, -0.02975394841673531},
			{-0.08233560460680717, 0.0917169067776333, 0.014065503939566504},
			{-0.0297539484167353, 0.014065503939566503, 0.020698397693335008}
		},
		{
			{0.0220993233168294, -0.010421069664453907, -0.0067053314459821515},
			{-0.01042106966445391, 0.02383066094206331, -0.003548704343060767},
			{-0.006705331445982154, -0.0035487043430607636, 0.020916344783986907}
		},
		{
			{0.028513471241908922, -0.011631704004947008, -0.0036193630097063247},
			{-0.011631704004947006, 0.03335405660846711, -0.016665537073532605},
			{-0.0036193630097063247, -0.0166655370735326, 0.029957557907660283}
		},
		{
			{0.09642155486343673, -0.024039657627001415, 0.0034923350405090883},
			{-0.02403965762700141, 0.07308927360763999, 0.011130303421219087},
			{0.0034923350405090935, 0.011130303421219092, 0.018063359997765798}
		},
		{
			{0.01722840263752584, -0.021566108616692357, 0.010831365371743656},
			{-0.021566108616692354, 0.08176654739404239, -0.05974868867112524},
			{0.010831365371743647, -0.0597486886711252, 0.06300088992165011}
		},
		{
			{0.049562915831255015, -0.025323243889493103, -0.016839204807020794},
			{-0.025323243889493106, 0.06456681118188212, -0.038374397555675406},
			{-0.016839204807020797, -0.03837439755567541, 0.06445528557082508}
		},
		{
			{0.03186955209647559, -0.017503490568025366, 0.0010825149277706976},
			{-0.01750349056802537, 0.06581870778466017, -0.015608091952067096},
			{0.0010825149277706872, -0.015608091952067093, 0.027384896582943404}
		},
		{
			{0.0810194277849237, -0.026848971344880092, -0.060426994927042114},
			{-0.026848971344880096, 0.08465318763302143, 0.03493122894989924},
			{-0.060426994927042114, 0.03493122894989925, 0.05880831257026547}
		},
		{
			{0.05337287261436812, -0.024140852124743817, -0.03104904338872292},
			{-0.02414085212474383, 0.07460854175109473, -0.050009497581598165},
			{-0.031049043388722924, -0.05000949758159819, 0.155751817346336}
		},
		{
			{0.003948486132673074, -0.008354243073584303, 0.0036152858184121035},
			{-0.008354243073584317, 0.0711112759241392, -0.04117561233615401},
			{0.003615285818412107, -0.04117561233615402, 0.05056792339193442}
		},
		{
			{0.06502922670390718, -0.04633111066736081, -0.01065933311908721},
			{-0.04633111066736083, 0.09593359336662433, -0.0032904431264192146},
			{-0.010659333119087216, -0.003290443126419209, 0.01366325571322171}
		},
		{
			{0.0270457843550692, -0.0140871787333215, -0.012253256980792993},
			{-0.014087178733321503, 0.05464785836410819, -0.0156957685234199},
			{-0.012253256980792996, -0.015695768523419893, 0.023804939067212892}
		},
		{
			{0.04494834047328968, -0.013018967271449803, -0.018611519887326712},
			{-0.013018967271449806, 0.04499547735048871, -0.014483781763475683},
			{-0.01861151988732672, -0.01448378176347568, 0.035788043806494106}
		},
		{
			{0.05794374676898896, -0.016502254586592793, 0.004443224377958956},
			{-0.0165022545865928, 0.043617252092908315, -0.005845906166264715},
			{0.004443224377958959, -0.005845906166264712, 0.007226434136863061}
		},
		{
			{0.0486234466585226, -0.01544653337268701, -0.014299693414058904},
			{-0.015446533372687001, 0.06545980292929243, -0.03334792150991822},
			{-0.014299693414058904, -0.033347921509918214, 0.04550171333490622}
		},
		{
			{0.02466422271737791, -0.0070153768784077955, -0.014202752851737515},
			{-0.007015376878407792, 0.0283686972969304, -0.0061136712238848},
			{-0.014202752851737515, -0.006113671223884798, 0.019988334516520212}
		},
		{
			{0.043404388003082425, -0.014268398533383719, 7.477966943563899E-4},
			{-0.014268398533383698, 0.0659167688575456, -0.015453377890156095},
			{7.477966943563877E-4, -0.015453377890156095, 0.0238365468484207}
		},
		{
			{0.024800246217707104, 0.004625228251603768, -0.005690045776056201},
			{0.004625228251603768, 0.013693465923551303, 0.0020272569097713063},
			{-0.005690045776056202, 0.0020272569097713063, 0.005629681221640051}
		},
		{
			{0.05526623386397109, -0.011819846035212975, -0.011109726716596387},
			{-0.011819846035212982, 0.05451705259138052, 0.003646248618358906},
			{-0.011109726716596394, 0.003646248618358906, 0.016470646312805003}
		}
	};

	double barycentre[59][3] =
	{
		{197.13793103448276, 137.30831643002028, 145.8235294117647},
		{152.65168539325842, 181.6938202247191, 131.32865168539325},
		{146.02758620689656, 114.04827586206896, 16.910344827586208},
		{88.9609756097561, 145.04146341463414, 129.51951219512196},
		{151.33196721311475, 164.24180327868854, 211.76639344262296},
		{222.2336956521739, 98.13586956521739, 18.45108695652174},
		{23.49367088607595, 118.16455696202532, 87.55696202531645},
		{133.77088948787062, 193.25067385444743, 169.76549865229111},
		{214.92857142857142, 120.46938775510205, 76.06122448979592},
		{57.9375, 19.5, 17.421875},
		{218.73821989528795, 180.07853403141362, 155.4973821989529},
		{158.59628770301623, 139.18097447795824, 184.96983758700696},
		{100.80071174377224, 102.5693950177936, 120.43416370106762},
		{169.0097719869707, 117.66775244299674, 92.74592833876221},
		{125.98060941828255, 125.17174515235457, 159.86426592797784},
		{69.32584269662921, 164.63670411985018, 190.18726591760299},
		{86.4307116104869, 130.43820224719101, 170.374531835206},
		{21.986607142857142, 20.669642857142858, 25.348214285714285},
		{27.2, 94.0, 55.8},
		{203.53773584905662, 136.45754716981133, 111.88443396226415},
		{95.31485587583148, 164.44124168514412, 160.16851441241684},
		{145.37891737891738, 111.26780626780626, 130.35042735042734},
		{154.49419953596288, 160.16705336426915, 96.71925754060325},
		{144.9306358381503, 94.48265895953757, 63.24277456647399},
		{118.13333333333334, 163.65287356321838, 227.72413793103448},
		{66.21656050955414, 51.5796178343949, 83.54777070063695},
		{184.3065134099617, 194.64367816091954, 229.4176245210728},
		{177.32258064516128, 120.3673835125448, 121.52329749103943},
		{183.70357142857142, 164.28571428571428, 70.08928571428571},
		{120.2363184079602, 174.56965174129354, 141.07960199004975},
		{29.238805970149254, 127.23880597014926, 130.08955223880596},
		{120.0049504950495, 195.83663366336634, 203.1509900990099},
		{182.25779036827194, 170.4844192634561, 114.40226628895184},
		{37.57839721254356, 36.22648083623693, 44.57491289198606},
		{150.26694915254237, 200.53813559322035, 214.07627118644066},
		{92.84814814814816, 148.21851851851852, 209.55925925925925},
		{156.95157384987894, 137.43099273607749, 62.33898305084746},
		{86.28684210526316, 184.30789473684212, 219.03157894736842},
		{110.7183908045977, 92.78735632183908, 56.33045977011494},
		{51.23696682464455, 153.2654028436019, 158.29857819905214},
		{189.30869565217392, 208.7826086956522, 172.71304347826086},
		{129.06497175141243, 138.71186440677965, 82.75141242937853},
		{102.49641577060932, 175.34408602150538, 185.1057347670251},
		{86.35593220338983, 82.2909604519774, 87.99435028248588},
		{101.89145496535797, 201.10623556581987, 240.55889145496536},
		{184.7006507592191, 162.96746203904556, 201.80911062906725},
		{137.84795321637426, 99.2046783625731, 95.44152046783626},
		{63.15450643776824, 40.141630901287556, 53.59656652360515},
		{136.24933687002653, 187.18832891246683, 244.3448275862069},
		{7.535211267605634, 162.1338028169014, 175.3943661971831},
		{124.04964539007092, 143.77541371158392, 195.69739952718678},
		{94.75384615384615, 127.5576923076923, 90.99230769230769},
		{167.17214700193423, 124.98646034816248, 155.64990328820116},
		{214.62857142857143, 202.62142857142857, 93.25714285714285},
		{190.5098901098901, 144.87472527472528, 175.621978021978},
		{119.8688524590164, 158.04449648711943, 113.88056206088993},
		{124.09895833333333, 73.29166666666667, 37.447916666666664},
		{209.23636363636365, 168.86060606060607, 10.618181818181819},
		{78.284375, 78.815625, 53.15625}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<59;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<59;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance60clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027392400816054718, -0.02056989521797561, -0.0017338437776410673},
		{-0.02056989521797561, 0.04288495256913846, -0.013333122231276095},
		{-0.0017338437776410684, -0.013333122231276105, 0.015218391994989502}
	};

	double matrix[60][3][3] =
	{
		{
			{0.021419285715559795, 0.0034074078974629905, -0.006109778521967542},
			{0.003407407897462989, 0.014435588002494695, 0.0029293002393683907},
			{-0.006109778521967541, 0.002929300239368389, 0.007802422643399575}
		},
		{
			{0.05440377129157402, -0.00816188425764569, 0.0010778682205099279},
			{-0.008161884257645689, 0.023543675768389897, -0.006066968513625674},
			{0.0010778682205099279, -0.006066968513625675, 0.008166253181068001}
		},
		{
			{0.09247857214432016, -0.022489763389822212, 0.0028663771327693535},
			{-0.022489763389822226, 0.08168954312262056, 0.009493452665704838},
			{0.0028663771327693557, 0.009493452665704841, 0.018063359903540903}
		},
		{
			{0.12064937347874911, -0.0649136025791667, -0.020790974183341394},
			{-0.06491360257916666, 0.09367366892818911, -0.025748822417517674},
			{-0.02079097418334139, -0.02574882241751768, 0.03496182437413666}
		},
		{
			{0.04955914819430213, -0.019932784005660946, -0.0125094600826489},
			{-0.019932784005660918, 0.054207513398328744, -0.013532530625181298},
			{-0.012509460082648903, -0.013532530625181297, 0.0323226444297036}
		},
		{
			{0.032187260055905845, -0.013272722374590418, -0.006766214529243646},
			{-0.013272722374590425, 0.042878260698834894, -0.0065559851149511105},
			{-0.006766214529243647, -0.006555985114951115, 0.014659773294851706}
		},
		{
			{0.0167968316320935, -0.0035526256482843028, -0.010378025008793895},
			{-0.003552625648284308, 0.033821555059651516, -0.010436485185335494},
			{-0.010378025008793904, -0.010436485185335489, 0.0201627167230191}
		},
		{
			{0.05464341613319529, -0.03940142903091406, -0.004727032259783393},
			{-0.03940142903091405, 0.101603638540451, -0.004919823505162965},
			{-0.004727032259783397, -0.00491982350516296, 0.008860678843886942}
		},
		{
			{0.015736881076572694, -0.008620235106217119, -0.003904551561348204},
			{-0.008620235106217128, 0.04704150371920886, -0.029161040946956696},
			{-0.0039045515613482097, -0.029161040946956682, 0.029568700651575804}
		},
		{
			{0.2124741829643471, -0.07245398635331139, -0.09433388606055028},
			{-0.07245398635331138, 0.035019625440219686, 0.023457813805583268},
			{-0.09433388606055028, 0.023457813805583275, 0.05502320434773308}
		},
		{
			{0.016950871636442495, -0.0104746219291889, 0.0012955429303445204},
			{-0.010474621929188892, 0.06865883141601449, -0.037115030064952495},
			{0.00129554293034452, -0.03711503006495252, 0.03837317555255931}
		},
		{
			{0.04107984423286154, -0.02831374205307341, -0.002160785727472761},
			{-0.028313742053073437, 0.06548259427188174, -0.033044655024952414},
			{-0.0021607857274727753, -0.033044655024952414, 0.040669879414518016}
		},
		{
			{0.017516806682167194, 0.002968574033713203, -0.008124284419694056},
			{0.002968574033713205, 0.035559535751493676, -0.010539946142514287},
			{-0.008124284419694055, -0.010539946142514288, 0.02225505777122189}
		},
		{
			{0.016160852744126403, 0.0038090809862406406, -0.008429832910279817},
			{0.003809080986240646, 0.047421744409441115, -0.019194335987975302},
			{-0.008429832910279815, -0.01919433598797531, 0.0235944960142589}
		},
		{
			{0.0598895388636113, -0.010344728755071904, -0.019138611590557304},
			{-0.010344728755071904, 0.0405475876485381, -0.010837678445452194},
			{-0.019138611590557304, -0.010837678445452194, 0.025354078004279097}
		},
		{
			{0.057361550251391766, -0.015979016002816687, -0.012262543688204609},
			{-0.0159790160028167, 0.05491316911849092, 0.004574351168813943},
			{-0.012262543688204612, 0.004574351168813934, 0.016888965789468104}
		},
		{
			{0.04770361071431351, -0.02707996778940152, -0.011453501537317208},
			{-0.02707996778940152, 0.0330047364853599, 0.0056724545981034855},
			{-0.011453501537317208, 0.00567245459810348, 0.010656670089024402}
		},
		{
			{0.04291258836659531, 0.002565123446421346, -0.011200352032591707},
			{0.002565123446421341, 0.04025928734478899, -0.014643151067219386},
			{-0.011200352032591704, -0.014643151067219393, 0.02757164696709529}
		},
		{
			{0.046993197776995725, 0.011926488490658508, -0.011083633273574062},
			{0.01192648849065851, 0.023527871135326256, 0.005164644730118026},
			{-0.01108363327357407, 0.005164644730118032, 0.005718464575612619}
		},
		{
			{0.096502913452937, -0.009467731808487725, -0.04060042234840656},
			{-0.009467731808487721, 0.05978266775204163, -0.031759678660385086},
			{-0.04060042234840657, -0.031759678660385086, 0.12331716191094104}
		},
		{
			{0.09318370068303175, -0.05081342566731465, 0.005002911223782694},
			{-0.05081342566731463, 0.058978809312530356, -0.01869421917761969},
			{0.005002911223782695, -0.01869421917761969, 0.016791907393681194}
		},
		{
			{0.023057600753228095, 6.780326604551659E-4, -0.006326808072454334},
			{6.780326604551763E-4, 0.03846825036555679, -0.02549133386847038},
			{-0.006326808072454348, -0.02549133386847039, 0.031786709963966986}
		},
		{
			{0.06673234331859408, -0.07169750478541521, 0.007968973180394048},
			{-0.07169750478541531, 0.15341871180995706, -0.043620348461897336},
			{0.007968973180394074, -0.043620348461897315, 0.029637391981667514}
		},
		{
			{0.11344645800434297, -0.097552137761743, -0.0181613414295232},
			{-0.09755213776174294, 0.09748187610524109, -0.005056471665392245},
			{-0.018161341429523192, -0.00505647166539225, 0.03433937062514972}
		},
		{
			{0.07325491577783429, -0.033133007030434716, -0.02110767216965991},
			{-0.03313300703043471, 0.03585598019337028, -0.0013885284112844492},
			{-0.02110767216965991, -0.0013885284112844561, 0.0350931054805028}
		},
		{
			{0.018004939266542994, -0.02160706756482101, 0.010976692181943809},
			{-0.021607067564821027, 0.07953632729225564, -0.05781030188213018},
			{0.010976692181943823, -0.0578103018821302, 0.060951439049172856}
		},
		{
			{0.023205288337528697, -0.00977073751905428, -0.007850428889264311},
			{-0.009770737519054284, 0.023941001365794117, -0.003583703523608813},
			{-0.007850428889264313, -0.003583703523608815, 0.021492406686183612}
		},
		{
			{0.08203342159510746, -0.061542346438191564, 0.015484695253619712},
			{-0.06154234643819161, 0.14739582594142905, -0.049094351248186924},
			{0.015484695253619741, -0.04909435124818695, 0.06855868815728729}
		},
		{
			{0.07939467094992655, -0.03188531294590442, -0.008813317207273925},
			{-0.03188531294590441, 0.06360655587657416, -7.048429895968348E-4},
			{-0.008813317207273918, -7.048429895968288E-4, 0.027287132391503405}
		},
		{
			{0.10985776413162393, -0.06025866368905673, -0.0061470285353447335},
			{-0.0602586636890568, 0.319602277625118, -0.0550165197020899},
			{-0.006147028535344705, -0.05501651970208992, 0.0236090761659902}
		},
		{
			{0.06080816411874474, -0.03598258945830479, -0.00494455959365636},
			{-0.03598258945830476, 0.0748428595227038, -0.031753465582828516},
			{-0.0049445595936563665, -0.0317534655828285, 0.041788855898194026}
		},
		{
			{0.026964779645785895, -0.01309655119401409, -0.012734448800768502},
			{-0.013096551194014093, 0.052008413309933776, -0.0177867252432775},
			{-0.012734448800768506, -0.017786725243277502, 0.024788411245092016}
		},
		{
			{0.041251982588408724, -0.023572160574273235, -0.0033611264793627273},
			{-0.02357216057427321, 0.07476848335793478, -0.004999542763853881},
			{-0.003361126479362724, -0.004999542763853878, 0.023975593264742703}
		},
		{
			{0.0771762567864235, -0.027904762999819498, -0.007091677023318369},
			{-0.027904762999819498, 0.033185719005432227, -0.015251335868324493},
			{-0.007091677023318375, -0.015251335868324493, 0.027943535039595197}
		},
		{
			{0.015152718720175113, -0.011997457147474801, 0.0019006938314435331},
			{-0.011997457147474782, 0.05735305882800182, -0.029718025790382893},
			{0.0019006938314435266, -0.029718025790382907, 0.0274920335116443}
		},
		{
			{0.048526254692742514, -0.016509931842218405, -0.01101134335217091},
			{-0.016509931842218405, 0.06402498381011064, -0.030698328507842806},
			{-0.01101134335217091, -0.030698328507842806, 0.045092348684852984}
		},
		{
			{0.07135859946702847, -0.05099141839814911, -0.0010513002820468995},
			{-0.0509914183981491, 0.08479722715386717, -0.01520577242593819},
			{-0.0010513002820469013, -0.015205772425938194, 0.022370378810234}
		},
		{
			{0.055925743554577176, -0.02326065908929937, -0.032674087211775775},
			{-0.023260659089299363, 0.06950086470000534, -0.051183075824735746},
			{-0.03267408721177577, -0.051183075824735746, 0.160608835039704}
		},
		{
			{0.030757617546161176, -0.012918430162121994, -0.00532580022921279},
			{-0.012918430162121994, 0.035691072987800804, -0.017564983068440808},
			{-0.005325800229212798, -0.017564983068440794, 0.03195854951303149}
		},
		{
			{0.0743354263087917, -0.06554780082582999, -0.007285877157039011},
			{-0.06554780082582996, 0.12066937765503905, -0.036887271100485786},
			{-0.007285877157039005, -0.0368872711004858, 0.04049809218866466}
		},
		{
			{0.043165093200322524, -0.010824646055069706, -0.003365100440213792},
			{-0.010824646055069699, 0.04694721455535098, -7.10659427449705E-5},
			{-0.0033651004402137923, -7.106594274497506E-5, 0.010741480022351601}
		},
		{
			{0.06729895183543276, -0.03567165429710281, 0.005720340980505004},
			{-0.0356716542971028, 0.04358156250248384, -0.004007176295360194},
			{0.005720340980505003, -0.004007176295360192, 0.01727160219684671}
		},
		{
			{0.06329331552825782, -0.03209612839017484, -0.021098271607264327},
			{-0.032096128390174825, 0.09453862352973644, -0.019188213777183397},
			{-0.021098271607264324, -0.019188213777183386, 0.04254004487592203}
		},
		{
			{0.04960667540212928, -0.015797809184452193, -0.025983612738263315},
			{-0.0157978091844522, 0.047229225274619986, -0.023236571093966086},
			{-0.025983612738263304, -0.023236571093966093, 0.053213858785266605}
		},
		{
			{0.015258912175593924, 0.0011640509146696124, -0.013681652479413208},
			{0.0011640509146696124, 0.01788138850816879, -0.011339538906008088},
			{-0.013681652479413199, -0.011339538906008095, 0.027775157124318793}
		},
		{
			{0.027306748556045504, -0.022102136015802097, -0.004182403144378058},
			{-0.022102136015802094, 0.043145821420188676, -0.0059809777980879535},
			{-0.0041824031443780585, -0.0059809777980879535, 0.0155556671468898}
		},
		{
			{0.037793995867289355, -0.018125128466701595, -1.8973164801858525E-4},
			{-0.01812512846670159, 0.054319364564608855, -0.022588449757390102},
			{-1.8973164801858134E-4, -0.022588449757390106, 0.027093229993936107}
		},
		{
			{0.024087779384308915, -0.004327682013570013, -0.008278408957593165},
			{-0.004327682013570017, 0.0349740969097872, -0.0028517940806173725},
			{-0.008278408957593164, -0.0028517940806173704, 0.008856245997234433}
		},
		{
			{0.04430620606462905, -0.017206226988995217, -6.26761090819954E-5},
			{-0.0172062269889952, 0.07398968647425379, -0.0112444756444418},
			{-6.267610908200104E-5, -0.011244475644441802, 0.023761715132921506}
		},
		{
			{0.004089486780366851, -0.00915815431418931, 0.0028533958010835956},
			{-0.009158154314189293, 0.06957641552038808, -0.04061046883818609},
			{0.002853395801083579, -0.04061046883818609, 0.050839919519783484}
		},
		{
			{0.02500468494798362, -0.015080047167664125, 0.004063044870504644},
			{-0.015080047167664116, 0.0645469878400467, -0.04457457595343316},
			{0.004063044870504644, -0.04457457595343315, 0.04657350586771593}
		},
		{
			{0.0174263237494249, -7.308620484345885E-4, -0.012363668814208504},
			{-7.308620484345937E-4, 0.029167865497926618, -0.01022276923332219},
			{-0.01236366881420851, -0.010222769233322198, 0.018560398070488413}
		},
		{
			{0.011888461268290714, 0.004516045660028106, -0.010321838828409214},
			{0.004516045660028098, 0.016240993754699395, -0.00617553408795146},
			{-0.010321838828409202, -0.0061755340879514585, 0.0200134891800545}
		},
		{
			{0.04125294279581081, -0.024184650270405242, -0.007836915664761851},
			{-0.02418465027040525, 0.07633770955372413, -0.030048277786626592},
			{-0.007836915664761867, -0.030048277786626568, 0.0409371459754837}
		},
		{
			{0.029214491158601898, -0.026450807627748592, 0.009040923608244584},
			{-0.026450807627748596, 0.05479151580547338, -0.013501953538790594},
			{0.009040923608244591, -0.013501953538790596, 0.0119755482957876}
		},
		{
			{0.08971730196128963, -0.05676708974314996, 0.012545820800894288},
			{-0.056767089743149986, 0.08745927439193832, -0.0317794082524921},
			{0.012545820800894301, -0.031779408252492106, 0.022987620463302404}
		},
		{
			{0.04090446703869708, -0.026690423369234488, -0.006169445542693511},
			{-0.026690423369234478, 0.09571191162832773, -0.025387134846818208},
			{-0.006169445542693513, -0.025387134846818194, 0.022177091768502702}
		},
		{
			{0.0255563570602646, -0.023832938209578006, 0.0026021613158438606},
			{-0.023832938209578006, 0.06010301535894531, -0.0030755474202282603},
			{0.002602161315843862, -0.0030755474202282594, 0.0025253620221287886}
		},
		{
			{0.0776254287477858, 0.0030776102504151788, 0.00841044194554141},
			{0.0030776102504151822, 0.12716402054900305, -0.022772794496505266},
			{0.008410441945541407, -0.02277279449650525, 0.0377362674825813}
		},
		{
			{0.003393722092129244, -0.0029234287158016745, 0.0020909502330866006},
			{-0.0029234287158016754, 0.07215332084111066, -0.04218637035237282},
			{0.0020909502330865998, -0.04218637035237282, 0.05116581813209179}
		}
	};

	double barycentre[60][3] =
	{
		{197.576, 150.08, 12.432},
		{209.67326732673268, 203.23762376237624, 79.60396039603961},
		{86.76701570680628, 81.40837696335079, 87.65968586387434},
		{217.79617834394904, 186.6687898089172, 166.81528662420382},
		{168.65481171548117, 127.6276150627615, 163.44142259414227},
		{168.23774509803923, 173.02450980392157, 110.15196078431373},
		{127.52815013404826, 159.7024128686327, 111.67024128686327},
		{128.9619952494062, 144.44893111638956, 195.49643705463183},
		{54.66528925619835, 151.84297520661158, 160.6818181818182},
		{64.45454545454545, 47.32900432900433, 75.05194805194805},
		{126.5119825708061, 197.7211328976035, 203.8082788671024},
		{195.99756690997566, 132.8102189781022, 149.49148418491484},
		{97.57, 164.878, 160.972},
		{81.62582781456953, 138.2086092715232, 131.26158940397352},
		{136.8101851851852, 122.21064814814815, 149.3912037037037},
		{77.2625, 78.69375, 53.04375},
		{183.76506024096386, 205.710843373494, 140.24698795180723},
		{169.25390625, 118.2265625, 128.8046875},
		{224.6, 198.01666666666668, 8.65},
		{49.660049627791565, 36.82382133995037, 44.42679900744417},
		{222.84444444444443, 162.94814814814814, 116.25925925925925},
		{23.545454545454547, 113.78787878787878, 81.58585858585859},
		{152.21166306695466, 168.2915766738661, 214.03023758099351},
		{182.00645161290322, 211.78064516129032, 185.96774193548387},
		{222.98275862068965, 102.26724137931035, 7.293103448275862},
		{102.65509761388286, 200.50976138828634, 240.6355748373102},
		{128.02134146341464, 136.59451219512195, 82.0640243902439},
		{181.59302325581396, 197.7248062015504, 229.79457364341084},
		{118.32438478747204, 164.1096196868009, 228.59284116331096},
		{104.56351791530945, 101.36807817589576, 117.51140065146579},
		{197.2846347607053, 127.39042821158691, 119.02770780856423},
		{95.73476702508961, 130.55197132616487, 93.73118279569893},
		{138.72340425531914, 91.53664302600473, 68.76832151300236},
		{219.80851063829786, 121.88652482269504, 79.84397163120568},
		{86.4937343358396, 184.04260651629073, 218.96491228070175},
		{192.2173913043478, 147.55314009661836, 177.731884057971},
		{188.31045751633988, 137.44117647058823, 94.66339869281046},
		{139.21614583333334, 189.61979166666666, 242.01041666666666},
		{102.8185053380783, 175.81494661921707, 186.95017793594306},
		{100.49844236760124, 126.25856697819314, 169.5264797507788},
		{107.97269624573379, 95.94539249146757, 52.6518771331058},
		{218.61702127659575, 91.36170212765957, 44.744680851063826},
		{96.5896551724138, 145.28620689655173, 208.04137931034484},
		{185.6847290640394, 165.66748768472905, 204.4729064039409},
		{131.47135416666666, 191.96875, 169.26041666666666},
		{152.79603399433427, 154.61473087818698, 87.8215297450425},
		{144.7289972899729, 103.85365853658537, 106.40108401084011},
		{183.44444444444446, 165.30864197530863, 69.41975308641975},
		{122.82474226804123, 70.91237113402062, 39.103092783505154},
		{8.64, 162.31333333333333, 174.68666666666667},
		{71.60983606557377, 162.32459016393443, 190.01311475409835},
		{104.89333333333333, 159.88533333333334, 129.67733333333334},
		{136.06728538283062, 179.03480278422273, 137.94895591647332},
		{168.99812030075188, 115.10902255639098, 93.68045112781955},
		{156.8132678132678, 132.74201474201473, 61.60687960687961},
		{193.24505928853756, 159.72332015810278, 136.04743083003953},
		{160.37740384615384, 143.59375, 189.97596153846155},
		{143.48322147651007, 110.3489932885906, 18.91275167785235},
		{25.143769968051117, 22.578274760383387, 27.354632587859424},
		{28.2, 127.15384615384616, 129.55384615384617}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<60;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<60;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance61clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026747692491991607, -0.019503363327987622, -0.0019150026573519635},
		{-0.019503363327987612, 0.04268660914887111, -0.013749588078676402},
		{-0.0019150026573519646, -0.013749588078676406, 0.015511076789525206}
	};

	double matrix[61][3][3] =
	{
		{
			{0.0200470011826056, -0.01949945416132869, 0.0013742751232116148},
			{-0.019499454161328696, 0.05837780675616393, -0.025752004175963104},
			{0.0013742751232116205, -0.025752004175963093, 0.028341694720059086}
		},
		{
			{0.027162246141146706, -0.006233875492762324, -0.00672282536626505},
			{-0.006233875492762329, 0.035298272414140686, -0.0038762971192604456},
			{-0.006722825366265048, -0.003876297119260446, 0.0109542203221526}
		},
		{
			{0.043498256709917305, -0.026089350515082682, -0.007536028713679721},
			{-0.026089350515082682, 0.09551120417254272, -0.057874405840086136},
			{-0.007536028713679723, -0.05787440584008613, 0.116354197293088}
		},
		{
			{0.043890895266933995, -0.007783707898776453, -0.019779587976407397},
			{-0.007783707898776455, 0.07330340854744467, -0.040634078784309094},
			{-0.019779587976407387, -0.040634078784309094, 0.05191201195350301}
		},
		{
			{0.012905366050273207, -0.00200896702680029, -0.011509868582724899},
			{-0.0020089670268002967, 0.03402466726768523, -0.0197427303590422},
			{-0.01150986858272491, -0.019742730359042192, 0.031391674454634}
		},
		{
			{0.07312629991408133, -0.05636933061896438, -0.009744013434017396},
			{-0.05636933061896439, 0.11378424308704403, -0.02609037792742582},
			{-0.009744013434017417, -0.026090377927425825, 0.029818797726463325}
		},
		{
			{0.22753803588356175, -0.06814663434133877, -0.09755271052796628},
			{-0.06814663434133877, 0.02962753279342983, 0.018876184804855513},
			{-0.0975527105279663, 0.018876184804855513, 0.05342352865684528}
		},
		{
			{0.037490129678687215, -0.024340511358816097, 0.003856965669624247},
			{-0.02434051135881607, 0.07271969895699734, -0.022221972327773665},
			{0.003856965669624246, -0.022221972327773665, 0.032178792098713487}
		},
		{
			{0.07070471265651038, -0.003799543535559939, -0.005834930809837532},
			{-0.0037995435355599357, 0.09219783054272661, 0.00800372688275318},
			{-0.005834930809837524, 0.008003726882753182, 0.008665187291234016}
		},
		{
			{0.13557224975900667, -0.065543848402383, -0.023717528428850648},
			{-0.06554384840238296, 0.3078582072961145, -0.06270671573427468},
			{-0.023717528428850672, -0.06270671573427467, 0.02407050846240039}
		},
		{
			{0.02970858349629278, -0.021006728725381, -0.0025892211129922927},
			{-0.021006728725381008, 0.031398224309883434, -0.004846018049409588},
			{-0.0025892211129922927, -0.004846018049409586, 0.0180297582670075}
		},
		{
			{0.06809271594339497, 0.004704810446479118, -0.04434844336526571},
			{0.004704810446479113, 0.18445725136991495, -0.013075601291332787},
			{-0.04434844336526572, -0.013075601291332771, 0.03989669863592691}
		},
		{
			{0.058620978060781495, -0.034188925541867726, -0.006523363855821278},
			{-0.03418892554186773, 0.044467275990190853, 0.0027837083339843968},
			{-0.006523363855821279, 0.002783708333984402, 0.014665707149765802}
		},
		{
			{0.08075799164542373, -0.018943997406589856, -0.0203251138792127},
			{-0.018943997406589815, 0.20599269939713502, 0.009409924055063003},
			{-0.020325113879212705, 0.00940992405506302, 0.025195925207796024}
		},
		{
			{0.014604964897580883, -0.020499386046945976, 0.007520109730341322},
			{-0.020499386046945997, 0.07033576148546589, -0.048030006656908174},
			{0.007520109730341333, -0.04803000665690819, 0.049888102103304716}
		},
		{
			{0.0165504774941667, -0.0024051753393648937, -0.007625063196137902},
			{-0.0024051753393648937, 0.02574381061884672, -0.007962606457833107},
			{-0.007625063196137906, -0.007962606457833109, 0.02298091089234061}
		},
		{
			{0.15039101426864984, -0.15064471996811993, -0.026328046782055737},
			{-0.15064471996811987, 0.1626652299365052, 0.008922802016105683},
			{-0.026328046782055723, 0.008922802016105678, 0.03048712031875532}
		},
		{
			{0.0608821013901108, -0.0363046795844549, -4.750291728202209E-4},
			{-0.03630467958445492, 0.07725852128105085, -0.03483613744057319},
			{-4.7502917282020093E-4, -0.034836137440573185, 0.039100734061694786}
		},
		{
			{0.046714057256428056, -0.0413340261670227, -6.150608015903091E-4},
			{-0.04133402616702267, 0.0913659319210377, -0.013126117690434699},
			{-6.150608015903104E-4, -0.013126117690434699, 0.010107554177071099}
		},
		{
			{0.00965277362847184, 0.0020282102437600806, -5.452420462575655E-4},
			{0.002028210243760059, 0.05724448755506476, -0.03788578371013547},
			{-5.452420462575538E-4, -0.03788578371013547, 0.05178143602763618}
		},
		{
			{0.035381204046534304, -0.008463831128721183, -0.008554422179267928},
			{-0.008463831128721185, 0.04464184913933901, -0.020897368050426704},
			{-0.00855442217926793, -0.020897368050426704, 0.0316250157339125}
		},
		{
			{0.03635286543789829, -0.017697759775312898, -0.0010536789435165606},
			{-0.017697759775312887, 0.04673428815820726, -0.015783595359703192},
			{-0.0010536789435165589, -0.015783595359703202, 0.0259030578303029}
		},
		{
			{0.0756115466184048, -0.015053804130597474, -0.005929974121380295},
			{-0.015053804130597478, 0.034891943088986174, -0.014199961187400592},
			{-0.005929974121380296, -0.014199961187400618, 0.026712631853195702}
		},
		{
			{0.052002583430667965, -0.02229032872379457, -0.009024761663567155},
			{-0.022290328723794578, 0.072627910257582, -0.007641083539803136},
			{-0.009024761663567157, -0.007641083539803136, 0.0250556694714577}
		},
		{
			{0.05701451136939588, -0.058521829748475765, 0.0021267338296239386},
			{-0.05852182974847575, 0.12335000332331719, -0.025627455947212427},
			{0.002126733829623931, -0.025627455947212427, 0.021427081590176904}
		},
		{
			{0.07996172649137706, -0.057457252508814415, 0.016271240314616308},
			{-0.057457252508814415, 0.08857467046642044, -0.03249229315956801},
			{0.016271240314616305, -0.03249229315956802, 0.022718921304377297}
		},
		{
			{0.022905531768740186, -0.010051892337479888, -0.007541130238003295},
			{-0.010051892337479886, 0.02348259287298478, -0.0034443984155391426},
			{-0.007541130238003295, -0.0034443984155391443, 0.02134005695793109}
		},
		{
			{0.027724393381820873, -0.017293427028309397, 0.0023385866426849492},
			{-0.017293427028309397, 0.08106623064420405, -0.03765010818351548},
			{0.0023385866426849475, -0.03765010818351549, 0.03626016250843609}
		},
		{
			{0.044225269479076755, -0.017931047979918645, -0.0035001614958934607},
			{-0.01793104797991867, 0.07224655006159991, -0.009986131235110472},
			{-0.003500161495893465, -0.009986131235110482, 0.027498964947498587}
		},
		{
			{0.10859624566656906, -0.04711458000793199, -0.02248585772572705},
			{-0.04711458000793204, 0.07587197293489858, -0.02073706672117883},
			{-0.022485857725727067, -0.020737066721178823, 0.03851166709433851}
		},
		{
			{0.02180873879795419, -0.019714974780995497, 2.5880790657142937E-4},
			{-0.01971497478099548, 0.05818146814953331, -0.00685858802732606},
			{2.5880790657142785E-4, -0.00685858802732606, 0.003831985015353751}
		},
		{
			{0.05684833908299604, -0.038629613829892356, -0.0016929700793654537},
			{-0.03862961382989234, 0.07060638603354216, -0.021830906493774976},
			{-0.0016929700793654632, -0.02183090649377498, 0.03701142422222409}
		},
		{
			{0.007613691056705484, -9.009965316021081E-4, -0.007525071716803958},
			{-9.009965316021085E-4, 0.05082360587167489, -0.015530329893510102},
			{-0.007525071716803958, -0.015530329893510098, 0.020593883763030188}
		},
		{
			{0.004121448591956781, -0.007232469144827957, 0.0020929808274517602},
			{-0.007232469144827971, 0.07210231176868989, -0.0421889190354386},
			{0.0020929808274517607, -0.0421889190354386, 0.05147367579006903}
		},
		{
			{0.011935632818886512, 0.0033872303602450566, -0.011562839539914207},
			{0.003387230360245053, 0.017410412917864094, -0.007679984848188876},
			{-0.011562839539914205, -0.007679984848188872, 0.02052492443156429}
		},
		{
			{0.025318088143172407, -0.007519869190846861, -0.013316790894500911},
			{-0.007519869190846859, 0.029624021441410204, -0.009580789092551863},
			{-0.013316790894500897, -0.009580789092551873, 0.020887889874978787}
		},
		{
			{0.035942536674712096, -0.0017814647342496003, -0.004873182672340996},
			{-0.0017814647342496038, 0.038360148473873014, -0.006838849126384567},
			{-0.004873182672340996, -0.006838849126384569, 0.015125407782033296}
		},
		{
			{0.08015010386020595, -0.058194434367730065, 0.012365377351522319},
			{-0.058194434367730065, 0.13362843974099411, -0.029682784624731746},
			{0.012365377351522315, -0.029682784624731735, 0.06064642884163661}
		},
		{
			{0.029314734140394885, -0.015820676283596003, -0.014019038782440495},
			{-0.01582067628359599, 0.052102331997345985, -0.012903009842476915},
			{-0.01401903878244049, -0.012903009842476904, 0.023512769184483518}
		},
		{
			{0.051426797796829876, -0.023720508325422683, -0.021308494109638393},
			{-0.02372050832542271, 0.0492256334579512, -0.021536152501962898},
			{-0.021308494109638386, -0.0215361525019629, 0.05015210333077091}
		},
		{
			{0.021635903022994327, -0.00832187894306706, -0.002048071837799535},
			{-0.00832187894306706, 0.03850207969740781, -0.018406581760885506},
			{-0.0020480718377995375, -0.01840658176088551, 0.03206541419727891}
		},
		{
			{0.0734571389710199, -0.04692054487225881, -0.011867131690586804},
			{-0.04692054487225881, 0.09409938535171934, 0.004025766684920309},
			{-0.011867131690586799, 0.004025766684920308, 0.014790172982422398}
		},
		{
			{0.03884805943201066, -0.021568813465317357, -0.0052927152922259794},
			{-0.021568813465317364, 0.056746286513667955, -0.009133486664454484},
			{-0.005292715292225988, -0.009133486664454496, 0.0145020250379029}
		},
		{
			{0.061543281119128886, -0.045117663673453275, -0.003161443582302248},
			{-0.0451176636734533, 0.084468851104332, -0.017968893106285192},
			{-0.003161443582302236, -0.01796889310628519, 0.02679339167790541}
		},
		{
			{0.02396047073150848, -0.01459277496043277, 0.002718765735187253},
			{-0.014592774960432786, 0.0592885643483754, -0.04177600582906588},
			{0.002718765735187255, -0.0417760058290659, 0.0349551493894864}
		},
		{
			{0.017187327845904307, -0.00936507773258511, 0.008811315090011426},
			{-0.009365077732585114, 0.037145685235382614, -0.025818380626998205},
			{0.00881131509001143, -0.025818380626998202, 0.031997375945720594}
		},
		{
			{0.057220407040554463, -0.00889564524872724, -0.013608905637358105},
			{-0.00889564524872724, 0.046295446730330994, 0.003869548945686875},
			{-0.013608905637358126, 0.003869548945686883, 0.016847417131645018}
		},
		{
			{0.05069058393351049, -0.013802430413470075, -0.017785119831148298},
			{-0.013802430413470061, 0.04429731091224786, -0.009172489832427504},
			{-0.01778511983114828, -0.009172489832427504, 0.028747563442993493}
		},
		{
			{0.09925531650353603, -0.024517824067282507, -0.001312475499810036},
			{-0.024517824067282507, 0.0542244224135072, -0.013869771775573405},
			{-0.001312475499810037, -0.013869771775573405, 0.00967692469401107}
		},
		{
			{0.049940572229644924, -0.02624987084712802, -0.0048892622395860065},
			{-0.02624987084712802, 0.05286039647510621, 2.7398424969933685E-4},
			{-0.004889262239586009, 2.739842496993349E-4, 0.0069778789666623976}
		},
		{
			{0.07590964699299695, -0.011246854119545912, -0.0029659854377904462},
			{-0.011246854119545908, 0.07158776066920788, -0.015319132623592604},
			{-0.002965985437790448, -0.015319132623592604, 0.02591778010610031}
		},
		{
			{0.01768830447040428, -0.002281569079685554, -0.009203907545815541},
			{-0.002281569079685555, 0.017918971403716608, -0.003940863618737302},
			{-0.009203907545815543, -0.003940863618737304, 0.019753622883871898}
		},
		{
			{0.10084108964253197, -0.011406393920898886, -7.606895286069839E-4},
			{-0.01140639392089889, 0.07663172703688785, 0.010961515164893802},
			{-7.60689528606984E-4, 0.0109615151648938, 0.014653478537608806}
		},
		{
			{0.031246454758841816, -0.013391064160540615, -0.014508620393048908},
			{-0.01339106416054062, 0.02113124717115792, 0.0039041741557306504},
			{-0.014508620393048913, 0.0039041741557306496, 0.014189137280194105}
		},
		{
			{0.08471975449236438, -0.007411166431513922, -0.03962124305070535},
			{-0.007411166431513922, 0.0920651707467679, -0.034075387815823116},
			{-0.03962124305070534, -0.034075387815823116, 0.10306556728731897}
		},
		{
			{0.05202067721715359, -0.037505870093910605, -0.004426934783718048},
			{-0.037505870093910584, 0.06904156396824694, -0.030095622148361475},
			{-0.004426934783718058, -0.03009562214836149, 0.03828805730230934}
		},
		{
			{0.06938987307565883, -0.021426739629642515, -0.010577847418108209},
			{-0.021426739629642515, 0.030427511144056715, -0.014376028390548093},
			{-0.010577847418108199, -0.014376028390548093, 0.023694604549708512}
		},
		{
			{0.03121800075762998, -0.0268901771114374, 0.004849763090792818},
			{-0.0268901771114374, 0.0529133772364027, -0.012713694971942493},
			{0.00484976309079282, -0.012713694971942498, 0.013869100313165695}
		},
		{
			{0.0015516208794731311, -3.395043471338395E-4, -0.0038727742520860823},
			{-3.3950434713384036E-4, 0.08492268179695989, -0.0379149487071877},
			{-0.0038727742520860827, -0.037914948707187715, 0.0335654590064212}
		},
		{
			{0.019884524763146595, 0.002499793866101434, -0.006350227718438315},
			{0.002499793866101434, 0.014020914819445004, 0.003195395992369259},
			{-0.0063502277184383175, 0.003195395992369259, 0.008389135118468236}
		},
		{
			{0.04819733893847161, -0.01316207121763461, -0.00371205840971221},
			{-0.013162071217634592, 0.04873803569272936, 5.830612691833383E-4},
			{-0.003712058409712208, 5.830612691833351E-4, 0.0022251670949787698}
		}
	};

	double barycentre[61][3] =
	{
		{76.5264423076923, 166.9903846153846, 202.51923076923077},
		{184.21561338289962, 165.28996282527882, 70.24907063197026},
		{131.75688073394497, 186.39678899082568, 244.2224770642202},
		{187.32310838445807, 147.77300613496934, 181.40899795501022},
		{129.27, 191.39, 169.61},
		{107.29878048780488, 125.08536585365853, 167.875},
		{63.89855072463768, 48.47342995169082, 77.18357487922705},
		{157.53916211293262, 111.68852459016394, 97.88888888888889},
		{124.13934426229508, 95.98770491803279, 99.20491803278688},
		{97.28125, 102.95535714285714, 123.19196428571429},
		{151.2445652173913, 156.64945652173913, 93.1711956521739},
		{68.5632183908046, 35.18390804597701, 43.252873563218394},
		{222.7530864197531, 96.87654320987654, 16.32716049382716},
		{25.285171102661597, 20.539923954372625, 24.403041825095055},
		{96.74119718309859, 198.49295774647888, 235.73415492957747},
		{88.2396449704142, 142.57396449704143, 125.93786982248521},
		{188.08163265306123, 211.12244897959184, 186.26530612244898},
		{201.3112128146453, 132.40732265446223, 115.18764302059496},
		{151.62298850574712, 143.88505747126436, 190.95862068965516},
		{39.573170731707314, 125.63414634146342, 109.5609756097561},
		{172.88372093023256, 118.52951699463327, 126.89445438282648},
		{98.24416517055656, 166.23877917414723, 175.84380610412927},
		{137.70471464019852, 118.05707196029776, 139.85111662531017},
		{144.09383378016085, 94.3538873994638, 65.36729222520107},
		{147.6008064516129, 166.14112903225808, 215.52620967741936},
		{195.3014705882353, 158.88235294117646, 136.25},
		{127.13975155279503, 138.61801242236024, 82.91614906832298},
		{132.9868073878628, 200.5725593667546, 206.78891820580475},
		{124.36363636363636, 73.6524064171123, 38.72727272727273},
		{218.65060240963857, 182.98192771084337, 165.05421686746988},
		{144.97841726618705, 111.12230215827338, 17.345323741007196},
		{109.36658932714617, 160.74709976798144, 225.6403712296984},
		{83.29629629629629, 159.02693602693603, 152.62962962962962},
		{11.096385542168674, 162.7710843373494, 173.789156626506},
		{112.43556701030928, 171.1958762886598, 143.55670103092783},
		{118.03896103896103, 157.05714285714285, 112.91948051948052},
		{109.41048034934498, 100.06550218340611, 49.2707423580786},
		{177.00666666666666, 196.66666666666666, 230.88666666666666},
		{94.73478260869565, 126.21304347826087, 89.8391304347826},
		{184.16075650118202, 166.84397163120568, 205.96217494089834},
		{106.03004291845494, 184.04291845493563, 197.19098712446353},
		{116.30602409638554, 142.2144578313253, 198.0578313253012},
		{172.80738786279684, 171.1820580474934, 108.36411609498681},
		{183.34466019417476, 123.10194174757281, 91.60922330097087},
		{55.92217898832685, 144.2568093385214, 165.51750972762645},
		{25.914893617021278, 102.91489361702128, 64.14893617021276},
		{76.30281690140845, 79.83098591549296, 52.41549295774648},
		{162.81553398058253, 127.51456310679612, 163.1747572815534},
		{227.10185185185185, 171.86111111111111, 107.28703703703704},
		{201.009900990099, 213.66336633663366, 111.20792079207921},
		{105.1931330472103, 78.13733905579399, 69.38197424892704},
		{141.23860589812332, 175.20911528150134, 129.45576407506704},
		{81.26102941176471, 82.34558823529412, 91.36764705882354},
		{167.17837837837837, 198.24324324324326, 149.21621621621622},
		{38.93650793650794, 37.1936507936508, 45.546031746031744},
		{194.2608695652174, 132.22774327122153, 152.59006211180125},
		{220.72602739726028, 115.06164383561644, 69.05479452054794},
		{156.64845605700714, 136.06413301662707, 62.70071258907363},
		{1.6341463414634145, 120.58536585365853, 109.39024390243902},
		{197.8617886178862, 149.33333333333334, 11.211382113821138},
		{222.91860465116278, 197.6046511627907, 22.13953488372093}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<61;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<61;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance62clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027005323369307308, -0.01971465818525608, -0.002011559849242795},
		{-0.019714658185256063, 0.04304634461386508, -0.013649613307056005},
		{-0.0020115598492427902, -0.013649613307056012, 0.015349576618836206}
	};

	double matrix[62][3][3] =
	{
		{
			{0.04806151771187669, -0.034080378606922264, -0.0019089834557285672},
			{-0.034080378606922264, 0.05667463214850814, -0.01597254423494389},
			{-0.0019089834557285612, -0.01597254423494389, 0.020624697212345083}
		},
		{
			{0.05929335810759104, -0.04318652316183112, -0.007279445187765795},
			{-0.043186523161831136, 0.09845142355086157, -0.005050342256783882},
			{-0.007279445187765795, -0.0050503422567838765, 0.014570070885091813}
		},
		{
			{0.0652810876717105, -0.0503266488932641, 0.0027990524148080575},
			{-0.050326648893264096, 0.0519705059109211, -0.006488845729664119},
			{0.002799052414808053, -0.006488845729664123, 0.016153410825426002}
		},
		{
			{0.05936443807972663, -0.014869377946508508, -0.014427641933263808},
			{-0.014869377946508508, 0.05581214486914548, 0.004357877055262499},
			{-0.014427641933263798, 0.0043578770552625086, 0.0167378669044646}
		},
		{
			{0.017270185068139415, -0.0025172993898383515, -0.005878037059898592},
			{-0.0025172993898383497, 0.03977312808924989, -0.0158311674636885},
			{-0.005878037059898589, -0.0158311674636885, 0.025176246511788895}
		},
		{
			{0.04871646213531846, -0.04316727831330711, 3.6493083716811637E-4},
			{-0.04316727831330711, 0.11230726766357282, -0.03954283773838947},
			{3.6493083716813025E-4, -0.03954283773838946, 0.044754040420368756}
		},
		{
			{0.029648511483442185, -0.006609340716466372, -0.010023564859584696},
			{-0.006609340716466367, 0.034073165549800194, -2.7185840183376313E-4},
			{-0.010023564859584697, -2.7185840183376227E-4, 0.0051132432871744005}
		},
		{
			{0.06165369783083766, -0.034478880352885134, 0.001240490031660108},
			{-0.0344788803528851, 0.08127634076759774, -0.017755349375769697},
			{0.0012404900316601046, -0.017755349375769697, 0.026241717990773804}
		},
		{
			{0.10754690769998802, -0.05867879288040681, -0.024343372434691805},
			{-0.058678792880406797, 0.07924688542268242, -0.014303951175010609},
			{-0.024343372434691805, -0.014303951175010612, 0.03321578615179239}
		},
		{
			{0.06619248562039053, -0.0037740877329944453, -0.03794173902222152},
			{-0.0037740877329944453, 0.10909559622567203, -0.013174719826927923},
			{-0.03794173902222149, -0.013174719826927937, 0.10100742415327194}
		},
		{
			{0.0016965864283813212, -0.005134248199665479, -0.0011008241961786608},
			{-0.005134248199665479, 0.08914542497683113, -0.058654629524581586},
			{-0.001100824196178662, -0.05865462952458157, 0.063642930651393}
		},
		{
			{0.04746349581376723, -0.01082202225520708, -0.016442804308987206},
			{-0.010822022255207089, 0.026147075923223094, -0.007839288463142677},
			{-0.01644280430898722, -0.00783928846314268, 0.0359478664743872}
		},
		{
			{0.07325491577783429, -0.033133007030434716, -0.02110767216965991},
			{-0.03313300703043471, 0.03585598019337028, -0.0013885284112844492},
			{-0.02110767216965991, -0.0013885284112844561, 0.0350931054805028}
		},
		{
			{0.04011593648440198, -0.028566043141071425, -0.0015997871773121008},
			{-0.028566043141071425, 0.07334680507137464, -0.015133127513035513},
			{-0.0015997871773121026, -0.015133127513035504, 0.01680477085835541}
		},
		{
			{0.0276069331721721, -0.012099982626441203, -0.004418475355186302},
			{-0.012099982626441203, 0.03730648098050068, -0.016818473748272687},
			{-0.004418475355186299, -0.016818473748272687, 0.029667153253558204}
		},
		{
			{0.04733441339890024, -0.016672491904814093, -0.02260926312138171},
			{-0.016672491904814082, 0.048478771336966514, -0.019927911452724312},
			{-0.02260926312138171, -0.019927911452724316, 0.047606767961762386}
		},
		{
			{0.049369097475323365, -0.014033258363917089, 0.002994363677086375},
			{-0.01403325836391708, 0.03774174329026409, -0.0070900982565936625},
			{0.002994363677086374, -0.007090098256593661, 0.008196640310962608}
		},
		{
			{9.011264031940298E-4, 9.526352218199639E-4, 0.0016736027574306303},
			{9.526352218199637E-4, 0.0817647686962557, -0.0369154418060168},
			{0.0016736027574306299, -0.0369154418060168, 0.0487547470504347}
		},
		{
			{0.056294837807910024, -7.214884531349099E-4, 2.8618574803357258E-5},
			{-7.214884531349302E-4, 0.14782679743436902, -0.024313673198777804},
			{2.8618574803361378E-5, -0.024313673198777794, 0.04916828352169078}
		},
		{
			{0.0720808817810436, -0.0765804078246741, 0.01492467900676935},
			{-0.07658040782467411, 0.16345969629670606, -0.08113241480635353},
			{0.014924679006769357, -0.08113241480635348, 0.06827478327712329}
		},
		{
			{0.015661835155133082, -0.0026143578803766703, -0.00650884099257369},
			{-0.0026143578803766716, 0.02698931709335703, -0.011004705696771883},
			{-0.006508840992573693, -0.011004705696771885, 0.0224915476547547}
		},
		{
			{0.015984321638455302, -0.002966288721307291, -0.013582635609626909},
			{-0.0029662887213072996, 0.028047197022913292, -0.012540163920543483},
			{-0.01358263560962691, -0.012540163920543478, 0.027711166343208013}
		},
		{
			{0.12813128962274503, -0.043791331769348664, -0.023766802197003487},
			{-0.04379133176934864, 0.2028789349043189, -0.0528582467233495},
			{-0.023766802197003466, -0.052858246723349475, 0.036356944234144}
		},
		{
			{0.042228025395315984, -0.04876787738178458, 0.019870999887545492},
			{-0.04876787738178456, 0.1620162659804819, -0.10946329163999492},
			{0.01987099988754549, -0.10946329163999492, 0.1410924764422099}
		},
		{
			{0.056312023913404674, -0.03161520780694583, -0.006063443983432681},
			{-0.03161520780694582, 0.0830537894170399, -0.0430008752783015},
			{-0.006063443983432684, -0.0430008752783015, 0.04792790234563752}
		},
		{
			{0.041504894854792126, -0.020091175191452922, -0.011265587011144112},
			{-0.020091175191452922, 0.02494490452136271, 0.0052263054839706445},
			{-0.011265587011144116, 0.005226305483970647, 0.011621679680587506}
		},
		{
			{0.021943707679462986, -0.013476624408157074, -0.0028020059800233435},
			{-0.013476624408157084, 0.03207362084274771, -0.005132334198990908},
			{-0.00280200598002334, -0.005132334198990908, 0.0202762843553263}
		},
		{
			{0.16675987209176005, -0.17732303228013802, -0.023813740528636315},
			{-0.17732303228013813, 0.2184357985273033, 0.006294744611589768},
			{-0.023813740528636322, 0.006294744611589765, 0.020889392716467}
		},
		{
			{0.014439705176669785, -0.022586904527799084, 0.01234629418804179},
			{-0.022586904527799094, 0.07846498532378389, -0.059180253995743},
			{0.012346294188041795, -0.05918025399574301, 0.06272450106173513}
		},
		{
			{0.027934915032295993, -0.015478023762817303, -0.0128372322126546},
			{-0.015478023762817296, 0.0525568861465822, -0.013065468009294106},
			{-0.012837232212654601, -0.0130654680092941, 0.024304819342623206}
		},
		{
			{0.04529593585074511, -0.014429067308124302, -0.013098928170436074},
			{-0.014429067308124295, 0.07871919751847618, -0.014587748336008413},
			{-0.013098928170436067, -0.01458774833600841, 0.016003887499322873}
		},
		{
			{0.0118415525563806, 3.4200104413933605E-4, -0.013578670805426098},
			{3.420010441393369E-4, 0.02043724213461988, -0.006572109006977725},
			{-0.013578670805426107, -0.006572109006977729, 0.02083452826369659}
		},
		{
			{0.039242599821148604, 0.006368602459196444, -0.007455955386425826},
			{0.006368602459196451, 0.0377280859084652, -6.938338568607668E-4},
			{-0.007455955386425827, -6.938338568607673E-4, 0.0030444204203577824}
		},
		{
			{0.02164103185528512, -0.013440000603824904, 6.918723709869404E-4},
			{-0.01344000060382492, 0.048010720415833215, -0.035877359712376794},
			{6.918723709869355E-4, -0.035877359712376766, 0.03344621649408997}
		},
		{
			{0.052862370469643434, -0.029246881704208, -0.005050947007360194},
			{-0.029246881704207993, 0.07911912042726779, -0.019874097077971196},
			{-0.005050947007360192, -0.019874097077971196, 0.0330008223915653}
		},
		{
			{0.051391189626712845, -0.03809677011842865, -0.005633078107961967},
			{-0.03809677011842864, 0.10251512613379193, -0.003212841292499188},
			{-0.0056330781079619585, -0.0032128412924991804, 0.0254001530744005}
		},
		{
			{0.23222203477871864, -0.04466107279371007, -0.11122037813504906},
			{-0.044661072793710045, 0.052153421327697486, 0.025222847984930467},
			{-0.11122037813504902, 0.025222847984930498, 0.05360509347506077}
		},
		{
			{0.07821117278367853, -0.07504849715566386, -0.0011457343359284658},
			{-0.07504849715566385, 0.12123329163749705, -0.029263280549253916},
			{-0.0011457343359284624, -0.029263280549253916, 0.02966603329055967}
		},
		{
			{0.022114698118072085, -0.010374585053020906, -0.00643327095963268},
			{-0.010374585053020899, 0.024123697718936903, -0.003798596521435148},
			{-0.00643327095963268, -0.0037985965214351464, 0.020318358524534102}
		},
		{
			{0.10276982395036094, -0.05424272062944072, 0.0010227671359910896},
			{-0.05424272062944077, 0.16930716904181506, 0.0019963044749516205},
			{0.0010227671359910886, 0.001996304474951622, 0.008169173194156805}
		},
		{
			{0.09907752580965544, -0.023753936931400835, 0.005649025469243687},
			{-0.023753936931400835, 0.08102366929742427, 0.009105095376968618},
			{0.005649025469243686, 0.009105095376968608, 0.019852751055589996}
		},
		{
			{0.06633974483769565, -0.019288426040077203, -0.01638415244949429},
			{-0.019288426040077206, 0.04925601479098699, -0.009685541659700939},
			{-0.016384152449494288, -0.009685541659700935, 0.026794445910194007}
		},
		{
			{0.04007509608854401, -0.01148712845631119, -0.0021286038835187414},
			{-0.011487128456311179, 0.048766362447380814, 6.205590582718698E-4},
			{-0.0021286038835187397, 6.205590582718681E-4, 0.009961576163262332}
		},
		{
			{0.043616781985326813, -0.016709757610032145, -0.002043607984102912},
			{-0.01670975761003211, 0.07624890988649081, -0.030352600313199682},
			{-0.002043607984102923, -0.03035260031319969, 0.03153248795666169}
		},
		{
			{0.004038146449383296, -0.002518154576717779, 0.006112798480801966},
			{-0.0025181545767177863, 0.05050936661422067, -0.037119929264202114},
			{0.006112798480801963, -0.03711992926420213, 0.046693359570244564}
		},
		{
			{0.026475344021554194, -0.026004811966757704, 0.0026471912368308394},
			{-0.026004811966757708, 0.06227067709918675, -0.002949583012075283},
			{0.0026471912368308402, -0.002949583012075284, 0.0021684735429134605}
		},
		{
			{0.08078202247310882, -0.059597558740562606, 0.012269779347391593},
			{-0.059597558740562634, 0.1397119069052079, -0.03129302422082197},
			{0.01226977934739161, -0.03129302422082198, 0.05974608772718979}
		},
		{
			{0.04284349553509549, -0.006713535993872989, -0.0206587989202164},
			{-0.006713535993872996, 0.07297890886148961, -0.035728663375409975},
			{-0.0206587989202164, -0.035728663375409996, 0.0463697221473096}
		},
		{
			{0.024101099433105903, -0.005398048677705124, -0.013329784111568307},
			{-0.005398048677705123, 0.034096957749814125, -0.009658702551872437},
			{-0.01332978411156831, -0.009658702551872438, 0.02070428277829571}
		},
		{
			{0.021747725810730104, 0.003461928096107349, -0.006254291039728163},
			{0.00346192809610735, 0.014392933939689101, 0.0024208245855346085},
			{-0.006254291039728172, 0.002420824585534604, 0.007242906105768771}
		},
		{
			{0.07576408854479237, -0.030162432105941214, -0.006996604296848796},
			{-0.030162432105941245, 0.03714415525349623, -0.017121841868721396},
			{-0.006996604296848807, -0.017121841868721392, 0.0292423464259961}
		},
		{
			{0.06260805373350216, -0.03362768700309549, -0.002512844600990103},
			{-0.03362768700309546, 0.07666052282143944, -0.03423627540908938},
			{-0.0025128446009901177, -0.03423627540908939, 0.04098663609231518}
		},
		{
			{0.012903007200141408, -0.010680997434751711, 0.0024744342291123313},
			{-0.010680997434751694, 0.05632597592132461, -0.029998884159752322},
			{0.0024744342291123296, -0.029998884159752322, 0.02903295822433471}
		},
		{
			{0.022263543731753106, -0.017687574020180598, 0.006200823779147216},
			{-0.017687574020180584, 0.07545205878291446, -0.03698817918344771},
			{0.006200823779147205, -0.036988179183447704, 0.03950669534023282}
		},
		{
			{0.017697653030814508, -0.002386164629166177, -0.009537793602951974},
			{-0.002386164629166178, 0.0238668852473898, -0.006604957834157322},
			{-0.009537793602951974, -0.006604957834157321, 0.019583874463880196}
		},
		{
			{0.004319087509655994, -0.014726429089085277, 0.00941940818334537},
			{-0.014726429089085292, 0.050211479351130274, -0.032102621080879905},
			{0.009419408183345385, -0.032102621080879905, 0.03463109684143807}
		},
		{
			{0.03193353212006823, -0.02457545151330312, 0.002344272241567945},
			{-0.024575451513303096, 0.050361253512304784, -0.012718639262754199},
			{0.0023442722415679402, -0.012718639262754199, 0.013029821745415103}
		},
		{
			{0.036570441218310115, -0.011633976096273185, 4.809251570828299E-4},
			{-0.011633976096273186, 0.0818926930071575, 0.0015334317379278614},
			{4.809251570828295E-4, 0.0015334317379278625, 0.020884345512179298}
		},
		{
			{0.03900950633312921, -0.02231739640593712, 9.184721604527739E-4},
			{-0.02231739640593709, 0.06445298016568868, -0.0357810415922137},
			{9.184721604527748E-4, -0.0357810415922137, 0.04150075988941121}
		},
		{
			{0.0311937659175118, -0.01153382875777889, -0.002940908647230383},
			{-0.011533828757778884, 0.05355887206106641, -0.010055891406675909},
			{-0.002940908647230376, -0.0100558914066759, 0.027675441740266184}
		},
		{
			{0.029965611292408725, -0.022644659046418093, 0.006090728273954597},
			{-0.022644659046418075, 0.06897670839812321, -0.04126122783080728},
			{0.006090728273954589, -0.04126122783080731, 0.04217996064073827}
		},
		{
			{0.03030341135794919, -0.00426923439416482, -0.006330079399402099},
			{-0.0042692343941648225, 0.06554969742856163, -0.0279541075175463},
			{-0.0063300793994021005, -0.027954107517546307, 0.04187271140836281}
		}
	};

	double barycentre[62][3] =
	{
		{150.2258064516129, 109.9605734767025, 62.6415770609319},
		{121.63695652173914, 144.93695652173912, 199.02173913043478},
		{219.36170212765958, 91.32978723404256, 45.08510638297872},
		{77.12251655629139, 78.86092715231788, 52.22185430463576},
		{92.04739336492891, 162.62559241706163, 162.54739336492892},
		{138.75449101796409, 167.1676646706587, 229.47904191616766},
		{184.2674418604651, 168.04651162790697, 70.47674418604652},
		{193.19614147909968, 136.40192926045017, 98.7652733118971},
		{218.0601092896175, 181.02732240437157, 158.59562841530055},
		{51.950118764845605, 37.02850356294537, 47.394299287410924},
		{16.179775280898877, 168.74157303370785, 186.2921348314607},
		{171.39468302658486, 125.95092024539878, 157.10020449897752},
		{222.98275862068965, 102.26724137931035, 7.293103448275862},
		{177.6235632183908, 173.1522988505747, 116.00862068965517},
		{103.76406533575317, 176.52813067150635, 185.09255898366607},
		{187.7067448680352, 168.17008797653958, 207.11730205278593},
		{215.64462809917356, 201.95867768595042, 98.35537190082644},
		{36.375, 125.9659090909091, 112.22727272727273},
		{26.436046511627907, 23.392441860465116, 27.938953488372093},
		{156.39467849223948, 161.70731707317074, 205.59866962305986},
		{87.77832512315271, 145.07142857142858, 130.67733990147784},
		{133.27868852459017, 192.9016393442623, 169.6448087431694},
		{90.2295918367347, 104.28061224489795, 125.78571428571429},
		{130.8511235955056, 190.8988764044944, 244.2865168539326},
		{197.5660792951542, 138.60352422907488, 152.27533039647577},
		{176.6787878787879, 204.3030303030303, 147.35757575757575},
		{153.69950738916256, 160.65024630541873, 97.30788177339902},
		{191.03225806451613, 209.36129032258066, 187.06451612903226},
		{99.89583333333333, 201.0648148148148, 239.4837962962963},
		{94.72131147540983, 127.52868852459017, 90.40163934426229},
		{153.67519181585678, 135.79539641943734, 181.8542199488491},
		{113.55958549222798, 172.80569948186528, 144.2020725388601},
		{224.6027397260274, 197.53424657534248, 16.315068493150687},
		{53.371308016877634, 148.40928270042195, 161.9198312236287},
		{105.5880829015544, 159.67357512953367, 225.32642487046633},
		{121.37837837837837, 69.43243243243244, 34.79054054054054},
		{66.55670103092784, 50.9639175257732, 78.85567010309278},
		{100.209375, 127.6625, 172.984375},
		{128.8862973760933, 139.0728862973761, 83.36151603498543},
		{117.91481481481482, 98.25925925925925, 105.1},
		{86.18079096045197, 81.19491525423729, 85.73446327683615},
		{134.1012658227848, 123.56455696202532, 149.5974683544304},
		{107.324, 97.312, 49.94},
		{170.81927710843374, 119.73293172690764, 93.86345381526104},
		{5.264367816091954, 153.0344827586207, 159.94252873563218},
		{143.76470588235293, 110.83823529411765, 16.91176470588235},
		{175.34285714285716, 196.75555555555556, 230.1809523809524},
		{186.45714285714286, 148.62448979591838, 182.64897959183673},
		{117.99261083743842, 156.79310344827587, 113.27586206896552},
		{197.5, 149.84920634920636, 12.65079365079365},
		{219.06711409395973, 122.44295302013423, 80.42281879194631},
		{208.5735294117647, 144.34558823529412, 122.92279411764706},
		{85.83193277310924, 184.80112044817926, 216.64425770308122},
		{127.32317073170732, 196.8231707317073, 204.57926829268294},
		{142.3068783068783, 176.6031746031746, 131.25396825396825},
		{15.880597014925373, 107.44776119402985, 74.70149253731343},
		{158.14824797843667, 141.53369272237197, 63.67385444743935},
		{130.47284345047925, 83.26837060702876, 64.59424920127796},
		{183.85294117647058, 122.91176470588235, 124.21638655462185},
		{157.3179347826087, 109.77173913043478, 126.50815217391305},
		{77.12, 160.4742857142857, 193.32857142857142},
		{150.825, 103.5, 95.03125}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<62;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<62;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance63clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027105408342593187, -0.020070875600271796, -0.0018362431236372027},
		{-0.020070875600271793, 0.04207790625250921, -0.013139985971973104},
		{-0.0018362431236372057, -0.013139985971973115, 0.015122325852984998}
	};

	double matrix[63][3][3] =
	{
		{
			{0.05434562613605022, -0.004997932625626887, -0.023273581283433174},
			{-0.004997932625626887, 0.09537324128319628, -0.03787598936389662},
			{-0.023273581283433178, -0.03787598936389661, 0.03605343520540231}
		},
		{
			{0.024479879521869093, -0.007381792619411251, -0.0023424971206864},
			{-0.007381792619411252, 0.049883702735415696, -0.03084503598671691},
			{-0.0023424971206864, -0.030845035986716892, 0.0356960169101178}
		},
		{
			{0.044259611261668545, -0.016898713503999744, -0.00786507462655183},
			{-0.016898713503999723, 0.05567021049385466, -7.797122806852508E-4},
			{-0.007865074626551824, -7.797122806852397E-4, 0.0162598694508169}
		},
		{
			{0.020576552805633908, -0.011051643037933701, -0.0018243589654304343},
			{-0.011051643037933696, 0.05899895426334874, -0.03562119379339251},
			{-0.0018243589654304334, -0.035621193793392514, 0.04089422303116011}
		},
		{
			{0.09549851082511142, -0.008471263902034875, 0.0015414718271219412},
			{-0.008471263902034874, 0.050186008330222104, 0.0058055070731968285},
			{0.0015414718271219408, 0.00580550707319683, 0.019337305915204404}
		},
		{
			{0.04920567563653437, -0.04134216331768564, -0.009578759187762166},
			{-0.041342163317685636, 0.08669530588830361, -0.0241576585660178},
			{-0.00957875918776216, -0.024157658566017787, 0.0414937899033742}
		},
		{
			{0.023510567097009515, -0.008899698422200498, -5.44207080431249E-4},
			{-0.008899698422200503, 0.048259121747004724, -0.0350366923969593},
			{-5.442070804312507E-4, -0.0350366923969593, 0.0473772385782258}
		},
		{
			{0.06770869382796661, -0.005342343864392015, -0.0016321254194807224},
			{-0.00534234386439202, 0.05171585268591123, -0.011271619968546006},
			{-0.0016321254194807244, -0.011271619968546021, 0.009441864022185054}
		},
		{
			{0.0206370025475997, 0.0035805199789772073, -0.005144208037853181},
			{0.0035805199789772078, 0.012960637342774802, 0.001910187992691232},
			{-0.00514420803785318, 0.0019101879926912329, 0.006276985220312649}
		},
		{
			{0.030473108474117192, -0.015476136357910605, -0.0032227016971924684},
			{-0.015476136357910602, 0.045953737796370464, -0.022118847686770506},
			{-0.003222701697192465, -0.022118847686770506, 0.02769546978945181}
		},
		{
			{0.026492014431743406, -0.017146811968668404, -0.00268425790711033},
			{-0.017146811968668414, 0.026026393386335514, -0.0054785199258844085},
			{-0.00268425790711033, -0.005478519925884408, 0.0191410091432324}
		},
		{
			{0.021960460374056214, 0.003500711692350472, -0.004819951663764903},
			{0.003500711692350474, 0.0397393938225384, -0.026727128601305793},
			{-0.004819951663764904, -0.026727128601305793, 0.03227317943667339}
		},
		{
			{0.014149601729644, 0.004436831103518768, -0.0130020961218353},
			{0.004436831103518768, 0.0217535099136409, -0.008716905003897515},
			{-0.013002096121835297, -0.008716905003897504, 0.0196046157586429}
		},
		{
			{0.06895049519069678, 0.009030100337363532, -0.04364078516372708},
			{0.009030100337363537, 0.202309479518639, 0.009492241779436372},
			{-0.0436407851637271, 0.009492241779436368, 0.029900027825907297}
		},
		{
			{0.008483555404760377, -1.9415191927396602E-4, -0.0061671668024449065},
			{-1.941519192739721E-4, 0.0470692526823101, -0.03516646820429269},
			{-0.006167166802444909, -0.03516646820429269, 0.03439666237105527}
		},
		{
			{0.04234974079388955, -0.03384828503423923, -0.0022370077084882378},
			{-0.03384828503423923, 0.05952814512010424, -0.013900971399412413},
			{-0.002237007708488243, -0.013900971399412407, 0.0238019833354342}
		},
		{
			{0.05995037198296283, -0.037813447730312186, -0.0105694797780084},
			{-0.03781344773031217, 0.07055933430080363, 0.003737845074462754},
			{-0.010569479778008404, 0.0037378450744627494, 0.007466641169857416}
		},
		{
			{0.07272304579352931, -0.03652899277368057, -0.03077825679968178},
			{-0.036528992773680574, 0.043815658678139136, 0.016592772100569312},
			{-0.03077825679968177, 0.01659277210056931, 0.0316994727933428}
		},
		{
			{0.04567850769860488, -0.02457898167486119, -0.010847930330336797},
			{-0.024578981674861188, 0.0716053884945932, -0.010571972108183194},
			{-0.010847930330336797, -0.010571972108183203, 0.015012597703338593}
		},
		{
			{0.04596737707137822, 0.011022655875653656, -0.01081607949621918},
			{0.011022655875653665, 0.024065089683752552, 0.005108352653486647},
			{-0.010816079496219188, 0.005108352653486643, 0.005314155574411958}
		},
		{
			{0.061937687436729554, -0.0377077818808439, -0.009961594630812143},
			{-0.037707781880843914, 0.04204670868499708, -0.017777704543394706},
			{-0.00996159463081215, -0.017777704543394703, 0.0322236532317694}
		},
		{
			{0.04013142069142352, -0.025060432711063146, -0.003547350576094461},
			{-0.025060432711063146, 0.06538181418830132, -0.014434773934272702},
			{-0.0035473505760944594, -0.014434773934272699, 0.016668184645855295}
		},
		{
			{0.030397622937026764, -0.024232814831491378, 0.0017626195388367426},
			{-0.02423281483149138, 0.05096447923927651, -0.009868004464846696},
			{0.0017626195388367413, -0.009868004464846694, 0.012932365691093694}
		},
		{
			{0.014026209016582194, 0.002698236197348135, -0.01180410674014159},
			{0.002698236197348135, 0.022535415588646794, -0.014084722872884389},
			{-0.01180410674014159, -0.014084722872884389, 0.026431887418302984}
		},
		{
			{0.03969044950509003, -0.02357185042338831, -0.002658096823830376},
			{-0.02357185042338831, 0.04302786196032502, -0.015214209032046396},
			{-0.0026580968238303785, -0.015214209032046403, 0.018060912297676993}
		},
		{
			{0.01507688595149771, -0.010245398819613918, 0.0020784141945855298},
			{-0.010245398819613925, 0.055504694532633285, -0.02959768373840718},
			{0.002078414194585535, -0.02959768373840718, 0.029020810111327684}
		},
		{
			{0.0043018335111945595, -0.008877145923879951, 0.003394789357018818},
			{-0.008877145923879955, 0.06939463859280395, -0.0400656110625078},
			{0.0033947893570188286, -0.04006561106250779, 0.05025308454564202}
		},
		{
			{0.21952146294664332, -0.07291695183295749, -0.09184590713400428},
			{-0.07291695183295747, 0.03157811455838423, 0.020255246207079018},
			{-0.09184590713400426, 0.020255246207079018, 0.052951882783660906}
		},
		{
			{0.06949716997954015, -0.028615574325940224, -0.0032250530524244366},
			{-0.02861557432594025, 0.03855645186142435, -0.02021389522021662},
			{-0.0032250530524244436, -0.020213895220216604, 0.03113788354658099}
		},
		{
			{0.06489807166306799, -0.04080441397333249, -0.012296333936167598},
			{-0.04080441397333253, 0.0930446545706247, -0.0062797622271933175},
			{-0.012296333936167594, -0.00627976222719331, 0.01333899196043319}
		},
		{
			{0.07717409433375728, -0.02659349764267643, -0.008353194495879611},
			{-0.026593497642676413, 0.05180217666930891, -0.0025317575266218147},
			{-0.00835319449587961, -0.0025317575266218164, 0.0296943425282043}
		},
		{
			{0.03256486405597131, -0.008252579804095229, -0.012123979828567295},
			{-0.008252579804095238, 0.026664450499789997, -0.004340337142223464},
			{-0.012123979828567305, -0.00434033714222346, 0.018253694534391202}
		},
		{
			{0.17696817690308286, -0.18444730155427327, -0.034815519706700555},
			{-0.18444730155427325, 0.20035997631873165, 0.020693191259617643},
			{-0.034815519706700555, 0.020693191259617633, 0.03680504854995883}
		},
		{
			{0.05038844271162556, -0.03065463066402456, -1.1287018729794684E-4},
			{-0.030654630664024553, 0.08321123816219356, -0.04215262549377651},
			{-1.1287018729792559E-4, -0.042152625493776484, 0.04271525671630033}
		},
		{
			{0.04791172183210188, -0.011834067935474521, -0.007249359965772608},
			{-0.011834067935474521, 0.034951920840097725, -0.014487620644534294},
			{-0.007249359965772605, -0.014487620644534295, 0.03887564320719161}
		},
		{
			{0.10494504012804902, -0.055067972590088096, -0.0229539746860999},
			{-0.05506797259008813, 0.08150711141108122, -0.0193656795537156},
			{-0.022953974686099908, -0.01936567955371561, 0.034752628167088816}
		},
		{
			{0.0616008549589302, -0.03089433765066358, -0.018631047376769128},
			{-0.030894337650663566, 0.092526028502177, -0.01376685654278233},
			{-0.01863104737676913, -0.013766856542782325, 0.03731422897192174}
		},
		{
			{0.047087286947087366, -0.02175104044479918, -0.011133556712804495},
			{-0.021751040444799183, 0.056288459271738554, 0.0055159534903875184},
			{-0.011133556712804495, 0.005515953490387514, 0.017102877463836597}
		},
		{
			{0.014827482529873103, -0.02186724271229431, 0.010340913218039918},
			{-0.021867242712294323, 0.07965984876358871, -0.05835165014902943},
			{0.01034091321803993, -0.05835165014902942, 0.060585283366876526}
		},
		{
			{0.07304711816054124, -0.07424678047080376, 0.020164601090233464},
			{-0.07424678047080371, 0.1506640217532211, -0.041520099798260504},
			{0.020164601090233443, -0.041520099798260525, 0.0651302112268865}
		},
		{
			{0.08663112179715285, -0.0590825862691864, -0.010827970376166488},
			{-0.059082586269186395, 0.11864761886798705, -0.02276865409253241},
			{-0.010827970376166483, -0.02276865409253241, 0.019194374953080108}
		},
		{
			{0.036767534741810326, -0.016224799113668135, -3.7997453118369007E-4},
			{-0.01622479911366814, 0.08685659303043466, -2.2570213808793477E-4},
			{-3.799745311836893E-4, -2.257021380879354E-4, 0.019980374027075802}
		},
		{
			{0.10970832665006011, -0.05826760032107909, -0.003678722458259483},
			{-0.05826760032107903, 0.29880586196373493, -0.05433276364892901},
			{-0.003678722458259481, -0.05433276364892901, 0.0237273455049559}
		},
		{
			{0.003393722092822195, -0.002923428715751014, 0.002090950233049353},
			{-0.0029234287157509932, 0.07215332084258887, -0.04218637035274912},
			{0.0020909502330493357, -0.04218637035274912, 0.051165818131585994}
		},
		{
			{0.06219323447850029, -0.03434069922008982, -0.005477632823314019},
			{-0.03434069922008982, 0.07384237696967051, -0.03231256232862672},
			{-0.005477632823314031, -0.032312562328626726, 0.04186224808358552}
		},
		{
			{0.015168780682078192, 0.00145006395145161, -0.00978044465428031},
			{0.0014500639514516082, 0.0130733189731403, -0.001321757672572509},
			{-0.009780444654280313, -0.0013217576725725094, 0.019803058584413922}
		},
		{
			{0.04840704959489776, -0.013445212871894211, -0.01475331138689452},
			{-0.013445212871894215, 0.06957035123919547, -0.032912729755464894},
			{-0.014753311386894521, -0.0329127297554649, 0.042967378698311715}
		},
		{
			{0.04576093433435124, -0.0345023602449829, 0.001835521135598359},
			{-0.034502360244982926, 0.07725572520017857, -0.019127015845786},
			{0.0018355211355983612, -0.019127015845786004, 0.019717937659810596}
		},
		{
			{0.025876520997369493, 0.012320344899167616, -0.0104747878311982},
			{0.012320344899167614, 0.02248272468411252, 9.245587835665127E-4},
			{-0.010474787831198203, 9.245587835665101E-4, 0.008262476509130234}
		},
		{
			{0.045512218457783485, -0.024664373563348174, -0.00947557924917254},
			{-0.024664373563348174, 0.07829100458077975, -0.037653539877091795},
			{-0.009475579249172542, -0.037653539877091816, 0.11317780948106998}
		},
		{
			{0.028690109682983782, -0.026519105919170668, 0.002191534457371007},
			{-0.02651910591917068, 0.062394685170684694, -0.0035302360700343476},
			{0.002191534457371009, -0.0035302360700343485, 0.0020005981327405505}
		},
		{
			{0.09228005754277777, -0.01332321717783774, -0.0183944784744649},
			{-0.01332321717783774, 0.16745136813662986, 0.002432750663482023},
			{-0.01839447847446493, 0.002432750663482002, 0.02269723986860283}
		},
		{
			{0.05736576201554786, -0.042029551662693544, 0.0010536222735410437},
			{-0.04202955166269354, 0.05886864002853592, -0.007522488224003142},
			{0.0010536222735410424, -0.007522488224003142, 0.014793501841440002}
		},
		{
			{0.0478383343140379, -0.016734595328748304, -0.02423476997056781},
			{-0.016734595328748318, 0.04305700029079793, -0.0198001244866552},
			{-0.024234769970567803, -0.019800124486655222, 0.050079043256620416}
		},
		{
			{0.022995476888847524, -0.008489726504452445, -0.009792836968354052},
			{-0.008489726504452448, 0.024410494057259965, -0.009023473375925975},
			{-0.009792836968354049, -0.009023473375925978, 0.022518043898465196}
		},
		{
			{0.026927100460372184, -0.014817013091115994, -0.012725316945006202},
			{-0.014817013091115983, 0.028941129390152677, 0.0014082020370658893},
			{-0.012725316945006195, 0.0014082020370658858, 0.012717478788920999}
		},
		{
			{0.1015111411170381, -0.013735558334729656, -0.039239954651672834},
			{-0.01373555833472967, 0.07066793006088574, -0.03545840807658997},
			{-0.03923995465167286, -0.03545840807658997, 0.11158919784097002}
		},
		{
			{0.021629685242386607, -0.001724493470530648, -0.0102128345150315},
			{-0.0017244934705306497, 0.026298040104275312, -0.0097377542002441},
			{-0.010212834515031495, -0.009737754200244106, 0.0185813554998729}
		},
		{
			{0.03255390829407499, -0.01922667234604837, 0.0023020213463572133},
			{-0.0192266723460484, 0.06893178284948007, -0.023631928991473806},
			{0.0023020213463572255, -0.02363192899147381, 0.03155476959562201}
		},
		{
			{0.0479643897850574, -0.017007010953066296, -0.015050305656615899},
			{-0.017007010953066296, 0.042056862377453895, -0.011584768083609202},
			{-0.015050305656615904, -0.011584768083609205, 0.03304790584866999}
		},
		{
			{0.06349997098988433, -0.06505954619981186, 0.007331880015993789},
			{-0.06505954619981184, 0.13948941177164706, -0.044358130126901714},
			{0.007331880015993783, -0.04435813012690173, 0.0339948000973284}
		},
		{
			{0.10169837395262904, -0.051096128063073225, -0.023003731084344513},
			{-0.05109612806307322, 0.1369214320497089, -0.0661483660797473},
			{-0.02300373108434455, -0.0661483660797473, 0.10456327884819501}
		},
		{
			{0.0161329699532741, 0.00175170775612134, -0.010126081912867589},
			{0.0017517077561213365, 0.0390982116953559, -0.01761117337781781},
			{-0.010126081912867589, -0.0176111733778178, 0.02645220268598229}
		}
	};

	double barycentre[63][3] =
	{
		{128.117994100295, 124.94395280235989, 160.80825958702064},
		{119.88655462184875, 194.53361344537817, 203.30252100840337},
		{113.96910112359551, 86.05898876404494, 43.9747191011236},
		{179.414, 118.838, 123.558},
		{86.34693877551021, 83.10969387755102, 87.28571428571429},
		{182.14848484848486, 116.41818181818182, 89.0969696969697},
		{68.45075757575758, 162.96969696969697, 189.06060606060606},
		{227.47297297297297, 191.72972972972974, 86.0},
		{190.88505747126436, 155.816091954023, 16.620689655172413},
		{99.25193199381762, 170.27820710973725, 180.225656877898},
		{143.9321608040201, 156.44472361809045, 93.12311557788945},
		{24.646464646464647, 114.73737373737374, 82.20202020202021},
		{121.01837270341207, 184.11286089238845, 161.58267716535434},
		{69.0670731707317, 33.75609756097561, 41.15243902439025},
		{52.65625, 153.625, 157.86607142857142},
		{150.38141025641025, 109.75641025641026, 65.41025641025641},
		{200.02941176470588, 210.52941176470588, 125.08823529411765},
		{221.0108695652174, 92.3695652173913, 10.543478260869565},
		{159.05164319248826, 139.3450704225352, 185.1361502347418},
		{225.2258064516129, 197.93548387096774, 10.17741935483871},
		{220.66233766233765, 130.7012987012987, 5.64935064935065},
		{172.96774193548387, 171.6889400921659, 113.38709677419355},
		{155.05820105820106, 141.1216931216931, 63.51851851851852},
		{97.43807339449542, 162.80275229357798, 145.47935779816513},
		{184.65882352941176, 156.5921568627451, 77.11764705882354},
		{86.16230366492147, 183.12041884816753, 216.4502617801047},
		{7.319148936170213, 162.07801418439718, 175.3404255319149},
		{64.27354260089686, 48.766816143497756, 76.6322869955157},
		{221.07692307692307, 124.55244755244755, 80.83916083916084},
		{124.65260545905707, 143.6848635235732, 195.61290322580646},
		{116.40722891566266, 162.19277108433735, 226.3277108433735},
		{112.58904109589041, 130.5917808219178, 83.71506849315068},
		{192.46012269938652, 208.25766871165644, 184.50306748466258},
		{197.2324093816631, 137.68443496801706, 146.71641791044777},
		{145.45808383233532, 113.6377245508982, 134.76646706586826},
		{218.54395604395606, 179.3901098901099, 155.82417582417582},
		{92.72972972972973, 146.37451737451738, 207.77220077220076},
		{78.47619047619048, 80.88392857142857, 53.279761904761905},
		{100.23250564334086, 200.9864559819413, 239.95259593679458},
		{159.84415584415584, 192.1103896103896, 226.1461038961039},
		{88.87086092715232, 130.14900662251657, 166.7185430463576},
		{131.00923076923078, 83.69846153846154, 67.32615384615384},
		{105.96238244514106, 101.38871473354232, 117.06583072100314},
		{29.61764705882353, 126.52941176470588, 129.94117647058823},
		{203.32432432432432, 139.8992628992629, 114.76904176904176},
		{136.80693069306932, 174.5470297029703, 130.40346534653466},
		{191.25393258426968, 146.21123595505617, 177.19101123595505},
		{163.43324250681198, 130.18801089918256, 100.44141689373296},
		{182.21, 187.84, 66.77},
		{132.33501259445845, 186.40554156171285, 244.09068010075566},
		{143.7027027027027, 108.87837837837837, 17.83108108108108},
		{24.867424242424242, 20.848484848484848, 24.704545454545453},
		{215.8452380952381, 92.78571428571429, 47.55952380952381},
		{183.9100642398287, 164.53961456102783, 203.70235546038543},
		{142.56221198156683, 200.72350230414747, 180.8709677419355},
		{163.02906976744185, 195.6918604651163, 149.02906976744185},
		{39.12149532710281, 37.90654205607477, 46.034267912772584},
		{115.12990196078431, 156.8406862745098, 115.4093137254902},
		{149.6754617414248, 102.62269129287598, 100.04485488126649},
		{169.47, 125.704, 157.054},
		{149.71458773784354, 163.5877378435518, 211.07188160676532},
		{194.0888888888889, 201.6074074074074, 230.95555555555555},
		{84.4954128440367, 136.48929663608564, 119.58409785932722}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<63;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<63;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance64clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026656829533110684, -0.019789626829040296, -0.0017751613305643625},
		{-0.01978962682904031, 0.043109467620951136, -0.014069985447432305},
		{-0.0017751613305643597, -0.014069985447432312, 0.01587723578713071}
	};

	double matrix[64][3][3] =
	{
		{
			{0.18173607750192378, -0.07602018832719917, -0.09582073126085888},
			{-0.07602018832719923, 0.06019219300384841, 0.027248061063138363},
			{-0.09582073126085891, 0.02724806106313836, 0.05632259383581333}
		},
		{
			{0.051897461467487, -0.04120652824204174, -0.005959737098801394},
			{-0.04120652824204171, 0.10583337782954295, -0.013300997574946603},
			{-0.005959737098801394, -0.013300997574946596, 0.010214311088151502}
		},
		{
			{0.019839080715148283, -0.01871858401693359, 0.007749237287814284},
			{-0.01871858401693359, 0.07276293233359883, -0.053873041370343315},
			{0.007749237287814279, -0.053873041370343315, 0.055298867856428804}
		},
		{
			{0.0104447288650866, -0.0011854468096716931, -0.008815528088650968},
			{-0.0011854468096716931, 0.027120676561663015, -0.006944556524277005},
			{-0.008815528088650968, -0.006944556524277009, 0.0195035552336615}
		},
		{
			{0.043587880751106756, -0.03189050359669252, -0.004744988847400267},
			{-0.03189050359669254, 0.07099808005159358, -0.010614020693773391},
			{-0.004744988847400268, -0.010614020693773398, 0.012967951386372}
		},
		{
			{0.057717244211555725, -0.05372114201635322, -0.0028425085147707127},
			{-0.05372114201635317, 0.08613544665280665, -0.018740888987805394},
			{-0.0028425085147707196, -0.018740888987805408, 0.03283372470772391}
		},
		{
			{0.053978037182401434, -0.02521951050793959, -0.004418968552606131},
			{-0.025219510507939615, 0.09117548359445408, -0.00653134568704919},
			{-0.004418968552606137, -0.006531345687049195, 0.025343156019181096}
		},
		{
			{0.008289940514949625, 0.001461425303529153, -0.005415395405690383},
			{0.0014614253035291442, 0.04036607344537249, -0.029530550548176288},
			{-0.005415395405690375, -0.029530550548176295, 0.036438785461748}
		},
		{
			{0.013751401369620117, 0.004320385331885076, -0.014081599006395612},
			{0.004320385331885069, 0.012028174996748492, -0.00781034175319469},
			{-0.014081599006395606, -0.007810341753194698, 0.021256420752056}
		},
		{
			{0.019491006418030712, 2.64966057768724E-4, -0.0120621222543468},
			{2.6496605776873093E-4, 0.02764297852322039, -0.011148965762826596},
			{-0.012062122254346804, -0.011148965762826594, 0.02085040595298409}
		},
		{
			{0.015844046645251793, -0.0034948720309275483, -0.014221327925469204},
			{-0.003494872030927543, 0.029804473804958397, -0.012388536278270409},
			{-0.0142213279254692, -0.012388536278270409, 0.0270391628379955}
		},
		{
			{0.0497991697636672, -0.023567276122198284, -0.020581756509448497},
			{-0.02356727612219829, 0.06545685592394389, -0.03653175321320762},
			{-0.020581756509448487, -0.03653175321320762, 0.12575707948096798}
		},
		{
			{0.016512842028040597, 0.004536081228590352, -0.007472613921274013},
			{0.0045360812285903575, 0.04567942138862892, -0.020989939587166804},
			{-0.007472613921274012, -0.020989939587166804, 0.0281219863084821}
		},
		{
			{0.026208844220079686, -0.011572711682164989, -0.00695794782717521},
			{-0.01157271168216498, 0.020695226957881292, -5.599967528933554E-4},
			{-0.006957947827175208, -5.599967528933571E-4, 0.012202459667701601}
		},
		{
			{0.012292369301553089, -0.006884158929681659, -0.00841919500140751},
			{-0.006884158929681657, 0.035764464945675506, -0.009350404176211236},
			{-0.008419195001407509, -0.009350404176211233, 0.020034902304187106}
		},
		{
			{0.03751020304635131, -0.02257684136809464, -0.014045775774433734},
			{-0.02257684136809466, 0.06554486120295663, -0.03216201359994571},
			{-0.014045775774433718, -0.03216201359994573, 0.03701037816748816}
		},
		{
			{0.0363174783831469, -0.014515459690405883, -0.0034376730003605766},
			{-0.014515459690405881, 0.04763206529915198, -0.00813629755041228},
			{-0.0034376730003605714, -0.008136297550412279, 0.02612655061183898}
		},
		{
			{0.05261181938110322, -0.03943093298737221, -0.0018711074323591627},
			{-0.03943093298737223, 0.07835744180549906, -0.018872169771864802},
			{-0.0018711074323591696, -0.0188721697718648, 0.0331384769318056}
		},
		{
			{0.05211552543131311, -0.02707075530440882, -0.007822241530323955},
			{-0.02707075530440882, 0.0718088240393793, -0.03364128154552407},
			{-0.007822241530323955, -0.03364128154552407, 0.0427178036835879}
		},
		{
			{0.12684943855822317, -0.004214198568938065, -0.045249788408804524},
			{-0.004214198568938082, 0.08211469917770585, -0.0642178035765323},
			{-0.0452497884088045, -0.06421780357653233, 0.11706211241196099}
		},
		{
			{0.09203612601432885, -0.028071777853367147, 0.003960983930358276},
			{-0.028071777853367143, 0.08794669154945937, 0.009637422054429268},
			{0.003960983930358274, 0.00963742205442927, 0.018063359995910307}
		},
		{
			{0.055708156773734446, -0.006341115118585846, -0.02379517715709888},
			{-0.006341115118585849, 0.05245844914521301, -0.014652699751173483},
			{-0.023795177157098876, -0.014652699751173491, 0.02743028191278988}
		},
		{
			{0.03138547602129019, -0.023523505884103194, 0.0013687368851469026},
			{-0.023523505884103166, 0.06482692894048223, -0.02020574547159682},
			{0.0013687368851469043, -0.020205745471596825, 0.0336340203884561}
		},
		{
			{0.043938665538803594, -0.02224565794953951, -2.9988575710388984E-4},
			{-0.02224565794953953, 0.04389210247386431, -0.008484095102900751},
			{-2.9988575710389103E-4, -0.008484095102900747, 0.007953261146470159}
		},
		{
			{0.05487010682213362, -0.031098446826470068, -0.004268858352129465},
			{-0.03109844682647006, 0.042843302084864525, 5.846324321941805E-4},
			{-0.004268858352129467, 5.846324321941774E-4, 0.013563690702755897}
		},
		{
			{0.0262110753703704, -0.0058588803313028345, -0.0076294471097835175},
			{-0.005858880331302831, 0.03584649048333587, -3.5398008737567294E-4},
			{-0.007629447109783522, -3.539800873756812E-4, 0.003930791410285247}
		},
		{
			{0.0030528981601861804, -0.0034137832604982632, 0.0017706140512040148},
			{-0.0034137832604982502, 0.07476861392855301, -0.0447390031091412},
			{0.001770614051204007, -0.044739003109141195, 0.053133766793367676}
		},
		{
			{0.07958884334248824, -0.05031930832700985, 0.01343879962264423},
			{-0.05031930832700985, 0.08658118252661758, -0.02669254506052522},
			{0.01343879962264423, -0.026692545060525222, 0.016229537776984406}
		},
		{
			{0.008975404238071503, 0.008947257831278945, -0.016584336789361206},
			{0.00894725783127894, 0.03539554681974258, -0.029949213317894987},
			{-0.01658433678936121, -0.02994921331789499, 0.06876328478094931}
		},
		{
			{0.06088970220697232, -0.022181700807768996, -0.005137249353812103},
			{-0.022181700807769024, 0.03433276396138552, -0.019761656539739107},
			{-0.0051372493538121115, -0.019761656539739096, 0.0334238797420957}
		},
		{
			{0.04772086067784575, -0.028405349279366766, 9.828130955109675E-4},
			{-0.028405349279366773, 0.0705571180238318, -0.019535333484838893},
			{9.82813095510964E-4, -0.0195353334848389, 0.019963129568118708}
		},
		{
			{0.03909352871112142, -0.008786734885281646, -0.0037078543919209644},
			{-0.008786734885281651, 0.048852308548729996, 7.628022283650685E-4},
			{-0.0037078543919209653, 7.628022283650647E-4, 0.002505553070586069}
		},
		{
			{0.027609707182482006, -0.020143293337504524, 0.0016131672316940814},
			{-0.02014329333750453, 0.06737254932004075, -0.03722322535692298},
			{0.0016131672316940732, -0.03722322535692298, 0.04049732506761198}
		},
		{
			{0.08163018848932843, -0.08032772506823113, 0.04433072328283665},
			{-0.08032772506823112, 0.14786467238737303, -0.0844205676592062},
			{0.04433072328283662, -0.0844205676592062, 0.102016543252164}
		},
		{
			{0.019947442891897295, -0.014291341006652587, 0.0031053255136359653},
			{-0.014291341006652584, 0.05045785659261268, -0.0423120132523115},
			{0.0031053255136359722, -0.042312013252311494, 0.05210590761636142}
		},
		{
			{0.06911091257031582, -0.04620468172764362, -8.256450008536399E-4},
			{-0.04620468172764364, 0.08642493261039418, -0.020491650939077097},
			{-8.256450008536313E-4, -0.020491650939077094, 0.036562995788576705}
		},
		{
			{0.02350634478172472, -0.009935387696172188, -0.007889492437308058},
			{-0.009935387696172193, 0.024314493971398406, -0.00400473725594885},
			{-0.007889492437308063, -0.004004737255948843, 0.020679812318887596}
		},
		{
			{0.10929571146606096, -0.04615367309030618, -0.020396318844456314},
			{-0.04615367309030617, 0.07982434398134772, -0.023913737136844887},
			{-0.020396318844456304, -0.023913737136844873, 0.03595261220870519}
		},
		{
			{0.05607021421969809, -0.016262239954323993, -0.011304361676048199},
			{-0.016262239954323996, 0.05565137699702501, 0.004529171839043757},
			{-0.011304361676048194, 0.00452917183904376, 0.016088828194245307}
		},
		{
			{0.08769939206103612, 0.003939303015158804, 0.0020266316921615647},
			{0.003939303015158808, 0.12127979905736296, -0.02294870961746191},
			{0.0020266316921615643, -0.0229487096174619, 0.040065685841791605}
		},
		{
			{0.09650291368820146, -0.009467732116946782, -0.04060042215073206},
			{-0.009467732116946823, 0.059782666802214245, -0.03175967821368435},
			{-0.0406004221507321, -0.03175967821368435, 0.12331716198796307}
		},
		{
			{0.061739793365566245, -0.03586312993130845, -0.00299736504080056},
			{-0.03586312993130844, 0.07438003972921452, -0.03352097885288091},
			{-0.00299736504080056, -0.033520978852880905, 0.03843507682533649}
		},
		{
			{0.02721198784967339, -0.019686470566181894, -0.00355833151772368},
			{-0.01968647056618189, 0.04605039341999942, -0.00898682596519762},
			{-0.0035583315177236774, -0.008986825965197618, 0.013227774673655003}
		},
		{
			{0.03919238099543646, -0.025642581883742275, 0.0032863803217104423},
			{-0.025642581883742264, 0.052570538830920194, -0.030749234844873897},
			{0.003286380321710442, -0.030749234844873897, 0.0374237670219069}
		},
		{
			{0.019146363687312005, 0.0021118274288136297, -0.006462499752497374},
			{0.002111827428813633, 0.014665959456101503, 0.0036889712319352697},
			{-0.006462499752497376, 0.003688971231935268, 0.008814384343057839}
		},
		{
			{0.04210548327086339, -0.004997313113297925, -0.01914044938377129},
			{-0.004997313113297923, 0.058629374178210784, -0.010397717763960602},
			{-0.019140449383771293, -0.010397717763960602, 0.033584044267970695}
		},
		{
			{0.004279646009561198, -0.010343684593706371, 0.0032515772695109737},
			{-0.010343684593706373, 0.0734810719176429, -0.043768058276301196},
			{0.0032515772695109724, -0.043768058276301196, 0.05091779608459078}
		},
		{
			{0.10054367613025002, -0.030020653804991703, -0.02429511036160318},
			{-0.030020653804991717, 0.09940158835631238, -0.02028689518184539},
			{-0.02429511036160317, -0.020286895181845423, 0.0583023647362127}
		},
		{
			{0.07664919054448092, -0.07323140232565137, 0.0178065379307161},
			{-0.07323140232565142, 0.1259550651603791, -0.06214271057930214},
			{0.0178065379307161, -0.062142710579302124, 0.05652273700990949}
		},
		{
			{0.042033323616773526, -0.014873653147932812, -0.018453334909678026},
			{-0.014873653147932812, 0.07012766181891995, -0.04683141974137569},
			{-0.018453334909678022, -0.046831419741375696, 0.06856832331273864}
		},
		{
			{0.15598295380799107, -0.15119114040810502, -0.021806579072402306},
			{-0.15119114040810505, 0.18298892141450496, 0.014214778851626206},
			{-0.02180657907240231, 0.014214778851626201, 0.0288524196056996}
		},
		{
			{0.03341554475144847, -0.034063985094827685, 0.011885984680283696},
			{-0.03406398509482769, 0.09815608802858032, -0.041736462695627446},
			{0.011885984680283694, -0.04173646269562745, 0.035889651795384614}
		},
		{
			{0.033531917037049885, -0.011349228104751297, -0.005787231329315648},
			{-0.011349228104751292, 0.03938672236441127, -0.014227684949632106},
			{-0.005787231329315646, -0.01422768494963211, 0.030659943431547418}
		},
		{
			{0.029988665982871594, -0.019893195610500295, -0.014035346012033097},
			{-0.019893195610500295, 0.051859328276532404, -0.0121834969621629},
			{-0.014035346012033089, -0.012183496962162898, 0.023295845220692904}
		},
		{
			{0.043139994269343084, -0.04346721061985261, 0.004097499374364178},
			{-0.0434672106198526, 0.05913132922772364, -0.0107140972184463},
			{0.004097499374364175, -0.010714097218446303, 0.012784343219330703}
		},
		{
			{0.024544219426168988, -0.017096649916433795, 0.0028733867040864488},
			{-0.0170966499164338, 0.06543053353714036, -0.003787482090112071},
			{0.002873386704086451, -0.0037874820901120775, 0.0027944459123729}
		},
		{
			{0.1252113612532692, -0.08412268030647338, 0.01466209586174271},
			{-0.08412268030647337, 0.21006112318046297, -0.008314973026442211},
			{0.014662095861742707, -0.008314973026442211, 0.0111359184425076}
		},
		{
			{0.07294056569641075, -0.042054816903757036, -0.014965713526979908},
			{-0.04205481690375702, 0.09974286296470197, -0.014259417074934206},
			{-0.014965713526979903, -0.01425941707493421, 0.0345688415413767}
		},
		{
			{0.06882912970678881, -0.05352210966864871, -0.0028215846583239217},
			{-0.0535221096686487, 0.114155125053897, -0.013409473454276387},
			{-0.0028215846583239243, -0.013409473454276387, 0.02718351817161488}
		},
		{
			{0.05148073543496069, -0.006996364293503796, -0.016274396086398704},
			{-0.006996364293503793, 0.030312429307007407, -0.0055492105081504425},
			{-0.016274396086398704, -0.005549210508150444, 0.02557125423578172}
		},
		{
			{0.015071376682309104, 9.126767275775701E-4, -0.00591264045866401},
			{9.126767275775731E-4, 0.036467215197862855, -0.019289614382477796},
			{-0.005912640458664001, -0.019289614382477775, 0.027779641343129508}
		},
		{
			{0.013193783116007532, -0.014081064998526654, 0.0033938716556885544},
			{-0.014081064998526656, 0.06106696451554271, -0.029118500316921814},
			{0.0033938716556885552, -0.029118500316921814, 0.023882480633532807}
		},
		{
			{0.03771127595266493, -0.007436842572782821, -0.0016983824738697184},
			{-0.007436842572782826, 0.044079186546778656, -0.004369888580529264},
			{-0.001698382473869717, -0.004369888580529266, 0.010104328783145001}
		},
		{
			{0.039862461615936165, -0.01535649781526299, -0.0025530874251777896},
			{-0.015356497815262984, 0.07473098792288135, -0.001380884215371768},
			{-0.002553087425177789, -0.0013808842153717707, 0.0194561585052585}
		}
	};

	double barycentre[64][3] =
	{
		{64.18222222222222, 46.88444444444445, 74.86222222222223},
		{134.6493827160494, 143.6395061728395, 194.0172839506173},
		{102.94588235294118, 201.9364705882353, 239.42117647058822},
		{93.22191780821917, 161.28493150684932, 144.44657534246576},
		{174.0089552238806, 170.8089552238806, 102.28059701492538},
		{185.62424242424242, 119.78484848484848, 86.01515151515152},
		{120.44318181818181, 70.35227272727273, 37.92045454545455},
		{50.12041884816754, 153.06806282722513, 157.64397905759162},
		{124.5925, 176.155, 140.995},
		{111.65706806282722, 155.42670157068062, 115.67277486910994},
		{133.74328358208956, 193.60298507462687, 169.72537313432835},
		{135.20209973753282, 187.46194225721786, 244.45669291338584},
		{82.23297491039426, 132.32258064516128, 125.39426523297492},
		{160.22834645669292, 188.8228346456693, 136.85826771653544},
		{142.71354166666666, 164.87760416666666, 110.81510416666667},
		{12.440677966101696, 105.88135593220339, 74.22033898305085},
		{150.84868421052633, 108.78947368421052, 130.46052631578948},
		{106.32954545454545, 161.34848484848484, 233.40530303030303},
		{197.79268292682926, 136.4430894308943, 154.5650406504065},
		{115.55825242718447, 114.31067961165049, 132.73300970873785},
		{85.53783783783784, 80.3027027027027, 86.34864864864865},
		{131.9149560117302, 125.67448680351906, 162.60117302052785},
		{154.24115044247787, 105.86283185840708, 94.0},
		{214.32592592592593, 203.43703703703704, 105.91111111111111},
		{222.70760233918128, 96.0701754385965, 18.28654970760234},
		{186.35135135135135, 168.03153153153153, 65.90990990990991},
		{22.551724137931036, 127.62068965517241, 134.8448275862069},
		{192.52918287937743, 163.0272373540856, 132.4591439688716},
		{44.484848484848484, 120.57575757575758, 96.48484848484848},
		{225.0569105691057, 119.73983739837398, 71.04065040650407},
		{165.47246376811594, 131.97391304347826, 103.59420289855072},
		{225.2405063291139, 196.74683544303798, 19.60759493670886},
		{181.76409185803757, 119.73695198329854, 123.59916492693111},
		{171.53012048192772, 183.48192771084337, 223.96686746987953},
		{66.01171875, 161.49609375, 188.61328125},
		{130.88888888888889, 163.93434343434345, 219.58080808080808},
		{127.64156626506023, 139.18072289156626, 83.87349397590361},
		{220.9625, 182.8625, 161.7875},
		{77.28064516129032, 78.75483870967741, 52.39032258064516},
		{25.1625, 23.00625, 27.7},
		{50.2741116751269, 36.56091370558376, 44.431472081218274},
		{205.560411311054, 136.27506426735218, 113.02313624678663},
		{155.69565217391303, 150.62608695652173, 74.34782608695652},
		{93.07865168539325, 168.70505617977528, 201.4943820224719},
		{197.7704918032787, 148.77868852459017, 10.80327868852459},
		{167.55227272727274, 124.01818181818182, 153.2022727272727},
		{6.834586466165414, 162.89473684210526, 175.8345864661654},
		{194.44736842105263, 208.14912280701753, 231.25438596491227},
		{160.1836228287841, 160.63275434243175, 205.32009925558313},
		{191.53348214285714, 158.23214285714286, 194.20982142857142},
		{188.11827956989248, 209.1021505376344, 177.38709677419354},
		{136.12394366197182, 199.90704225352113, 207.77464788732394},
		{100.05794392523364, 167.83551401869158, 172.97757009345796},
		{96.01357466063348, 126.70588235294117, 88.76470588235294},
		{155.14201183431953, 123.28994082840237, 59.11538461538461},
		{143.5912408759124, 108.91240875912409, 16.94160583941606},
		{111.38576779026218, 95.80524344569288, 104.84644194756554},
		{102.5056603773585, 138.59245283018868, 199.1811320754717},
		{88.37209302325581, 129.64341085271317, 166.2984496124031},
		{170.67334669338678, 139.4869739478958, 177.7434869739479},
		{111.19280205655527, 188.39845758354755, 192.53984575835474},
		{84.31333333333333, 187.85, 223.01},
		{108.1640625, 97.33203125, 50.73046875},
		{134.41525423728814, 87.02542372881356, 65.9774011299435}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<64;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<64;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance65clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027403243719403593, -0.020703521012051376, -0.0016686251114044794},
		{-0.02070352101205138, 0.043725567688286296, -0.013437049577031006},
		{-0.0016686251114044846, -0.013437049577030997, 0.015178238996641901}
	};

	double matrix[65][3][3] =
	{
		{
			{0.0865067253840395, -0.06079054794288913, 0.004687676923120191},
			{-0.060790547942889205, 0.14330690865907195, -0.04982893194834805},
			{0.004687676923120186, -0.049828931948348046, 0.07128259659723438}
		},
		{
			{0.04225380552259529, -0.006309938974905421, -0.020513936894462896},
			{-0.006309938974905416, 0.07694518202888218, -0.036556666678285527},
			{-0.0205139368944629, -0.03655666667828551, 0.04574404052799551}
		},
		{
			{0.0821298224362901, -0.026887015179888778, -0.06420942854284652},
			{-0.026887015179888757, 0.07752535489994464, 0.02716902655131206},
			{-0.06420942854284652, 0.027169026551312057, 0.06106577564275591}
		},
		{
			{0.03278096907824529, -0.021798075559940396, 0.005328308640403293},
			{-0.021798075559940407, 0.04960508808512515, -0.01453091179589801},
			{0.005328308640403297, -0.01453091179589801, 0.012719893397967}
		},
		{
			{0.0386714811703683, 0.02294821035647279, 0.0067001496506074384},
			{0.022948210356472796, 0.22799064284475218, -0.024398972214455552},
			{0.006700149650607426, -0.02439897221445554, 0.0049166346411122774}
		},
		{
			{0.033414717531652906, -0.0050021832305964424, -0.0021342523534447497},
			{-0.0050021832305964355, 0.03984445401499757, -0.004054553928407954},
			{-0.002134252353444749, -0.004054553928407944, 0.010927353031765596}
		},
		{
			{0.014028273000952295, -0.010289522510216705, 0.0014014727854112234},
			{-0.010289522510216703, 0.0534515415060191, -0.026542920991609716},
			{0.0014014727854112174, -0.02654292099160972, 0.026450691755119635}
		},
		{
			{0.15029824587185234, -0.14546914871656183, -0.02981467154158649},
			{-0.14546914871656175, 0.15189155856871725, 0.011292230197160396},
			{-0.02981467154158648, 0.011292230197160386, 0.033717307715651026}
		},
		{
			{0.07903482911725805, -0.008422615797783988, -7.833317958812409E-5},
			{-0.008422615797783995, 0.0318112534932868, -9.031162929013445E-4},
			{-7.833317958812409E-5, -9.031162929013436E-4, 0.0359810141905657}
		},
		{
			{0.06978717307901505, 0.005621913391934545, 0.0038233902744554083},
			{0.005621913391934538, 0.06944945635890834, -0.008551157936718894},
			{0.0038233902744554066, -0.00855115793671889, 0.0160741022141796}
		},
		{
			{0.026135702210495496, -0.015611968488822611, -0.008793435927057145},
			{-0.015611968488822615, 0.02612155935646452, 2.2075300179234814E-4},
			{-0.008793435927057149, 2.2075300179234987E-4, 0.012424147703556494}
		},
		{
			{0.016234948570970575, -0.020819446676631277, 0.01048322858419018},
			{-0.020819446676631284, 0.07919789565220883, -0.059329950612867555},
			{0.01048322858419019, -0.05932995061286757, 0.06113031302493496}
		},
		{
			{0.06685843493439067, -0.015498943528870093, -0.023849066643537697},
			{-0.015498943528870107, 0.030846151744994714, -0.003248028968570337},
			{-0.023849066643537708, -0.0032480289685703403, 0.025076392061542104}
		},
		{
			{0.02217474511997459, -4.151257261986521E-5, -0.012220930836779494},
			{-4.151257261986695E-5, 0.02643340946103078, -0.011266793278655709},
			{-0.012220930836779494, -0.011266793278655703, 0.0223302601907132}
		},
		{
			{0.04696488903861124, -0.02856636734120019, -0.0089226531472608},
			{-0.02856636734120018, 0.06927636587762788, -0.022290797746548303},
			{-0.0089226531472608, -0.02229079774654831, 0.03379306645367161}
		},
		{
			{0.057084686392788735, -0.025659646119153296, -0.030873325834731284},
			{-0.025659646119153307, 0.07791504052502501, -0.052037180118405295},
			{-0.030873325834731288, -0.0520371801184053, 0.15158552496660896}
		},
		{
			{0.1858980796398431, -0.05660785370264079, -0.0749098787362874},
			{-0.05660785370264081, 0.14171581401551803, 0.014555822125465925},
			{-0.0749098787362874, 0.014555822125465925, 0.08974756254428641}
		},
		{
			{0.23357486061523597, -0.053354873960614294, -0.10492391173763599},
			{-0.0533548739606143, 0.02898334119057364, 0.04429260563693865},
			{-0.10492391173763597, 0.044292605636938646, 0.07432391256558496}
		},
		{
			{0.010834206838572296, -1.952222514208478E-4, -0.004908251995645088},
			{-1.9522225142084822E-4, 0.040513966453701915, -0.030606762208490283},
			{-0.004908251995645088, -0.030606762208490283, 0.03442979325432988}
		},
		{
			{0.013667695615011502, -7.62760074626812E-4, -0.008728992847899976},
			{-7.627600746268155E-4, 0.042897492761113105, -0.016503936712904285},
			{-0.00872899284789998, -0.01650393671290428, 0.025677218604752017}
		},
		{
			{0.046033127074471734, -0.0167528960601068, -0.011492706613485105},
			{-0.016752896060106794, 0.0483472737403084, 0.002840842152256961},
			{-0.011492706613485105, 0.0028408421522569645, 0.016558180650577396}
		},
		{
			{0.06696150218844937, -0.043132478287669015, -0.010642421643324301},
			{-0.043132478287668995, 0.10335135979576203, -0.0027189135963663286},
			{-0.010642421643324297, -0.002718913596366329, 0.011697278721339504}
		},
		{
			{0.0951023720986129, -0.03851583079891831, 0.0023546792218911237},
			{-0.03851583079891827, 0.06287545562010145, -0.02059047118383669},
			{0.0023546792218911224, -0.020590471183836688, 0.0154256678518068}
		},
		{
			{0.07415251668523179, -0.044741090228275715, -0.015287783395491498},
			{-0.04474109022827576, 0.10993254662958611, -0.025004821280774407},
			{-0.015287783395491505, -0.025004821280774393, 0.024880954234997806}
		},
		{
			{0.014704692887810008, 0.00138891733326759, -0.010554652800614406},
			{0.0013889173332675869, 0.013979074478605793, -0.0018359105187511677},
			{-0.010554652800614399, -0.0018359105187511638, 0.01980941849640559}
		},
		{
			{0.057820579804689805, -0.026924118380011658, -8.731830370848001E-4},
			{-0.02692411838001164, 0.09565669276156434, -0.0370720709551291},
			{-8.731830370848036E-4, -0.037072070955129086, 0.0564252815526753}
		},
		{
			{0.0660693437401832, -0.04134163320493553, 0.003980588222809129},
			{-0.04134163320493552, 0.06772872493073151, -0.009624820538834065},
			{0.003980588222809129, -0.009624820538834067, 0.04719024547043061}
		},
		{
			{0.004099683921025805, -0.008739442714270875, 0.003435133264131734},
			{-0.008739442714270872, 0.06700891436306687, -0.04276209519938461},
			{0.0034351332641317333, -0.04276209519938462, 0.050348122443472136}
		},
		{
			{0.04336486088528197, -0.016107763131421964, -0.0025898039154828665},
			{-0.01610776313142196, 0.07495969085636833, -0.013030055604556596},
			{-0.0025898039154828682, -0.013030055604556584, 0.0257913213019624}
		},
		{
			{0.026415819381805195, -0.0031238348675503287, -0.005506446163226104},
			{-0.0031238348675503244, 0.035152869596483796, -0.010507659845124405},
			{-0.005506446163226108, -0.010507659845124407, 0.034211878341494306}
		},
		{
			{0.012946517677558297, 8.009481541985716E-4, 0.00921905074865538},
			{8.009481541985742E-4, 0.06134961801885407, -0.0359429294264418},
			{0.009219050748655384, -0.035942929426441804, 0.04978610669779782}
		},
		{
			{0.01926830780844712, -0.00710777006863442, -0.011771400069306603},
			{-0.007107770068634427, 0.021695469893144394, -0.002097749465401125},
			{-0.011771400069306607, -0.0020977494654011233, 0.016876758115983995}
		},
		{
			{0.11100592482788497, -0.06416188157235532, -0.00350966268453536},
			{-0.06416188157235532, 0.2872408859867851, -0.04342153663363642},
			{-0.0035096626845353644, -0.043421536633636446, 0.019564887893211605}
		},
		{
			{0.11171872254057894, -0.05250495438363611, -0.02051241026292878},
			{-0.0525049543836361, 0.0914402692048907, -0.028849469990356084},
			{-0.0205124102629288, -0.028849469990356095, 0.040616423579104007}
		},
		{
			{0.07229518027277901, -0.03402683648367089, -0.023725050454327785},
			{-0.0340268364836709, 0.03778641317162611, 0.003923239380468978},
			{-0.023725050454327785, 0.003923239380468986, 0.028217352167216794}
		},
		{
			{0.05131755094195979, -0.038645816591855925, -0.007958550844008244},
			{-0.03864581659185592, 0.06573507547169062, -0.014476760294122816},
			{-0.00795855084400824, -0.01447676029412282, 0.038518798483753294}
		},
		{
			{0.041097924649796065, -0.011576570434966203, -0.012693688960441103},
			{-0.01157657043496621, 0.04868623830633665, -0.0026067864367799887},
			{-0.012693688960441107, -0.0026067864367799957, 0.019666134312934715}
		},
		{
			{0.04992424971627251, 0.01438615004671415, -0.014328933492864451},
			{0.014386150046714147, 0.021537363228056956, 0.003246846375775483},
			{-0.014328933492864444, 0.0032468463757754865, 0.007240693120707001}
		},
		{
			{0.023326321674438, -9.915369486403012E-4, -0.0170800267963005},
			{-9.915369486402925E-4, 0.03803629481028452, -0.02078182124446752},
			{-0.017080026796300492, -0.02078182124446752, 0.0381667518063924}
		},
		{
			{0.0346511296107795, -0.011835899254164992, -7.107133133775175E-4},
			{-0.011835899254165005, 0.058408781989178274, -0.029249670671846875},
			{-7.107133133775179E-4, -0.029249670671846882, 0.0324758166226042}
		},
		{
			{0.055557313361513705, -0.037109966944264806, -0.014525536330972904},
			{-0.03710996694426478, 0.08543932066956811, -0.021582748931561622},
			{-0.014525536330972894, -0.02158274893156162, 0.04194806340431451}
		},
		{
			{0.031151809307337654, -0.03313914011653968, 0.002432414341443749},
			{-0.03313914011653965, 0.05739475119514568, -0.014932768799790086},
			{0.002432414341443749, -0.01493276879979009, 0.023129601908305198}
		},
		{
			{0.061702222670224786, -0.04151776605690387, -0.005276499093958751},
			{-0.041517766056903896, 0.07962794853609712, -0.017317055490702896},
			{-0.005276499093958767, -0.01731705549070289, 0.034881219277384204}
		},
		{
			{0.025662786838796622, -0.003011408496318849, -0.009597503736834104},
			{-0.0030114084963188386, 0.03419874406788639, -0.0015616656064395772},
			{-0.009597503736834101, -0.0015616656064395798, 0.014750271417174702}
		},
		{
			{0.03262284701612138, -0.008380113013269679, -0.013923607823712183},
			{-0.008380113013269685, 0.0281548886647177, -0.0068289509760143296},
			{-0.013923607823712186, -0.006828950976014329, 0.022823297058581694}
		},
		{
			{0.046505899196873805, -0.0323217044402529, -6.067185881955487E-4},
			{-0.03232170444025286, 0.08127197792365576, -0.04354382361725276},
			{-6.067185881955574E-4, -0.04354382361725275, 0.04727640646811996}
		},
		{
			{0.07008604115015908, -0.05176607002455422, -0.00357993327528881},
			{-0.05176607002455422, 0.12080235276319809, -0.026263771147144125},
			{-0.0035799332752888035, -0.026263771147144118, 0.016743644632606112}
		},
		{
			{0.07868714818145797, -0.05490741399588767, 0.012805622303212172},
			{-0.05490741399588768, 0.0885692438153712, -0.029281825833337487},
			{0.012805622303212177, -0.029281825833337494, 0.022483488806881502}
		},
		{
			{0.03664394120218678, -0.022403417028928178, -0.0059552693409800125},
			{-0.0224034170289282, 0.058107919290096795, -0.008695910830981462},
			{-0.005955269340980024, -0.008695910830981462, 0.014450085696486297}
		},
		{
			{0.012441484321951194, 0.0016187900249071312, -0.013731385163385788},
			{0.0016187900249071225, 0.026037625046684987, -0.016857928583395694},
			{-0.013731385163385793, -0.016857928583395684, 0.02860884184664748}
		},
		{
			{0.061334562446238736, -0.0808804750183285, 0.017051150933388343},
			{-0.08088047501832857, 0.19026840071899004, -0.07422895988420079},
			{0.01705115093338837, -0.07422895988420079, 0.06149092748156939}
		},
		{
			{0.0501718321024565, -0.02104703153991328, -0.024251278465368693},
			{-0.02104703153991328, 0.04863079791815561, -0.0228961220350917},
			{-0.02425127846536869, -0.022896122035091705, 0.05297448076136288}
		},
		{
			{0.013456710325730991, 0.0011245421385833662, -0.011408085438199893},
			{0.0011245421385833627, 0.02737063912521212, -0.015111888587738013},
			{-0.011408085438199884, -0.015111888587738011, 0.025125251386907403}
		},
		{
			{0.055073180347515883, -0.02617986337965379, -0.0022060964973784174},
			{-0.02617986337965379, 0.027757522106596492, -0.008279727645853512},
			{-0.002206096497378414, -0.008279727645853508, 0.016722486538123107}
		},
		{
			{0.06309951333700202, -0.035269747885052515, -0.010708619523086702},
			{-0.03526974788505253, 0.04810193021876512, 0.005848303868213994},
			{-0.010708619523086703, 0.00584830386821399, 0.00767586502579111}
		},
		{
			{0.04421252748362484, -0.043272440396614, 0.0015244404549710168},
			{-0.043272440396614, 0.12803423065256195, -0.0343973558085191},
			{0.001524440454971022, -0.0343973558085191, 0.0159271272102666}
		},
		{
			{0.04700704045536831, -0.024479502840635887, -0.001693238139194675},
			{-0.02447950284063591, 0.0755853457029908, -0.030116343852960192},
			{-0.0016932381391946733, -0.030116343852960185, 0.03377837170421111}
		},
		{
			{0.10235396584966898, -0.006949830214617814, -0.04000050727114332},
			{-0.006949830214617814, 0.08800461601404835, -0.032335785489984815},
			{-0.040000507271143335, -0.032335785489984815, 0.08736641758222329}
		},
		{
			{0.025666795041541603, -0.010321814432006481, -0.0030411477741292712},
			{-0.010321814432006485, 0.036428694468691854, -0.01855947052822271},
			{-0.003041147774129274, -0.018559470528222703, 0.031106993880519525}
		},
		{
			{0.013858609870984591, -0.0042251506047575205, -0.003168881760300351},
			{-0.004225150604757523, 0.05068261398009925, -0.024530154636581883},
			{-0.0031688817603003515, -0.024530154636581883, 0.03352263838323598}
		},
		{
			{0.018537739965812827, -0.011667470296149418, 0.0032533000777929164},
			{-0.011667470296149413, 0.04603029902240993, -0.03533398099841968},
			{0.0032533000777929203, -0.035333980998419674, 0.0470210243387494}
		},
		{
			{0.051454635446705255, -0.030718790325708206, -0.0011586462498118196},
			{-0.030718790325708217, 0.054022992924488165, 4.771528464820114E-4},
			{-0.0011586462498118196, 4.771528464820117E-4, 0.0055437490310553}
		},
		{
			{0.020945511232950288, 0.002643429115230251, -0.0057796157422033145},
			{0.0026434291152302534, 0.013876787519222207, 0.002650806324260943},
			{-0.005779615742203319, 0.0026508063242609422, 0.006918768279925285}
		},
		{
			{0.02598049520212882, -0.020175100712834293, 0.002437736019209341},
			{-0.020175100712834293, 0.05599253585428202, -0.003848582090199582},
			{0.0024377360192093405, -0.003848582090199582, 0.0028102892663598917}
		},
		{
			{0.03945092225597541, -0.021864394459860523, -0.0014001735739347467},
			{-0.021864394459860544, 0.08752377758068995, -2.514566396091552E-4},
			{-0.0014001735739347493, -2.5145663960915606E-4, 0.019475808203410504}
		}
	};

	double barycentre[65][3] =
	{
		{185.5693779904306, 199.10526315789474, 230.39234449760767},
		{187.12946428571428, 148.71875, 182.27455357142858},
		{61.21146953405018, 41.3584229390681, 58.5663082437276},
		{161.24647887323943, 142.8450704225352, 60.774647887323944},
		{59.22222222222222, 21.041666666666668, 19.875},
		{107.4873949579832, 98.07142857142857, 49.331932773109244},
		{85.69333333333333, 184.11466666666666, 219.328},
		{187.03947368421052, 210.97368421052633, 184.98684210526315},
		{96.38888888888889, 79.27777777777777, 75.53968253968254},
		{81.58048780487805, 94.49756097560976, 104.79512195121951},
		{145.12259615384616, 153.4783653846154, 90.88942307692308},
		{101.46782178217822, 203.27970297029702, 239.04455445544554},
		{138.24347826086955, 121.71304347826087, 143.8289855072464},
		{118.3204134366925, 157.58139534883722, 114.62015503875969},
		{195.82713347921225, 135.10284463894968, 155.17943107221006},
		{142.33136094674558, 192.2869822485207, 240.81360946745562},
		{22.133928571428573, 20.459821428571427, 25.254464285714285},
		{74.63736263736264, 62.68681318681319, 87.32967032967034},
		{48.85279187817259, 150.00507614213197, 152.7715736040609},
		{85.50154798761609, 137.88235294117646, 121.6811145510836},
		{74.75824175824175, 81.21245421245422, 52.13186813186813},
		{123.79347826086956, 142.8641304347826, 194.19021739130434},
		{224.69444444444446, 162.84027777777777, 112.57638888888889},
		{114.33333333333333, 123.62592592592593, 165.4037037037037},
		{138.47368421052633, 175.53383458646616, 130.59899749373434},
		{115.28776978417267, 175.5251798561151, 243.13669064748203},
		{121.89135802469136, 161.43456790123457, 219.441975308642},
		{6.595890410958904, 160.52739726027397, 173.5958904109589},
		{123.24489795918367, 72.87244897959184, 38.964285714285715},
		{95.40232558139535, 162.6860465116279, 168.93953488372094},
		{23.738095238095237, 117.84126984126983, 92.95238095238095},
		{154.40178571428572, 197.52232142857142, 159.86160714285714},
		{114.17437722419929, 102.17081850533808, 113.02491103202847},
		{218.1024096385542, 183.210843373494, 165.33734939759037},
		{223.55882352941177, 99.36029411764706, 10.764705882352942},
		{167.63888888888889, 113.97222222222223, 81.5111111111111},
		{162.19703389830508, 130.83050847457628, 170.510593220339},
		{225.5686274509804, 196.92156862745097, 3.3333333333333335},
		{169.7047619047619, 117.36904761904762, 140.8904761904762},
		{150.5956873315364, 103.83827493261455, 104.94609164420486},
		{91.34137931034483, 147.53793103448277, 206.88275862068966},
		{140.44666666666666, 124.73, 68.69333333333333},
		{200.6688524590164, 128.68196721311475, 94.16065573770491},
		{184.25099601593627, 164.9203187250996, 71.59760956175299},
		{108.11428571428571, 132.84444444444443, 88.07619047619048},
		{196.64761904761906, 129.52142857142857, 124.17619047619047},
		{79.64814814814815, 130.46296296296296, 165.00462962962962},
		{190.4149377593361, 161.22821576763485, 135.0746887966805},
		{170.09535452322737, 171.6234718826406, 107.82151589242054},
		{99.50938337801608, 163.4798927613941, 140.38605898123325},
		{153.78249336870027, 173.72944297082228, 217.46949602122015},
		{185.72117962466487, 166.9329758713137, 205.96246648793564},
		{121.6926952141058, 184.76574307304787, 162.82619647355165},
		{219.64615384615385, 104.93076923076923, 57.51538461538462},
		{195.95867768595042, 210.17355371900825, 125.39669421487604},
		{154.15075376884423, 149.69095477386935, 198.71608040201005},
		{171.6951219512195, 123.10365853658537, 108.9308943089431},
		{36.96949152542373, 37.22372881355932, 44.389830508474574},
		{101.49072164948454, 177.42680412371135, 189.35670103092784},
		{127.3225806451613, 198.26236559139784, 200.89032258064515},
		{64.46280991735537, 164.15702479338842, 187.5},
		{212.28947368421052, 201.82894736842104, 65.47368421052632},
		{198.68595041322314, 150.20661157024793, 11.892561983471074},
		{146.4078947368421, 110.84210526315789, 19.20394736842105},
		{135.67705382436262, 88.02549575070822, 68.1813031161473}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<65;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<65;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance66clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027151369877053, -0.020309323745498715, -0.0018188231698233537},
		{-0.020309323745498726, 0.04299404083392094, -0.01354837799650929},
		{-0.0018188231698233466, -0.013548377996509297, 0.015400281223336304}
	};

	double matrix[66][3][3] =
	{
		{
			{0.012920976335830801, 0.01478927261820008, -0.02246965992747377},
			{0.014789272618200074, 0.0555979877184926, -0.037076986712180515},
			{-0.02246965992747375, -0.03707698671218048, 0.04241108892624571}
		},
		{
			{0.0194027687875546, -0.0037643554646192177, -0.013539288903403099},
			{-0.003764355464619222, 0.01698016924525129, -0.005941620866898863},
			{-0.013539288903403099, -0.0059416208668988685, 0.024790531789866704}
		},
		{
			{0.03165888681409522, -0.006855545613419757, -0.003417578847099957},
			{-0.006855545613419753, 0.037181886556206085, -0.012101617033346591},
			{-0.00341757884709997, -0.012101617033346581, 0.03315495853836651}
		},
		{
			{0.06939593997138467, -0.06743682907650507, 0.008494775760477398},
			{-0.0674368290765051, 0.14525697022006104, -0.047889303787597814},
			{0.008494775760477413, -0.04788930378759782, 0.02982954491179811}
		},
		{
			{0.0576764209189367, -0.032408632345462624, -0.012327887344657977},
			{-0.0324086323454626, 0.07912012457361652, -0.026572093774129498},
			{-0.01232788734465798, -0.02657209377412949, 0.03850624554377646}
		},
		{
			{0.043084289120576096, -0.015773692115819804, -0.01192391226354279},
			{-0.015773692115819794, 0.04940497906141593, 0.004043677934534673},
			{-0.011923912263542795, 0.004043677934534667, 0.016251104269547297}
		},
		{
			{0.017325925183342694, -0.0016336017407073446, -0.013529724348227894},
			{-0.001633601740707336, 0.029991738089175907, -0.013896892727825315},
			{-0.013529724348227887, -0.013896892727825304, 0.031025305742639685}
		},
		{
			{0.09630631753084976, -0.013537066758494417, -0.029986493639421304},
			{-0.01353706675849439, 0.09322527931492314, -0.02882752393348806},
			{-0.029986493639421283, -0.028827523933488062, 0.07657525420211539}
		},
		{
			{0.015187539987828222, 0.00273414333817972, -0.014209942639330807},
			{0.0027341433381797287, 0.026418888661501355, -0.011839451855429168},
			{-0.014209942639330807, -0.011839451855429159, 0.022740528332965564}
		},
		{
			{0.04936909747252616, -0.014033258353964411, 0.002994363675652161},
			{-0.014033258353964408, 0.03774174328016449, -0.007090098253927541},
			{0.0029943636756521595, -0.007090098253927541, 0.00819664031282444}
		},
		{
			{0.17991145056098817, -0.20880853024358204, -0.025049786851808503},
			{-0.20880853024358204, 0.2755515892138339, 0.005938805812220973},
			{-0.025049786851808507, 0.005938805812220969, 0.024791617848942498}
		},
		{
			{0.04543984168473042, -0.024719072975751613, -0.009973115303017845},
			{-0.024719072975751603, 0.029327679606312808, 0.004105919372678527},
			{-0.009973115303017838, 0.0041059193726785265, 0.010907121110810106}
		},
		{
			{0.13327083713880591, -0.10375040055248393, 0.001405708739772196},
			{-0.10375040055248383, 0.31955213843183694, -0.030232012272350915},
			{0.001405708739772189, -0.03023201227235091, 0.01728701320026831}
		},
		{
			{0.035357920766394886, -0.013331586953925981, 0.0018703837540640514},
			{-0.013331586953925981, 0.0874039221715106, 0.0011359786127638953},
			{0.0018703837540640512, 0.001135978612763891, 0.015126867635753195}
		},
		{
			{0.02412556261809841, -0.01432951230187799, -0.006500522854421875},
			{-0.014329512301877997, 0.03749548007030024, -0.005764203555123002},
			{-0.006500522854421878, -0.005764203555123009, 0.0173640804600804}
		},
		{
			{0.0492179051767575, -0.024995358212573995, -0.005625606832463849},
			{-0.024995358212573995, 0.03959788904241518, 9.719458264758241E-4},
			{-0.005625606832463847, 9.719458264758241E-4, 0.014803182446892302}
		},
		{
			{0.06144584108250941, -0.04135299370788282, -0.0026921128384997345},
			{-0.041352993707882826, 0.08564085924960878, -0.03565700765440223},
			{-0.002692112838499744, -0.03565700765440223, 0.04297219934533062}
		},
		{
			{0.10266174224864402, -0.0020844652183111298, -0.0016879208157759395},
			{-0.00208446521831113, 0.03664618758318119, 0.001015521828080963},
			{-0.0016879208157759393, 0.0010155218280809668, 0.018063359969120906}
		},
		{
			{0.05688618004606715, -0.02697336581227412, -0.004881057207158024},
			{-0.026973365812274094, 0.08169228556317687, -0.008019886392332545},
			{-0.0048810572071580245, -0.008019886392332552, 0.025626256097138794}
		},
		{
			{0.03243395482393231, -0.025760797402566597, 0.0029981688887589695},
			{-0.02576079740256661, 0.051271132504878664, -0.0131385647337256},
			{0.0029981688887589725, -0.013138564733725596, 0.012973415507837906}
		},
		{
			{0.08027719208695451, -0.0699891926511042, 0.028166981421125722},
			{-0.06998919265110423, 0.12468926878624291, -0.07647139336750189},
			{0.028166981421125736, -0.07647139336750187, 0.0914290076127645}
		},
		{
			{0.011999264789113513, 0.0030056174830635253, -0.011050610694755512},
			{0.003005617483063527, 0.02520910369411311, -0.01279328651545871},
			{-0.011050610694755507, -0.012793286515458701, 0.023003619515724306}
		},
		{
			{0.24657857426252439, -0.05154019773342323, -0.1214621662837389},
			{-0.051540197733423276, 0.013028050515106235, 0.018486467580927757},
			{-0.12146216628373899, 0.018486467580927753, 0.08095425974797373}
		},
		{
			{0.09868781892878987, -0.017494564967627996, 0.004242482152786342},
			{-0.017494564967628, 0.04147234704268655, 0.001095980590536588},
			{0.004242482152786343, 0.0010959805905365898, 0.0034427312266452517}
		},
		{
			{0.07475807397243667, -0.052345139514144226, -0.008744535087472437},
			{-0.052345139514144226, 0.09990071691755625, -0.028105120775557223},
			{-0.008744535087472435, -0.028105120775557223, 0.042824604916629205}
		},
		{
			{0.03111025348760979, -0.013946492980147794, -2.4717785620500133E-4},
			{-0.013946492980147805, 0.06478005342615721, -0.023248775732725692},
			{-2.4717785620499873E-4, -0.023248775732725692, 0.03373157932613061}
		},
		{
			{0.08117404002097903, -0.029462405689132807, -0.06096578473513391},
			{-0.0294624056891328, 0.0759189567424311, 0.0357046022334383},
			{-0.0609657847351339, 0.03570460223343831, 0.0592802130540484}
		},
		{
			{0.08311472408323023, -0.018008916282917405, -0.005969509568587722},
			{-0.018008916282917422, 0.07260243838999991, -0.003757112004743728},
			{-0.0059695095685877225, -0.003757112004743727, 0.030332704156296304}
		},
		{
			{0.04997113204273914, -0.00991453971410841, -0.01068668946460708},
			{-0.009914539714108413, 0.04180056679208961, -0.004558935294324197},
			{-0.010686689464607081, -0.004558935294324195, 0.02020986502204111}
		},
		{
			{0.10764128716848913, -0.05899303443550247, -0.023429730130063907},
			{-0.05899303443550249, 0.08026047422066473, -0.017960493302316395},
			{-0.02342973013006391, -0.01796049330231638, 0.036013132386358185}
		},
		{
			{0.030806125183416824, -0.019485720376925735, 0.0034705258577903972},
			{-0.019485720376925756, 0.07336081496064895, -0.04400932463380769},
			{0.0034705258577904, -0.0440093246338077, 0.040481231308322076}
		},
		{
			{0.029247209378490277, -0.014158049161470388, -0.013132396369361397},
			{-0.014158049161470398, 0.03432338630876701, -0.00753495716940726},
			{-0.013132396369361402, -0.007534957169407268, 0.025081975661764094}
		},
		{
			{0.05075842834156936, -0.01979589034416633, 0.003836037868581858},
			{-0.01979589034416633, 0.05849418380789992, -0.0318177123853478},
			{0.003836037868581846, -0.03181771238534781, 0.033068758248674404}
		},
		{
			{0.022466927352874408, -0.021150585354760686, 0.005084445984464387},
			{-0.02115058535476069, 0.06189946431782325, -0.04465815149378561},
			{0.005084445984464383, -0.04465815149378562, 0.0473555067431842}
		},
		{
			{0.026549867984404223, -0.026094299616148727, 0.002733708800010173},
			{-0.02609429961614873, 0.062392349082523314, -0.0031257094945528713},
			{0.0027337088000101736, -0.00312570949455287, 0.0020388203803322906}
		},
		{
			{0.030404742199342614, -0.016849369664848804, -0.009785147158709578},
			{-0.016849369664848797, 0.06242365412135875, -0.013861434624187204},
			{-0.009785147158709573, -0.013861434624187199, 0.0337559789393701}
		},
		{
			{0.08047960989522776, -0.032534764769468635, -0.010011723276557503},
			{-0.032534764769468635, 0.06106091145770497, 7.80257750738339E-5},
			{-0.010011723276557498, 7.80257750738287E-5, 0.031251894835242794}
		},
		{
			{0.022354263217689307, -4.2000451288442056E-4, -0.010468957271225005},
			{-4.200045128844223E-4, 0.032505884350859, 0.004921390483342214},
			{-0.010468957271225007, 0.004921390483342211, 0.006544855251102705}
		},
		{
			{0.0382772830901746, -5.103677664829685E-4, -0.008797351944748805},
			{-5.103677664829546E-4, 0.035610407593293994, -0.005084510322092807},
			{-0.008797351944748805, -0.005084510322092806, 0.017116491660911712}
		},
		{
			{0.021940688939781277, -0.021852556176117383, 0.01084739331740429},
			{-0.021852556176117362, 0.08094267493259792, -0.05846206991967588},
			{0.010847393317404287, -0.05846206991967587, 0.059285058235727606}
		},
		{
			{0.01918854531431959, 0.0022127704108765318, -0.006506451909363629},
			{0.002212770410876534, 0.015004769317589, 0.004252414834625838},
			{-0.006506451909363633, 0.004252414834625839, 0.009111996886815738}
		},
		{
			{0.05951419364354679, -0.03471852881294237, -0.006999119057979574},
			{-0.034718528812942386, 0.07662712581415437, -0.0343117229714797},
			{-0.0069991190579795646, -0.03431172297147969, 0.0436793575310667}
		},
		{
			{0.05263995501393079, -0.04257823767858411, -0.006123409539848311},
			{-0.042578237678584055, 0.10149441205505089, -0.007969451431004292},
			{-0.006123409539848307, -0.007969451431004308, 0.009951536840826114}
		},
		{
			{0.044800740129894406, -0.018462772695787492, -0.016927015385044198},
			{-0.01846277269578749, 0.058076349415243096, -0.03701939987165699},
			{-0.016927015385044188, -0.03701939987165699, 0.06104852668579067}
		},
		{
			{0.006513295934600845, 0.004601553681137155, -0.010688251055457506},
			{0.004601553681137153, 0.027913313538014704, -0.0207448579376035},
			{-0.010688251055457502, -0.0207448579376035, 0.025549056976382496}
		},
		{
			{0.04023071507798508, -0.028821503790249486, -0.0015690985264722197},
			{-0.028821503790249458, 0.05666674738203778, -0.01702370251222359},
			{-0.001569098526472221, -0.017023702512223595, 0.022068001117926082}
		},
		{
			{0.01423491667721199, 0.001474773669808238, -0.011505671389163396},
			{0.0014747736698082384, 0.015240875391322496, -0.002997409813281676},
			{-0.011505671389163398, -0.0029974098132816798, 0.020014653115598705}
		},
		{
			{0.02205007998420349, -0.010368323982685893, -0.006344171186053398},
			{-0.010368323982685902, 0.024687248713717292, -0.0036367604872531902},
			{-0.006344171186053403, -0.003636760487253197, 0.0202366537067132}
		},
		{
			{0.06425658868193793, -0.03509859115128451, -0.02041290179425715},
			{-0.0350985911512845, 0.09670471887112807, -0.01757809619830509},
			{-0.02041290179425713, -0.017578096198305075, 0.03757441258553371}
		},
		{
			{0.003727922434143883, -0.005075443131139567, 0.0034924587157731174},
			{-0.005075443131139582, 0.07148280288145022, -0.05052848652117108},
			{0.0034924587157731273, -0.0505284865211711, 0.05786011863499768}
		},
		{
			{0.04547994748647239, -0.003963622257498373, -0.013325960407771606},
			{-0.003963622257498375, 0.0376326587466296, -0.0116390586682219},
			{-0.013325960407771606, -0.011639058668221895, 0.0328974125905636}
		},
		{
			{0.057301390607806195, -0.034849586293905443, -0.017286271487038908},
			{-0.034849586293905443, 0.08289150831179906, -0.039811760657207915},
			{-0.017286271487038908, -0.039811760657207915, 0.11536170413889302}
		},
		{
			{0.044376384936445405, 0.010136125144641598, -0.007393833097516343},
			{0.010136125144641593, 0.024479542369136093, -6.047859497779827E-4},
			{-0.007393833097516338, -6.047859497779798E-4, 0.003064532807933269}
		},
		{
			{0.04589575051274556, -0.03590056162337889, 3.755831019219653E-4},
			{-0.03590056162337887, 0.07962185012683543, -0.016301801254377305},
			{3.7558310192196227E-4, -0.016301801254377305, 0.016714530733132598}
		},
		{
			{0.029804253380436387, -0.009653544603612936, -0.0018863777050631293},
			{-0.00965354460361293, 0.038934568951399184, -0.019059630617534906},
			{-0.0018863777050631275, -0.01905963061753491, 0.028316085766785206}
		},
		{
			{0.09758485670621118, -0.02990638940889813, -0.014595067347279684},
			{-0.02990638940889811, 0.154308644692367, -0.04492294564561425},
			{-0.014595067347279701, -0.044922945645614235, 0.06595157664251003}
		},
		{
			{0.014548696206270197, -0.01264165670735351, 0.002272457852973619},
			{-0.012641656707353498, 0.058920598943973834, -0.029124245404499118},
			{0.0022724578529736104, -0.02912424540449912, 0.027676995432167416}
		},
		{
			{0.052900093935523654, -0.046207446508286475, -0.0031625344234228487},
			{-0.04620744650828644, 0.06925081362673606, -0.0132805595410629},
			{-0.0031625344234228556, -0.013280559541062907, 0.02481128949170541}
		},
		{
			{0.036792800806946996, 0.021665992764954223, 0.0063559665235288065},
			{0.021665992764954182, 0.23646339911925812, -0.02596725830693121},
			{0.0063559665235287995, -0.025967258306931227, 0.00504376159689421}
		},
		{
			{0.06422872318787655, -0.015878495154326776, -0.016075759725383394},
			{-0.015878495154326773, 0.03461454789765038, -3.006216661541536E-4},
			{-0.016075759725383398, -3.006216661541501E-4, 0.018719926444417195}
		},
		{
			{0.07410504696918468, -0.030602104753968712, -0.0027707696863698197},
			{-0.030602104753968712, 0.041235200097408324, -0.021364718467256204},
			{-0.002770769686369818, -0.021364718467256204, 0.026035844294747187}
		},
		{
			{0.03751020303311332, -0.022576841353282216, -0.014045775797366294},
			{-0.022576841353282227, 0.06554486122188313, -0.03216201359662894},
			{-0.014045775797366275, -0.03216201359662896, 0.03701037817937395}
		},
		{
			{0.0044135910454389535, -0.00911649080507215, 0.004204455815283418},
			{-0.009116490805072179, 0.07404367192643857, -0.04356315840426863},
			{0.0042044558152834356, -0.04356315840426863, 0.05095415502331251}
		},
		{
			{0.18589807976320974, -0.05660785401260878, -0.0749098786003929},
			{-0.05660785401260879, 0.1417158145479509, 0.014555821966136834},
			{-0.07490987860039294, 0.01455582196613682, 0.08974756253834468}
		},
		{
			{0.017616031819840852, -0.010800504286532852, 9.619711284900479E-4},
			{-0.010800504286532847, 0.06956848202011714, -0.03827050264799077},
			{9.6197112849005E-4, -0.03827050264799078, 0.04091488863847068}
		},
		{
			{0.022467364091633323, -0.005677973691168724, -0.010537259070224299},
			{-0.005677973691168719, 0.02929941964674419, -0.007877554077660451},
			{-0.0105372590702243, -0.007877554077660448, 0.0201719200247907}
		}
	};

	double barycentre[66][3] =
	{
		{42.6, 124.16923076923077, 97.81538461538462},
		{144.18141592920355, 199.67256637168143, 176.1637168141593},
		{96.31026785714286, 163.39955357142858, 170.02678571428572},
		{153.24892703862662, 162.82403433476395, 209.67596566523605},
		{173.52281368821292, 120.74334600760456, 94.92015209125475},
		{74.4734693877551, 81.42857142857143, 50.391836734693875},
		{89.42857142857143, 140.84586466165413, 114.68045112781955},
		{37.03103448275862, 36.710344827586205, 44.4},
		{100.8891820580475, 162.71503957783642, 139.5725593667546},
		{216.14285714285714, 201.49579831932772, 99.85714285714286},
		{193.35256410256412, 207.7948717948718, 185.02564102564102},
		{177.76129032258063, 203.67741935483872, 144.52903225806452},
		{106.7109375, 97.16796875, 108.92578125},
		{132.85113268608416, 85.78964401294499, 66.45631067961165},
		{153.84596577017115, 162.02933985330074, 97.33007334963325},
		{222.89772727272728, 96.81818181818181, 18.948863636363637},
		{199.92237442922374, 142.36301369863014, 156.6986301369863},
		{79.1762114537445, 84.19383259911895, 92.01321585903084},
		{123.36196319018404, 72.21472392638037, 35.91411042944785},
		{157.75956284153006, 142.18579234972677, 62.91803278688525},
		{177.90301003344482, 180.40802675585283, 219.44481605351172},
		{120.7560975609756, 183.90243902439025, 160.78319783197833},
		{67.0326797385621, 52.09803921568628, 83.74509803921569},
		{129.58671586715866, 113.6309963099631, 132.82656826568265},
		{111.25978647686833, 125.92526690391459, 167.7900355871886},
		{147.82972972972973, 103.22162162162162, 98.93513513513514},
		{62.84297520661157, 40.32644628099174, 54.19421487603306},
		{96.88796680497926, 76.29875518672199, 70.01244813278008},
		{169.82879377431905, 138.9669260700389, 177.68677042801556},
		{219.32738095238096, 181.13690476190476, 154.83928571428572},
		{69.88622754491018, 137.1556886227545, 175.79640718562874},
		{97.86387434554973, 123.93717277486911, 84.23560209424083},
		{82.18536585365854, 125.79512195121951, 141.43414634146342},
		{68.25, 166.34583333333333, 192.00833333333333},
		{144.93478260869566, 112.18115942028986, 17.347826086956523},
		{179.5079006772009, 124.68171557562077, 149.59142212189616},
		{119.46652719665272, 164.52092050209205, 228.4979079497908},
		{188.40277777777777, 177.66666666666666, 60.90277777777778},
		{109.79565217391304, 99.14782608695653, 48.36521739130435},
		{103.89583333333333, 199.86458333333334, 241.14166666666668},
		{199.16528925619835, 148.80165289256198, 11.446280991735538},
		{200.92857142857142, 134.07894736842104, 119.21052631578948},
		{132.93986636971047, 143.38752783964364, 195.03786191536747},
		{188.3221052631579, 157.81052631578947, 194.32842105263157},
		{58.37647058823529, 159.7764705882353, 151.69411764705882},
		{187.66417910447763, 152.75, 86.32462686567165},
		{139.63476070528966, 176.90428211586902, 132.64231738035264},
		{129.5840220385675, 138.61432506887053, 83.20661157024793},
		{97.11145510835914, 145.05263157894737, 206.53869969040247},
		{24.228571428571428, 130.95714285714286, 141.45714285714286},
		{169.48728813559322, 116.63983050847457, 122.95550847457628},
		{143.07960199004975, 190.48009950248758, 239.8681592039801},
		{225.875, 197.78125, 11.59375},
		{178.38888888888889, 171.475, 117.70277777777778},
		{103.50927835051546, 177.55463917525773, 190.56288659793813},
		{191.29357798165137, 209.42201834862385, 233.52293577981652},
		{86.0078947368421, 184.27894736842106, 220.23684210526315},
		{156.65384615384616, 109.15384615384616, 65.95454545454545},
		{57.84848484848485, 19.681818181818183, 17.954545454545453},
		{147.9867374005305, 124.0159151193634, 156.43766578249335},
		{218.4689265536723, 119.32203389830508, 77.48587570621469},
		{12.473684210526315, 107.14035087719299, 75.14035087719299},
		{9.61744966442953, 162.9731543624161, 175.2013422818792},
		{21.99099099099099, 20.486486486486488, 25.2972972972973},
		{125.6712643678161, 197.19310344827585, 204.60459770114943},
		{120.40052356020942, 157.782722513089, 113.42408376963351}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<66;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<66;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance67clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027009003954871078, -0.020001359839930184, -0.0015880972116052471},
		{-0.020001359839930167, 0.04217888577496816, -0.013733094173583094},
		{-0.0015880972116052478, -0.013733094173583097, 0.015593779837600411}
	};

	double matrix[67][3][3] =
	{
		{
			{0.030840520953759134, -0.015778845131195898, -0.00963375683411229},
			{-0.0157788451311959, 0.0360837085172794, -0.003163832638631241},
			{-0.009633756834112293, -0.00316383263863124, 0.01326673429911951}
		},
		{
			{0.014445598750682008, 0.003920576482188335, -0.012546771155504701},
			{0.00392057648218834, 0.00882352114212526, -0.008560949902717309},
			{-0.012546771155504708, -0.008560949902717305, 0.02266013016078609}
		},
		{
			{0.017277774454164896, -0.006243323417775988, -0.004960177266058399},
			{-0.006243323417775994, 0.043024700668821025, -0.013284890128889093},
			{-0.004960177266058401, -0.013284890128889101, 0.033521364167281714}
		},
		{
			{0.11204044953255313, -0.062094864233079784, -0.016003037131629417},
			{-0.062094864233079756, 0.10300729565415292, -0.030073060765690305},
			{-0.01600303713162942, -0.0300730607656903, 0.04135867027248989}
		},
		{
			{0.0308826641212354, -0.00868354569923871, -0.0038445408517448895},
			{-0.00868354569923871, 0.07106733666199319, -0.02442927703304061},
			{-0.0038445408517448904, -0.02442927703304058, 0.03544280762407191}
		},
		{
			{0.016840214819475022, -0.0013700231762480315, -0.015416555813497513},
			{-0.0013700231762480298, 0.03669019004091038, -0.0160789483034774},
			{-0.015416555813497502, -0.016078948303477406, 0.031573444349046895}
		},
		{
			{0.05966244084937008, -0.0051109676280394496, -0.008834730942572956},
			{-0.005110967628039426, 0.04366202681844614, -0.04607816692184043},
			{-0.008834730942572953, -0.04607816692184043, 0.06377749435528551}
		},
		{
			{0.013855072534085173, -0.012614963333164883, 0.002573419504512984},
			{-0.012614963333164874, 0.05859899958200259, -0.029337155560189992},
			{0.002573419504512978, -0.029337155560189985, 0.028310226119917695}
		},
		{
			{0.04299494129196157, -0.017726639504573587, -0.00694116753704338},
			{-0.017726639504573587, 0.05921442660993233, -0.002256800702185286},
			{-0.0069411675370433905, -0.0022568007021852815, 0.016677807957825405}
		},
		{
			{0.05641399530771941, -0.03180861221162057, 0.005041382091934777},
			{-0.03180861221162054, 0.09865477671150458, -0.03555219876988769},
			{0.005041382091934773, -0.03555219876988769, 0.047688500469598986}
		},
		{
			{0.023785509640966346, -0.016483195194019362, 0.00628812227949381},
			{-0.01648319519401936, 0.07317946540283961, -0.039325217339901984},
			{0.006288122279493814, -0.039325217339902005, 0.040014114414266076}
		},
		{
			{0.10049186839115404, -0.06507041799271057, 0.016558983519931892},
			{-0.06507041799271053, 0.09366208225583539, -0.03445114107212048},
			{0.016558983519931878, -0.03445114107212048, 0.0211094529209942}
		},
		{
			{0.04128491048395812, -0.03722967969473369, -0.0035275396009432722},
			{-0.037229679694733696, 0.0740720927757611, -0.017581222131682298},
			{-0.0035275396009432705, -0.017581222131682284, 0.0391816164303832}
		},
		{
			{0.1480593610974276, -0.14282131989012978, -0.03216287987342974},
			{-0.1428213198901298, 0.14523284947897058, 0.016259369025136212},
			{-0.03216287987342976, 0.016259369025136222, 0.03619585858296644}
		},
		{
			{0.028744352947830426, -0.016704710018155915, -0.012959986751089413},
			{-0.01670471001815591, 0.02469333445825201, 0.0016204339131666986},
			{-0.012959986751089413, 0.0016204339131666952, 0.012853330038483508}
		},
		{
			{0.06680637242522311, 0.003452247874242269, -0.04227985022870825},
			{0.0034522478742422587, 0.187846206557326, -0.014575227033622077},
			{-0.042279850228708234, -0.014575227033622075, 0.039161277186385714}
		},
		{
			{0.010903747102087104, -0.009766667159576636, 2.293708478674566E-5},
			{-0.00976666715957664, 0.059400343133493363, -0.04628425800525633},
			{2.2937084786743057E-5, -0.04628425800525631, 0.050160959856439494}
		},
		{
			{0.0230523059038059, -0.00807023874881449, -0.008436639080376267},
			{-0.008070238748814488, 0.037877308113884414, -0.007756505014404332},
			{-0.008436639080376267, -0.007756505014404325, 0.023945407281619598}
		},
		{
			{0.03865003459966582, -0.016893829093849, -0.009446438749996209},
			{-0.016893829093848994, 0.057646649912914266, 0.007561643340289558},
			{-0.0094464387499962, 0.007561643340289564, 0.019105188487085104}
		},
		{
			{0.05927381946083112, -0.03665395487846473, -0.01981816550399263},
			{-0.03665395487846472, 0.08078940207751498, -0.0349256949795893},
			{-0.019818165503992624, -0.03492569497958929, 0.10922425963353506}
		},
		{
			{0.018003729132194345, -0.018388374010296436, 0.017705547597315144},
			{-0.01838837401029644, 0.028698462908163826, -0.01109241690982311},
			{0.017705547597315137, -0.011092416909823096, 0.02234107631407895}
		},
		{
			{0.03506612130704851, -0.025558142410750214, 8.964701006811556E-4},
			{-0.025558142410750214, 0.047618025651909104, -0.013649424100040502},
			{8.964701006811571E-4, -0.013649424100040502, 0.013406420298940803}
		},
		{
			{0.05445397060011421, -0.024738170648594314, -0.00928682122217634},
			{-0.024738170648594307, 0.05774938327255953, -0.02782665748347639},
			{-0.00928682122217634, -0.02782665748347638, 0.04221491817678522}
		},
		{
			{0.06831569836435117, -0.046888104014384244, 0.004305674900562228},
			{-0.0468881040143842, 0.0673921879177742, -0.010589923712111687},
			{0.004305674900562224, -0.010589923712111694, 0.052309921085863624}
		},
		{
			{0.046398733630349624, -0.04161149802432444, 0.002832342927736205},
			{-0.041611498024324456, 0.0813661466309269, -0.014799209039888298},
			{0.0028323429277362006, -0.014799209039888296, 0.014313767791621402}
		},
		{
			{0.02491088932224109, -0.003652846865606496, -0.007698457742994813},
			{-0.003652846865606497, 0.039814427242162914, -0.014436180585798392},
			{-0.00769845774299481, -0.014436180585798396, 0.029196857498892906}
		},
		{
			{0.06054842653722807, -0.04150780167629497, -0.010250041142038594},
			{-0.041507801676294954, 0.06788118626740289, 0.003959649167373801},
			{-0.010250041142038596, 0.003959649167373796, 0.0076207355461128164}
		},
		{
			{0.07325491577783429, -0.033133007030434716, -0.02110767216965991},
			{-0.03313300703043471, 0.03585598019337028, -0.0013885284112844492},
			{-0.02110767216965991, -0.0013885284112844561, 0.0350931054805028}
		},
		{
			{0.0023270695275912317, -0.008864608094577522, 0.0020790117394768296},
			{-0.008864608094577545, 0.076750411023098, -0.0420834988113745},
			{0.0020790117394768426, -0.04208349881137449, 0.0517464098377702}
		},
		{
			{0.045744234019900354, -0.018115931160884308, -0.021296829084071114},
			{-0.018115931160884287, 0.05222378256010967, -0.03321115342051689},
			{-0.021296829084071107, -0.03321115342051689, 0.0603065289020719}
		},
		{
			{0.06364181338820245, -0.043934802125758135, -0.010107532403191592},
			{-0.043934802125758135, 0.09797367681247977, -0.008231661606026786},
			{-0.010107532403191597, -0.008231661606026789, 0.0131459560874596}
		},
		{
			{0.2343546639693806, -0.08348852914502401, -0.1188840755664934},
			{-0.08348852914502393, 0.04580187638182426, 0.029723472604312053},
			{-0.11888407556649333, 0.02972347260431207, 0.07023903152829049}
		},
		{
			{0.07914329460351599, -0.025798817778646392, -0.004660205855041736},
			{-0.025798817778646402, 0.027721269255553807, -0.018977221359761105},
			{-0.004660205855041739, -0.018977221359761102, 0.0282558426451409}
		},
		{
			{0.03468043083046903, -0.027684002914075936, 0.005406131454368115},
			{-0.027684002914075936, 0.04981310916869326, -0.00714222287304229},
			{0.005406131454368116, -0.00714222287304229, 0.010542726062572002}
		},
		{
			{0.0846772721499573, -0.019653716019297645, -0.0374932388123799},
			{-0.019653716019297645, 0.07242568963476677, -0.032447159951953096},
			{-0.03749323881237993, -0.032447159951953075, 0.11240812387713102}
		},
		{
			{0.05746777391778031, -0.012933248008389301, -0.022085836612705103},
			{-0.012933248008389304, 0.11245431079281992, -0.04327604241361957},
			{-0.02208583661270511, -0.043276042413619584, 0.04076135994330257}
		},
		{
			{0.06840432823082455, -0.07100322714313205, 0.00883425498037189},
			{-0.0710032271431321, 0.1298143412991922, -0.04543453108406723},
			{0.008834254980371905, -0.045434531084067226, 0.0368915120825984}
		},
		{
			{0.0171218283086177, 6.038802278631105E-4, -0.00911636889237998},
			{6.038802278631097E-4, 0.030425049556221107, -0.0029934840373663377},
			{-0.00911636889237998, -0.0029934840373663507, 0.013052714040534099}
		},
		{
			{0.022357468151210175, 0.004876757787491196, -0.002998172447271832},
			{0.004876757787491205, 0.0313269726320713, -0.01709040579165128},
			{-0.0029981724472718345, -0.01709040579165127, 0.058215842736862665}
		},
		{
			{0.057237909939683036, 0.013779254210225014, -0.015177697949849024},
			{0.013779254210225007, 0.023898113856656425, 0.004836675032823516},
			{-0.015177697949849018, 0.004836675032823515, 0.007527336308774011}
		},
		{
			{0.015692423665644002, 0.0045846381859733125, -0.008580284421839071},
			{0.004584638185973311, 0.02975071483113651, 0.006116232369899658},
			{-0.008580284421839068, 0.00611623236989966, 0.007441111006592265}
		},
		{
			{0.0881626278847996, -0.0675689449100706, 0.02110405214103861},
			{-0.0675689449100706, 0.12924606739303302, -0.07108277252638255},
			{0.021104052141038623, -0.07108277252638256, 0.07882885441453319}
		},
		{
			{0.031224964919137226, -0.016380668949872498, 0.0011950587561124905},
			{-0.01638066894987249, 0.0536672557547445, -0.028560012951778097},
			{0.0011950587561124965, -0.028560012951778117, 0.030920710333012316}
		},
		{
			{0.04415416490825702, -0.02570263109960217, 0.0038217988243563657},
			{-0.02570263109960215, 0.0769162765757586, -0.038208781355825325},
			{0.003821798824356353, -0.038208781355825325, 0.03928801375046019}
		},
		{
			{0.14716246126178908, -0.11320993673270008, 0.015345307060929613},
			{-0.11320993673270016, 0.2722914151299752, -0.015045642700079725},
			{0.015345307060929613, -0.015045642700079714, 0.008056602040887925}
		},
		{
			{0.021260590965640404, -2.4224560381553954E-4, -0.011545845583774108},
			{-2.4224560381554475E-4, 0.024591785425702714, -0.009238117278499072},
			{-0.011545845583774106, -0.009238117278499075, 0.02047974613785042}
		},
		{
			{0.07782488438869041, -0.04570695514219448, 0.002115706353276249},
			{-0.0457069551421945, 0.06792498369947225, -0.026700839018895427},
			{0.002115706353276259, -0.026700839018895414, 0.02776681888307632}
		},
		{
			{0.04335182691864649, -0.007541548885259141, -0.0186458263325576},
			{-0.007541548885259156, 0.049235881321910833, -0.01920120398243327},
			{-0.018645826332557607, -0.01920120398243327, 0.0407874510971991}
		},
		{
			{0.037104453303557425, -0.012548666026963588, -0.004629162681311112},
			{-0.012548666026963598, 0.06937655513273973, -0.02675142060314742},
			{-0.004629162681311119, -0.02675142060314741, 0.03436334728823601}
		},
		{
			{0.01332957447484262, -0.0026452010933768113, -0.014701531163166016},
			{-0.002645201093376806, 0.0333613819862678, -0.013390968661763904},
			{-0.014701531163166016, -0.013390968661763907, 0.028797472246759603}
		},
		{
			{0.07182121401434048, -0.021858459781413285, -0.008340574562066848},
			{-0.021858459781413268, 0.09903613673645872, -0.016435621197415713},
			{-0.008340574562066865, -0.016435621197415727, 0.02609462085112281}
		},
		{
			{0.03553381222699893, -0.011291717927725828, -8.019136703857135E-4},
			{-0.011291717927725825, 0.07080788558355036, -0.005252320855424325},
			{-8.019136703857101E-4, -0.00525232085542432, 0.0248865174541639}
		},
		{
			{0.0899085294020603, -0.008565749739065459, -0.008320665378245273},
			{-0.008565749739065456, 0.02767458188029159, 0.005424972407229498},
			{-0.008320665378245273, 0.005424972407229499, 0.007111364319968987}
		},
		{
			{0.06257211752624126, -0.0360207753263285, -0.004210792065088507},
			{-0.03602077532632847, 0.07465869225241273, -0.030262693872468407},
			{-0.004210792065088512, -0.0302626938724684, 0.03747387252266549}
		},
		{
			{0.019906366952520207, 0.0028009905159221363, -0.006423432428063968},
			{0.00280099051592214, 0.014796042580925307, 0.0030641797965438467},
			{-0.006423432428063973, 0.003064179796543848, 0.008031440621931424}
		},
		{
			{0.046228985763212285, -0.008751970946138752, -0.01449663186784682},
			{-0.008751970946138748, 0.06795434406513211, -0.00930565030258534},
			{-0.014496631867846816, -0.009305650302585339, 0.014515227110306927}
		},
		{
			{0.030653514946636817, -0.026926381389253223, 0.003449926007469013},
			{-0.026926381389253223, 0.061693683489669214, -0.0026288848910151477},
			{0.003449926007469013, -0.002628884891015151, 0.0019920239819619604}
		},
		{
			{0.07259319073935953, -0.04464590889941757, 0.006125816934299686},
			{-0.04464590889941756, 0.052791966861904245, -0.004600573776078488},
			{0.006125816934299683, -0.004600573776078491, 0.017211617235122004}
		},
		{
			{0.026906597934489913, -0.01950913497075972, -0.004469418225949253},
			{-0.019509134970759723, 0.04401266059863072, -0.0019078075625254473},
			{-0.0044694182259492525, -0.0019078075625254512, 0.012681738612753303}
		},
		{
			{0.06868182968364032, -0.048125658065827824, -0.003953830388071595},
			{-0.048125658065827845, 0.12224697565092793, -0.03263333096098117},
			{-0.00395383038807161, -0.03263333096098117, 0.025568005829758482}
		},
		{
			{0.003631345839189652, -0.0028485774113753445, 0.00223371225978677},
			{-0.0028485774113753415, 0.06785325740334289, -0.043406581615076587},
			{0.0022337122597867677, -0.04340658161507658, 0.051347624344203396}
		},
		{
			{0.09529517188238759, -0.016284198911257868, -6.560078936217152E-5},
			{-0.01628419891125787, 0.07595028012900792, 0.012427163561306721},
			{-6.560078936217433E-5, 0.012427163561306721, 0.018015988920707698}
		},
		{
			{0.05721296703890157, -0.020159337600895593, 0.006870579866646928},
			{-0.020159337600895593, 0.05385743016004668, -0.007585942907116528},
			{0.006870579866646927, -0.007585942907116529, 0.007905109494250679}
		},
		{
			{0.008786521143876631, -8.609061776478498E-4, -0.006831293386131019},
			{-8.609061776478498E-4, 0.039474650716501906, -0.02727388755670142},
			{-0.006831293386131017, -0.02727388755670142, 0.03009267199321853}
		},
		{
			{0.08075799164542373, -0.018943997406589856, -0.0203251138792127},
			{-0.018943997406589815, 0.20599269939713502, 0.009409924055063003},
			{-0.020325113879212705, 0.00940992405506302, 0.025195925207796024}
		},
		{
			{0.011156482380270803, -0.0016297344465953127, -0.010404239755229494},
			{-0.0016297344465953144, 0.029200212681328615, -0.011314642504949398},
			{-0.0104042397552295, -0.011314642504949401, 0.0246159704042339}
		},
		{
			{0.013452937034484806, -0.021321403413162424, 0.012454955450199024},
			{-0.021321403413162413, 0.08389223751361555, -0.06102318386231913},
			{0.012454955450199007, -0.06102318386231913, 0.06311320311653612}
		}
	};

	double barycentre[67][3] =
	{
		{97.67251461988305, 117.9766081871345, 76.70760233918129},
		{126.03333333333333, 176.8846153846154, 141.32051282051282},
		{107.86506024096386, 183.3277108433735, 189.90843373493976},
		{218.25625, 184.59375, 166.0125},
		{144.60597014925372, 102.13134328358208, 96.86865671641792},
		{89.06451612903226, 139.01433691756273, 111.68817204301075},
		{84.25824175824175, 118.06043956043956, 136.4065934065934},
		{86.27019498607243, 185.3983286908078, 219.82729805013926},
		{114.09850746268657, 84.0865671641791, 43.38805970149254},
		{115.95424836601308, 177.8202614379085, 242.781045751634},
		{129.99222797927462, 199.5699481865285, 205.46891191709844},
		{194.07421875, 158.7890625, 138.3203125},
		{166.77685950413223, 113.69146005509641, 81.06611570247934},
		{186.06756756756758, 211.43243243243242, 186.40540540540542},
		{162.5243243243243, 195.68648648648647, 149.05945945945945},
		{69.32530120481928, 34.903614457831324, 42.493975903614455},
		{51.52272727272727, 163.63636363636363, 191.47727272727272},
		{123.98407643312102, 138.93312101910828, 85.69745222929936},
		{78.74285714285715, 80.12698412698413, 52.26984126984127},
		{145.34501347708894, 190.59029649595686, 239.29380053908355},
		{26.344827586206897, 93.37931034482759, 55.310344827586206},
		{182.67948717948718, 150.0897435897436, 69.2905982905983},
		{192.60965794768612, 138.476861167002, 165.8370221327968},
		{125.22693266832918, 163.21695760598504, 219.99750623441398},
		{179.09294871794873, 168.92628205128204, 102.8173076923077},
		{99.54310344827586, 166.42672413793105, 167.48060344827587},
		{199.0, 210.74545454545455, 122.4},
		{222.98275862068965, 102.26724137931035, 7.293103448275862},
		{4.937007874015748, 160.75590551181102, 172.81102362204723},
		{187.4758064516129, 158.74798387096774, 195.81451612903226},
		{124.76867469879518, 143.39036144578313, 194.6433734939759},
		{61.54066985645933, 47.23444976076555, 75.6555023923445},
		{224.18421052631578, 122.06140350877193, 76.57894736842105},
		{151.4958904109589, 134.9945205479452, 61.69041095890411},
		{39.00974025974026, 36.87337662337662, 44.896103896103895},
		{126.18991097922849, 125.4272997032641, 161.7299703264095},
		{156.28, 163.122, 208.52},
		{153.05654761904762, 173.21428571428572, 118.11904761904762},
		{23.85, 118.0875, 87.3375},
		{225.43636363636364, 197.56363636363636, 5.8},
		{184.23157894736843, 183.66315789473686, 60.76842105263158},
		{184.39597315436242, 192.05704697986576, 226.66442953020135},
		{86.34246575342466, 165.7013698630137, 191.2876712328767},
		{194.66815144766147, 128.0913140311804, 132.34298440979956},
		{105.92015209125475, 96.96197718631178, 108.5893536121673},
		{120.72081218274111, 158.5989847715736, 114.78934010152284},
		{221.05555555555554, 156.43055555555554, 118.15277777777777},
		{166.42125984251967, 121.40944881889764, 148.1791338582677},
		{168.9832089552239, 117.64365671641791, 111.73320895522389},
		{131.69182389937106, 193.0503144654088, 170.75157232704402},
		{94.84583333333333, 147.4875, 215.81666666666666},
		{134.6153846153846, 88.02564102564102, 64.09487179487179},
		{136.05517241379312, 112.84137931034483, 132.41034482758621},
		{194.43684210526317, 129.03684210526316, 101.68684210526315},
		{197.61344537815125, 149.47899159663865, 11.067226890756302},
		{160.9149377593361, 136.49792531120332, 180.08091286307055},
		{144.2516129032258, 109.40645161290323, 19.412903225806453},
		{218.06666666666666, 90.46666666666667, 44.3},
		{151.95774647887325, 153.49295774647888, 89.78028169014084},
		{86.66793893129771, 132.63740458015266, 173.15648854961833},
		{27.82089552238806, 128.0597014925373, 131.22388059701493},
		{85.01928374655647, 79.00550964187327, 85.38567493112947},
		{225.93939393939394, 194.42424242424244, 74.27272727272727},
		{55.004629629629626, 155.35185185185185, 156.50925925925927},
		{25.22222222222222, 20.482758620689655, 24.325670498084293},
		{95.37606837606837, 158.9031339031339, 138.7806267806268},
		{100.68378378378378, 203.9918918918919, 239.77297297297298}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<67;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<67;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance68clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.02709734504565408, -0.019132320654149083, -0.0020276593970471224},
		{-0.01913232065414909, 0.040750343432951704, -0.0127047384354532},
		{-0.002027659397047122, -0.0127047384354532, 0.014853414553672107}
	};

	double matrix[68][3][3] =
	{
		{
			{0.061330063004395405, -0.029454236766481123, -0.012693670484048694},
			{-0.029454236766481134, 0.056063821953236934, 0.0014470114699121498},
			{-0.012693670484048694, 0.0014470114699121372, 0.017115274226028595}
		},
		{
			{0.05708564477474043, 0.012345723465161874, -0.01544601301134031},
			{0.01234572346516187, 0.022736092038239213, 0.006205541112828709},
			{-0.015446013011340302, 0.00620554111282871, 0.008720613279273537}
		},
		{
			{0.004465187421467776, -0.012279634935916791, 0.0013118069225466523},
			{-0.01227963493591678, 0.07140752049845708, -0.042184425152363085},
			{0.0013118069225466497, -0.0421844251523631, 0.052485895784421116}
		},
		{
			{0.09433074286469158, -0.015363494901269596, -0.004888157395893889},
			{-0.015363494901269615, 0.042187158160308824, 0.0018426605972802121},
			{-0.004888157395893893, 0.0018426605972802106, 0.007020665471608688}
		},
		{
			{0.015419816535793503, -0.0029938619921389227, -0.006605151631143032},
			{-0.0029938619921389205, 0.027014626379788687, -0.010549871259280898},
			{-0.00660515163114303, -0.010549871259280892, 0.023806737181426195}
		},
		{
			{0.028939515606830463, -0.02653335238771677, 0.002321429833545618},
			{-0.026533352387716792, 0.06222889478358362, -0.0032896974800093004},
			{0.002321429833545618, -0.0032896974800093, 0.00195979182809684}
		},
		{
			{0.029916913107918712, -0.0065559795357762515, -0.023354579882262593},
			{-0.0065559795357762445, 0.050308445137166286, -0.024696005215611015},
			{-0.02335457988226258, -0.024696005215611015, 0.04689102961443509}
		},
		{
			{0.10095584432374695, -0.04964434074947565, -0.022352924290495974},
			{-0.04964434074947567, 0.1293335466529229, -0.0637216304501453},
			{-0.02235292429049598, -0.06372163045014533, 0.10315465779311099}
		},
		{
			{0.06748704885229062, -0.032840185886766, -0.02135153884754902},
			{-0.032840185886766016, 0.11687780615004603, -0.029267310206535207},
			{-0.021351538847549017, -0.029267310206535196, 0.04145043682726121}
		},
		{
			{0.06787967908304929, -0.040822398246860146, -0.007321741888174896},
			{-0.04082239824686015, 0.08033849757166162, -0.030517638243978518},
			{-0.0073217418881748805, -0.0305176382439785, 0.0444792006982138}
		},
		{
			{0.02366526613010688, -0.011575238269737697, -0.0119477893363911},
			{-0.011575238269737697, 0.026016021980316203, -0.0023168902259715542},
			{-0.011947789336391103, -0.0023168902259715542, 0.014580341758193501}
		},
		{
			{0.0448159761813996, -0.017818690139394907, -0.0210624632988048},
			{-0.017818690139394907, 0.02298627092567332, 0.0059857581088307915},
			{-0.0210624632988048, 0.005985758108830796, 0.0195907123279911}
		},
		{
			{0.013981473238693426, 0.0030079002450248476, -0.015210565653772419},
			{0.0030079002450248433, 0.015423791574282999, -0.00670800484100759},
			{-0.015210565653772408, -0.006708004841007582, 0.021336133895303196}
		},
		{
			{0.04496687441237136, -0.016494563913907887, -0.01099397262762739},
			{-0.016494563913907884, 0.05648126069351431, -0.027040140335370996},
			{-0.010993972627627392, -0.027040140335371006, 0.0478185704058804}
		},
		{
			{0.05458360467358712, -0.013891182462695701, -0.010405797213816105},
			{-0.01389118246269571, 0.024497877751694305, -0.012145281856047505},
			{-0.010405797213816105, -0.012145281856047505, 0.04761771182500301}
		},
		{
			{0.03561497673302151, -0.01157681082429084, -0.003956297802193164},
			{-0.011576810824290856, 0.16832760048923806, -0.026089903777782614},
			{-0.003956297802193169, -0.026089903777782593, 0.051593522973072084}
		},
		{
			{0.04620648565621677, -0.013830361797131362, -0.006025321934200289},
			{-0.01383036179713137, 0.06766602587150534, -0.010765250580747307},
			{-0.00602532193420029, -0.01076525058074732, 0.018840307720287}
		},
		{
			{0.06870114521889671, -0.04555451577504297, -0.00829027519008741},
			{-0.045554515775043, 0.08755684398009726, -0.02477672538492262},
			{-0.0082902751900874, -0.024776725384922607, 0.0388828128300769}
		},
		{
			{0.04720586815192693, -0.018217007375351826, -0.018453769499422602},
			{-0.01821700737535182, 0.07446853824197217, -0.04372542115737568},
			{-0.01845376949942259, -0.04372542115737571, 0.123647372158362}
		},
		{
			{0.032042408319962294, -0.02629444252254001, 0.005686442404055103},
			{-0.02629444252254, 0.0514307236682729, -0.008169375301992684},
			{0.005686442404055099, -0.00816937530199268, 0.012447894416046604}
		},
		{
			{0.09805574286847968, -0.05710095116814443, -0.0017758332574248116},
			{-0.05710095116814448, 0.04375245846419299, -0.004677510804632003},
			{-0.0017758332574248116, -0.004677510804632001, 0.0121623431660735}
		},
		{
			{0.027469040000360063, -0.012718370683242396, -0.0025279038754843323},
			{-0.0127183706832424, 0.03862809258206618, -0.018962929120412905},
			{-0.0025279038754843306, -0.018962929120412895, 0.03118873532126951}
		},
		{
			{0.13322011414173318, -0.12504552413354206, -0.03146281413918562},
			{-0.12504552413354197, 0.13260882061662876, 0.010747374458843486},
			{-0.0314628141391856, 0.010747374458843483, 0.03328376049444869}
		},
		{
			{0.007961943705588304, -0.0012757829745069108, -0.004436228123842239},
			{-0.001275782974506912, 0.04111345314510629, -0.0330058386316689},
			{-0.00443622812384224, -0.0330058386316689, 0.03648846429900901}
		},
		{
			{0.0525114702958154, -0.06066793578150092, 0.005426289368995156},
			{-0.060667935781500905, 0.12527003290074495, -0.02654444036031949},
			{0.005426289368995155, -0.026544440360319492, 0.023774100964037304}
		},
		{
			{0.07033577722676022, -0.044055433217372555, -0.01385034891907271},
			{-0.04405543321737256, 0.11706941387875398, -0.02815515613124257},
			{-0.013850348919072695, -0.02815515613124258, 0.024999491717447996}
		},
		{
			{0.01608770596362178, -0.02112198617231898, 0.010150014209651573},
			{-0.02112198617231898, 0.0794816329806183, -0.05747694964022835},
			{0.01015001420965158, -0.05747694964022836, 0.06082071905850074}
		},
		{
			{0.04417673999856591, -0.02047296089544589, -0.011483777698425606},
			{-0.020472960895445886, 0.0546825066469444, 0.006255075006207631},
			{-0.011483777698425606, 0.006255075006207634, 0.018392826888487902}
		},
		{
			{0.0451911758987313, -0.012929938292803114, -0.00703297698007846},
			{-0.012929938292803117, 0.06814819546789519, -0.0143599786090144},
			{-0.007032976980078459, -0.01435997860901439, 0.024507009351066616}
		},
		{
			{0.0709169812774091, -0.04894521962783599, -0.012881164745274894},
			{-0.048945219627836, 0.09499863475366614, 1.2134741509865505E-4},
			{-0.01288116474527489, 1.2134741509866286E-4, 0.018840285240053593}
		},
		{
			{0.1309719203958311, -0.06862152993656445, -0.042208084806345636},
			{-0.06862152993656441, 0.059040133675919884, 0.0254908414672323},
			{-0.04220808480634563, 0.025490841467232312, 0.023060874610870412}
		},
		{
			{0.09584772706941515, -0.09334187490785117, 0.012938189458884114},
			{-0.09334187490785106, 0.32564281782226606, -0.025614129989440706},
			{0.012938189458884098, -0.025614129989440706, 0.012546482473304005}
		},
		{
			{0.07475757377668828, -0.07631428216290409, 0.022116508959722204},
			{-0.07631428216290405, 0.15117920066245982, -0.038510747374726886},
			{0.0221165089597222, -0.038510747374726886, 0.0597979519438669}
		},
		{
			{0.015483078126193303, 0.008113317964640328, -0.0018043025620320613},
			{0.008113317964640326, 0.030287907865086894, -0.03130752565087572},
			{-0.0018043025620320605, -0.031307525650875724, 0.100733112502251}
		},
		{
			{0.0450848889549067, -0.03154450254098581, 0.0015050777622998526},
			{-0.031544502540985814, 0.06594451460005928, -0.016849189458172494},
			{0.0015050777622998505, -0.016849189458172494, 0.01920344494162591}
		},
		{
			{0.03215294485387963, -0.019512260167471613, -0.0053966666859481816},
			{-0.01951226016747159, 0.03203917951100736, 0.0014068797615091966},
			{-0.005396666685948175, 0.0014068797615091949, 0.0157183985240751}
		},
		{
			{0.025198150637621215, -0.012050455657385306, -0.012844775208979002},
			{-0.012050455657385302, 0.05421704206757561, -0.015675162762582413},
			{-0.012844775208978998, -0.015675162762582417, 0.023676645231165406}
		},
		{
			{0.09761319331270664, -0.01734542527386128, -0.004100474427848429},
			{-0.017345425273861285, 0.10447966605505096, 0.0033063619865815845},
			{-0.004100474427848429, 0.003306361986581581, 0.012150392263064698}
		},
		{
			{0.015632955796026714, -0.00389315174988044, -0.0015700152668987493},
			{-0.00389315174988044, 0.053222668776144615, -0.03081711849594041},
			{-0.001570015266898747, -0.030817118495940425, 0.036185939219774005}
		},
		{
			{0.05479636336551077, -0.034397050286474024, -0.009006597156013405},
			{-0.03439705028647403, 0.07119437887333528, 0.0037637566048959606},
			{-0.009006597156013409, 0.003763756604895966, 0.007724744489007347}
		},
		{
			{0.053430378639091544, -0.02502033257100779, -0.021601978009601588},
			{-0.025020332571007775, 0.04805545321343341, -0.024004581246576905},
			{-0.021601978009601584, -0.0240045812465769, 0.05334722101576261}
		},
		{
			{0.018003729132194345, -0.018388374010296436, 0.017705547597315144},
			{-0.01838837401029644, 0.028698462908163826, -0.01109241690982311},
			{0.017705547597315137, -0.011092416909823096, 0.02234107631407895}
		},
		{
			{0.023638020851566785, -0.0033473392999162667, -0.013461441045445593},
			{-0.0033473392999162736, 0.029044658665776418, -0.010226491115500499},
			{-0.013461441045445593, -0.010226491115500506, 0.02056861961134469}
		},
		{
			{0.029128508268294814, -0.020316426661555892, -0.004316972338050359},
			{-0.020316426661555885, 0.031980704673184646, -0.004558635153792016},
			{-0.00431697233805036, -0.00455863515379202, 0.015552932078053305}
		},
		{
			{0.05162284237043993, -0.030376734482209164, -0.0025659022052452337},
			{-0.030376734482209164, 0.08288881852501928, -0.0426763751705092},
			{-0.002565902205245224, -0.0426763751705092, 0.044950803622819877}
		},
		{
			{0.034501760270287465, -0.02215063786591187, 0.001249360720607615},
			{-0.022150637865911853, 0.0659535523810241, -0.02550855081197339},
			{0.0012493607206076071, -0.0255085508119734, 0.03282208323396041}
		},
		{
			{0.08143436940685078, 0.0107949438717987, -0.0401935085344639},
			{0.01079494387179867, 0.0920552075978913, 0.020583764849034153},
			{-0.040193508534463886, 0.020583764849034146, 0.05144414872581021}
		},
		{
			{0.11445845626012405, -0.06084697918720422, -0.018824170664901486},
			{-0.06084697918720426, 0.09561736394888574, -0.022418979542398187},
			{-0.018824170664901496, -0.0224189795423982, 0.034460455036732375}
		},
		{
			{0.056731962198014435, -0.019733839485523295, -0.002788344650844459},
			{-0.019733839485523295, 0.03584104956530989, 8.715665421454718E-4},
			{-0.00278834465084446, 8.715665421454705E-4, 0.005449199225360358}
		},
		{
			{0.014726858692234418, -0.010633141206906898, 0.0026256150613231505},
			{-0.010633141206906898, 0.053985551074488096, -0.026900203059929184},
			{0.0026256150613231505, -0.0269002030599292, 0.027869211062324394}
		},
		{
			{0.06926566911676349, -0.04152674423128019, -0.0036696344664590317},
			{-0.041526744231280194, 0.06778920472289404, -0.020953483711212598},
			{-0.0036696344664590274, -0.020953483711212598, 0.037808937307412416}
		},
		{
			{0.05088546153072243, -0.015193168231460706, -0.007435228546308715},
			{-0.015193168231460715, 0.03380928621721231, -0.004534740359564636},
			{-0.007435228546308722, -0.004534740359564632, 0.027517248631509894}
		},
		{
			{0.04651782554501336, -0.04491211959676826, -0.002552868551825534},
			{-0.04491211959676828, 0.102047536861352, -0.013581879352606598},
			{-0.0025528685518255313, -0.013581879352606593, 0.011087933900575702}
		},
		{
			{0.026612121673936392, -0.008243392810335782, -0.008235908366693103},
			{-0.008243392810335778, 0.03640362381689399, -0.0072756454049149166},
			{-0.008235908366693101, -0.007275645404914913, 0.019950947797534382}
		},
		{
			{0.10978314676897602, 1.8108272627970212E-4, -0.006600697006976516},
			{1.8108272627968824E-4, 0.11029020358968902, 0.0033581129014345562},
			{-0.006600697006976521, 0.003358112901434557, 0.016797515120660876}
		},
		{
			{0.048268810665794235, -0.03389067822584445, -0.008982199672992085},
			{-0.033890678225844406, 0.06957125947342184, -0.018441961754445613},
			{-0.008982199672992082, -0.01844196175444561, 0.04191938449113991}
		},
		{
			{0.022997907348794016, -3.5645122342966434E-4, -0.007129567471660044},
			{-3.5645122342966695E-4, 0.03498063525813558, -0.011322171448326205},
			{-0.007129567471660044, -0.011322171448326208, 0.02594350549680549}
		},
		{
			{0.11318213549776704, -0.04380960496359754, -0.0021043111716362167},
			{-0.043809604963597544, 0.052120103974320986, -0.012213873988217088},
			{-0.002104311171636222, -0.012213873988217092, 0.011030131819656902}
		},
		{
			{0.01093786247244011, 0.0010020421376122175, -0.0029950129723811374},
			{0.0010020421376122188, 0.016543184127283898, 0.0027464650618579905},
			{-0.00299501297238114, 0.00274646506185799, 0.006603186035176938}
		},
		{
			{0.028268771387582183, -0.019153338083027962, -2.5932863640565525E-4},
			{-0.019153338083027993, 0.06746723683568315, -0.04090549495946141},
			{-2.5932863640564354E-4, -0.04090549495946138, 0.04503858078582386}
		},
		{
			{0.028589590343569934, -0.023505072399999657, 0.007052677118232454},
			{-0.023505072399999646, 0.06894795308927452, -0.04020510995768164},
			{0.007052677118232445, -0.04020510995768164, 0.042164772418504325}
		},
		{
			{0.10893459570638298, -0.0616455285658045, 0.002347809208200334},
			{-0.061645528565804526, 0.08589608203456794, -0.018736551712582105},
			{0.002347809208200336, -0.018736551712582105, 0.017996049107299003}
		},
		{
			{0.013027780771918695, 0.001997011646305111, -0.009450473606652857},
			{0.0019970116463051083, 0.0245303519504744, -0.0033792472233876297},
			{-0.009450473606652856, -0.003379247223387628, 0.018648235790393184}
		},
		{
			{0.01638732630310698, -0.0048979970013265026, -0.011636867264535793},
			{-0.004897997001326507, 0.03526823646308891, -0.017871596210596398},
			{-0.011636867264535795, -0.017871596210596398, 0.03167214115036868}
		},
		{
			{0.0036343511745690494, -0.0028402628383497035, 0.002233874561470361},
			{-0.0028402628383497044, 0.06777185093507779, -0.04343716002426926},
			{0.0022338745614703627, -0.04343716002426926, 0.0513520636446168}
		},
		{
			{0.07667228999519886, -0.029095455149835907, -0.00617715218151961},
			{-0.029095455149835896, 0.03347247342312146, -0.01640754954306349},
			{-0.006177152181519616, -0.01640754954306349, 0.030550389121676208}
		},
		{
			{0.060655471683558226, -0.03855167343686618, 0.012231873301480678},
			{-0.038551673436866205, 0.04185588369123886, -0.011670735063046006},
			{0.012231873301480685, -0.01167073506304601, 0.021805971115814296}
		},
		{
			{0.03727533848711118, -0.02778593694089782, -0.003270033259799933},
			{-0.02778593694089782, 0.0731806369206193, -0.014026036024351303},
			{-0.003270033259799931, -0.014026036024351304, 0.016017980826464415}
		}
	};

	double barycentre[68][3] =
	{
		{147.53571428571428, 126.54220779220779, 160.02272727272728},
		{225.43396226415095, 197.0188679245283, 4.566037735849057},
		{7.347517730496454, 162.45390070921985, 175.58156028368793},
		{131.5547169811321, 112.69811320754717, 130.7056603773585},
		{88.89851485148515, 148.70792079207922, 134.5049504950495},
		{143.84615384615384, 109.53846153846153, 17.762237762237763},
		{167.60377358490567, 117.54716981132076, 143.46630727762803},
		{194.25925925925927, 201.6, 230.85925925925926},
		{115.74716981132076, 124.69433962264151, 162.64150943396226},
		{207.668, 140.128, 121.744},
		{160.53591160220995, 194.4972375690608, 148.1657458563536},
		{207.92957746478874, 144.8450704225352, 6.633802816901408},
		{121.4125, 175.2825, 141.9875},
		{195.7032640949555, 151.47774480712167, 183.18694362017803},
		{240.88888888888889, 123.51851851851852, 8.222222222222221},
		{29.078624078624077, 24.604422604422606, 29.36855036855037},
		{116.84702549575071, 82.39943342776203, 43.388101983002834},
		{197.4148148148148, 131.92962962962963, 97.75925925925925},
		{131.72660098522167, 185.24384236453201, 243.91871921182266},
		{153.2275, 132.475, 64.045},
		{213.93421052631578, 93.3157894736842, 49.10526315789474},
		{103.50095969289828, 177.42802303262957, 188.23608445297504},
		{185.22, 211.58666666666667, 184.48},
		{51.23348017621145, 155.87224669603523, 162.1850220264317},
		{145.0239651416122, 164.65141612200435, 214.03050108932462},
		{81.65137614678899, 130.76146788990826, 171.30733944954127},
		{101.38534278959811, 201.69267139479905, 239.98581560283688},
		{79.97687861271676, 81.26589595375722, 52.578034682080926},
		{140.84444444444443, 92.8638888888889, 64.29166666666667},
		{115.89268292682927, 142.0341463414634, 196.98536585365855},
		{229.33333333333334, 88.45, 17.9},
		{95.708, 99.916, 117.904},
		{161.18861209964413, 191.53024911032028, 228.14946619217082},
		{23.92207792207792, 118.23376623376623, 88.16883116883118},
		{163.80428134556576, 131.3547400611621, 103.25688073394495},
		{182.1811023622047, 160.4015748031496, 69.74803149606299},
		{89.29338842975207, 131.13223140495867, 100.95867768595042},
		{109.02684563758389, 91.40604026845638, 81.15436241610739},
		{126.46296296296296, 198.7314814814815, 204.43055555555554},
		{199.82222222222222, 213.51111111111112, 126.44444444444444},
		{179.866090712743, 165.3196544276458, 204.78185745140388},
		{25.9375, 95.34375, 56.3125},
		{117.95037220843672, 157.6153846153846, 114.07196029776675},
		{148.38922155688624, 156.20658682634732, 88.22754491017965},
		{197.60377358490567, 135.1438679245283, 150.46226415094338},
		{149.64155844155843, 103.21298701298701, 101.85974025974026},
		{55.15604395604396, 39.54725274725275, 53.56043956043956},
		{217.31292517006804, 187.01360544217687, 167.0204081632653},
		{208.22988505747125, 201.79310344827587, 68.0919540229885},
		{85.32303370786516, 184.89606741573033, 219.48314606741573},
		{109.98581560283688, 160.5531914893617, 225.15602836879432},
		{175.54072398190044, 135.14253393665157, 171.28733031674207},
		{151.20876288659792, 142.99484536082474, 191.1159793814433},
		{121.61656441717791, 135.00306748466258, 83.0521472392638},
		{79.10344827586206, 72.16091954022988, 86.11494252873563},
		{174.70153846153846, 113.02153846153846, 86.27692307692308},
		{96.86695278969957, 165.4656652360515, 164.01931330472104},
		{229.4805194805195, 177.2077922077922, 118.87012987012987},
		{179.20689655172413, 155.49425287356323, 28.436781609195403},
		{181.93973214285714, 119.61383928571429, 121.15625},
		{76.51136363636364, 161.25, 195.2159090909091},
		{188.1042654028436, 164.3649289099526, 135.02843601895734},
		{148.3706896551724, 173.1005747126437, 120.92241379310344},
		{130.56034482758622, 192.39367816091954, 171.1867816091954},
		{31.027397260273972, 127.94520547945206, 130.8082191780822},
		{224.66363636363636, 123.12727272727273, 76.96363636363637},
		{208.98, 101.26, 3.88},
		{176.35197368421052, 171.51973684210526, 103.46381578947368}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<68;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<68;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance69clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.027296218688237905, -0.019885991880530904, -0.0018562990066904094},
		{-0.019885991880530897, 0.04361686470242848, -0.013930569476665404},
		{-0.001856299006690413, -0.013930569476665395, 0.015509370410501301}
	};

	double matrix[69][3][3] =
	{
		{
			{0.0352163477130627, -0.020635953682631707, 3.5573277424386616E-4},
			{-0.020635953682631714, 0.06424109397337363, -0.022740866884433594},
			{3.557327742438705E-4, -0.022740866884433598, 0.030531576659940197}
		},
		{
			{0.027622108224033538, -0.009469837493294213, -0.006832781853021214},
			{-0.009469837493294213, 0.032686941426738905, 0.0014632859834959422},
			{-0.0068327818530212105, 0.0014632859834959387, 0.0140337342227961}
		},
		{
			{0.08285906241535092, -0.03195968121575591, -0.0027977438450652262},
			{-0.03195968121575589, 0.03538744583411587, -0.020659782139452208},
			{-0.002797743845065221, -0.0206597821394522, 0.028841191300280507}
		},
		{
			{0.028593342175894987, -0.018109748442768095, -0.013274854154703792},
			{-0.01810974844276809, 0.054014022750753815, -0.012501585188118},
			{-0.013274854154703798, -0.012501585188117989, 0.023780147737973798}
		},
		{
			{0.003948901973191073, -0.0030170521813937716, 0.002080047505619873},
			{-0.0030170521813937647, 0.06582557719903143, -0.04426026096189828},
			{0.002080047505619866, -0.04426026096189831, 0.051470460108605086}
		},
		{
			{0.042263282863433504, -0.014158713785756099, -0.010747790492834801},
			{-0.014158713785756099, 0.05323759115620146, -0.009021539129551788},
			{-0.01074779049283481, -0.009021539129551791, 0.032500986594872015}
		},
		{
			{0.04873510254118424, -0.03700118782979756, 2.617128670308255E-4},
			{-0.03700118782979754, 0.07815525833203647, -0.017401431095081996},
			{2.61712867030822E-4, -0.01740143109508201, 0.016343000087531104}
		},
		{
			{0.012060813355390925, -0.012036754747029827, 0.003909017653749141},
			{-0.012036754747029827, 0.05682807611744717, -0.030413831864902496},
			{0.003909017653749139, -0.030413831864902503, 0.0312664421755418}
		},
		{
			{0.05989034543386395, -0.035910499790471964, -0.015353114804468382},
			{-0.03591049979047194, 0.10002652219787395, -0.004889499459584076},
			{-0.015353114804468382, -0.004889499459584066, 0.014407399093260794}
		},
		{
			{0.013916179178757017, -0.021504838896206045, 0.011557283908388737},
			{-0.021504838896206024, 0.07507457183546887, -0.05458397054871795},
			{0.011557283908388716, -0.05458397054871795, 0.058592023394185934}
		},
		{
			{0.049211058323676116, -0.04824408249240864, -0.0011701646457128317},
			{-0.04824408249240866, 0.11480240805955294, -0.0483720599241729},
			{-0.0011701646457128352, -0.04837205992417287, 0.05838374492401692}
		},
		{
			{0.058629485314486585, -0.014778694946251114, -0.013277142217785195},
			{-0.014778694946251105, 0.056336890743658705, 0.0040017187304699255},
			{-0.013277142217785193, 0.004001718730469917, 0.0159887953397614}
		},
		{
			{0.046993197776995725, 0.011926488490658508, -0.011083633273574062},
			{0.01192648849065851, 0.023527871135326256, 0.005164644730118026},
			{-0.01108363327357407, 0.005164644730118032, 0.005718464575612619}
		},
		{
			{0.04753378732748538, -0.0270373114110591, -0.011260297161910102},
			{-0.0270373114110591, 0.032969033951725006, 0.005488991355279987},
			{-0.011260297161910102, 0.0054889913552799855, 0.010700677185620896}
		},
		{
			{0.020512886157056195, 0.002998231812591208, -0.00635566552652359},
			{0.00299823181259121, 0.014672708298813404, 0.0027897523568994574},
			{-0.0063556655265235885, 0.0027897523568994574, 0.00774010211571354}
		},
		{
			{0.06219323449657675, -0.03582974240053934, -3.503329437980489E-4},
			{-0.0358297424005393, 0.07386074146455647, -0.026805155119358704},
			{-3.5033294379805237E-4, -0.0268051551193587, 0.034342208251666}
		},
		{
			{0.05651873238590792, -0.021860619354690813, 0.0034342920319972037},
			{-0.021860619354690813, 0.026276052841004403, 9.277648872861493E-4},
			{0.0034342920319972037, 9.277648872861484E-4, 0.017609000383833492}
		},
		{
			{0.004165021080971356, -0.00835952654531629, 0.003047546454164073},
			{-0.008359526545316267, 0.0685474016788857, -0.03955650754706098},
			{0.0030475464541640583, -0.039556507547060984, 0.05083218729241928}
		},
		{
			{0.05997915905216392, -0.03640926616535266, -0.004514638590656518},
			{-0.03640926616535263, 0.07990489434664871, -0.03753952970185068},
			{-0.004514638590656504, -0.037539529701850684, 0.04840378414419102}
		},
		{
			{0.131453492935974, -0.12367591964252399, -0.029630375153609605},
			{-0.12367591964252396, 0.13318359300830596, 0.008708948169056535},
			{-0.029630375153609598, 0.00870894816905654, 0.0320522508987983}
		},
		{
			{0.018833165155813292, -0.005940058774897842, -0.00562440884072357},
			{-0.005940058774897843, 0.027823255763089416, -0.008362508185785598},
			{-0.00562440884072357, -0.00836250818578559, 0.019591722472699195}
		},
		{
			{0.08744359606751355, -0.07100539213326228, 0.017611733237596152},
			{-0.07100539213326221, 0.14607116631322295, -0.046829001484296015},
			{0.01761173323759613, -0.04682900148429602, 0.07222528883781461}
		},
		{
			{0.024349544306239163, -0.01518259239229278, -7.285423134573577E-4},
			{-0.01518259239229278, 0.02471181709777907, -0.0033861696959663666},
			{-7.285423134573569E-4, -0.0033861696959663666, 0.020053821137138893}
		},
		{
			{0.05912353498639651, -0.013538242242322729, -0.013736860055134015},
			{-0.013538242242322725, 0.044527096950632145, -0.009888060177404926},
			{-0.013736860055134009, -0.009888060177404925, 0.02743971458307343}
		},
		{
			{0.02262352966506112, -0.00953078283603822, -0.007265009680058618},
			{-0.00953078283603822, 0.02516692126008333, -0.004327851822192508},
			{-0.007265009680058617, -0.004327851822192513, 0.0197119361325359}
		},
		{
			{0.012711832646274804, 2.630576208386493E-4, -0.013068076566365506},
			{2.630576208386467E-4, 0.022405280634243102, -0.007149486316755292},
			{-0.013068076566365504, -0.0071494863167552965, 0.019744587577917007}
		},
		{
			{0.05769738847787738, -0.058241679082426084, -0.002995324139487606},
			{-0.058241679082426084, 0.1499493308185699, -0.031881956697611485},
			{-0.002995324139487599, -0.03188195669761149, 0.05354453989359392}
		},
		{
			{0.015450861583864207, -0.00505934483038324, -0.012267911453118303},
			{-0.0050593448303832365, 0.03091818248490489, -0.014070288006729194},
			{-0.012267911453118303, -0.014070288006729194, 0.02672159233667331}
		},
		{
			{0.04279671247589872, -0.026182781825124412, 0.0026337048643994},
			{-0.026182781825124426, 0.07374532438665853, -0.03451235966842844},
			{0.002633704864399405, -0.03451235966842844, 0.04294805875435043}
		},
		{
			{0.045906258667049366, -0.05567018008520023, 0.023774145099439543},
			{-0.05567018008520026, 0.15389175688780404, -0.09505000086397315},
			{0.02377414509943956, -0.09505000086397318, 0.11631527030782195}
		},
		{
			{0.04610869354447289, -0.013030782897334192, -0.027318439743222067},
			{-0.013030782897334194, 0.0421583474939892, -0.012730521442447087},
			{-0.027318439743222078, -0.012730521442447084, 0.04298081843623307}
		},
		{
			{0.045560030476752035, -0.010457168488478713, -0.0159174963647042},
			{-0.010457168488478712, 0.08841822919013764, -0.011202470406761986},
			{-0.0159174963647042, -0.011202470406762002, 0.012199088858088698}
		},
		{
			{0.07325999540482207, -0.053269856900264326, 0.018855358565387993},
			{-0.0532698569002643, 0.08828010312135598, -0.03180109407071622},
			{0.01885535856538799, -0.03180109407071622, 0.021675084500759504}
		},
		{
			{0.043162115849383585, -0.03683992512428278, -2.5107102159189695E-4},
			{-0.036839925124282795, 0.06097318792807265, -0.014811374370463693},
			{-2.5107102159189695E-4, -0.014811374370463686, 0.023015962120967196}
		},
		{
			{0.07712977950674312, -0.034102344172207595, 0.005252764596603081},
			{-0.03410234417220763, 0.08526228567716755, -0.013994387094173716},
			{0.005252764596603084, -0.013994387094173714, 0.0217106693386766}
		},
		{
			{0.05739292273636433, -0.02606558992990183, -0.004087986351807784},
			{-0.02606558992990184, 0.08814073474953306, -0.0054605545909624095},
			{-0.004087986351807784, -0.0054605545909624156, 0.025128282018363098}
		},
		{
			{0.019945341982904215, -0.007482577707903185, -0.001354657903356287},
			{-0.00748257770790318, 0.053880550025954904, -0.030388475243492908},
			{-0.0013546579033562878, -0.030388475243492908, 0.034793731359463204}
		},
		{
			{0.02352796829477587, -0.015697336857435146, 0.002430396046336036},
			{-0.01569733685743515, 0.06591228984295268, -0.04806671508307451},
			{0.0024303960463360327, -0.048066715083074515, 0.04993713207225631}
		},
		{
			{0.06451060346026127, -0.015724969517382607, 0.0032168252231215178},
			{-0.01572496951738262, 0.024395362301059126, -0.006384695391195896},
			{0.0032168252231215204, -0.006384695391195894, 0.008192738297167499}
		},
		{
			{0.10989352418785593, -0.07022300761485098, 0.0029836823453377294},
			{-0.07022300761485097, 0.174460301735619, 0.0034038178855833406},
			{0.0029836823453377307, 0.0034038178855833445, 0.010040895440387098}
		},
		{
			{0.027750820510658747, -0.027637844958297134, 0.005389690780076234},
			{-0.027637844958297127, 0.11649991329831996, -0.04434711178392608},
			{0.005389690780076235, -0.044347111783926085, 0.0327533544562362}
		},
		{
			{0.07325479645106638, -0.03303675926053009, -0.021110389275099593},
			{-0.03303675926053008, 0.03577217281162088, -0.0014281046226409261},
			{-0.02111038927509959, -0.0014281046226409244, 0.035076704673124}
		},
		{
			{0.047614285525196996, -0.0411950876844637, -0.0075265986995981075},
			{-0.0411950876844637, 0.07964092939614187, -0.020959501107898307},
			{-0.007526598699598097, -0.02095950110789831, 0.04360439642256532}
		},
		{
			{0.17507317317686982, -0.039527364779453775, -0.07806131362734886},
			{-0.03952736477945373, 0.11783630580651397, 0.01618178622179637},
			{-0.07806131362734882, 0.01618178622179633, 0.09371032391576069}
		},
		{
			{0.022173873124857506, -0.0034128616443452574, -0.018123249400414196},
			{-0.003412861644345266, 0.046483946098929904, -0.0159815090049274},
			{-0.018123249400414192, -0.01598150900492741, 0.03852113296188087}
		},
		{
			{0.024191743187867473, -0.005302268305129148, -0.013958593449407497},
			{-0.005302268305129148, 0.031213987396079695, -0.009926357542448071},
			{-0.0139585934494075, -0.009926357542448066, 0.022014871482801603}
		},
		{
			{0.05891405718268667, -0.057406088490177413, 0.033324185748135726},
			{-0.05740608849017745, 0.2809356486457126, -0.020932771531470308},
			{0.03332418574813576, -0.02093277153147033, 0.019441231347938334}
		},
		{
			{0.06962857271774517, -0.041343244700560375, -0.017734747990111408},
			{-0.04134324470056039, 0.08171242927541064, -0.015914542344273985},
			{-0.017734747990111398, -0.015914542344273988, 0.045329786540781805}
		},
		{
			{0.10499204780484794, -0.0074994296805613245, -0.04113231853638667},
			{-0.007499429680561352, 0.08861742300380707, -0.03232007530920447},
			{-0.041132318536386686, -0.03232007530920451, 0.08602355874316994}
		},
		{
			{0.09844012922929325, -0.028823239818733574, 0.008957108834372892},
			{-0.028823239818733585, 0.040696182699721986, -0.014137429948237584},
			{0.008957108834372892, -0.014137429948237589, 0.034687690474440584}
		},
		{
			{0.10093096961238794, -0.01513748509870768, 7.193105491969842E-4},
			{-0.01513748509870768, 0.07194132616749263, 0.01390089785591},
			{7.193105491969846E-4, 0.013900897855909991, 0.021071017899393602}
		},
		{
			{0.03464621798728412, -0.01028078199153751, -0.004082474037403692},
			{-0.010280781991537511, 0.05656823441573731, -0.034804631131680204},
			{-0.004082474037403689, -0.034804631131680204, 0.04113254279882918}
		},
		{
			{0.112489479972579, -0.05801689409788498, -0.018400931013534204},
			{-0.058016894097884956, 0.09424488103534863, -0.022981486236582405},
			{-0.018400931013534204, -0.022981486236582423, 0.03437239409487399}
		},
		{
			{0.005395369300555075, 0.006899490625394153, -0.009885708880490233},
			{0.0068994906253941534, 0.028210957188495436, -0.021457019896615522},
			{-0.009885708880490231, -0.021457019896615522, 0.025199123359751215}
		},
		{
			{0.03528899127566299, -0.013829060428932309, -0.006300169818503139},
			{-0.013829060428932307, 0.04226153734900206, -0.005849278331035008},
			{-0.006300169818503133, -0.0058492783310350035, 0.014450414920098398}
		},
		{
			{0.017488815723830712, -0.00244725319954262, -0.009447755456575772},
			{-0.0024472531995426107, 0.02319763250234889, -0.006221795206851717},
			{-0.009447755456575776, -0.006221795206851712, 0.020533114252405497}
		},
		{
			{0.029820204132426274, -0.02439902364137209, 0.002364959274954509},
			{-0.024399023641372097, 0.05025022559888022, -0.011686130039517198},
			{0.002364959274954508, -0.011686130039517198, 0.012658602590368096}
		},
		{
			{0.0375422233172276, -0.013153187435437887, -4.55087598061978E-4},
			{-0.013153187435437886, 0.078791751757379, 0.0013572069369488292},
			{-4.5508759806197783E-4, 0.0013572069369488294, 0.022220921020703}
		},
		{
			{0.030897386049636294, -0.006497017661896037, -0.004736039779032194},
			{-0.006497017661896046, 0.04086335763704049, -0.01646447875365939},
			{-0.004736039779032197, -0.016464478753659403, 0.025920194594927996}
		},
		{
			{0.024992674488746997, -0.01110409403418551, -0.004915209760582407},
			{-0.011104094034185502, 0.03496695539891518, -0.01721058063245389},
			{-0.004915209760582404, -0.017210580632453898, 0.029892453428453508}
		},
		{
			{0.0386714811703683, 0.02294821035647279, 0.0067001496506074384},
			{0.022948210356472796, 0.22799064284475218, -0.024398972214455552},
			{0.006700149650607426, -0.02439897221445554, 0.0049166346411122774}
		},
		{
			{0.04115013486534879, -0.008661078233823305, -0.0034922899576847475},
			{-0.008661078233823309, 0.0409026865112355, -0.0053656958603916114},
			{-0.00349228995768475, -0.0053656958603916114, 0.0109362209060656}
		},
		{
			{0.023057600754074124, 6.780326608967831E-4, -0.006326808074478456},
			{6.780326608967796E-4, 0.03846825037225434, -0.02549133388148384},
			{-0.006326808074478456, -0.025491333881483842, 0.03178670997828762}
		},
		{
			{0.07405248600841038, -0.07491628461434777, 0.017606573718605655},
			{-0.0749162846143478, 0.14870582023667417, -0.0847448128196077},
			{0.01760657371860567, -0.0847448128196077, 0.07826872882328989}
		},
		{
			{0.11504492203190592, -0.05683204213663669, 0.007421978820911175},
			{-0.056832042136636673, 0.057706231070233635, -0.01804301060160522},
			{0.007421978820911175, -0.01804301060160522, 0.015853822869810612}
		},
		{
			{0.04188462195746672, -0.007514146972465177, -0.019728560099711096},
			{-0.007514146972465174, 0.07417278890347612, -0.03311379139439881},
			{-0.0197285600997111, -0.03311379139439881, 0.04656552616595939}
		},
		{
			{0.02570925766537049, -0.025157078650267582, 0.0021616877068186286},
			{-0.025157078650267586, 0.06185388174055131, -0.0036667090530659485},
			{0.0021616877068186277, -0.003666709053065947, 0.002457655979832809}
		},
		{
			{0.08305357577183092, -0.027916141595187852, -0.06407211351743303},
			{-0.02791614159518786, 0.07935687494646579, 0.025800705131352988},
			{-0.06407211351743305, 0.025800705131352995, 0.060370989264389885}
		},
		{
			{0.0733747164564428, -0.05877785096997146, -0.0055346255348889635},
			{-0.058777850969971436, 0.11721505849760389, -0.03509354572107529},
			{-0.005534625534888961, -0.035093545721075294, 0.0421370155935096}
		}
	};

	double barycentre[69][3] =
	{
		{151.8523676880223, 104.2284122562674, 99.34540389972145},
		{184.86328125, 162.99609375, 71.48828125},
		{224.6086956521739, 123.74782608695652, 78.32173913043478},
		{94.6260162601626, 126.95934959349593, 89.97967479674797},
		{29.59259259259259, 129.4814814814815, 134.55555555555554},
		{175.5896805896806, 130.05405405405406, 163.5921375921376},
		{163.1238095238095, 133.08253968253968, 100.77142857142857},
		{85.91232876712328, 183.2164383561644, 217.6054794520548},
		{126.87378640776699, 147.09466019417476, 199.16990291262135},
		{99.3075, 201.865, 239.96},
		{144.63125, 170.040625, 230.421875},
		{76.58528428093645, 79.45150501672241, 52.77591973244147},
		{224.6, 198.01666666666668, 8.65},
		{184.67307692307693, 206.66666666666666, 140.55128205128204},
		{196.90322580645162, 150.36290322580646, 12.709677419354838},
		{200.48985507246377, 135.7391304347826, 107.3623188405797},
		{218.77173913043478, 91.01086956521739, 44.44565217391305},
		{9.890322580645162, 162.18064516129033, 174.6451612903226},
		{202.35256410256412, 141.09294871794873, 159.59615384615384},
		{185.3840579710145, 212.07246376811594, 185.47826086956522},
		{88.48031496062993, 143.91863517060366, 129.3727034120735},
		{184.65829145728642, 199.55276381909547, 232.53266331658293},
		{150.78353658536585, 161.40548780487805, 96.21646341463415},
		{140.31699346405227, 126.08823529411765, 157.11111111111111},
		{128.06686930091186, 139.57142857142858, 83.38601823708207},
		{112.99488491048594, 172.5473145780051, 143.72634271099744},
		{149.40983606557376, 197.56967213114754, 213.0860655737705},
		{134.06738544474393, 193.03773584905662, 168.92722371967656},
		{194.13350785340313, 128.3848167539267, 134.47905759162305},
		{130.0, 191.48093841642228, 244.48093841642228},
		{187.5310559006211, 169.09937888198758, 208.53416149068323},
		{153.40978593272172, 137.0886850152905, 184.1987767584098},
		{190.5767634854772, 160.92946058091286, 133.9668049792531},
		{149.66118421052633, 111.15131578947368, 65.35197368421052},
		{110.98684210526316, 161.9, 228.72105263157894},
		{121.86842105263158, 70.46052631578948, 35.828947368421055},
		{120.14043583535108, 195.31961259079904, 203.62469733656175},
		{68.5425101214575, 165.53846153846155, 191.31578947368422},
		{208.32038834951456, 202.9902912621359, 78.64077669902913},
		{115.5, 93.01315789473684, 95.25877192982456},
		{68.85798816568047, 133.698224852071, 170.77514792899407},
		{222.8728813559322, 102.7457627118644, 7.237288135593221},
		{181.82474226804123, 118.20618556701031, 83.69072164948453},
		{22.315555555555555, 20.288888888888888, 25.23111111111111},
		{163.73760932944606, 116.09912536443149, 141.2798833819242},
		{118.16957605985037, 157.05236907730674, 113.50623441396509},
		{89.44041450777202, 100.93782383419689, 118.81347150259067},
		{95.21016949152542, 144.72881355932202, 200.51525423728813},
		{37.19798657718121, 37.16778523489933, 44.211409395973156},
		{127.89682539682539, 111.98412698412699, 128.87301587301587},
		{81.97050938337802, 73.69973190348526, 85.64879356568365},
		{175.61256544502618, 114.73821989528795, 114.65183246073299},
		{216.76223776223776, 188.08391608391608, 167.93006993006992},
		{58.45977011494253, 159.867816091954, 151.98275862068965},
		{172.5016077170418, 174.6816720257235, 108.53376205787781},
		{142.86522911051213, 177.3989218328841, 132.32075471698113},
		{156.76347305389223, 142.374251497006, 62.6437125748503},
		{132.8047138047138, 84.17171717171718, 64.28956228956228},
		{95.01946472019465, 161.82968369829683, 164.54014598540147},
		{103.04190476190476, 176.88190476190476, 185.11619047619047},
		{59.74285714285714, 21.228571428571428, 19.771428571428572},
		{106.61278195488721, 95.22932330827068, 51.12781954887218},
		{24.102040816326532, 114.60204081632654, 82.44897959183673},
		{158.0078125, 160.83072916666666, 205.3203125},
		{226.72549019607843, 170.15686274509804, 121.09803921568627},
		{185.4340909090909, 150.42727272727274, 184.87272727272727},
		{143.25174825174824, 110.48251748251748, 17.832167832167833},
		{61.048780487804876, 41.613240418118465, 60.254355400696866},
		{107.49612403100775, 124.12790697674419, 166.31007751937983}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<69;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<69;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

double distance70clusters(double RGB1[3], double RGB2[3]){
	double matrixRGBu[3][3]=
	{
		{0.026442805384084465, -0.01936138387574668, -0.002050640723154965},
		{-0.019361383875746683, 0.04280898632389261, -0.0135278818135233},
		{-0.002050640723154965, -0.013527881813523306, 0.015370185012974802}
	};

	double matrix[70][3][3] =
	{
		{
			{0.05455571636470976, -0.025367128183748477, -0.0016192554533216634},
			{-0.025367128183748484, 0.027181435118273683, -0.008330978320075615},
			{-0.0016192554533216662, -0.008330978320075618, 0.016315315261402206}
		},
		{
			{0.04797638466560517, -0.02183784242292177, -0.005873979737852226},
			{-0.021837842422921788, 0.07366676944826549, -0.01375079451601861},
			{-0.005873979737852219, -0.013750794516018593, 0.024983355218392796}
		},
		{
			{0.027795815422569797, -0.005587797699577684, -0.005633347870222475},
			{-0.005587797699577684, 0.039939848517782574, -0.015441991756309713},
			{-0.005633347870222475, -0.015441991756309715, 0.030702307309012702}
		},
		{
			{0.07331947744124424, -0.0358373051068093, -0.022158254405357694},
			{-0.03583730510680929, 0.04100639982720121, 0.0033126900904115394},
			{-0.022158254405357687, 0.0033126900904115325, 0.027582388376655793}
		},
		{
			{0.0678452876479868, 0.09677434790005975, -0.06582351484475141},
			{0.0967743479000598, 0.374164225698192, -0.21476601238245038},
			{-0.06582351484475148, -0.21476601238245055, 0.12573962744183276}
		},
		{
			{0.08120060706915797, -0.027522500898627764, -0.061062025742001313},
			{-0.027522500898627712, 0.08478670691944445, 0.03533859634906293},
			{-0.061062025742001286, 0.03533859634906291, 0.05940888845159881}
		},
		{
			{0.042809972413854584, -0.029598940836890887, -0.007724068249950556},
			{-0.029598940836890894, 0.09025687574595946, -0.0265809682434711},
			{-0.007724068249950558, -0.02658096824347108, 0.026206399613482704}
		},
		{
			{0.04596737707137822, 0.011022655875653656, -0.01081607949621918},
			{0.011022655875653665, 0.024065089683752552, 0.005108352653486647},
			{-0.010816079496219188, 0.005108352653486643, 0.005314155574411958}
		},
		{
			{0.038614855396375054, -0.014249021598950324, -0.004132275421065802},
			{-0.014249021598950378, 0.31123246095719603, -0.041479919041297504},
			{-0.004132275421065801, -0.041479919041297504, 0.006486525674364103}
		},
		{
			{0.08018747709747394, -0.05958168988486206, 0.012304612277146784},
			{-0.059581689884862045, 0.1317975764576039, -0.032143855671721094},
			{0.01230461227714678, -0.032143855671721074, 0.06036829840210049}
		},
		{
			{0.01505301785359992, 0.0024840765310340024, -0.01385103042500342},
			{0.0024840765310340015, 0.018152933284752284, -0.010906718439375487},
			{-0.013851030425003416, -0.01090671843937548, 0.0258619926912521}
		},
		{
			{0.06848227209496868, -0.005337383532462419, -0.0010518421317445648},
			{-0.0053373835324624225, 0.04913395806107826, -0.019250621527920685},
			{-0.0010518421317445648, -0.01925062152792069, 0.00937611420644428}
		},
		{
			{0.020374557138225717, -0.018602154202033525, 0.007701537955233622},
			{-0.01860215420203353, 0.07260651510940544, -0.05424575285750233},
			{0.007701537955233625, -0.05424575285750231, 0.05564838860730691}
		},
		{
			{0.0669916704347177, -0.07448711478976468, 0.008909790405292224},
			{-0.07448711478976469, 0.14973448597307487, -0.03986713475470489},
			{0.008909790405292224, -0.03986713475470489, 0.02835261419419669}
		},
		{
			{0.023112031498483787, -0.009931967240966429, -0.008119814556300169},
			{-0.00993196724096643, 0.0246816161971599, -0.003533531455831981},
			{-0.008119814556300172, -0.0035335314558319827, 0.021313941664451698}
		},
		{
			{0.04831380761307019, -0.018885225671599004, -0.023981645386476486},
			{-0.018885225671599018, 0.047141663899649834, -0.02198688993038491},
			{-0.0239816453864765, -0.021986889930384914, 0.05182631954015471}
		},
		{
			{0.23527755568931558, -0.05257290349477352, -0.12747105580431115},
			{-0.05257290349477347, 0.01308391029155448, 0.02499503770676288},
			{-0.1274710558043111, 0.024995037706762886, 0.07816809284442991}
		},
		{
			{0.10815395071044517, -0.0627937414365707, -0.021681419645477228},
			{-0.06279374143657065, 0.09258396736928305, -0.0220687491193114},
			{-0.021681419645477228, -0.0220687491193114, 0.03566523009517224}
		},
		{
			{0.09967725520160742, -0.0057909099730543215, -0.04202272639088451},
			{-0.005790909973054308, 0.08376435277071409, -0.028921730142438692},
			{-0.04202272639088453, -0.028921730142438703, 0.09361146405192465}
		},
		{
			{0.12949631849266197, -0.04031980431528529, -0.023228638217264085},
			{-0.0403198043152853, 0.040471922985349115, 0.00941639658760473},
			{-0.02322863821726409, 0.009416396587604734, 0.025280999999953}
		},
		{
			{0.0024049082862889898, -0.0011587559068358371, 7.745765773884902E-5},
			{-0.0011587559068358545, 0.08377924803928086, -0.035430939829812},
			{7.74576577388603E-5, -0.035430939829812, 0.0452275307849231}
		},
		{
			{0.062103265585789914, -0.07856077255567573, 0.027874293547276604},
			{-0.07856077255567571, 0.3475505732042709, -0.00413475401100546},
			{0.027874293547276607, -0.004134754011005428, 0.01727548929482401}
		},
		{
			{0.0436865222009557, -0.041521133920333825, -0.003835840796835358},
			{-0.041521133920333825, 0.11989053014248108, -0.02571317760120222},
			{-0.00383584079683536, -0.025713177601202217, 0.017339093691479797}
		},
		{
			{0.018762556880491613, -0.008013816395408484, 2.3732483743711154E-4},
			{-0.008013816395408489, 0.06784134477824227, -0.03473276913433646},
			{2.37324837437115E-4, -0.03473276913433646, 0.036350960502322775}
		},
		{
			{0.026557669734998294, -0.017198379875187287, -8.640567453497947E-4},
			{-0.017198379875187287, 0.025120885220191073, -0.0033630595111390662},
			{-8.64056745349796E-4, -0.003363059511139066, 0.0199223689167693}
		},
		{
			{0.02537043698601301, -0.005811864486444314, -0.012996148245184792},
			{-0.005811864486444315, 0.03183695869926521, -0.009241503161731682},
			{-0.012996148245184799, -0.009241503161731675, 0.02104714122729219}
		},
		{
			{0.051287606652777804, -0.033071791320572676, -2.917101424509275E-4},
			{-0.03307179132057268, 0.09062542689094207, -0.048064353828677076},
			{-2.9171014245093704E-4, -0.04806435382867706, 0.04608372807562218}
		},
		{
			{0.046394408962222806, -0.03961418598071325, 0.0038726896575833358},
			{-0.03961418598071325, 0.08387966264910683, -0.022690572942407915},
			{0.0038726896575833384, -0.022690572942407925, 0.019173561345102806}
		},
		{
			{0.013569556193112696, -0.014226271184027086, 0.0025786287058872435},
			{-0.014226271184027086, 0.0590147798732157, -0.027988180283652304},
			{0.002578628705887244, -0.027988180283652297, 0.0258728722833369}
		},
		{
			{0.04677378134772069, -0.028094965651497, -4.768436695813086E-4},
			{-0.028094965651496995, 0.06818289352288807, -0.0314180196742987},
			{-4.7684366958130556E-4, -0.031418019674298706, 0.03519284352026511}
		},
		{
			{0.015136027730633484, -0.0023719320948203306, -0.006665777396529371},
			{-0.00237193209482033, 0.040999260591306284, -0.0149486964897547},
			{-0.006665777396529371, -0.0149486964897547, 0.03135484272497291}
		},
		{
			{0.09392273111283939, -0.013337136615156729, -0.0020298535282576666},
			{-0.013337136615156736, 0.07217169558268074, 0.0136253892990278},
			{-0.0020298535282576666, 0.0136253892990278, 0.018306859501417604}
		},
		{
			{0.020820665446764097, -0.013817360209658704, 0.00723019362366211},
			{-0.013817360209658704, 0.038173941458015295, -0.016305310917876292},
			{0.007230193623662109, -0.01630531091787629, 0.022122888536076992}
		},
		{
			{0.018064799570973195, -0.0016653089024664582, -0.01345155634877059},
			{-0.0016653089024664548, 0.026308857239052904, -0.011214286073388707},
			{-0.013451556348770592, -0.011214286073388705, 0.030206280110635392}
		},
		{
			{0.00613691483942674, -0.00839307138583122, 0.008229036166119906},
			{-0.008393071385831227, 0.03846010122443551, -0.025902548692515508},
			{0.008229036166119913, -0.025902548692515508, 0.03196987454366631}
		},
		{
			{0.022881521000414105, -0.00674891142730833, -0.013757640031675704},
			{-0.006748911427308333, 0.018668503036239993, -7.761608935571004E-4},
			{-0.0137576400316757, -7.761608935571039E-4, 0.015655617430767498}
		},
		{
			{0.05376985736550134, -0.008485531828459505, -0.011787766032732211},
			{-0.008485531828459507, 0.046620644040708085, 0.007244189172064238},
			{-0.011787766032732211, 0.007244189172064233, 0.0176859959772067}
		},
		{
			{0.0589156095959591, -0.03734111151140489, 9.739173242521021E-4},
			{-0.03734111151140488, 0.07853017082738524, -0.034379133726063306},
			{9.739173242521012E-4, -0.034379133726063306, 0.04001906048856971}
		},
		{
			{0.06758402566630033, -0.02905177726182628, -0.001227447432797582},
			{-0.029051777261826284, 0.0522694731878072, -0.017488979814576304},
			{-0.001227447432797582, -0.017488979814576297, 0.05650936639650091}
		},
		{
			{0.00710574778694973, 0.004671678704734202, -0.008996980331680863},
			{0.004671678704734209, 0.03198301147382767, -0.024163011895163983},
			{-0.008996980331680877, -0.024163011895163976, 0.027846992507123684}
		},
		{
			{0.27189227605379807, -0.09689548331646798, -0.1150796942289721},
			{-0.09689548331646797, 0.14005250368741898, 0.04313680961430587},
			{-0.11507969422897207, 0.04313680961430586, 0.10100449301717998}
		},
		{
			{0.0038135764355707543, -0.009608452353872575, 0.002070589971581412},
			{-0.009608452353872587, 0.06849431757243864, -0.042624285954414476},
			{0.002070589971581418, -0.042624285954414455, 0.05036053543755796}
		},
		{
			{0.021671190967490733, -0.019548418950462745, 1.709867791330482E-4},
			{-0.01954841895046273, 0.05807369291751287, -0.006936655319219129},
			{1.7098677913304598E-4, -0.006936655319219127, 0.0039014998326708595}
		},
		{
			{0.015440104975451494, 4.0177081711729903E-4, -0.010161272145689995},
			{4.0177081711729947E-4, 0.012388805938235404, -0.001102881155691593},
			{-0.01016127214569, -0.001102881155691598, 0.019073568274489697}
		},
		{
			{0.04989012247989868, -0.02117282897506271, -0.028493257775081732},
			{-0.021172828975062733, 0.07231262539878698, -0.0502682287691643},
			{-0.02849325777508175, -0.05026822876916431, 0.1569268244140791}
		},
		{
			{0.019146363694691092, 0.00211182743717525, -0.006462499760098758},
			{0.002111827437175247, 0.0146659594549477, 0.003688971235821204},
			{-0.006462499760098756, 0.003688971235821206, 0.008814384335001164}
		},
		{
			{0.04552172265628523, -0.009087406101927816, -0.017689102064048928},
			{-0.009087406101927827, 0.07536692557571782, -0.03922005653648657},
			{-0.01768910206404893, -0.039220056536486594, 0.05094257378871184}
		},
		{
			{0.021491224676136872, -0.0013630482022639681, -0.009870314685945557},
			{-0.0013630482022639703, 0.055966084931618705, -0.010613860186810091},
			{-0.009870314685945566, -0.010613860186810084, 0.026150547287101807}
		},
		{
			{0.023038834780633805, 0.009752814935099446, -0.00802889529940715},
			{0.009752814935099451, 0.02151259762300562, 0.00328074313065555},
			{-0.008028895299407156, 0.003280743130655547, 0.0064969675420300625}
		},
		{
			{0.034013424905873384, -0.02570317396280278, 0.004701230832283983},
			{-0.025703173962802795, 0.049883027008556693, -0.007651786553508605},
			{0.004701230832283987, -0.0076517865535086025, 0.012467738426198298}
		},
		{
			{0.04076569611796849, -0.026818424767329315, -0.001164292178385904},
			{-0.0268184247673293, 0.05343769702990732, -0.022675411134286307},
			{-0.001164292178385902, -0.02267541113428631, 0.034873346986740196}
		},
		{
			{0.03430241963552841, -0.024535653534357403, 9.14876425967418E-4},
			{-0.024535653534357396, 0.04806175203150291, -0.0137524399986066},
			{9.148764259674198E-4, -0.0137524399986066, 0.0133420914730336}
		},
		{
			{0.03547977805661242, -0.01686932313759048, 1.2999196353536725E-4},
			{-0.0168693231375905, 0.07149532971596871, -0.02467907366089669},
			{1.2999196353537246E-4, -0.02467907366089668, 0.031066619757550883}
		},
		{
			{0.045360399661360164, -0.02015550286173026, -0.0015950785709967132},
			{-0.02015550286173024, 0.07487152520627789, -0.009395650610016147},
			{-0.0015950785709967124, -0.009395650610016154, 0.02512807545717721}
		},
		{
			{0.16082516901938784, -0.17105834842883483, -0.03395842083807749},
			{-0.17105834842883477, 0.19257388335514078, 0.019769242821682485},
			{-0.033958420838077485, 0.019769242821682475, 0.03422513164711109}
		},
		{
			{0.05680931331645665, -0.04204240938717386, -0.008882331164809461},
			{-0.042042409387173844, 0.10552777786498403, -0.010963659717783007},
			{-0.00888233116480946, -0.010963659717783004, 0.010874586332742804}
		},
		{
			{0.0613815184580942, -0.032756155797789115, -0.011031290250241903},
			{-0.03275615579778912, 0.05567141666154093, 0.006514837648802789},
			{-0.011031290250241904, 0.006514837648802784, 0.007604731188262022}
		},
		{
			{0.030177562292285555, -0.018545405662460088, -0.013702723507197374},
			{-0.018545405662460088, 0.04497850388371402, -0.008584184398126055},
			{-0.013702723507197373, -0.008584184398126058, 0.023788748585889107}
		},
		{
			{0.054529644231087665, -0.03376869439646944, -5.874324558009549E-4},
			{-0.033768694396469436, 0.07789311999117918, -0.017665104768693814},
			{-5.874324558009549E-4, -0.017665104768693807, 0.031509464582973504}
		},
		{
			{0.034644158288520716, -0.0066094374315310385, -0.0013047249602680618},
			{-0.0066094374315310315, 0.044710824192512995, -8.992896649376114E-4},
			{-0.0013047249602680627, -8.992896649376123E-4, 0.010201549081940197}
		},
		{
			{0.0783155193112192, -0.04796582152719385, -0.014225425317930102},
			{-0.04796582152719381, 0.10069482024533195, -0.018620138454494395},
			{-0.014225425317930114, -0.0186201384544944, 0.036919049490701294}
		},
		{
			{0.04283129097692201, -0.02600877575343431, 0.0012266601679421455},
			{-0.02600877575343429, 0.07429554898040576, -0.021914771077625808},
			{0.0012266601679421516, -0.02191477107762581, 0.02748734923176531}
		},
		{
			{0.051214958900587304, -0.036068299486951595, -0.006967586473591136},
			{-0.036068299486951574, 0.07429030645257192, -0.021185790794171176},
			{-0.006967586473591143, -0.021185790794171183, 0.041157128801101}
		},
		{
			{0.06383790193316616, -0.021013371536376065, -0.009319430322658096},
			{-0.02101337153637606, 0.05104157735994181, -0.004342603736267226},
			{-0.009319430322658098, -0.004342603736267232, 0.012847229457450905}
		},
		{
			{0.018214845639330082, -0.015492255503708367, 0.0036706994526359183},
			{-0.015492255503708374, 0.05426413749817973, -0.04560138730787058},
			{0.0036706994526359204, -0.0456013873078706, 0.05193424825026796}
		},
		{
			{0.013774455317955606, -6.305666956766005E-4, -0.011328051871549604},
			{-6.305666956766005E-4, 0.025794508326900986, -0.00927842935456789},
			{-0.011328051871549602, -0.00927842935456789, 0.018630108625473797}
		},
		{
			{0.07525452865032331, -0.04591775943804292, -0.010903963947392197},
			{-0.04591775943804288, 0.11129971685799898, -0.0289557370200436},
			{-0.010903963947392197, -0.028955737020043594, 0.0240729197817728}
		},
		{
			{0.04862987824992567, -0.016117610855785502, -0.012997181430611205},
			{-0.016117610855785496, 0.025832124793022604, -0.006524492435597603},
			{-0.0129971814306112, -0.006524492435597605, 0.032951493675504095}
		},
		{
			{0.044214404749134795, -0.030791064156990993, -7.980849374664032E-4},
			{-0.030791064156990993, 0.10145530546839192, 0.0032625930160267175},
			{-7.98084937466403E-4, 0.0032625930160267175, 0.013982122203689103}
		},
		{
			{0.04257949613573405, -0.03083230400149866, -0.0017335672921433218},
			{-0.030832304001498684, 0.07714431155887323, -0.0205034394111854},
			{-0.00173356729214332, -0.020503439411185403, 0.021580703075763902}
		}
	};

	double barycentre[70][3] =
	{
		{219.55555555555554, 103.60317460317461, 57.75396825396825},
		{144.29912023460412, 95.97360703812316, 63.22873900293255},
		{97.19685039370079, 165.53740157480314, 170.81496062992127},
		{223.59701492537314, 98.91791044776119, 10.925373134328359},
		{86.39285714285714, 25.0, 18.678571428571427},
		{62.469565217391306, 40.143478260869564, 53.84782608695652},
		{160.37089201877933, 142.3661971830986, 188.95305164319248},
		{225.37704918032787, 198.04918032786884, 9.59016393442623},
		{43.065934065934066, 20.835164835164836, 22.857142857142858},
		{178.43430656934308, 197.82481751824818, 230.77372262773721},
		{124.04034582132564, 186.76368876080693, 163.64553314121036},
		{229.66265060240963, 185.53012048192772, 85.80722891566265},
		{102.68837209302326, 201.59534883720931, 239.77906976744185},
		{154.19002375296913, 168.0522565320665, 213.41567695961996},
		{126.92705167173253, 139.4012158054711, 84.59878419452887},
		{186.1323155216285, 166.61323155216286, 205.41730279898218},
		{65.18493150684931, 50.5, 83.36986301369863},
		{218.367816091954, 181.4655172413793, 158.683908045977},
		{36.830935251798564, 37.097122302158276, 44.85251798561151},
		{124.58260869565217, 112.63478260869566, 128.06521739130434},
		{34.455555555555556, 125.78888888888889, 113.41111111111111},
		{91.66350710900474, 99.49289099526067, 117.08530805687204},
		{71.91025641025641, 130.3397435897436, 171.01282051282053},
		{131.47848101265822, 200.4354430379747, 204.82025316455696},
		{151.81530343007915, 159.5065963060686, 96.15303430079156},
		{119.68021680216802, 157.20325203252034, 113.37669376693766},
		{198.61670761670763, 137.1130221130221, 148.64864864864865},
		{179.09811320754716, 166.28301886792454, 97.95094339622642},
		{84.99006622516556, 187.96688741721854, 221.99668874172184},
		{181.5785288270378, 123.47514910536779, 121.24850894632206},
		{107.9737532808399, 185.13648293963254, 189.98162729658793},
		{84.34834834834835, 79.47747747747748, 83.73873873873873},
		{87.25506072874494, 144.8744939271255, 144.72874493927125},
		{88.84328358208955, 139.80223880597015, 114.83208955223881},
		{16.5, 108.87878787878788, 75.56060606060606},
		{155.11682242990653, 198.4532710280374, 161.1728971962617},
		{76.98245614035088, 79.19649122807017, 51.27719298245614},
		{208.2754716981132, 144.988679245283, 121.8},
		{124.08602150537635, 163.98387096774192, 219.70698924731184},
		{52.285714285714285, 156.88888888888889, 154.76190476190476},
		{19.70899470899471, 20.666666666666668, 25.544973544973544},
		{6.6938775510204085, 160.14285714285714, 173.2517006802721},
		{145.0, 111.82608695652173, 16.884057971014492},
		{139.93224932249322, 175.9918699186992, 130.31978319783198},
		{135.6340206185567, 187.48711340206185, 243.90463917525773},
		{199.0, 149.23333333333332, 11.016666666666667},
		{190.7759433962264, 148.17216981132074, 179.31367924528303},
		{160.54489164086687, 110.671826625387, 132.61609907120743},
		{184.65656565656565, 188.36363636363637, 63.878787878787875},
		{153.09585492227978, 136.78497409326425, 63.090673575129536},
		{92.98780487804878, 167.10670731707316, 201.7621951219512},
		{184.05045871559633, 150.90366972477065, 67.55963302752293},
		{152.09065934065933, 105.60164835164835, 99.39010989010988},
		{124.03211009174312, 74.11009174311927, 42.38073394495413},
		{191.09876543209876, 209.12962962962962, 185.0},
		{129.2198952879581, 145.44502617801047, 195.67539267015707},
		{197.140350877193, 210.96491228070175, 126.20175438596492},
		{96.19444444444444, 122.64444444444445, 83.7388888888889},
		{202.80887372013652, 127.19112627986348, 97.53242320819113},
		{108.02380952380952, 96.56349206349206, 50.42063492063492},
		{98.17094017094017, 138.5042735042735, 197.68803418803418},
		{170.36886993603412, 119.78251599147121, 91.08528784648188},
		{104.02439024390245, 160.39512195121952, 236.9121951219512},
		{144.2173913043478, 126.3623188405797, 156.95072463768116},
		{63.821596244131456, 164.63849765258215, 190.61971830985917},
		{106.19318181818181, 167.51420454545453, 139.28977272727272},
		{112.5650406504065, 123.15853658536585, 165.08536585365854},
		{174.3747276688453, 127.52505446623094, 160.08932461873638},
		{120.54054054054055, 89.64478764478764, 88.02702702702703},
		{175.9927797833935, 171.65342960288808, 125.61010830324909}
	};

	int min1 = 0;
	double distanceMin1 = euclid(barycentre[min1], RGB1);
	double currentDistance1 = 0;
	for(int i=1;i<70;i++){
		currentDistance1 = euclid(barycentre[i], RGB1);
		if(currentDistance1 < distanceMin1){
			min1 = i;
			distanceMin1 = currentDistance1;
		}
	}

	int min2 = 0;
	double distanceMin2 = euclid(barycentre[min2], RGB2);
	double currentDistance2 = 0;
	for(int i=1;i<70;i++){
		currentDistance2 = euclid(barycentre[i], RGB2);
		if(currentDistance2 < distanceMin2){
			min2 = i;
			distanceMin2 = currentDistance2;
		}
	}

	double distance = 0;
	if(min1 == min2){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrix[min1][i][j];
			}
		}
		distance = sqrt(distance);
	}
	else {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				distance += (RGB1[i] - RGB2[i])*(RGB1[j] - RGB2[j])*matrixRGBu[i][j];
			}
		}
		distance = sqrt(distance);
	}
	return distance;
}

